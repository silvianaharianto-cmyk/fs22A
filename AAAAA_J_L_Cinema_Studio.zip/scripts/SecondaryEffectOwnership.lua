-- One effect owner per vehicle during simultaneous History/Final playback.
-- A take that directly records this vehicle wins over another take's parked
-- background snapshot. Never adds a body/camera writer or changes timestamps.
JLRSSecondaryEffects={owners=setmetatable({},{__mode='k'})}
local E=JLRSSecondaryEffects
local function selected(ch)
    if ch.kind=='allMotor' or ch.kind=='animation' or ch.kind=='tool' or ch.kind=='part' or ch.kind=='rotator' or (ch.kind=='light' and ch.name=='beaconLightsActive')then return true end
    return ch.kind=='custom' and (ch.getter=='jlrsStrobe' or ch.getter=='jlrsSuspension' or ch.getter=='jlrsTireColor' or ch.getter=='jlrsWheelSteering' or ch.getter=='jlrsTensionBelt' or ch.getter=='jlrsVehicleDirt' or ch.getter=='jlrsVehicleParticles'
        or (ch.getter or ''):match('^jlrsInstantEffects_'))
end
local function priority(track,v)
    if track.target==v then return 2 end
    for _,car in ipairs(track.recordVehicles or {})do if car==v then return 2 end end
    return 1
end
local apply=JLRSActivities.apply
JLRSActivities.apply=function(ch,v,values,state,paused,restoring)
    local track=E.track
    if not selected(ch)or not track or not v then return apply(ch,v,values,state,paused,restoring)end
    local owner=E.owners[v]
    if restoring then
        if owner and owner.track~=track and owner.track.replaying then return end
        return apply(ch,v,values,state,paused,restoring)
    end
    local rank=priority(track,v)
    if owner and owner.track~=track and owner.track.replaying and owner.rank>=rank then return end
    if not owner or owner.track~=track then owner={track=track,rank=rank};E.owners[v]=owner end
    -- Dirt values and inactive particle parameters are state setters. Compare
    -- all recorded values; active emitters and Instant audio still run per frame.
    local cacheable=ch.getter=='jlrsVehicleDirt' or (ch.getter=='jlrsVehicleParticles'
        and ((ch.name or ''):match('/color$')or values[1]<.5))
    -- A live emitter invalidates the old inactive snapshot. Otherwise the
    -- next OFF can match that stale snapshot and leave playback.on latched ON.
    if not cacheable then
        state.jlrsEffectValues=nil
        state.jlrsEffectOwner=nil
        state.jlrsEffectPaused=nil
    end
    local old=state.jlrsEffectValues
    if cacheable and old and state.jlrsEffectOwner==owner and state.jlrsEffectPaused==paused then
        local equal=true;for i=1,6 do if old[i]~=values[i]then equal=false;break end end
        if equal then return end
    end
    local result=apply(ch,v,values,state,paused,restoring)
    if cacheable then
        old=old or {};state.jlrsEffectValues=old
        for i=1,6 do old[i]=values[i]end
        state.jlrsEffectPaused=paused;state.jlrsEffectOwner=owner
    end
    return result
end
local function scope(raw,track,...)
    local previous=E.track;E.track=track
    local ok,result=pcall(raw,track,...);E.track=previous
    if not ok then error(result,0)end
    return result
end
local tick=JLRSActivities.tick
JLRSActivities.tick=function(track,...)return scope(tick,track,...)end
local restore=JLRSActivities.restore
JLRSActivities.restore=function(track,...)
    local result=scope(restore,track,...)
    for v,owner in pairs(E.owners)do if owner.track==track then E.owners[v]=nil end end
    return result
end
