-- Own only wheel visuals of active replay tracks; native physics stays untouched.
JLRSWheelVisual={nodes={}}
local function indexedWheel(state,node)
    if state.wheelIndexSource~=state.wheels then
        local index={};for _,wheel in ipairs(state.wheels)do index[wheel.node]=wheel end
        state.wheelIndexSource=state.wheels;state.wheelIndex=index
    end
    return state.wheelIndex[node]
end
function JLRSWheelVisual.standardPose(state)
    if not state then return false end
    local track=state.track
    if not track.replaying or not (track.frames or track.worldPoseReplay) then return false end
    local pose=track.replayAudioTime==track.replayTime and track.replayAudioPose
    if not pose then return false end
    local n=state.offset
    state.x,state.y,state.z=pose[n+1],pose[n+2],pose[n+3]
    state.rx,state.ry,state.rz=pose[n+4],pose[n+5],pose[n+6]
    if state.changeSteering then
        state.ry,state.rz=state.changeSteering[1],state.changeSteering[2]
    end
    -- Record All has the same authoritative steering pose. Only tyre roll
    -- belongs to its existing per-vehicle missing-roll fallback.
    local all=track.allWheelReplay
    if track.frames and track.frames.jlrsRecordAll and all and all.time==track.replayTime then
        local wheel=indexedWheel(all,state.node)
        if wheel and wheel.spin~=nil then state.rx=wheel.spin end
    end
    -- Keep displacement roll for older/remapped recordings missing X roll.
    local fallback=not (track.frames and track.frames.jlrsRecordAll) and track.changeWheelReplay
    if fallback and fallback.time==track.replayTime then
        local wheel=indexedWheel(fallback,state.node)
        if wheel and wheel.spin~=nil then state.rx=wheel.spin end
    end
    return true
end
function JLRSWheelVisual.pin(state)
    if state and state.rx~=nil and entityExists(state.node) then
        local perf=JLRSFinalReplayPerf
        if perf and perf.localTranslation and perf.localRotation then
            perf.localTranslation(state.node,state.x,state.y,state.z)
            perf.localRotation(state.node,state.rx,state.ry,state.rz)
        else
            setTranslation(state.node,state.x,state.y,state.z)
            setRotation(state.node,state.rx,state.ry,state.rz)
        end
    end
end
function JLRSWheelVisual.install()
    local W=JLRSWheelVisual
    if W.installed or not WheelsUtil or type(WheelsUtil.updateVisualWheel)~='function' then return end
    local original=WheelsUtil.updateVisualWheel
    WheelsUtil.updateVisualWheel=function(vehicle,wheel,x,y,z,xDrive,suspensionLength,...)
        local state=W.nodes[wheel.driveNode]
        if state and state.track.replaying then
            -- Suspension activity invokes the native wheel pass before refresh.
            -- Pinning the previous frame here froze standard-record wheel roll.
            W.standardPose(state)
            W.standardPose(W.nodes[wheel.repr])
            local recorded=wheel.jlrsReplaySuspension
            if recorded then
                x,y,z=recorded[1],recorded[2],recorded[3]
                suspensionLength=recorded[5];wheel.steeringAngle=recorded[6]
            end
            local result=original(vehicle,wheel,x,y,z,state.rx,suspensionLength,...)
            if wheel.jlrsChangeSteering then
                for _,node in ipairs({wheel.repr,wheel.driveNode})do
                    local visual=W.nodes[node]
                    if visual then
                        local _,ry,rz=getRotation(node)
                        visual.changeSteering=visual.changeSteering or {}
                        visual.changeSteering[1],visual.changeSteering[2]=ry,rz
                        W.standardPose(visual)
                    end
                end
            end
            -- The final roll write survives a late native graphics/interpolation pass.
            JLRSWheelVisual.pin(W.nodes[wheel.repr])
            JLRSWheelVisual.pin(state)
            wheel.lastXDrive=state.rx
            return result
        end
        return original(vehicle,wheel,x,y,z,xDrive,suspensionLength,...)
    end
    W.installed=true
end
function JLRSWheelVisual.clear(track)
    for _,state in ipairs(track.visualWheelStates or {}) do
        if JLRSWheelVisual.nodes[state.node]==state then JLRSWheelVisual.nodes[state.node]=nil end
    end
    track.visualWheelStates=nil
end
function JLRSWheelVisual.refresh(track)
    if not track.replaying then JLRSWheelVisual.clear(track);return end
    local states=track.visualWheelStates
    if not states or track.visualWheelEntries~=track.entries then
        JLRSWheelVisual.clear(track);states={};track.visualWheelStates=states;track.visualWheelEntries=track.entries
        local recorded={};for i,entry in ipairs(track.entries or {}) do if not entry.world then recorded[entry.node]=(i-1)*6 end end
        local seen={}
        local function addNode(node)
            if node and recorded[node] and not seen[node] and entityExists(node) then
                seen[node]=true
                local state={node=node,track=track,offset=recorded[node]};states[#states+1]=state;JLRSWheelVisual.nodes[node]=state
            end
        end
        local function add(wheel)
            addNode(wheel.repr);addNode(wheel.driveNode)
            for _,child in ipairs(wheel.additionalWheels or {}) do add(child) end
        end
        for _,vehicle in ipairs(track.recordVehicles or {track.target}) do
            for _,wheel in ipairs(vehicle.spec_wheels and vehicle.spec_wheels.wheels or {}) do add(wheel) end
        end
    end
    local pose=track.replayAudioTime==track.replayTime and track.replayAudioPose
    for _,state in ipairs(states) do
        if entityExists(state.node) then
            -- The interpolated local wheel pose is authoritative. Reading the
            -- node here can accidentally capture the native pass's idle suspension.
            if pose then
                local n=state.offset
                state.x,state.y,state.z=pose[n+1],pose[n+2],pose[n+3]
            elseif not track.paused or state.x==nil then
                state.x,state.y,state.z=getTranslation(state.node)
            end
            if not track.paused or state.rx==nil then state.rx,state.ry,state.rz=getRotation(state.node) end
            JLRSWheelVisual.standardPose(state)
            JLRSWheelVisual.pin(state)
        end
    end
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    JLRSWheelVisual.install()
    local result=tick(track,...)
    local c=JLReplayStudio
    -- RenderStability already refreshes each main/live track after every inner
    -- vehicle pass. During Final draw, avoid doing that same work here first.
    -- Seeks/cuts outside the boundary still refresh immediately. World cargo
    -- and Follow One use their own explicit refresh calls and are unchanged.
    if not (c and c.finalPlaying and c.jlrsRenderBoundary
        and c.jlrsLateWheelPass and c.jlrsLateWheelPass[track]) then
        JLRSWheelVisual.refresh(track)
    end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    JLRSWheelVisual.clear(track);track.visualWheelEntries=nil
    return stop(track,...)
end
local reset=JLRSLive.resetClock
JLRSLive.resetClock=function(c,...)
    for _,track in ipairs(c.liveTracks or {}) do JLRSWheelVisual.clear(track) end
    local result=reset(c,...)
    for _,track in ipairs(c.liveTracks or {}) do JLRSWheelVisual.refresh(track) end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);JLRSWheelVisual.nodes={};JLRSWheelVisual.install();return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=deleteMap(c,...);JLRSWheelVisual.nodes={};return result
end
