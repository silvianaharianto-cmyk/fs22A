-- Many moving props previously sealed one XML file per 120 samples each.
-- Retain the same samples but amortize native XML save/verify over larger chunks.
JLRSObstacleCache={CHUNK_FRAMES=512}
local initialize=JLRSWorld.initialize
JLRSWorld.initialize=function(scene,...)
    local result=initialize(scene,...)
    for _,entry in ipairs(scene.entries or {})do
        local stream=entry.samples;local state=stream and stream._jlrs
        if entry.prop and state and state.sealed==0 then
            -- On-disk readers already serialize chunkSize per stream.
            -- Queue RAM watermarks and emergency limits remain unchanged.
            state.chunkSize=JLRSObstacleCache.CHUNK_FRAMES
        end
    end
    return result
end
