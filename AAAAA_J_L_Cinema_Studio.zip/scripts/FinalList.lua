-- Persistent Final manager; vehicle History and camera streams remain unchanged.
JLRSFinalList={ROWS=8}
local L=JLRSFinalList
local function copy(t)local out={};for k,v in pairs(t or {})do out[k]=v end;return out end
function L.close(c)
    c.finalListOpen=false;c.menu=c.finalListReturnMenu or false;c.hitboxes={}
    JLRSMouse.refresh(c)
end
function L.open(c)
    JLRSFinal.load(c)
    if c.finalRecording then c:notify('Stop Final dahulu untuk mengatur daftar.');return end
    c.finalListReturnMenu=c.menu;c.finalListOpen=true;c.menu=true
    c.finalDraft=copy(c.finalApplied);c.finalListOffset=0;c.hitboxes={}
    JLRSMouse.refresh(c)
end
function L.ids(c)
    local ids={};for _,t in ipairs(c.finalTakes or {})do if (c.finalApplied or {})[t.id]then ids[#ids+1]=t.id end end;return ids
end
function L.apply(c)
    local before=c.finalApplied;c.finalApplied=copy(c.finalDraft)
    if #L.ids(c)==0 then c.finalApplied=before;c:notify('Centang minimal satu Record Final.');return end
    if not JLRSFinal.save(c) then c.finalApplied=before;return end
    c.finalListReady=true;L.close(c);c:notify('Final dipilih | klik REPLAY FINAL untuk memutar berurutan')
end
function L.rename(c,t,name)
    if c.finalRecording or c.finalPlaying then c:notify('Stop Final dahulu sebelum Rename.');return end
    if type(name)~='string' then return end
    name=name:gsub('[%c]',' '):match('^%s*(.-)%s*$')
    if name=='' then c:notify('Nama Final tidak boleh kosong.');return end
    local before=t.name;t.name=name:sub(1,64)
    if not JLRSFinal.save(c)then t.name=before end
end
function L.renameDialog(c,t)
    if g_gui and type(g_gui.showTextInputDialog)=='function' then
        g_gui:showTextInputDialog({text='Rename Record Final',defaultText=t.name or string.format('Final #%03d',t.id),maxCharacters=64,
            callback=function(text,accepted)if accepted then L.rename(c,t,text)end end})
    else c:notify('Dialog nama tidak tersedia.') end
end
function L.delete(c,t)
    if c.finalRecording or c.finalPlaying then c:notify('Stop Final dahulu sebelum Delete.');return end
    local index;for i,item in ipairs(c.finalTakes)do if item==t then index=i;break end end
    if not index then return end
    local selected=(c.finalApplied or {})[t.id]
    table.remove(c.finalTakes,index);c.finalApplied=c.finalApplied or {};c.finalApplied[t.id]=nil
    if not JLRSFinal.save(c)then table.insert(c.finalTakes,index,t);c.finalApplied[t.id]=selected;return end
    if c.finalDraft then c.finalDraft[t.id]=nil end
    c.finalSelected=math.min(c.finalSelected or 0,#c.finalTakes)
    c.finalListOffset=math.min(c.finalListOffset or 0,math.max(0,#c.finalTakes-L.ROWS))
    if #L.ids(c)==0 then c.finalListReady=false end
    -- Do not delete shared History or camera chunk files referenced by backup catalog.
    c:notify('Record Final dihapus | History kendaraan tetap tersedia')
end
function L.scroll(c,direction)
    c.finalListOffset=math.max(0,math.min(math.max(0,#c.finalTakes-L.ROWS),(c.finalListOffset or 0)+direction))
end
function L.draw(c)
    c.hitboxes={}
    JLRSMenu.rect(c,.19,.14,.62,.72,.015,.023,.037,.98)
    JLRSMenu.rect(c,.19,.78,.62,.08,.025,.16,.23)
    JLRSMenu.text(.21,.818,.023,'J_L Cinema Studio | Record Final')
    JLRSMenu.text(.21,.790,.011,'Centang lalu Apply | Replay Final memutar pilihan secara berurutan')
    JLRSMenu.button(c,.75,.806,.04,.035,'X',function()L.close(c)end)
    local offset=c.finalListOffset or 0
    JLRSMenu.text(.21,.753,.012,#c.finalTakes..' Final | scroll mouse untuk melihat daftar',.2,.85,.95)
    for row=1,L.ROWS do
        local t=c.finalTakes[offset+row]
        if t then
            local y=.69-(row-1)*.058
            JLRSMenu.rect(c,.205,y-.004,.59,.052,.045,.07,.105)
            local marked=(c.finalDraft or {})[t.id]
            JLRSMenu.button(c,.215,y,.031,.034,'',function()c.finalDraft[t.id]=not c.finalDraft[t.id]end,marked)
            if marked then
                for i=0,3 do JLRSMenu.rect(c,.221+i*.0018,y+.017-i*.0018,.003,.003,.2,1,.65,1)end
                for i=0,7 do JLRSMenu.rect(c,.227+i*.0014,y+.011+i*.0018,.003,.003,.2,1,.65,1)end
            end
            local name=t.name or string.format('Final #%03d',t.id)
            JLRSMenu.text(.256,y+.020,.013,name:sub(1,32))
            JLRSMenu.text(.256,y+.002,.010,JLRSMiniHud.formatTime(t.duration)..' | '..t.shot..' shots | #'..t.id,.65,.74,.83)
            JLRSMenu.button(c,.60,y,.088,.034,'RENAME',function()L.renameDialog(c,t)end)
            JLRSMenu.button(c,.70,y,.086,.034,'DELETE',function()L.delete(c,t)end,false,{.48,.07,.13})
        end
    end
    if #c.finalTakes==0 then JLRSMenu.text(.22,.67,.016,'Belum ada hasil Record Final.')end
    JLRSMenu.button(c,.21,.205,.08,.033,'UP',function()L.scroll(c,-L.ROWS)end)
    JLRSMenu.button(c,.30,.205,.09,.033,'DOWN',function()L.scroll(c,L.ROWS)end)
    JLRSMenu.button(c,.40,.205,.10,.033,'SAVE',function()JLRSManualSave.save(c,true)end)
    JLRSMenu.button(c,.52,.205,.13,.033,'APPLY',function()L.apply(c)end,true)
    JLRSMenu.button(c,.66,.205,.126,.033,'CLOSE',function()L.close(c)end)
    JLRSMenu.text(.21,.174,.011,(c.notice or ''):sub(1,85),1,.75,.35)
    JLRSMenu.text(.21,.146,.009,'©Copyright 2023 | Jupryan Lowlight',.65,.74,.83)
end
local draw=JLRSMenu.draw
JLRSMenu.draw=function(c,...)if c.finalListOpen and c.menu then return L.draw(c)end;return draw(c,...)end
local toggle=JLRSMenu.toggle
JLRSMenu.toggle=function(c,...)if c.finalListOpen then return L.close(c)end;return toggle(c,...)end
local install=JLRSFinal.install
JLRSFinal.install=function(c,...)
    local result=install(c,...)
    if not c.mission or c.finalListMouse then return result end
    local previous=c.mission.mouseEvent
    c.finalListMouse=function(m,x,y,down,up,button,...)
        if c.finalListOpen and not(g_gui and g_gui:getIsGuiVisible()) then
            c.mouseX=x;c.mouseY=y
            if down and button==Input.MOUSE_BUTTON_WHEEL_UP then L.scroll(c,-1)
            elseif down and button==Input.MOUSE_BUTTON_WHEEL_DOWN then L.scroll(c,1)
            elseif down and button==Input.MOUSE_BUTTON_LEFT then JLRSMenu.click(c,x,y,down,button)end
            return
        end
        return previous(m,x,y,down,up,button,...)
    end
    c.mission.mouseEvent=c.finalListMouse;c.finalListPreviousMouse=previous
    return result
end
local play=JLRSFinal.play
local function playId(c,id)
    for index,t in ipairs(c.finalTakes)do if t.id==id then c.finalSelected=index;play(c);return c.finalPlaying~=nil end end
    return false
end
JLRSFinal.play=function(c,...)
    if not c.finalListReady then return play(c,...)end
    if c.recording or c.finalRecording then c:notify('Stop Record dahulu sebelum Replay Final.');return end
    local ids=L.ids(c);if #ids==0 then return L.open(c)end
    -- Resolve every dependency before beginning a multi-take playlist.
    for _,id in ipairs(ids)do for _,t in ipairs(c.finalTakes)do if t.id==id then
        for _,clipId in ipairs(t.clips)do
            local valid=false;for _,clip in ipairs(c.history or {})do if clip.id==clipId and JLRSHistory.valid(clip)then valid=true;break end end
            if not valid then c:notify('Final #'..id..' membutuhkan History #'..clipId);return end
        end
    end end end
    c.finalQueueAdvancing=true;c.finalQueue={ids=ids,index=1}
    local ok=playId(c,ids[1]);c.finalQueueAdvancing=nil
    if not ok then c.finalQueue=nil end
end
local tick=JLRSFinal.tick
JLRSFinal.tick=function(c,...)
    local result=tick(c,...);local queue=c.finalQueue
    if queue and c.finalPlaying and c.finalPlaying.ended and queue.index<#queue.ids then
        queue.index=queue.index+1;c.finalQueueAdvancing=true
        local ok=playId(c,queue.ids[queue.index]);c.finalQueueAdvancing=nil
        if not ok then c.finalQueue=nil end
    end
    return result
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)if not c.finalQueueAdvancing then c.finalQueue=nil end;return stop(c,...)end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.finalApplied={};c.finalDraft={};c.finalListReady=false;c.finalListOpen=false;c.finalQueue=nil;c.finalListMouse=nil;return result
end
local finalLoad=JLRSFinal.load
JLRSFinal.load=function(c,...)
    local pending=c.finalLoadPending;local result=finalLoad(c,...)
    if pending and not c.finalLoadPending then c.finalListReady=#L.ids(c)>0 end
    return result
end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.mission and c.mission.mouseEvent==c.finalListMouse then c.mission.mouseEvent=c.finalListPreviousMouse end
    c.finalListMouse=nil;c.finalListOpen=false;c.finalQueue=nil
    return delete(c,...)
end
