-- Replay-only coupling support. Recorded poses and activity streams are immutable.
-- Live vehicle recording retains its native contact controller.
JLRSTrailerPathSync={}
local S=JLRSTrailerPathSync
local NAME='jlrsTrailerAttachment'
function S.plan(track)
    local data=track.frames and track.frames.jlrsActivities
    if not data then return end
    local plan=track.trailerPathPlan
    if plan and plan.entries==track.entries and plan.data==data then return plan end
    plan={entries=track.entries,data=data,roots={},bodies={},links={}}
    for i,e in ipairs(track.entries or {})do
        if e.world and e.vehicle then
            local v=e.vehicle;plan.bodies[v]=plan.bodies[v]or {}
            plan.bodies[v][#plan.bodies[v]+1]={entry=e,offset=(i-1)*6}
            if e.node==v.rootNode then plan.roots[v]=(i-1)*6 end
        end
    end
    for i,ch in ipairs(data.schema or {})do
        if ch.getter==NAME then
            local parent=JLRSActivities.resolve(ch,track.recordVehicles or {track.target})
            local child=JLRSTrailers.find(ch.name)
            if parent and child and parent~=child and plan.roots[parent] and plan.roots[child] then
                plan.links[#plan.links+1]={parent=parent,child=child,index=i,donorConfig=ch.config or ''}
            end
        end
    end
    track.trailerPathPlan=plan;return plan
end
function S.hasTrailer(track)
    local plan=S.plan(track);return plan and #plan.links>0
end
-- Live Drive ON alone must not turn an ordinary precise trailer replay into
-- velocity playback. ensureContacts still promotes tracks at Live Record start.
local detach=JLRSLive.detachPhysics
JLRSLive.detachPhysics=function(track,...)
    local c=JLReplayStudio
    if c.preciseReplay and not c.recording and S.hasTrailer(track)then
        local batch,physics=c.worldBatch,c.physicsReplay
        c.worldBatch=true;c.physicsReplay=false
        local ok,result=pcall(detach,track,...)
        c.worldBatch=batch;c.physicsReplay=physics
        if not ok then error(result,0)end
        return result
    end
    return detach(track,...)
end
function S.precise(track)
    local c=JLReplayStudio
    if not c.preciseReplay or c.recording or not track.collisionReplay
        or not track.livePrecisionContact or not S.hasTrailer(track)then return end
    -- StopRecord leaves the promoted Live track running. Return just its body
    -- controller to precision without stopReplay (no joint/audio/end-pose reset).
    JLRSLive.restorePhysics(track)
    track.collisionReplay=false
    local ok,result=pcall(JLRSLive.detachPhysics,track)
    if not ok or result==false then
        JLRSLive.restorePhysics(track);track.collisionReplay=true
        if not ok then error(result,0)end
        return
    end
    track.livePrecisionContact=nil;track.collisionVelocity=nil;track.collisionCorrection=nil
end
local function compatible(parent,child,joint,input)
    local ins=child.spec_attachable and child.spec_attachable.inputAttacherJoints
    local inputDesc=ins and ins[input]
    local joints=parent.spec_attacherJoints and parent.spec_attacherJoints.attacherJoints
    if not inputDesc or not joints then return end
    local desc=joints[joint]
    if desc and (not inputDesc.jointType or not desc.jointType or desc.jointType==inputDesc.jointType)then
        return desc,inputDesc,joint
    end
    for i,item in ipairs(joints)do
        if inputDesc.jointType and item.jointType==inputDesc.jointType then return item,inputDesc,i end
    end
end
-- Attachment indices belong to the donor model. Resolve an equivalent hitch
-- on a replacement before connecting its visual hoses; native restoration is unchanged.
local connect=JLRSTrailers.connect
JLRSTrailers.connect=function(parent,child,values,native)
    if not native and values[1]>=.5 then
        local _,_,joint=compatible(parent,child,math.floor(values[2]),math.floor(values[3]))
        if joint and joint~=values[2]then
            local copy={};for i=1,6 do copy[i]=values[i]end;copy[2]=joint
            return connect(parent,child,copy,native)
        end
    end
    return connect(parent,child,values,native)
end
local adapter=JLRSActivities.adapters and JLRSActivities.adapters[NAME]
if adapter then
    local write=adapter.write
    adapter.write=function(parent,ch,values,paused,restoring)
        local child=JLRSTrailers.find(ch.name)
        if child and not restoring and values[1]>=.5 then
            local _,_,joint=compatible(parent,child,math.floor(values[2]),math.floor(values[3]))
            if joint and joint~=values[2]then
                local copy={};for i=1,6 do copy[i]=values[i]end;copy[2]=joint
                return write(parent,ch,copy,paused,restoring)
            end
        end
        return write(parent,ch,values,paused,restoring)
    end
end
local function helpers(track)
    local h=track.trailerPathHelpers
    if h then return h end
    local root=createTransformGroup('JLRS_Trailer_Path');link(getRootNode(),root)
    local child=createTransformGroup('JLRS_Trailer_Component');link(root,child)
    h={root,child};track.trailerPathHelpers=h;return h
end
local function setPose(node,p,n)
    setTranslation(node,p[n+1],p[n+2],p[n+3]);setRotation(node,p[n+4],p[n+5],p[n+6])
end
local function write(body,p)
    local e=body.entry;local v=e.vehicle;local ci=e.componentIndex
    local x,y,z=getWorldTranslation(e.node);local rx,ry,rz=getWorldRotation(e.node)
    if x==p[1]and y==p[2]and z==p[3]and rx==p[4]and ry==p[5]and rz==p[6]then return end
    local component=v and ci and v.components and v.components[ci]
    if component and component.node==e.node and type(v.setWorldPosition)=='function'then
        local interp=component.networkInterpolators
        v:setWorldPosition(p[1],p[2],p[3],p[4],p[5],p[6],ci,
            interp~=nil and interp.position~=nil and interp.quaternion~=nil)
    else setWorldTranslation(e.node,p[1],p[2],p[3]);setWorldRotation(e.node,p[4],p[5],p[6])end
end
function S.carry(track,plan,pose,parent,child,values,align)
    local pr,cr=plan.roots[parent],plan.roots[child]
    if not pr or not cr or not JLRSRecorder.valid(parent)or not JLRSRecorder.valid(child)then return end
    local bodies=plan.bodies[child];local h=helpers(track)
    local ax,ay,az=getWorldTranslation(parent.rootNode);local arx,ary,arz=getWorldRotation(parent.rootNode)
    local desired={}
    -- Preserve the recorded articulated orientation and all component offsets,
    -- relative to the tractor's actual current pose in Physics On.
    for i,body in ipairs(bodies)do
        setPose(h[1],pose,pr)
        setWorldTranslation(h[2],pose[body.offset+1],pose[body.offset+2],pose[body.offset+3])
        setWorldRotation(h[2],pose[body.offset+4],pose[body.offset+5],pose[body.offset+6])
        setTranslation(h[1],ax,ay,az);setRotation(h[1],arx,ary,arz)
        local x,y,z=getWorldTranslation(h[2]);local rx,ry,rz=getWorldRotation(h[2])
        desired[i]={x,y,z,rx,ry,rz}
    end
    if align then
        local joint,input=compatible(parent,child,math.floor(values[2]),math.floor(values[3]))
        if joint and joint.jointTransform and input.node and entityExists(joint.jointTransform)and entityExists(input.node)then
            local node=input.node;local owner
            while node and node~=0 and not owner do
                for i,body in ipairs(bodies)do if body.entry.node==node then owner=i;break end end
                if not owner then node=getParent(node)end
            end
            if owner then
                local ix,iy,iz=getWorldTranslation(input.node)
                local lx,ly,lz=worldToLocal(bodies[owner].entry.node,ix,iy,iz)
                setPose(h[1],desired[owner],0)
                local tx,ty,tz=localToWorld(h[1],lx,ly,lz)
                local jx,jy,jz=getWorldTranslation(joint.jointTransform)
                local dx,dy,dz=jx-tx,jy-ty,jz-tz
                for _,p in ipairs(desired)do p[1]=p[1]+dx;p[2]=p[2]+dy;p[3]=p[3]+dz end
            end
        end
    end
    for i,body in ipairs(bodies)do write(body,desired[i])end
end
function S.sync(track)
    local c=JLReplayStudio
    if c.recording or not track.replaying or not (track.collisionReplay or (c.preciseReplay and track.livePhysics))then return end
    local plan=S.plan(track);local state=track.activityReplay
    local pose=track.replayAudioPose
    if not plan or not state or not pose then return end
    local active={}
    for _,item in ipairs(plan.links)do
        local channel=state.channels[item.index];local values=channel and channel.values
        local replaced=item.donorConfig~=(item.parent.configFileName or item.parent.xmlFilename or '')
        if values and values[1]and values[1]>=.5 and (track.collisionReplay or replaced)then
            item.values=values;active[item.child]=item
        end
    end
    local visited={}
    local function apply(item)
        if visited[item.child]then return end;visited[item.child]=true
        if active[item.parent]then apply(active[item.parent])end
        S.carry(track,plan,pose,item.parent,item.child,item.values,true)
        -- Positively fastened cargo keeps its recorded relative pose on the
        -- supported trailer. Wheel/steering writers remain the existing ones.
        if JLRSCargoWheels then for v in pairs(plan.bodies)do
            if v~=item.child and v~=item.parent and not active[v]and JLRSCargoWheels.fastened(v,item.child)then
                S.carry(track,plan,pose,item.child,v,item.values,false)
            end
        end end
    end
    for _,item in pairs(active)do apply(item)end
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    if track.replaying then S.precise(track)end
    local result=tick(track,...);S.sync(track);return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    if track.trailerPathHelpers then delete(track.trailerPathHelpers[1]);track.trailerPathHelpers=nil end
    track.trailerPathPlan=nil
    return stop(track,...)
end
