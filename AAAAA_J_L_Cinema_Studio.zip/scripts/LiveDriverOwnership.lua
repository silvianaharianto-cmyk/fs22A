-- A controlled Live Drive vehicle belongs to native FS22, not a background
-- snapshot in another vehicle's recording. Direct replay owners stay intact.
JLRSLiveDriverOwnership={}
local H=JLRSLiveDriverOwnership
local function direct(track,v)
    if track.target==v then return true end
    for _,car in ipairs(track.recordVehicles or {})do if car==v then return true end end
    return false
end
function H.native(c,v)
    if not c or not c.liveDrive or not v or not g_currentMission or g_currentMission.controlledVehicle~=v then return false end
    -- Final is cinematic playback. Ensemble resetClock runs before World.start
    -- has installed secondary paths; that temporary absence is not a native
    -- driving handoff for the last vehicle selected by the player.
    if c.finalPlaying or c.finalRecording or c.jlrsEnsemblePreparing then return false end
    if c.replaying and direct(c,v)then return false end
    for _,track in ipairs(c.liveTracks or {})do
        if track.replaying and direct(track,v)then return false end
    end
    -- A moving secondary path/cargo still belongs to its precision replay.
    -- Parked background snapshots can be handed off by the existing world
    -- policy; do not change TAB's camera-only behavior on recorded paths.
    local function held(replay)
        for _,state in ipairs(replay and replay.states or {})do
            if state.group.object==v and (state.cargo or state.hasRecordedTravel)then return true end
        end
        return false
    end
    if not c.recording then
        if held(c.worldReplay)then return false end
        for _,track in ipairs(c.liveTracks or {})do if held(track.cargoReplay)then return false end end
    end
    return true
end
local apply=JLRSActivities.apply
JLRSActivities.apply=function(ch,v,values,state,paused,restoring)
    local track=JLRSSecondaryEffects and JLRSSecondaryEffects.track
    if not restoring and track and v and not direct(track,v)then
        if state.liveDriverReleased then
            local c=JLReplayStudio
            if not(c.finalPlaying or c.finalRecording or c.jlrsEnsemblePreparing)then return end
            -- An already running Live replay may become Record Final without
            -- rebuilding its channels. Reclaim those released channels too.
            state.liveDriverReleased=nil
            state.original=JLRSActivities.values(ch,v)
            state.applied=nil;state.started=nil
            state.jlrsEffectValues=nil;state.jlrsEffectOwner=nil;state.jlrsEffectPaused=nil
        end
        if H.native(JLReplayStudio,v)then
            -- Undo already installed audio getter hooks before the native motor
            -- resumes. Restoring values alone cannot remove those wrappers.
            if state.audioProxy then JLRSAudio.restore(state.audioProxy);state.audioProxy=nil end
            apply(ch,v,state.original or values,state,false,true)
            state.liveDriverReleased=true
            return
        end
    end
    if restoring and state.liveDriverReleased then return end
    return apply(ch,v,values,state,paused,restoring)
end
local ensemble=JLRSGroup.all
JLRSGroup.all=function(c,...)
    local previous=c.jlrsEnsemblePreparing;c.jlrsEnsemblePreparing=true
    local ok,result=pcall(ensemble,c,...)
    c.jlrsEnsemblePreparing=previous
    if not ok then error(result,0)end
    return result
end
local restore=JLRSActivities.restore
JLRSActivities.restore=function(track,...)
    -- Native driving may have changed lights, engine or ramp since handoff.
    -- Do not restore the old replay-start snapshot over those user changes.
    for _,state in ipairs(track.activityReplay and track.activityReplay.channels or {})do
        if state.liveDriverReleased then state.vehicle=nil end
    end
    return restore(track,...)
end
