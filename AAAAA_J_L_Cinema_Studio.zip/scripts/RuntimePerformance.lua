-- Bounded diagnostics for the unresolved FPS regression: one line / 10 seconds.
-- Timing never enters History, never changes simulation rate or physics.
JLRSRuntimePerf={interval=10000,scopes={}}
local P=JLRSRuntimePerf
local function active()
    local c=JLReplayStudio
    return c.recording or c.replaying or c.finalRecording or c.finalPlaying or #(c.liveTracks or {})>0
end
local function wrap(owner,name,label)
    local original=owner[name]
    owner[name]=function(...)
        if not active() or type(getTimeSec)~='function' then return original(...) end
        local start=getTimeSec();local result=original(...)
        local ms=math.max(0,(getTimeSec()-start)*1000)
        local s=P.scopes[label] or {count=0,total=0,max=0};P.scopes[label]=s
        s.count=s.count+1;s.total=s.total+ms;s.max=math.max(s.max,ms)
        return result
    end
end
wrap(JLRSRecorder,'recordTick','motionRecord')
wrap(JLRSRecorder,'replayTick','motionReplay')
wrap(JLRSActivities,'record','activityRecord')
wrap(JLRSActivities,'tick','activityReplay')
wrap(JLRSWriteBudget,'service','cacheWrite')
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...)
    local time=g_time or 0
    if not active() then P.start=nil;P.scopes={};return result end
    if not P.start then P.start=time end
    if time-P.start>=P.interval and next(P.scopes) then
        local parts={}
        for _,name in ipairs({'motionRecord','activityRecord','motionReplay','activityReplay','cacheWrite'}) do
            local s=P.scopes[name]
            if s then parts[#parts+1]=string.format('%s=%.3f/%.3fms n=%d',name,s.total/s.count,s.max,s.count) end
        end
        local data=c.activityRecording and c.activityRecording.data or c.frames and c.frames.jlrsActivities
        print('[JLRS PERF V1.18.61] channels='..tostring(data and #data.schema or 0)..' queueMiB='..string.format('%.1f',JLRSWriteBudget.bytes/1048576)..' chunks='..#JLRSWriteBudget.queue..' mean/max '..table.concat(parts,' | '))
        P.start=time;P.scopes={}
    end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)P.start=nil;P.scopes={};return load(c,...)end
