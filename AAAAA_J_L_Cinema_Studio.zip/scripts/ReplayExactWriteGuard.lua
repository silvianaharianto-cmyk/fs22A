-- Exact redundant-world-write guard only inside an isolated replay tick.
-- Physics On, reset/seek, recording and changed poses retain the original path.
JLRSReplayWriteGuard={}
local G=JLRSReplayWriteGuard
function G.skip(entry,pose,n)
    local track=G.track
    if not track or not track.livePhysics or track.collisionReplay or not track.jlrsWriteGuardSet[entry] then return false end
    local last=entry.jlrsExactWorld
    if not last then return false end
    for i=1,6 do if last[i]~=pose[n+i]then return false end end
    local x,y,z=getWorldTranslation(entry.node)
    if x~=pose[n+1]or y~=pose[n+2]or z~=pose[n+3]then return false end
    local rx,ry,rz=getWorldRotation(entry.node)
    return rx==pose[n+4]and ry==pose[n+5]and rz==pose[n+6]
end
function G.remember(entry,pose,n)
    if not G.track or not G.track.livePhysics or G.track.collisionReplay or not G.track.jlrsWriteGuardSet[entry] then return end
    local last=entry.jlrsExactWorld or {};entry.jlrsExactWorld=last
    for i=1,6 do last[i]=pose[n+i]end
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    if track.jlrsWriteGuardEntries~=track.entries then
        track.jlrsWriteGuardEntries=track.entries;track.jlrsWriteGuardSet={}
        for _,e in ipairs(track.entries or {})do track.jlrsWriteGuardSet[e]=true end
    end
    local previous=G.track;G.track=track
    local ok,result=pcall(tick,track,...);G.track=previous
    if not ok then error(result,0)end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    for _,e in ipairs(track.entries or {})do e.jlrsExactWorld=nil end
    track.jlrsWriteGuardEntries=nil;track.jlrsWriteGuardSet=nil
    return stop(track,...)
end
