JLRSLiveObstacle={}
function JLRSLiveObstacle.attached(o,vehicles)
    for _,v in ipairs(vehicles or {})do
        for _,d in pairs(v.spec_tensionBelts and v.spec_tensionBelts.objectsToJoint or {})do
            if type(d)=='table' and d.object==o then return true end
        end
        for k,d in pairs(v.spec_dynamicMountAttacher and v.spec_dynamicMountAttacher.dynamicMountedObjects or {})do
            if k==o or d==o or (type(d)=='table' and d.object==o)then return true end
        end
    end
    return false
end
function JLRSLiveObstacle.releaseLoose(c)
    local released=0
    for _,track in ipairs(c.liveTracks or {})do
        local replay=track.cargoReplay
        if replay then
            for i=#replay.states,1,-1 do
                local state=replay.states[i];local group=state.group
                if group.prop and not JLRSLiveObstacle.attached(group.object,track.recordVehicles) then
                    -- Keep the rewound/current pose. releaseReplay would restore its old end pose.
                    JLRSWorld.release(state);table.remove(replay.states,i);released=released+1
                end
            end
        end
    end
    return released
end
local collect=JLRSWorld.collect
JLRSWorld.collect=function(c,...)
    if c==JLReplayStudio and c.recording and c.liveDrive then
        if not JLRSLiveObstacle.ensureContacts(c) then error('Collision seluruh kendaraan Live belum siap.') end
        JLRSLiveObstacle.releaseLoose(c)
    end
    return collect(c,...)
end
-- Replay All adds takes chronologically. A newer Live take includes the
-- newly simulated loose-object path; hand each such node to that newer scene.
local start=JLRSWorld.start
JLRSWorld.start=function(c,scene,owner,cargoOnly,...)
    if c.worldBatch and owner and cargoOnly and scene then
        local incoming={}
        for _,group in ipairs(scene.groups or {})do
            if group.prop and not JLRSLiveObstacle.attached(group.object,owner.recordVehicles) then
                for _,e in ipairs(group.entries)do incoming[e.node]=true end
            end
        end
        for _,track in ipairs(c.liveTracks or {})do
            if track~=owner and track.cargoReplay then
                local states=track.cargoReplay.states
                for i=#states,1,-1 do
                    local state=states[i];local group=state.group;local overlap=false
                    if group.prop and not JLRSLiveObstacle.attached(group.object,track.recordVehicles) then
                        for _,e in ipairs(group.entries)do if incoming[e.node]then overlap=true;break end end
                    end
                    if overlap then JLRSWorld.release(state);table.remove(states,i)end
                end
            end
        end
    end
    return start(c,scene,owner,cargoOnly,...)
end

-- Live Drive needs native contact shapes, even when the take supplies its path.
local detach=JLRSLive.detachPhysics
JLRSLive.detachPhysics=function(track)
    local c=JLReplayStudio
    if track~=c and not track.worldPoseReplay and c.preciseReplay and c.liveDrive and c.recording and not c.worldBatch then
        local precise,physics=c.preciseReplay,c.physicsReplay
        c.preciseReplay=false;c.physicsReplay=true
        local ok,result=pcall(detach,track)
        c.preciseReplay=precise;c.physicsReplay=physics
        if not ok then error(result)end
        track.livePrecisionContact=result and true or nil
        return result
    end
    return detach(track)
end

-- Tracks created in Replay All may be isolated precision tracks. Promote the
-- entire existing ensemble at each Live Record boundary, not just its newest car.
function JLRSLiveObstacle.ensureContacts(c)
    if not c.liveDrive or not c.preciseReplay then return true end
    for _,track in ipairs(c.liveTracks or {})do
        if track.replaying and not track.collisionReplay then
            JLRSLive.restorePhysics(track)
            local precise,physics,batch=c.preciseReplay,c.physicsReplay,c.worldBatch
            c.preciseReplay=false;c.physicsReplay=true;c.worldBatch=false
            local ok,result=pcall(JLRSLive.detachPhysics,track)
            c.preciseReplay=precise;c.physicsReplay=physics;c.worldBatch=batch
            if not ok or not result then
                -- Restore isolation if contact conversion cannot be completed.
                track.collisionReplay=false;c:stop()
                c:notify('Collision Live tidak dapat dipulihkan: '..tostring(ok and 'komponen tidak didukung' or result))
                return false
            end
            track.livePrecisionContact=true
            JLRSCollision.place(track,JLRSRecorder.sample(track,track.replayTime or 0))
        end
    end
    return true
end
