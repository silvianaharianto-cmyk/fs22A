-- Exact sampling optimization during vehicle replay and Replay Final. No frame skipping,
-- physics toggles, particle reductions or persistent recording data changes.
JLRSFinalReplayPerf={}
local P=JLRSFinalReplayPerf
function P.active()return JLReplayStudio and (JLReplayStudio.finalPlaying or JLReplayStudio.replaying or #(JLReplayStudio.liveTracks or {})>0) and true or false end
-- Derivative calculations only inspect six channels of each world component.
-- Leave the main full pose/wheels/audio/activity sampling path unchanged.
function P.bodySample(track,time)
    local frames=track.frames;local count=JLRSFrames.count(frames)
    if count==0 then return JLRSRecorder.sample(track,time)end
    local i=math.max(1,math.min(track.frameIndex or 1,count));local steps=0
    while i>1 and steps<8 and JLRSFrames.get(frames,i).t>time do i=i-1;steps=steps+1 end
    steps=0
    while i<count and steps<8 and JLRSFrames.get(frames,i+1).t<time do i=i+1;steps=steps+1 end
    if not(JLRSFrames.get(frames,i).t<=time and (i==count or JLRSFrames.get(frames,i+1).t>=time))then
        local low,high=1,count
        while low<=high do
            local mid=math.floor((low+high)/2)
            if JLRSFrames.get(frames,mid).t<=time then i=mid;low=mid+1 else high=mid-1 end
        end
    end
    local a,b=JLRSFrames.get(frames,i),JLRSFrames.get(frames,math.min(i+1,count))
    local alpha=b.t>a.t and math.max(0,math.min(1,(time-a.t)/(b.t-a.t)))or 0
    local plan=track.finalBodyPlan
    if not plan or plan.entries~=track.entries then
        plan={entries=track.entries,offsets={}};track.finalBodyPlan=plan
        for index,entry in ipairs(track.entries or {})do if entry.world then plan.offsets[#plan.offsets+1]=(index-1)*6 end end
    end
    local pose={}
    for _,offset in ipairs(plan.offsets)do
        for j=1,6 do
            local n=offset+j;local x,y=a.pose[n],b.pose[n]
            if x==y then pose[n]=x
            elseif j<=3 then pose[n]=x+(y-x)*alpha
            else pose[n]=JLRSRecorder.angle(x,y,alpha)end
        end
    end
    return pose
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    if not P.active()then return tick(track,...)end
    -- Keep the existing four-pose cache alive around every outer replay stage,
    -- including audio/activity consumers, and always unwind it on failure.
    local previous=track.smoothSamples;local previousScope=track.finalSampleScope
    track.finalSampleScope=true;track.smoothSamples={}
    local ok,result=pcall(tick,track,...)
    track.smoothSamples=previous;track.finalSampleScope=previousScope
    if not ok then error(result)end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)track.finalBodyPlan=nil;return stop(track,...)end

-- Changing visual targets go straight to the native setter. Unchanged targets
-- still inspect the actual node so native suspension/other mods are corrected.
local translations,rotations={},{}
local function applyLocal(cache,getter,setter,node,x,y,z)
    if not P.active() then return setter(node,x,y,z) end
    local last=cache[node]
    if last and last[1]==x and last[2]==y and last[3]==z and type(getter)=='function' then
        local a,b,c=getter(node)
        if a==x and b==y and c==z then return end
    end
    -- Commit only after the native write succeeds. No frames are cached here.
    local result=setter(node,x,y,z)
    if not last then last={};cache[node]=last end
    last[1],last[2],last[3]=x,y,z
    return result
end
function P.localTranslation(node,x,y,z)
    return applyLocal(translations,getTranslation,setTranslation,node,x,y,z)
end
function P.localRotation(node,x,y,z)
    return applyLocal(rotations,getRotation,setRotation,node,x,y,z)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...) translations={};rotations={};return load(c,...) end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...) translations={};rotations={};return delete(c,...) end
