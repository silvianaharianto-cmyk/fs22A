-- Apply optical zoom gain inside the native SoundManager volume calculation.
-- Keep native radii/culling/playback, RPM modifiers, fades and samples untouched.
JLRSFovAudio={}
local A=JLRSFovAudio
local lastFov,lastScale
function A.scale(fov)
    if type(fov)~='number' or fov~=fov then return 1 end
    if fov==lastFov then return lastScale end
    local optical=math.tan(math.rad(55)/2)/math.tan(math.max(math.rad(10),math.min(math.rad(110),fov))/2)
    lastFov=fov;lastScale=2 * math.max(0.35,math.min(1.75,optical))
    return lastScale
end
function A.camera(c)
    if not c or not c.mission or (g_gui and g_gui:getIsGuiVisible()) then return end
    local final=c.finalPlaying and c.finalPlaying.camera
    if final and entityExists(final) then return final end
    if c.active and c.camera and entityExists(c.camera) and not c.editingOpen then return c.camera end
end
function A.restore(c)
    -- No native audio properties were changed. Removing membership restores gain.
    c.fovAudioSamples=nil;c.fovAudioScan=nil
end
function A.collect(c)
    local samples=setmetatable({},{__mode='k'});c.fovAudioSamples=samples
    local function vehicle(v)
        local spec=v and v.spec_motorized
        if spec then
            for _,list in ipairs({spec.motorSamples or {},spec.samples or {}}) do
                for _,sample in pairs(list) do
                    if type(sample)=='table' then samples[sample]=true end
                end
            end
        end
    end
    for _,v in pairs(c.mission and c.mission.vehicles or {}) do vehicle(v) end
    vehicle(c.target)
    for _,track in ipairs(c.liveTracks or {}) do vehicle(track.target) end
end
function A.gain(c,sample)
    -- Most SoundManager samples belong to ambient audio/other systems.
    -- Membership is sufficient to reject them without native camera queries.
    if not c or not (c.fovAudioSamples and c.fovAudioSamples[sample]) then return 1 end
    local camera=A.camera(c)
    if not camera or not getFovY then return 1 end
    return A.scale(getFovY(camera))
end
function A.install()
    local owner=g_soundManager
    if not owner or type(owner.getCurrentSampleVolume)~='function' or owner.getCurrentSampleVolume==A.wrapper then return end
    local previous=owner.getCurrentSampleVolume;local raw=rawget(owner,'getCurrentSampleVolume')
    local wrapper=function(manager,sample,...)
        -- The returned base already contains native fade/volumeScale/offsets;
        -- SoundManager applies recorded RPM/load volume modifiers afterwards.
        local volume=previous(manager,sample,...)
        local gain=A.gain(JLReplayStudio,sample)
        if gain==1 or type(volume)~='number' then return volume end
        return volume*gain
    end
    A.owner=owner;A.raw=raw;A.wrapper=wrapper;owner.getCurrentSampleVolume=wrapper
end
function A.tick(c)
    A.install()
    if not A.camera(c) then if c.fovAudioSamples then A.restore(c) end;return end
    local now=g_time or 0
    if not c.fovAudioScan or now<c.fovAudioScan or now-c.fovAudioScan>=500 then
        A.collect(c);c.fovAudioScan=now
    end
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...) local result=draw(c,...);A.tick(c);return result end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)local result=load(c,...);A.install();return result end
local deactivate=JLRSCamera.deactivate
JLRSCamera.deactivate=function(c,...)
    local result=deactivate(c,...)
    if not A.camera(c) then A.restore(c) end
    return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    A.restore(c)
    if A.owner and A.owner.getCurrentSampleVolume==A.wrapper then A.owner.getCurrentSampleVolume=A.raw end
    A.owner=nil;A.raw=nil;A.wrapper=nil
    return unload(c,...)
end
A.install()
