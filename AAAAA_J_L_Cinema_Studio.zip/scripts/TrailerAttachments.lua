-- Native coupling transitions use the existing persistent, sparse activity stream.
-- Replay body poses remain independent: only hoses are connected during playback,
-- never a new constraint between two bodies controlled by recorded transforms.
JLRSTrailers={original=setmetatable({},{__mode='k'}),visual=setmetatable({},{__mode='k'})}
local T=JLRSTrailers
local NAME='jlrsTrailerAttachment'
T.cache=setmetatable({},{__mode='v'})
local function implements(v)
    if type(v.getAttachedImplements)=='function' then return v:getAttachedImplements() or {} end
    return v.spec_attacherJoints and v.spec_attacherJoints.attachedImplements or {}
end
function T.find(id)
    local cached=T.cache[id]
    if cached and cached.jlrsPersistentId==id and JLRSRecorder.valid(cached) then return cached end
    for _,v in pairs((g_currentMission or {}).vehicles or {}) do
        if v.jlrsPersistentId==id and JLRSRecorder.valid(v) then T.cache[id]=v;return v end
    end
end
function T.read(v,child)
    for _,imp in ipairs(implements(v)) do if imp.object==child then
        return {1,imp.jointDescIndex or 0,imp.inputJointDescIndex or
            (child.spec_attachable or {}).inputAttacherJointDescIndex or 0,0,0,0}
    end end
    return {0,0,0,0,0,0}
end
function T.disconnect(v,child)
    local spec=child.spec_connectionHoses
    if not spec then return end
    -- Native detach already handles custom hoses and delayed connectors. These
    -- are the visual-only playback connections, which have no native implement.
    for i=#(spec.updateableHoses or {}),1,-1 do
        local hose=spec.updateableHoses[i]
        if hose.connectedObject==v and type(child.disconnectHose)=='function' then child:disconnectHose(hose) end
    end
    local visual=T.visual[child]
    if visual and visual.parent==v then
        if type(child.getConnectionHosesByInputAttacherJoint)=='function' and type(child.disconnectHose)=='function' then
            for _,hose in ipairs(child:getConnectionHosesByInputAttacherJoint(visual.input) or {}) do child:disconnectHose(hose) end
        end
        for _,list in ipairs({(spec.customHosesByInputAttacher or {})[visual.input] or {},
                             (spec.customTargetsByInputAttacher or {})[visual.input] or {}}) do
            for _,hose in ipairs(list) do if hose.isActive and type(child.disconnectCustomHoseNode)=='function' then
                if hose.connectedHose then child:disconnectCustomHoseNode(hose.connectedHose,hose)
                else child:disconnectCustomHoseNode(hose,hose.connectedTarget) end
            end end
        end
        T.visual[child]=nil
    end
    local parentSpec=v.spec_connectionHoses
    for _,connector in pairs(parentSpec and parentSpec.toolConnectorHoses or {}) do
        if connector.delayedMounting and connector.delayedMounting.sourceObject==child then connector.delayedMounting=nil end
    end
end
function T.detach(v,child)
    if T.read(v,child)[1]==1 then
        if type(v.detachImplementByObject)~='function' then error('Native trailer detach API unavailable') end
        v:detachImplementByObject(child)
        if T.read(v,child)[1]==1 then error('Trailer detach did not complete') end
    end
    T.disconnect(v,child)
end
function T.connect(v,child,values,native)
    if values[1]<.5 then return end
    local joint,input=math.floor(values[2]),math.floor(values[3])
    if joint<1 or input<1 then return end
    if not v.spec_attacherJoints or not v.spec_attacherJoints.attacherJoints[joint]
        or not child.spec_attachable or not (child.spec_attachable.inputAttacherJoints or {})[input] then return end
    if native then
        if type(v.attachImplement)=='function' then v:attachImplement(child,input,joint,false,nil,nil,true) end
        return
    end
    T.visual[child]={parent=v,input=input,joint=joint}
    if type(child.connectHosesToAttacherVehicle)=='function' then child:connectHosesToAttacherVehicle(v,input,joint) end
    if type(child.connectCustomHosesToAttacherVehicle)=='function' then child:connectCustomHosesToAttacherVehicle(v,input,joint) end
end
function T.prepare(track)
    local data=track.frames and track.frames.jlrsActivities
    if not data then return end
    track.trailerOriginal=track.trailerOriginal or {}
    for _,ch in ipairs(data.schema) do if ch.getter==NAME then
        local v=JLRSActivities.resolve(ch,track.recordVehicles or {track.target});local child=T.find(ch.name)
        if v and child then
            T.original[v]=T.original[v] or {}
            if not T.original[v][child] then
                local item={parent=v,child=child,values=T.read(v,child)}
                T.original[v][child]=item;track.trailerOriginal[#track.trailerOriginal+1]=item
            end
            T.detach(v,child)
        end
    end end
end
JLRSActivities.registerAdapter(NAME,{
    reuseReplayValues=true,
    discover=function(v)
        if not v.spec_attacherJoints or #(v.spec_attacherJoints.attacherJoints or {})==0 then return {} end
        local channels={}
        for _,child in pairs((g_currentMission or {}).vehicles or {}) do
            if child~=v and JLRSRecorder.valid(child) and child.spec_attachable and not JLRSWorld.isTrain(child) then
                local id=JLRSPersist.identity(child);T.cache[id]=child
                channels[#channels+1]={name=id,index=0,mode='step'}
            end
        end
        table.sort(channels,function(a,b)return a.name<b.name end);return channels
    end,
    read=function(v,ch) local child=T.find(ch.name);return child and T.read(v,child) or {0,0,0,0,0,0} end,
    write=function(v,ch,values,paused,restoring)
        local child=T.find(ch.name);if not child then return end
        if restoring then T.disconnect(v,child);return end
        local previous=T.visual[child]
        local on=values[1]>=.5
        if previous and previous.parent==v and (not on or previous.joint~=values[2] or previous.input~=values[3]) then T.disconnect(v,child);previous=nil end
        if on and (not previous or previous.parent~=v) then T.connect(v,child,values,false) end
        -- No polling of the whole map for hose rendering; update only active hoses.
        if on and type(child.updateConnectionHose)=='function' then
            for i,hose in ipairs((child.spec_connectionHoses or {}).updateableHoses or {}) do
                if hose.connectedObject==v then child:updateConnectionHose(hose,i) end
            end
        end
    end
})
function T.restore(track)
    for _,item in ipairs(track.trailerOriginal or {}) do
        if JLRSRecorder.valid(item.parent) and JLRSRecorder.valid(item.child) then
            T.disconnect(item.parent,item.child);T.connect(item.parent,item.child,item.values,true)
        end
        if T.original[item.parent] then T.original[item.parent][item.child]=nil end
    end
    track.trailerOriginal=nil
end
local function prepareSafe(track)
    local ok,err=pcall(T.prepare,track)
    if not ok then
        pcall(T.restore,track)
        track:notify('Replay trailer batal: '..tostring(err))
    end
    return ok
end
local lock=JLRSRecorder.lockBodies
JLRSRecorder.lockBodies=function(track,...)
    if not prepareSafe(track) then return false end
    local result=lock(track,...)
    if result==false then T.restore(track) end
    return result
end
local isolate=JLRSLive.detachPhysics
JLRSLive.detachPhysics=function(track,...)
    if not prepareSafe(track) then return false end
    local result=isolate(track,...)
    if result==false then T.restore(track) end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    local result=stop(track,...);T.restore(track);return result
end
function T.resetBegin(c,vehicles,frames)
    local desired={};local active={};for _,v in ipairs(vehicles) do active[v]=true end
    for _,item in ipairs(c.trailerResetSnapshot or {}) do
        if active[item.parent] and JLRSRecorder.valid(item.child) then desired[item.child]=item end
    end
    local data=frames and frames.jlrsActivities
    if data and data.frames and JLRSFrames.count(data.frames)>0 then
        local pose=JLRSFrames.get(data.frames,1).pose
        for i,ch in ipairs(data.schema) do if ch.getter==NAME then
            local parent=JLRSActivities.resolve(ch,vehicles);local child=T.find(ch.name)
            if parent and child then
                local values={};for j=1,6 do values[j]=pose[(i-1)*6+j] end
                -- An unattached channel must not overwrite another parent's attachment.
                if values[1]>=.5 then desired[child]={parent=parent,child=child,values=values}
                elseif desired[child] and desired[child].parent==parent then desired[child]=nil end
            end
        end end
    end
    for _,v in ipairs(vehicles) do
        local list={};for _,imp in ipairs(implements(v)) do list[#list+1]=imp.object end
        for _,child in ipairs(list) do if active[child] then T.detach(v,child) end end
    end
    return desired
end
function T.resetEnd(desired)
    for _,item in pairs(desired or {}) do T.connect(item.parent,item.child,item.values,true) end
end
local snapshot=JLRSResetVehicle.snapshot
JLRSResetVehicle.snapshot=function(c,...)
    local result=snapshot(c,...);c.trailerResetSnapshot={}
    for _,v in pairs((c.mission or {}).vehicles or {}) do
        for _,imp in ipairs(implements(v)) do if imp.object then
            c.trailerResetSnapshot[#c.trailerResetSnapshot+1]={parent=v,child=imp.object,values=T.read(v,imp.object)}
        end end
    end
    return result
end

local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=deleteMap(c,...)
    c.trailerResetSnapshot=nil;T.cache=setmetatable({},{__mode='v'})
    T.original=setmetatable({},{__mode='k'});T.visual=setmetatable({},{__mode='k'})
    return result
end
