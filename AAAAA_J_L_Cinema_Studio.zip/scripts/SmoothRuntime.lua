-- Cache repeated pose requests only inside a replay tick. Never cache seeks/recording.
JLRSSmooth={}
local sample=JLRSRecorder.sample
JLRSRecorder.sample=function(track,time,...)
    local cache=track.smoothSamples
    if cache then
        for _,item in ipairs(cache) do
            if item.time==time and item.frames==track.frames then return item.pose end
        end
    end
    local pose=sample(track,time,...)
    if cache and #cache<4 then cache[#cache+1]={time=time,frames=track.frames,pose=pose} end
    return pose
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    local previous=track.smoothSamples;track.smoothSamples=(track.finalSampleScope and previous) or {}
    -- Clear even when a native setter fails; the existing recovery wrapper owns the error.
    local ok,result=pcall(tick,track,...)
    track.smoothSamples=previous
    if not ok then error(result) end
    return result
end
-- The cache index is a housekeeping file, not the authoritative History. Do not
-- rewrite every idle object's index on each moving stream's full chunk.
local manifest=JLRSFrames.manifest
JLRSFrames.manifest=function(...)
    if JLReplayStudio.recording then JLRSFrames.indexDirty=true;return end
    local result=manifest(...);JLRSFrames.indexDirty=nil;return result
end
local stop=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    local result=stop(c,...)
    if not c.recording and JLRSFrames.indexDirty then
        local ok,err=pcall(JLRSFrames.manifest)
        if not ok then print('[J_L Cinema Studio] CACHE INDEX: '..tostring(err)) end
    end
    return result
end
