-- Additive route editor. Original motion/activity streams are never rewritten.
JLRSCurva={colors={{1,.3,.2},{.2,.85,1},{.35,1,.3},{1,.85,.15},{.9,.3,1},{.1,1,.85},{1,.5,.1},{.65,.7,1}}}
local C=JLRSCurva
local function copy(t)local r={};for k,v in pairs(t or {})do r[k]=v end;return r end
local function finite(n)return type(n)=='number' and n==n and math.abs(n)<1e12 end
local function init(c)c.curvaNames=c.curvaNames or {};c.curvas=c.curvas or {};c.curvaJobs=c.curvaJobs or {};c.curvaQueued=c.curvaQueued or {};c.curvaByFrames=c.curvaByFrames or {};c.curvaItems=c.curvaItems or {};c.curvaEnabled=c.curvaEnabled~=false end
local function parentOf(v)
 local native=v.getAttacherVehicle and v:getAttacherVehicle()or nil
 local visual=JLRSTrailers and JLRSTrailers.visual[v]
 return native or (visual and visual.parent)
end
function C.name(c,v)return (c.curvaNames or {})[JLRSPersist.identity(v)]or v.jlrsColorDisplayName or (v.getName and v:getName())or 'Vehicle'end
function C.rename(c,v,text)
 if not JLRSRecorder.valid(v)then return end;init(c)
 if text~=nil then
  text=tostring(text):gsub('[%c]',''):match('^%s*(.-)%s*$'):sub(1,64)
  if text==''then return end
  c.curvaNames[JLRSPersist.identity(v)]=text;c.curvaDirty=true;C.catalog(c);C.save(c)
 elseif g_gui and g_gui.showTextInputDialog then
  g_gui:showTextInputDialog({text='Rename Curva Vehicle',defaultText=C.name(c,v),maxCharacters=64,callback=function(value,ok)if ok then C.rename(c,v,value)end end})
 end
end
local function clipFor(c,track)
 local frames=track.frames
 while frames and frames.editingView do frames=frames.editingView.source end
 local clip=c.curvaByFrames[frames];if clip and clip.frames==frames then return clip end
 if track.curvaClipId then for _,item in ipairs(c.history or {})do if item.id==track.curvaClipId and item.frames==frames then c.curvaByFrames[frames]=item;return item end end end
 for _,item in ipairs(c.history or {})do if item.frames==frames then c.curvaByFrames[frames]=item;return item end end
end
local function rootOffset(clip,v)
 for i,e in ipairs(clip.entries or {})do if e.world and e.node==v.rootNode then return (i-1)*6 end end
 -- Legacy/rebound takes can identify the main body through their ownership map.
 local resolved=JLRSFinalEditing.entryOwners(clip).resolved
 for i,e in ipairs(clip.entries or {})do
  if e.world and resolved[i] and resolved[i].vehicle==v then return (i-1)*6 end
 end
end
function C.catalog(c)
 init(c);c.curvaItems={};c.curvaByFrames={}
 for _,clip in ipairs(c.history or {})do
  c.curvaByFrames[clip.frames]=clip
  for index,v in ipairs(clip.vehicles or {clip.target})do
   if v and not(JLRSWorld and JLRSWorld.isTrain(v))then
    local offset=rootOffset(clip,v)
    if offset then
     local key=clip.id..':'..index;local q=c.curvas[key]
     local name=C.name(c,v)
     local item={key=key,clip=clip,vehicle=v,index=index,offset=offset,name=('#%03d %s'):format(clip.id,name)}
     c.curvaItems[#c.curvaItems+1]=item
     if not q and not c.curvaQueued[key]then
      c.curvaQueued[key]=true;c.curvaJobs[#c.curvaJobs+1]={item=item,entries=clip.entries,index=1,points={},count=math.min(64,JLRSFrames.count(clip.frames))}
     end
    end
   end
  end
 end
 c.curvaSelection=math.max(1,math.min(c.curvaSelection or 1,#c.curvaItems))
end
local function interval(q,t)
 local p=q.points;local n=#p;if n<2 then return 1,0 end
 t=math.max(p[1].t,math.min(t,p[n].t));local low,high=1,n-1
 while low<=high do local mid=math.floor((low+high)/2);if p[mid+1].t<t then low=mid+1 elseif p[mid].t>t then high=mid-1 else return mid,(t-p[mid].t)/math.max(1e-9,p[mid+1].t-p[mid].t)end end
 return n-1,1
end
-- Time-parameterized cubic Hermite interpolation of original route + edited offsets.
function C.evaluate(q,t,offsetOnly)
 local p=q.points;if #p<2 then return 0,0,0 end
 local i,u=interval(q,t);local a,b=p[i],p[i+1];local prev,next=p[math.max(1,i-1)],p[math.min(#p,i+2)]
 local h=b.t-a.t;local out={};local h00=2*u^3-3*u^2+1;local h10=u^3-2*u^2+u;local h01=-2*u^3+3*u^2;local h11=u^3-u^2
 for k=1,3 do
  local function value(point)return (offsetOnly and 0 or point[k])+(point[k+3]or 0)end
  local av,bv=value(a),value(b)
  local m1=(value(b)-value(prev))/math.max(1e-9,b.t-prev.t);local m2=(value(next)-value(a))/math.max(1e-9,next.t-a.t)
  out[k]=h00*av+h10*h*m1+h01*bv+h11*h*m2
 end
 return out[1],out[2],out[3]
end
local function original(q,t)
 local p=q.points;local i,u=interval(q,t);local a,b=p[i],p[i+1];local prev,next=p[math.max(1,i-1)],p[math.min(#p,i+2)];local h=b.t-a.t;local out={}
 for k=1,3 do out[k]=(2*u^3-3*u^2+1)*a[k]+(u^3-2*u^2+u)*h*(b[k]-prev[k])/math.max(1e-9,b.t-prev.t)+(-2*u^3+3*u^2)*b[k]+(u^3-u^2)*h*(next[k]-a[k])/math.max(1e-9,next.t-a.t)end
 return out[1],out[2],out[3]
end
function C.recount(c)
 c.curvaHasSpeed=false;for _,route in pairs(c.curvas or {})do if route.enabled~=false and not route.deleted and (route.speed or 1)~=1 then c.curvaHasSpeed=true;break end end
 c.curvaHasEdits=false;for _,route in pairs(c.curvas or {})do if route.changed and route.enabled~=false and not route.deleted then c.curvaHasEdits=true;break end end
end
function C.compile(q)
 q.changed=(q.speed or 1)~=1;for _,p in ipairs(q.points)do for k=4,6 do if math.abs(p[k]or 0)>1e-9 then q.changed=true end end end
 q.lengths={};local total=0
 for i=1,#q.points-1 do
  local a,b=q.points[i],q.points[i+1];local row={total};local x,y,z=C.evaluate(q,a.t);local ox,oy,oz=original(q,a.t)
  for j=1,16 do local t=a.t+(b.t-a.t)*j/16;local nx,ny,nz=C.evaluate(q,t);local nox,noy,noz=original(q,t)
   local delta=math.sqrt((nx-x)^2+(ny-y)^2+(nz-z)^2)-math.sqrt((nox-ox)^2+(noy-oy)^2+(noz-oz)^2)
   local forward=(nox-ox)*math.sin(a.yaw or 0)+(noz-oz)*math.cos(a.yaw or 0)
   total=total+delta*(forward<0 and -1 or 1);row[#row+1]=total;x,y,z=nx,ny,nz;ox,oy,oz=nox,noy,noz
  end
  q.lengths[i]=row
 end
 q.preview={}
 for i=1,#q.points-1 do local a,b=q.points[i],q.points[i+1];for j=0,3 do q.preview[#q.preview+1]={C.evaluate(q,a.t+(b.t-a.t)*j/4)}end end
 q.preview[#q.preview+1]={C.evaluate(q,q.points[#q.points].t)}
 q.revision=(q.revision or 0)+1
 if JLReplayStudio then C.recount(JLReplayStudio)end
end
local function geometry(q,t)
 local first,last=q.points[1].t,q.points[#q.points].t;local epsilon=math.max(.001,math.min(.02,(last-first)/1000))
 local a,b=math.max(first,t-epsilon),math.min(last,t+epsilon);local x,y,z=C.evaluate(q,t);local ax,ay,az=C.evaluate(q,a);local bx,by,bz=C.evaluate(q,b)
 local ox,oy,oz=original(q,t);local oax,oay,oaz=original(q,a);local obx,oby,obz=original(q,b)
 local dx,dy,dz=bx-ax,by-ay,bz-az;local odx,ody,odz=obx-oax,oby-oay,obz-oaz
 local yaw,pitch=0,0
 if dx*dx+dz*dz>1e-10 and odx*odx+odz*odz>1e-10 then
  yaw=JLRSRecorder.angle(math.atan2(odx,odz),math.atan2(dx,dz),1)-math.atan2(odx,odz)
  pitch=-math.atan2(dy,math.sqrt(dx*dx+dz*dz))+math.atan2(ody,math.sqrt(odx*odx+odz*odz))
 end
 local function curvature(cx,cz,px,pz,nx,nz)
  local vx,vz=nx-px,nz-pz;local span=b-a
  local accx,accz=nx-2*cx+px,nz-2*cz+pz
  local norm=vx*vx+vz*vz;if norm<1e-10 or span<1e-9 then return 0 end
  return 4*(vz*accx-vx*accz)/norm^1.5
 end
 local steering=curvature(x,z,ax,az,bx,bz);local oldSteer=curvature(ox,oz,oax,oaz,obx,obz)
 local i,u=interval(q,t);local row=q.lengths[i];local f=u*16;local j=math.min(15,math.floor(f));local roll=row and (row[j+1]+(row[j+2]-row[j+1])*(f-j))or 0
 local sx,sy,sz=C.evaluate(q,t,true)
 local heading=q.points[i].yaw or 0;local sign=odx*math.sin(heading)+odz*math.cos(heading)<0 and -1 or 1
 return sx,sy,sz,yaw,pitch,steering*sign,oldSteer*sign,roll
end
function C.process(c)
 init(c);if c.recording or c.finalRecording then return end
 for _=1,2 do
  local job=c.curvaJobs[1];if not job then return end
  local item=job.item
  if job.entries~=item.clip.entries then job.entries=item.clip.entries;job.index=1;job.points={};item.vehicle=(item.clip.vehicles or {})[item.index]or item.clip.target;item.offset=item.vehicle and rootOffset(item.clip,item.vehicle)or item.offset end
  local n=JLRSFrames.count(item.clip.frames)
  if c.curvaByFrames[item.clip.frames]~=item.clip then n=0 end
  if job.count<2 or n<2 then table.remove(c.curvaJobs,1);c.curvaQueued[item.key]=nil
  else
   local index=math.floor((job.index-1)*(n-1)/(job.count-1))+1;local f=JLRSFrames.get(item.clip.frames,index);local o=item.offset
   if #job.points==0 or f.t>job.points[#job.points].t then job.points[#job.points+1]={f.pose[o+1],f.pose[o+2],f.pose[o+3],0,0,0,t=f.t,yaw=f.pose[o+5]}end
   job.index=job.index+1
   if job.index>job.count then
    if #job.points>=2 and not c.curvas[item.key]then local q={points=job.points,color=#c.curvaItems%#C.colors+1,enabled=true};q.color=tonumber(item.key:match('^(%d+)'))*31+item.index;C.compile(q);c.curvas[item.key]=q;C.recount(c) end
    c.curvaQueued[item.key]=nil;table.remove(c.curvaJobs,1)
   end
  end
 end
end
local motionSource,bodySource
local function helpers(c)
 if c.curvaHelpers then return c.curvaHelpers end
 local h={};for i=1,3 do h[i]=createTransformGroup('JLRS_Curva_'..i);link(getRootNode(),h[i])end;c.curvaHelpers=h;return h
end
function C.transform(track,time,pose,bodyOnly)
 local c=JLReplayStudio;if not c or not c.curvaEnabled or not c.curvas or not c.curvaHasEdits then if not bodyOnly then track.curvaWheelNodes=nil;track.curvaApplied=false end;return pose end
 local clip=clipFor(c,track);if not clip then if not bodyOnly then track.curvaWheelNodes=nil;track.curvaApplied=false end;return pose end
 local plan=track.curvaPlan
 if not plan or plan.entries~=track.entries or plan.clip~=clip or plan.vehicles~=clip.vehicles then
  plan={entries=track.entries,clip=clip,vehicles=clip.vehicles,groups={},wheels={}};track.curvaPlan=plan
  local owners=JLRSFinalEditing.entryOwners(clip).resolved;local nodeOwner={}
  for i,e in ipairs(clip.entries)do if owners[i]then nodeOwner[e.node]=owners[i].vehicle end end
  for vi,v in ipairs(clip.vehicles or {clip.target})do
   local group={key=clip.id..':'..vi,vehicle=v,world={},locals={},wheels={},wheelbase=2.5}
   local minz,maxz
   local roles={}
   for wi,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do
    local steering=math.abs(tonumber(w.rotSpeed)or 0)>1e-9 or (v.spec_drivable and wi<=2)
    local function add(wheel)
     if wheel.repr then roles[wheel.repr]={kind='repr',wheel=wheel,steering=steering}end
     if wheel.driveNode then roles[wheel.driveNode]={kind='drive',wheel=wheel,steering=steering}end
     for _,extra in ipairs(wheel.additionalWheels or {})do add(extra)end
    end;add(w)
    if w.repr and entityExists(w.repr)then local x,y,z=getWorldTranslation(w.repr);local rx,ry,rz=getWorldTranslation(v.rootNode);local _,_,lz=worldDirectionToLocal(v.rootNode,x-rx,y-ry,z-rz);minz=minz and math.min(minz,lz)or lz;maxz=maxz and math.max(maxz,lz)or lz end
   end
   if minz and maxz and maxz-minz>.1 then group.wheelbase=maxz-minz end
   for i,e in ipairs(track.entries or {})do
    local offset=(i-1)*6
    if e.node==v.rootNode then group.root=offset end
    if (e.vehicle or nodeOwner[e.node])==v or e.node==v.rootNode then
     if not e.world then group.locals[#group.locals+1]=offset end
     if e.world then group.world[#group.world+1]=offset elseif roles[e.node]then local role=roles[e.node];group.wheels[#group.wheels+1]={offset=offset,role=role,node=e.node}end
    end
   end
   if group.root then plan.groups[#plan.groups+1]=group end
  end
 end
 local out;track.curvaWheelNodes=track.curvaWheelNodes or {}
 if not bodyOnly then track.curvaWheelNodes={}end
 local function active(group)
  local visited={}
  while group and not visited[group]do
   visited[group]=true;local q=c.curvas[group.key]
   if q and q.changed and not q.deleted and q.enabled~=false then return q,group end
   local v=group.vehicle;local parent=parentOf(v);group=nil
   for _,candidate in ipairs(plan.groups)do if candidate.vehicle==parent then group=candidate;break end end
  end
 end
 for _,g in ipairs(plan.groups)do local q,anchor=active(g)
  if q and q.changed and not q.deleted and q.enabled~=false and pose[g.root+1]then
   out=out or copy(pose);local routeTime=q.points[1].t+(time-q.points[1].t)*(q.speed or 1)
   local sourcePose=pose
   if (q.speed or 1)~=1 then
    local cursor=track.frameIndex;sourcePose=(bodyOnly and bodySource or motionSource)(track,routeTime);track.frameIndex=cursor
   end
   local x,y,z,yaw,pitch,steering,oldSteer,roll=geometry(q,routeTime);local o=anchor.root
   if not bodyOnly then
    for _,offset in ipairs(g.locals)do for j=1,6 do out[offset+j]=sourcePose[offset+j]end end
    if g.vehicle==clip.target then for j=#(track.entries or {})*6+1,#sourcePose do out[j]=sourcePose[j]end end
   end
   local h=helpers(c)
   setTranslation(h[1],sourcePose[o+1],sourcePose[o+2],sourcePose[o+3]);setRotation(h[1],sourcePose[o+4],sourcePose[o+5],sourcePose[o+6])
   setTranslation(h[2],sourcePose[o+1]+x,sourcePose[o+2]+y,sourcePose[o+3]+z);setRotation(h[2],sourcePose[o+4]+pitch,sourcePose[o+5]+yaw,sourcePose[o+6])
   for _,n in ipairs(g.world)do
    if sourcePose[n+1]then
     link(h[1],h[3]);setWorldTranslation(h[3],sourcePose[n+1],sourcePose[n+2],sourcePose[n+3]);setWorldRotation(h[3],sourcePose[n+4],sourcePose[n+5],sourcePose[n+6])
     local lx,ly,lz=getTranslation(h[3]);local rx,ry,rz=getRotation(h[3]);link(h[2],h[3]);setTranslation(h[3],lx,ly,lz);setRotation(h[3],rx,ry,rz)
     out[n+1],out[n+2],out[n+3]=getWorldTranslation(h[3]);out[n+4],out[n+5],out[n+6]=getWorldRotation(h[3])
    end
   end
   if not bodyOnly then
    local delta=math.atan(g.wheelbase*steering)-math.atan(g.wheelbase*oldSteer)
    for _,w in ipairs(g.wheels)do local n=w.offset;local role=w.role
     if sourcePose[n+1]then
      if role.kind=='drive' then out[n+4]=sourcePose[n+4]+roll/math.max(.001,role.wheel.radius or 1)end
      if role.kind=='repr' and role.steering then out[n+5]=sourcePose[n+5]+delta end
      track.curvaWheelNodes[w.node]=true
     end
    end
   end
  end
 end
 if not bodyOnly then track.curvaApplied=out~=nil end
 return out or pose
end
local sample=JLRSRecorder.sample;motionSource=sample
JLRSRecorder.sample=function(track,time,...)return C.transform(track,time,sample(track,time,...),false)end
local body=JLRSFinalReplayPerf.bodySample;bodySource=body
JLRSFinalReplayPerf.bodySample=function(track,time,...)return C.transform(track,time,body(track,time,...),true)end
local wheelPose=JLRSWheelVisual.standardPose
JLRSWheelVisual.standardPose=function(state)
 if state and state.track.replaying and state.track.curvaWheelNodes and state.track.curvaWheelNodes[state.node]then
  local track=state.track;local pose=track.replayAudioTime==track.replayTime and track.replayAudioPose
  if pose then local n=state.offset;state.x,state.y,state.z=pose[n+1],pose[n+2],pose[n+3];state.rx,state.ry,state.rz=pose[n+4],pose[n+5],pose[n+6];return true end
 end
 return wheelPose(state)
end
function C.save(c)
 init(c);if c.curvaLoadError then c:notify('File Curva rusak; pemulihan diperlukan sebelum Save.');return false end
 local ok,why=pcall(function()
  assert(JLRSFrames.directory,'Folder cache belum tersedia.')
  local revision=(c.curvaRevision or 0)+1;local path=JLRSFrames.directory..'curva_'..(revision%2==0 and 'A.xml' or 'B.xml')
  local xml=assert(XMLFile.create('jlrsCurva',path,'curva'))
  local written,err=pcall(function()
   xml:setInt('curva#revision',revision);xml:setInt('curva#enabled',c.curvaEnabled and 1 or 0);local count=0
   for key,q in pairs(c.curvas)do
    local k='curva.route('..count..')';xml:setString(k..'#key',key);xml:setInt(k..'#color',q.color or 1);xml:setInt(k..'#enabled',q.enabled~=false and 1 or 0);xml:setInt(k..'#deleted',q.deleted and 1 or 0);xml:setInt(k..'#points',#q.points);xml:setString(k..'#speed',tostring(q.speed or 1))
    for i,p in ipairs(q.points)do local v={p.t,p.yaw or 0};for j=1,6 do v[#v+1]=p[j]or 0 end;xml:setString(k..'.point('..(i-1)..')#data',table.concat(v,' '))end
    count=count+1
   end
   xml:setInt('curva#count',count);local names=0
   for id,name in pairs(c.curvaNames or {})do local k='curva.name('..names..')';xml:setString(k..'#vehicle',id);xml:setString(k..'#text',name);names=names+1 end
   xml:setInt('curva#names',names);xml:setString('curva#complete','JLRS_CURVA_1');assert(xml:save()~=false,'Save Curva gagal / disk penuh.')
  end)
  xml:delete();if not written then error(err)end
  local check=assert(XMLFile.load('jlrsCurvaVerify',path));local valid=check:getString('curva#complete')=='JLRS_CURVA_1'and check:getInt('curva#revision')==revision;check:delete();assert(valid,'Verifikasi Curva gagal.')
  c.curvaRevision=revision;c.curvaDirty=false
 end)
 c:notify(ok and 'Curva tersimpan | rekaman asli tetap utuh' or ('Save Curva gagal: '..tostring(why)));return ok
end
function C.load(c)
 init(c);if c.curvaLoaded or c.jlrsLoadPending or not JLRSFrames.directory then return end
 local best,exists
 for _,suffix in ipairs({'A.xml','B.xml'})do
  local path=JLRSFrames.directory..'curva_'..suffix
  if fileExists(path)then
   exists=true;local xml=XMLFile.load('jlrsCurvaLoad',path)
   if xml then
    local ok,data=pcall(function()
     assert(xml:getString('curva#complete')=='JLRS_CURVA_1');local count=xml:getInt('curva#count',0);assert(count>=0 and count<=100000)
     local data={revision=xml:getInt('curva#revision',0),enabled=xml:getInt('curva#enabled',1)==1,routes={},names={}}
     for i=0,count-1 do
      local k='curva.route('..i..')';local key=xml:getString(k..'#key','');assert(key:match('^%d+:%d+$'))
      local n=xml:getInt(k..'#points',0);assert(n>=2 and n<=10000);local q={points={},enabled=xml:getInt(k..'#enabled',1)==1,deleted=xml:getInt(k..'#deleted',0)==1,color=xml:getInt(k..'#color',1)}
      q.speed=tonumber(xml:getString(k..'#speed','1'));assert(finite(q.speed)and q.speed>=.1 and q.speed<=1)
      for j=0,n-1 do
       local values={};for word in xml:getString(k..'.point('..j..')#data',''):gmatch('%S+')do local num=tonumber(word);assert(finite(num));values[#values+1]=num end
       assert(#values==8);local p={t=values[1],yaw=values[2]};for index=1,6 do p[index]=values[index+2]end
       assert(not q.points[#q.points]or p.t>q.points[#q.points].t);q.points[#q.points+1]=p
      end
      C.compile(q);data.routes[key]=q
     end
     local names=xml:getInt('curva#names',0);assert(names>=0 and names<=100000)
     for i=0,names-1 do local k='curva.name('..i..')';local id=xml:getString(k..'#vehicle','');local name=xml:getString(k..'#text',''):sub(1,64);if id~=''and name~=''then data.names[id]=name end end
     return data
    end)
    xml:delete();if ok and (not best or data.revision>best.revision)then best=data end
   end
  end
 end
 if best then c.curvaNames=best.names or {};c.curvas=best.routes;c.curvaRevision=best.revision;c.curvaEnabled=best.enabled elseif exists then c.curvaLoadError=true;c:notify('File Curva tidak dapat dibaca; rekaman asli tetap digunakan.')end
 c.curvaLoaded=true;C.recount(c);C.catalog(c)
end
function C.selected(c)local item=c.curvaItems[c.curvaSelection or 1];return item,item and c.curvas[item.key]end
local function canEdit(c)
 if c.recording or c.replaying or c.finalRecording or c.finalPlaying or #(c.liveTracks or {})>0 or c.changePending then c:notify('Stop Record / Replay sebelum edit Curva.');return false end
 return true
end
function C.move(c,index,axis,delta)
 if not canEdit(c)then return false end
 local _,q=C.selected(c);local p=q and q.points[index];if not p or q.deleted or not finite(delta)then return false end
 if c.curvaWhole then for _,point in ipairs(q.points)do point[axis+3]=(point[axis+3]or 0)+delta end else p[axis+3]=(p[axis+3]or 0)+delta end;C.compile(q);c.curvaDirty=true;return true
end
function C.addPoint(c)
 if not canEdit(c)then return end
 local _,q=C.selected(c);if not q or q.deleted then return end
 local index=math.min(c.curvaPoint or 1,#q.points-1);local a,b=q.points[index],q.points[index+1];local t=(a.t+b.t)/2
 if t==a.t or t==b.t then return end
 local x,y,z=original(q,t);local dx,dy,dz=C.evaluate(q,t,true)
 table.insert(q.points,index+1,{x,y,z,dx,dy,dz,t=t,yaw=JLRSRecorder.angle(a.yaw or 0,b.yaw or 0,.5)});c.curvaPoint=index+1;C.compile(q);c.curvaDirty=true
end
function C.removePoint(c)
 if not canEdit(c)then return end
 local _,q=C.selected(c);local index=c.curvaPoint or 1
 if not q or #q.points<=2 or index<=1 or index>=#q.points then c:notify('Titik awal dan akhir dipertahankan.');return end
 table.remove(q.points,index);c.curvaPoint=math.min(index,#q.points);C.compile(q);c.curvaDirty=true
end
function C.reset(c,remove)
 if not canEdit(c)then return end
 local _,q=C.selected(c);if not q then return end
 for _,p in ipairs(q.points)do p[4],p[5],p[6]=0,0,0 end
 q.speed=1;q.deleted=remove==true;q.enabled=not q.deleted;C.compile(q);c.curvaPoint=1;c.curvaDirty=true
end
function C.open(c)
 init(c);C.load(c);C.catalog(c);c.curvaReturnMenu=c.menu;c.curvaOpen=true;c.menu=true;c.curvaEdit=false;c.curvaPoint=1;JLRSMouse.refresh(c)
end
function C.close(c)c.curvaOpen=false;c.curvaEdit=false;c.curvaDrag=nil;c.menu=c.curvaReturnMenu or false;c.hitboxes={};JLRSMouse.refresh(c);JLRSMouse.syncCursor(c)end
local function screen(x,y,z)
 if not project then return end
 local sx,sy,sz=project(x,y,z);if not sx or not sy or (sz and (sz<0 or sz>1))then return end
 return sx,sy
end
function C.rgb(color)
 local hue=((color or 1)*.61803398875)%1;local h=hue*6;local i=math.floor(h);local f=h-i;local low=.2;local falling=1-.8*f;local rising=.2+.8*f
 local palette={{1,rising,low},{falling,1,low},{low,1,rising},{low,falling,1},{rising,low,1},{1,low,falling}}
 return palette[i%6+1]
end
local function line(a,b,rgb)
 if not drawDebugLine then return end
 local function draw(p,q,color)
  drawDebugLine(p[1],p[2],p[3],color[1],color[2],color[3],q[1],q[2],q[3],color[1],color[2],color[3],false)
 end
 local terrain=g_currentMission and g_currentMission.terrainRootNode
 if not terrain or terrain==0 or not entityExists(terrain)or type(getTerrainHeightAtWorldPos)~='function'then draw(a,b,rgb);return end
 local function at(t)return {a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t,a[3]+(b[3]-a[3])*t}end
 local function below(p)return p[2]<getTerrainHeightAtWorldPos(terrain,p[1],0,p[3])-.01 end
 -- Small local sections preserve vehicle colors outside underground portions.
 local length=math.sqrt((b[1]-a[1])^2+(b[2]-a[2])^2+(b[3]-a[3])^2)
 local steps=math.max(1,math.min(32,math.ceil(length/.5)))
 local previous=a;local old=below(a)
 for i=1,steps do
  local next=at(i/steps);local under=below(next)
  if old~=under then
   local lo,hi=(i-1)/steps,i/steps
   for _=1,8 do local mid=(lo+hi)/2;if below(at(mid))==old then lo=mid else hi=mid end end
   local cut=at((lo+hi)/2);draw(previous,cut,old and {0,0,0}or rgb);draw(cut,next,under and {0,0,0}or rgb)
  else draw(previous,next,under and {0,0,0}or rgb)end
  previous=next;old=under
 end
end
function C.routeDraw(c)
 c.curvaPointHits={};c.curvaAxes={}
 if not c.curvaEnabled or not c.curvaOpen then return end
 for _,item in ipairs(c.curvaItems)do local q=c.curvas[item.key]
  if q and not q.deleted and q.enabled~=false then
   local rgb=C.rgb(q.color);for i=1,#(q.preview or {})-1 do line(q.preview[i],q.preview[i+1],rgb)end
  end
 end
 local item,q=C.selected(c);if not q or q.deleted or q.enabled==false then return end
 for i,p in ipairs(q.points)do
  local x,y,z=p[1]+p[4],p[2]+p[5],p[3]+p[6]
  if drawDebugPoint then drawDebugPoint(x,y,z,1,1,1,1,false)end
  local sx,sy=screen(x,y,z)
  if sx and sx>=0 and sx<.735 and sy>=0 and sy<=1 then
   JLRSMenu.rect(c,sx-.003,sy-.004,.006,.008,i==c.curvaPoint and 1 or .7,1,.3)
   c.curvaPointHits[#c.curvaPointHits+1]={x=sx,y=sy,index=i}
  end
 end
 if not c.curvaEdit then return end
 local p=q.points[c.curvaPoint or 1];if not p then return end
 local center={p[1]+p[4],p[2]+p[5],p[3]+p[6]};local sx,sy=screen(unpack(center));if not sx then return end
 local camera=getCamera();local x,y,z=getWorldTranslation(camera);local size=math.max(1,math.min(20,math.sqrt((x-center[1])^2+(y-center[2])^2+(z-center[3])^2)*.08))
 for axis=1,3 do local endpoint=copy(center);endpoint[axis]=endpoint[axis]+size;local rgb=axis==1 and {1,.2,.2}or axis==2 and {.2,1,.2}or {.2,.5,1};line(center,endpoint,rgb)
  local ex,ey=screen(unpack(endpoint));if ex then
   JLRSMenu.text(ex,ey,.014,({'X','Y','Z'})[axis],rgb[1],rgb[2],rgb[3]);c.curvaAxes[#c.curvaAxes+1]={axis=axis,x=sx,y=sy,ex=ex,ey=ey,size=size}
  end
 end
end
function C.draw(c)
 local M=JLRSMenu;c.hitboxes={};C.routeDraw(c)
 M.rect(c,.735,.12,.25,.72,.015,.025,.04,.97);M.text(.75,.805,.021,'CURVA',.2,.9,1)
 M.button(c,.945,.797,.025,.03,'X',function()C.close(c)end)
 M.button(c,.75,.749,.22,.033,'Curva: '..(c.curvaEnabled and 'ON' or 'OFF'),function()c.curvaEnabled=not c.curvaEnabled;c.curvaDirty=true end,c.curvaEnabled)
 local item,q=C.selected(c)
 M.button(c,.75,.699,.032,.032,'<',function()c.curvaSelection=math.max(1,(c.curvaSelection or 1)-1);c.curvaPoint=1 end)
 M.button(c,.938,.699,.032,.032,'>',function()c.curvaSelection=math.min(#c.curvaItems,(c.curvaSelection or 1)+1);c.curvaPoint=1 end)
 local label=item and item.name or 'Belum ada record';M.text(.79,.712,.011,JLRSHistoryGroups.fitName(label,.011,.14))
 M.text(.75,.678,.01,string.format('%d / %d kendaraan | %d titik',c.curvaSelection or 0,#c.curvaItems,q and #q.points or 0))
 local rgb=q and C.rgb(q.color)or {.5,.5,.5};M.rect(c,.75,.666,.22,.004,unpack(rgb))
 M.button(c,.75,.616,.22,.034,'Edit Curva: '..(c.curvaEdit and 'ON' or 'OFF'),function()if canEdit(c)then c.curvaEdit=not c.curvaEdit end end,c.curvaEdit)
 M.button(c,.75,.571,.105,.034,'+ TITIK',function()C.addPoint(c)end);M.button(c,.865,.571,.105,.034,'- TITIK',function()C.removePoint(c)end)
 M.button(c,.75,.526,.105,.034,'RESET',function()C.reset(c,false)end);M.button(c,.865,.526,.105,.034,'DELETE',function()C.reset(c,true)end,false,{.5,.08,.12})
 M.button(c,.75,.481,.22,.034,'SAVE CURVA',function()C.save(c)end)
 local p=q and q.points[c.curvaPoint or 1];M.text(.75,.454,.011,'Titik '..(c.curvaPoint or 1)..(p and (' | '..string.format('%.2fs',p.t))or ''))
 for axis=1,3 do local y=.407-(axis-1)*.044
  M.text(.75,y+.01,.013,({'X','Y','Z'})[axis]);M.button(c,.78,y,.035,.031,'-',function()C.move(c,c.curvaPoint or 1,axis,-(c.curvaStep or .25))end)
  M.text(.825,y+.01,.01,p and string.format('%.2f',p[axis]+p[axis+3])or '--');M.button(c,.935,y,.035,.031,'+',function()C.move(c,c.curvaPoint or 1,axis,c.curvaStep or .25)end)
 end


 M.text(.75,.139,.009,c.curvaDirty and 'Belum disimpan' or 'Curva siap',1,.75,.3)


end
local function distance(x,y,a)
 local dx,dy=a.ex-a.x,a.ey-a.y;local length=dx*dx+dy*dy;if length<1e-8 then return 1 end
 local t=math.max(.15,math.min(1,((x-a.x)*dx+(y-a.y)*dy)/length))
 return math.sqrt((x-a.x-dx*t)^2+(y-a.y-dy*t)^2)
end
function C.mouse(c,x,y,down,up,button)
 c.mouseX=x;c.mouseY=y
 if c.curvaDrag then
  local d=c.curvaDrag;local a=d.axis;local dx,dy=a.ex-a.x,a.ey-a.y;local denominator=dx*dx+dy*dy
  if denominator>1e-8 then
   local displacement=((x-d.x)*dx+(y-d.y)*dy)/denominator*a.size;local _,q=C.selected(c)
   if q then local p=q.points[d.index];p[a.axis+3]=d.start+displacement;C.compile(q);c.curvaDirty=true end
  end
  if up then c.curvaDrag=nil end;return
 end
 if down and (button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN)then
  if x>=.735 then c.curvaSelection=math.max(1,math.min(#c.curvaItems,(c.curvaSelection or 1)+(button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1)));c.curvaPoint=1 end;return
 end
 if not down or button~=Input.MOUSE_BUTTON_LEFT then return end
 if x>=.735 then JLRSMenu.click(c,x,y,down,button);return end
 if not c.curvaEdit or not canEdit(c)then return end
 local best,dist;for _,a in ipairs(c.curvaAxes or {})do local d=distance(x,y,a);if d<.012 and (not dist or d<dist)then best=a;dist=d end end
 if best then local _,q=C.selected(c);local p=q and q.points[c.curvaPoint or 1];if p then c.curvaDrag={axis=best,index=c.curvaPoint or 1,start=p[best.axis+3],x=x,y=y}end;return end
 local hit,near;for _,p in ipairs(c.curvaPointHits or {})do local d=(x-p.x)^2+(y-p.y)^2;if d<.0004 and (not near or d<near)then hit=p;near=d end end
 if hit then c.curvaPoint=hit.index;if hit.routeIndex then c.curvaSelection=hit.routeIndex end end
end
local menu=JLRSMenu.draw
JLRSMenu.draw=function(c,...)
 if c.curvaOpen and c.menu then return C.draw(c)end
 local result=menu(c,...)
 return result
end
local toggle=JLRSMenu.toggle
JLRSMenu.toggle=function(c,...)if c.curvaOpen then return C.close(c)end;return toggle(c,...)end
local archive=JLRSHistory.archive
JLRSHistory.archive=function(c,...)local result=archive(c,...);if c.curvaOpen then C.catalog(c)end;return result end
local update=JLReplayStudio.update
JLReplayStudio.update=function(c,...)
 local result=update(c,...)
 if not c.curvaLoaded then C.load(c)end
 if c.curvaLoaded and c.curvaOpen and (not c.curvaCatalogClock or (g_time or 0)>=c.curvaCatalogClock)then C.catalog(c);c.curvaCatalogClock=(g_time or 0)+1000 end
 if c.curvaLoaded and c.curvaOpen then C.process(c)end
 return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
 local result=load(c,...);c.curvaNames={};c.curvas={};c.curvaJobs={};c.curvaQueued={};c.curvaByFrames={};c.curvaItems={};c.curvaEnabled=true;c.curvaLoaded=false;c.curvaOpen=false;c.curvaRevision=0;c.curvaDirty=false;c.curvaCatalogClock=nil;c.curvaLoadError=nil;c.curvaHelpers=nil;c.curvaHasEdits=false
 if c.mission then
  local previous=c.mission.mouseEvent;c.curvaPreviousMouse=previous
  c.curvaMouse=function(m,x,y,down,up,button,...)
   if c.curvaOpen and c.menu and not(g_gui and g_gui:getIsGuiVisible())then return C.mouse(c,x,y,down,up,button)end
   return previous(m,x,y,down,up,button,...)
  end
  c.mission.mouseEvent=c.curvaMouse
 end;return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
 if c.curvaDirty and c.curvaLoaded then C.save(c)end
 if c.mission and c.mission.mouseEvent==c.curvaMouse then c.mission.mouseEvent=c.curvaPreviousMouse end
 c.curvaOpen=false;c.curvaDrag=nil
 local result=unload(c,...)
 for _,n in ipairs(c.curvaHelpers or {})do if entityExists(n)then delete(n)end end
 c.curvaHelpers=nil;c.curvas={};c.curvaJobs={};return result
end

-- V1.18.89: vehicle selection, isolated edit history and orthogonal editor camera.
function C.routes(c)
 if c.curvaPage~='edit' then return c.curvaItems or {} end
 local items={};for _,item in ipairs(c.curvaItems or {})do if (c.curvaMarked or {})[item.vehicle]then items[#items+1]=item end end;return items
end
function C.selected(c)local item=C.routes(c)[c.curvaSelection or 1];return item,item and c.curvas[item.key]end
function C.vehicles(c)
 local result,seen={},{};for _,v in ipairs((c.mission or g_currentMission or {}).vehicles or {})do
  if not seen[v] and JLRSRecorder.valid(v) and not(JLRSWorld and JLRSWorld.isTrain(v))then seen[v]=true;result[#result+1]=v end
 end
 table.sort(result,function(a,b)return ((a.getName and a:getName())or '')<((b.getName and b:getName())or '')end);return result
end
local function snapshot(q)
 local result={enabled=q.enabled,deleted=q.deleted,color=q.color,speed=q.speed or 1,points={}}
 for i,p in ipairs(q.points)do result.points[i]=copy(p)end;return result
end
function C.commit(c,key,before)
 local q=c.curvas[key];if not q or not before then return end
 local after=snapshot(q);local different=(before.speed or 1)~=(after.speed or 1) or before.deleted~=after.deleted or before.enabled~=after.enabled or #before.points~=#after.points
 if not different then for i,p in ipairs(before.points)do for k=4,6 do if p[k]~=after.points[i][k]then different=true end end end end
 if different then c.curvaUndo=c.curvaUndo or {};c.curvaUndo[#c.curvaUndo+1]={key=key,before=before,after=after};c.curvaRedo={} end
end
for _,method in ipairs({'move','addPoint','removePoint','reset'})do
 local previous=C[method];C[method]=function(c,...)
  local item,q=C.selected(c);local before=q and snapshot(q);local result=previous(c,...);if item then C.commit(c,item.key,before)end;return result
 end
end
function C.undo(c,redo)
 if not canEdit(c)then return end
 local from=redo and c.curvaRedo or c.curvaUndo;local action=from and table.remove(from);if not action then return end
 local value=redo and action.after or action.before;c.curvas[action.key]=snapshot(value);C.compile(c.curvas[action.key]);C.recount(c);c.curvaPoint=1;c.curvaDirty=true
 local to=redo and 'curvaUndo' or 'curvaRedo';c[to]=c[to]or {};c[to][#c[to]+1]=action
end
function C.releaseCamera(c)
 local p=c.curvaViewCamera;c.curvaViewCamera=nil
 if p then if entityExists(p.previous)then setCamera(p.previous)else local n=JLRSCamera.gameplay();if n and entityExists(n)then setCamera(n)end end;if entityExists(p.node)then delete(p.node)end end
 JLRSCamera.clearInput(c)
end
function C.view(c,mode)
 if not canEdit(c)then return end
 local item,q=C.selected(c);if not item then return end
 local point=q and q.points[c.curvaPoint or 1];local x,y,z
 if point then x,y,z=point[1]+point[4],point[2]+point[5],point[3]+point[6]else x,y,z=getWorldTranslation(item.vehicle.rootNode)end
 if not c.curvaViewCamera then local node=createCamera('JLRS_Curva_View',math.rad(55),.1,6000);link(getRootNode(),node);c.curvaViewCamera={node=node,previous=getCamera()}end
 local p=c.curvaViewCamera;local d=math.max(12,(tonumber(item.vehicle.sizeLength)or 8)*2)
 local offset=mode=='ATAS' and {0,d,0}or mode=='SAMPING' and {d,3,0}or mode=='DEPAN' and {0,3,d}or {0,3,-d}
 -- Orthogonal views: zero roll and no tilt for horizontal views.
 p.position={x+offset[1],y+offset[2],z+offset[3]};p.rotation=mode=='ATAS' and {-math.pi/2,0,0}or {0,mode=='SAMPING' and math.pi/2 or mode=='DEPAN' and 0 or math.pi,0}
 p.mode=mode;setTranslation(p.node,unpack(p.position));setRotation(p.node,unpack(p.rotation));setCamera(p.node);JLRSCamera.clearInput(c)
end
function C.cameraTick(c,dt)
 if not c.curvaOpen then return end
 local p=c.curvaViewCamera
 if not p then
  local previous=getCamera();if not previous or not entityExists(previous)then return end
  local x,y,z=getWorldTranslation(previous);local rx,ry,rz=getWorldRotation(previous)
  local node=createCamera('JLRS_Curva_View',math.rad(55),.1,6000);link(getRootNode(),node)
  p={node=node,previous=previous,position={x,y,z},rotation={rx,ry,rz}};c.curvaViewCamera=p
 end
 if not canEdit(c)then C.releaseCamera(c);return end
 if g_gui and g_gui:getIsGuiVisible()then return end
 local function key(name)local id=Input['KEY_'..name];return id and Input.isKeyPressed(id)and 1 or 0 end
 local h,v,u=key('d')-key('a'),key('w')-key('s'),key('q')-key('e')
 local length=math.sqrt(h*h+v*v+u*u);local speed=math.min(math.max(tonumber(dt)or 0,0),100)*.012
 if length>0 then local dx,dy,dz=localDirectionToWorld(p.node,h,0,-v);p.position[1]=p.position[1]+dx*speed/length;p.position[2]=p.position[2]+(dy+u)*speed/length;p.position[3]=p.position[3]+dz*speed/length end
 if p.zoomTarget then p.zoom=p.zoom or 55;p.zoom=p.zoom+(p.zoomTarget-p.zoom)*(1-math.exp(-math.max(0,tonumber(dt)or 0)/90));setFovY(p.node,math.rad(p.zoom))end
 setTranslation(p.node,unpack(p.position));setRotation(p.node,unpack(p.rotation));setCamera(p.node)
end
local oldOpen=C.open
C.open=function(c,...)oldOpen(c,...);c.curvaPage='vehicles';c.curvaMarked=c.curvaMarked or {};c.curvaIcons=c.curvaIcons or {};c.curvaVehicleOffset=0;c.curvaViews=false end
local oldClose=C.close
C.close=function(c,...)
 if c.curvaDrag and c.curvaDrag.before then C.commit(c,c.curvaDrag.key,c.curvaDrag.before)end
 C.releaseCamera(c);for _,id in pairs(c.curvaIcons or {})do delete(id)end;c.curvaIcons={};c.curvaPage=nil;return oldClose(c,...)
end
local oldDraw=C.draw
C.draw=function(c)
 local M=JLRSMenu
 if c.curvaPage=='vehicles' then
  c.hitboxes={};c.curvaPointHits={};c.curvaAxes={};local vehicles=C.vehicles(c);local visible={}
  c.curvaVehicleOffset=math.max(0,math.min(c.curvaVehicleOffset or 0,math.max(0,#vehicles-7)))
  M.rect(c,.735,.10,.25,.74,.015,.025,.04,.97);M.text(.75,.805,.019,'CURVA | KENDARAAN');M.button(c,.945,.797,.025,.03,'X',function()C.close(c)end)
  for row=1,7 do local vehicle=vehicles[c.curvaVehicleOffset+row];if vehicle then
   local y=.721-(row-1)*.073;local recorded=false;for _,item in ipairs(c.curvaItems)do if item.vehicle==vehicle then recorded=true;break end end
   M.rect(c,.745,y,.23,.065,.04,.065,.09,.95)
   M.button(c,.751,y+.019,.025,.026,c.curvaMarked[vehicle]and 'X' or '',function()c.curvaLabelVehicle=vehicle;if recorded then c.curvaMarked[vehicle]=not c.curvaMarked[vehicle]else c:notify('Kendaraan ini belum memiliki rekaman.')end end,c.curvaMarked[vehicle])
   M.button(c,.781,y+.006,.147,.052,'',function()c.curvaLabelVehicle=vehicle;if recorded then c.curvaMarked[vehicle]=not c.curvaMarked[vehicle]end end,c.curvaMarked[vehicle])
   local store=g_storeManager and g_storeManager:getItemByXMLFilename(vehicle.configFileName or '');local image=store and store.imageFilename
   if image and image~=''then visible[image]=true;local id=c.curvaIcons[image];if not id then id=createImageOverlay(image);if id and id~=0 then c.curvaIcons[image]=id end end;if id and id~=0 then setOverlayColor(id,1,1,1,1);renderOverlay(id,.78,y+.007,.041,.049)end end
   local name=C.name(c,vehicle);M.text(.825,y+.035,.011,JLRSHistoryGroups.fitName(name,.011,.104));M.text(.825,y+.012,.008,recorded and 'Curva tersedia' or 'Belum direkam',.65,.75,.85)
   M.button(c,.933,y+.019,.038,.026,'NAME',function()c.curvaLabelVehicle=vehicle;C.rename(c,vehicle)end)
  end end
  for image,id in pairs(c.curvaIcons)do if not visible[image]then delete(id);c.curvaIcons[image]=nil end end
  local v=c.curvaLabelVehicle
  if JLRSRecorder.valid(v)then local x,y,z=getWorldTranslation(v.rootNode);local sx,sy=screen(x,y+3,z);if sx and sx<.73 then
   M.rect(c,sx-.08,sy,.16,.025,.01,.02,.03,.85);M.text(sx-.077,sy+.003,.012,JLRSHistoryGroups.fitName(C.name(c,v),.012,.154))
  end end
  M.text(.75,.184,.01,'Scroll daftar | Centang kendaraan')
  M.button(c,.75,.125,.22,.036,'EDIT CURVA',function()local found=false;for _,item in ipairs(c.curvaItems)do if c.curvaMarked[item.vehicle]then found=true end end;if found and canEdit(c)then c.curvaPage='edit';c.curvaSelection=1;c.curvaPoint=1;c.curvaEdit=true;C.view(c,'ATAS') else c:notify('Pilih kendaraan yang sudah direkam.')end end)
  return
 end
 -- Reuse settings draw with a filtered catalog; restore full catalog immediately.
 local all=c.curvaItems;local filtered=C.routes(c);c.curvaItems=filtered;c.curvaSelection=math.max(1,math.min(c.curvaSelection or 1,#filtered));oldDraw(c);c.curvaItems=all
 M.button(c,.75,.259,.105,.031,'UNDO',function()C.undo(c,false)end);M.button(c,.865,.259,.105,.031,'REDO',function()C.undo(c,true)end)
 M.button(c,.75,.217,.22,.031,'CAMERA VIEW',function()c.curvaViews=not c.curvaViews end)
 M.button(c,.75,.169,.22,.031,'LIST KENDARAAN',function()C.releaseCamera(c);c.curvaPage='vehicles';c.curvaEdit=false end)
 if c.curvaViews then
  M.rect(c,.50,.217,.225,.18,.015,.025,.04,.97)
  for i,mode in ipairs({'SAMPING','ATAS','BELAKANG','DEPAN'})do M.button(c,.51,.357-(i-1)*.042,.205,.035,mode,function()C.view(c,mode);c.curvaViews=false end)end
 end
end
local oldMouse=C.mouse
C.mouse=function(c,x,y,down,up,button)
 if c.curvaPage=='vehicles' then
  c.mouseX=x;c.mouseY=y
  if down and (button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN)and x>=.735 then c.curvaVehicleOffset=math.max(0,math.min(math.max(0,#C.vehicles(c)-7),(c.curvaVehicleOffset or 0)+(button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1)));return end
  if down then JLRSMenu.click(c,x,y,down,button)end;return
 end
 if down and c.curvaViews and x>=.50 and x<.735 then JLRSMenu.click(c,x,y,down,button);return end
 local drag=c.curvaDrag;local beforeItem,beforeQ=C.selected(c)
 local all=c.curvaItems;c.curvaItems=C.routes(c);oldMouse(c,x,y,down,up,button);c.curvaItems=all
 if not drag and c.curvaDrag and beforeQ then c.curvaDrag.before=snapshot(beforeQ);c.curvaDrag.key=beforeItem.key end
 if drag and up and drag.before then C.commit(c,drag.key,drag.before)end
end
-- Camera-facing line bundle gives width without a platform-dependent debug API.
local thinLine=line
line=function(a,b,rgb)
 thinLine(a,b,rgb);local camera=getCamera();if not camera or not entityExists(camera)then return end
 local x,y,z=getWorldTranslation(camera);local width=math.max(.012,math.min(.2,math.sqrt((x-a[1])^2+(y-a[2])^2+(z-a[3])^2)*.00065))
 for _,o in ipairs({{-1,0},{1,0},{0,-1},{0,1}})do local dx,dy,dz=localDirectionToWorld(camera,o[1]*width,o[2]*width,0);thinLine({a[1]+dx,a[2]+dy,a[3]+dz},{b[1]+dx,b[2]+dy,b[3]+dz},rgb)end
end
local oldRouteDraw=C.routeDraw
C.routeDraw=function(c)
 if c.curvaPage=='vehicles' then c.curvaPointHits={};c.curvaAxes={};return end
 oldRouteDraw(c)
 local selected=c.curvaSelection or 1
 for routeIndex,item in ipairs(C.routes(c))do if routeIndex~=selected then local q=c.curvas[item.key]
  if q and not q.deleted and q.enabled~=false then local rgb=C.rgb(q.color)
   for index,p in ipairs(q.points)do local sx,sy=screen(p[1]+p[4],p[2]+p[5],p[3]+p[6]);if sx and sx>=0 and sx<.735 and sy>=0 and sy<=1 then
    JLRSMenu.rect(c,sx-.005,sy-.007,.01,.014,unpack(rgb));c.curvaPointHits[#c.curvaPointHits+1]={x=sx,y=sy,index=index,routeIndex=routeIndex}
   end end
  end
 end end
 for _,p in ipairs(c.curvaPointHits or {})do if not p.routeIndex then JLRSMenu.rect(c,p.x-.005,p.y-.007,.01,.014,1,1,.3)end end
 for _,a in ipairs(c.curvaAxes or {})do JLRSMenu.rect(c,a.ex-.005,a.ey-.007,.01,.014,a.axis==1 and 1 or .2,a.axis==2 and 1 or .2,a.axis==3 and 1 or .2)end
end
local editorUpdate=JLReplayStudio.update
JLReplayStudio.update=function(c,dt,...)local result=editorUpdate(c,dt,...);C.cameraTick(c,dt);return result end
local editorUnload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)C.releaseCamera(c);for _,id in pairs(c.curvaIcons or {})do delete(id)end;c.curvaIcons={};c.curvaMarked={};c.curvaUndo={};c.curvaRedo={};return editorUnload(c,...)end

-- Resolve edited paths once at playback entry, including playback after Reset Vehicle.
-- Initial placement and subsequent pose/velocity samplers share the same Curva.
local curvaStartReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(track,...)
 local c=JLReplayStudio
 if c and c.curvas then
  C.catalog(c);C.recount(c)
  local clip=clipFor(c,track);track.curvaClipId=clip and clip.id or nil
  track.curvaPlan=nil;track.curvaWheelNodes=nil
  -- The editor's fixed camera must relinquish ownership before replay cameras start.
  if c.curvaOpen then C.close(c)end
 end
 local result=curvaStartReplay(track,...)
 if c and c.curvaEnabled and c.curvaHasEdits then
  local tracks={track};for _,live in ipairs(c.liveTracks or {})do if live~=track then tracks[#tracks+1]=live end end
  for _,owner in ipairs(tracks)do if owner.replaying then
   local pose=JLRSRecorder.sample(owner,owner.replayTime or 0)
   if owner.curvaApplied then
    if owner.collisionReplay then JLRSCollision.place(owner,pose)else JLRSRecorder.apply(owner.entries,pose)end
    owner.replayAudioPose=pose;owner.replayAudioTime=owner.replayTime or 0
   end
  end end
 end
 return result
end

-- Per-vehicle speed and whole-route translation; no Copy/Paste or Follow One.
function C.speed(c,delta)
 if not canEdit(c)then return end
 local item,q=C.selected(c);if not q or q.deleted then return end
 local before=snapshot(q);q.speed=math.max(.1,math.min(1,math.floor(((q.speed or 1)+delta)*100+.5)/100));C.compile(q);C.recount(c);c.curvaDirty=true;C.commit(c,item.key,before)
end
local toolsDraw=C.draw
C.draw=function(c,...)
 local result=toolsDraw(c,...);if c.curvaPage~='edit'then return result end
 local M=JLRSMenu
 M.button(c,.75,.287,.22,.027,'JALUR / SPEED',function()c.curvaTools=not c.curvaTools end)
 if c.curvaTools then
  local _,q=C.selected(c);M.rect(c,.49,.43,.235,.33,.015,.025,.04,.98)
  M.text(.502,.735,.015,'PENGATURAN JALUR')
  M.text(.50,.643,.012,'Speed: '..string.format('%.0f%%',(q and q.speed or 1)*100))
  M.button(c,.50,.594,.105,.033,'- SPEED',function()C.speed(c,-.1)end)
  M.button(c,.615,.594,.10,.033,'+ SPEED',function()C.speed(c,.1)end)
  M.button(c,.50,.538,.215,.036,c.curvaWhole and 'GIZMO: SELURUH JALUR' or 'GIZMO: TITIK',function()if canEdit(c)then c.curvaWhole=not c.curvaWhole;c.curvaEdit=true end end,c.curvaWhole)
  M.text(.50,.499,.010,'Mode Jalur: drag X / Y / Z')
  M.text(.50,.475,.010,'Warna kendaraan tujuan tetap')
  M.text(.50,.451,.010,'Save Curva untuk menyimpan')
 end
 return result
end
local toolsMouse=C.mouse
C.mouse=function(c,x,y,down,up,button)
 if c.curvaPage=='edit'and c.curvaTools and down and x>=.49 and x<.735 and y>=.43 and y<=.76 then JLRSMenu.click(c,x,y,down,button);return end
 local d=c.curvaDrag
 if d and d.whole then
  local a=d.axis;local dx,dy=a.ex-a.x,a.ey-a.y;local denominator=dx*dx+dy*dy;local q=c.curvas[d.key]
  if q and denominator>1e-8 then
   local delta=((x-d.x)*dx+(y-d.y)*dy)/denominator*a.size
   for i,p in ipairs(q.points)do p[a.axis+3]=d.starts[i]+delta end
   C.compile(q);c.curvaDirty=true
  end
  if up then C.commit(c,d.key,d.before);c.curvaDrag=nil end;return
 end
 local result=toolsMouse(c,x,y,down,up,button)
 if not d and c.curvaDrag and c.curvaWhole then
  local drag=c.curvaDrag;local q=c.curvas[drag.key];drag.whole=true;drag.starts={};for i,p in ipairs(q.points)do drag.starts[i]=p[drag.axis.axis+3]end
 end
 return result
end
local toolsOpen=C.open
C.open=function(c,...)c.curvaTools=false;c.curvaWhole=false;return toolsOpen(c,...)end
function C.vehicleTime(track,v,time)
 local c=JLReplayStudio;if not c or not c.curvaEnabled or not c.curvaHasEdits then return time end
 local clip=clipFor(c,track);if not clip then return time end
 local visited={}
 while v and not visited[v]do
  visited[v]=true
  for index,vehicle in ipairs(clip.vehicles or {clip.target})do if vehicle==v then
   local q=c.curvas[clip.id..':'..index]
   if q and not q.deleted and q.enabled~=false and (q.changed or (q.speed or 1)~=1)then return q.points[1].t+(time-q.points[1].t)*(q.speed or 1)end
  end end
  v=parentOf(v)
 end
 return time
end
-- Existing activity adapters receive their original values at the vehicle's source time.
local activityTick=JLRSActivities.tick
local activityApply=JLRSActivities.apply
JLRSActivities.tick=function(track,...)
 local c=JLReplayStudio;if not c or not c.curvaEnabled or not c.curvaHasSpeed then return activityTick(track,...)end
 local prior=C.activityScope;C.activityScope={track=track,poses={},samples={},times={}}
 local ok,result=pcall(activityTick,track,...);C.activityScope=prior;if not ok then error(result)end;return result
end
JLRSActivities.apply=function(channel,vehicle,values,state,paused,restoring,...)
 local scope=C.activityScope
 if scope and vehicle and not restoring then
  local track=scope.track;local time=scope.times[vehicle];if time==nil then time=C.vehicleTime(track,vehicle,track.replayTime or 0);scope.times[vehicle]=time end
  if time~=(track.replayTime or 0)then
   local data=track.frames and track.frames.jlrsActivities
   if data then
    if not scope.poses[vehicle]then scope.samples[vehicle]={reuse=true};scope.poses[vehicle]=JLRSActivities.at(data,time,scope.samples[vehicle])end
    if not scope.indices then scope.indices={};for i,ch in ipairs(data.schema)do scope.indices[ch]=(i-1)*6 end end
    local offset=scope.indices[channel];if offset then local pose=scope.poses[vehicle];local adjusted={};for j=1,6 do adjusted[j]=pose[offset+j]end;values=adjusted end
   end
  end
 end
 return activityApply(channel,vehicle,values,state,paused,restoring,...)
end
-- Extend the replay clock for slowed routes; History durations remain original.
local timedStart=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(track,...)
 local c=JLReplayStudio;local clip=c and c.curvaHasSpeed and clipFor(c,track)
 if clip and c.curvaEnabled then
  local duration=clip.duration
  for index,v in ipairs(clip.vehicles or {clip.target})do local q=c.curvas[clip.id..':'..index]
   if q and not q.deleted and q.enabled~=false then local start=q.points[1].t;duration=math.max(duration,start+(clip.duration-start)/(q.speed or 1))end
  end
  track.duration=duration
 end
 return timedStart(track,...)
end
local timedStop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
 local c=JLReplayStudio;local clip=c and c.curvaHasSpeed and clipFor(c,track);local result=timedStop(track,...)
 if clip then track.duration=clip.duration end;return result
end
local timedLiveAdd=JLRSLive.add
JLRSLive.add=function(c,...)
 local clip=c.curvaHasSpeed and clipFor(c,c);local originalDuration=c.duration
 if clip and c.curvaEnabled then
  local duration=clip.duration
  for index,v in ipairs(clip.vehicles or {clip.target})do local q=c.curvas[clip.id..':'..index]
   if q and not q.deleted and q.enabled~=false then local first=q.points[1].t;duration=math.max(duration,first+(clip.duration-first)/(q.speed or 1))end
  end
  c.duration=duration
 end
 local ok,result=pcall(timedLiveAdd,c,...);c.duration=originalDuration
 if not ok then error(result)end;return result
end

-- Map-area wheel zoom belongs to the editor camera; HUD wheels retain list scrolling.
local cameraMouse=C.mouse
C.mouse=function(c,x,y,down,up,button)
 local wheel=button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN
 local panel=x>=.735 or (c.curvaViews and x>=.50 and x<.735 and y>=.19 and y<=.40)or (c.curvaTools and x>=.49 and x<.735 and y>=.43 and y<=.76)
 if c.curvaOpen and down and wheel and not panel and not c.curvaDrag and canEdit(c)then
  C.cameraTick(c,0);local p=c.curvaViewCamera
  if p then p.zoomTarget=math.max(10,math.min(110,(p.zoomTarget or p.zoom or 55)+(button==Input.MOUSE_BUTTON_WHEEL_UP and -3 or 3)))end
  return
 end
 return cameraMouse(c,x,y,down,up,button)
end
