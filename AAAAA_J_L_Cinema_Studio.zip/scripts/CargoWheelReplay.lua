-- Final visual-only cargo tyre pass. No pose/cache/physics/camera writes.
-- All replay tracks have completed before comparing cargo with its platform.
JLRSCargoWheels={nodes={},vehicles={},registry={}}
local C=JLRSCargoWheels
local function attached(v)
    local parent=v.getAttacherVehicle and v:getAttacherVehicle() or nil
    local visual=JLRSTrailers and JLRSTrailers.visual[v]
    return parent or (visual and visual.parent)
end
local function platform(v)
    return v.spec_tensionBelts or v.spec_dynamicMountAttacher or v.spec_trailer or (v.spec_attachable and (not v.spec_motorized or attached(v)))
end
local function localPoint(deck,p)
    if type(worldToLocal)=='function'then return worldToLocal(deck.vehicle.rootNode,p[1],p[2],p[3])end
    local x,y,z=p[1]-deck.p[1],p[2]-deck.p[2],p[3]-deck.p[3]
    local a,b=math.cos(deck.r[2]),math.sin(deck.r[2]);x,z=a*x-b*z,b*x+a*z
    a,b=math.cos(deck.r[1]),math.sin(deck.r[1]);y,z=a*y+b*z,-b*y+a*z
    a,b=math.cos(deck.r[3]),math.sin(deck.r[3]);return a*x+b*y,-b*x+a*y,z
end
local function tyre(w,fn)
    if w.driveNode and entityExists(w.driveNode)then fn(w)end
    for _,extra in ipairs(w.additionalWheels or {})do tyre(extra,fn)end
end
function C.fastened(v,deck)
    for _,cargo in pairs(JLRSTrailerReplay and JLRSTrailerReplay.visual[deck]or {})do if cargo[v]then return true end end
    for key,data in pairs(deck.spec_tensionBelts and deck.spec_tensionBelts.objectsToJoint or {})do
        if key==v or data==v or (type(data)=='table' and data.object==v)then return true end
    end
    for key,data in pairs(deck.spec_dynamicMountAttacher and deck.spec_dynamicMountAttacher.dynamicMountedObjects or {})do
        if key==v or data==v or (type(data)=='table' and data.object==v)then return true end
    end
    return false
end
local function beltBounds(deck)
    local bounds;local spec=deck.vehicle.spec_tensionBelts
    for _,belt in pairs(spec and (spec.sortedBelts or spec.singleBelts)or {})do
        for _,node in pairs({belt.startNode,belt.endNode})do
            if node and entityExists(node)then
                local p={getWorldTranslation(node)};local x,y,z=localPoint(deck,p)
                if not bounds then bounds={minX=x,maxX=x,minY=y,maxY=y,minZ=z,maxZ=z,count=0}end
                bounds.minX=math.min(bounds.minX,x);bounds.maxX=math.max(bounds.maxX,x)
                bounds.minY=math.min(bounds.minY,y);bounds.maxY=math.max(bounds.maxY,y)
                bounds.minZ=math.min(bounds.minZ,z);bounds.maxZ=math.max(bounds.maxZ,z)
                bounds.count=bounds.count+1
            end
        end
    end
    return bounds and bounds.count>=2 and bounds or nil
end
local function footprint(deck,p)
    local x,y,z=localPoint(deck,p);local d=deck.vehicle;local size=d.size or {}
    local width=size.width or d.sizeWidth or 3;local length=size.length or d.sizeLength or 10
    local native=math.abs(x-(size.widthOffset or 0))<=width/2+.35
        and math.abs(z-(size.lengthOffset or 0))<=length/2+.5
        and math.abs(y)<=math.max(8,(size.height or 2)+6)
    -- Trailer origins need not be centred on their deck. The real belt
    -- anchors cover later loads even outside the root-centred size box.
    local b=deck.beltBounds
    local anchored=b and x>=b.minX-.35 and x<=b.maxX+.35
        and z>=b.minZ-.5 and z<=b.maxZ+.5
        and y>=b.minY-.35 and y<=b.maxY+6
    return native or anchored,x,z,not native and anchored,y
end
local function onDeck(item,deck)
    local yes,x,z,extended,height=footprint(deck,item.p)
    local bound=C.fastened(item.vehicle,deck.vehicle)
    if bound and yes and height>.15 and height<6 then return true,x,z,true end
    -- A belt mesh alone does not identify which vehicle is carried. Cars
    -- approaching a platform must retain wheel travel while climbing the ramp.
    if yes and height>.15 and not extended then return true,x,z,bound end
    -- Long cargo can have its origin past the deck edge while its tyres remain
    -- on the deck. Test actual tyre centres instead of enlarging every platform.
    -- A flush does not translate tyre centres. Read each once, then reuse the
    -- same current world position for every candidate platform (never across frames).
    if not item.wheelPoints then
        item.wheelPoints={}
        for _,w in ipairs(item.vehicle.spec_wheels and item.vehicle.spec_wheels.wheels or {})do
            local node=w.driveNode or w.repr
            if node and entityExists(node)then
                item.wheelPoints[#item.wheelPoints+1]={wheel=w,point={getWorldTranslation(node)}}
            end
        end
    end
    for _,sample in ipairs(item.wheelPoints)do
        local w,point=sample.wheel,sample.point
        do
            local hit,_,_,beyond,height=footprint(deck,point)
            local b=deck.beltBounds
            local radius=w.radius or (w.physics and w.physics.radius)or 0
            local onSurface=not beyond or (b and height-radius>=b.minY-.35 and height-radius<=b.maxY+.6)
            if hit and height>.15 and height<6 and onSurface then return true,x,z,bound end
        end
    end
    return false
end
function C.clear()
    C.nodes={};C.vehicles={};C.registry={}
end
function C.flush(c)
    local precise=JLReplayStudio.preciseReplay==true
    local list,seen={},{}
    local function add(v,track)
        if seen[v]or not JLRSRecorder.valid(v)then return end
        seen[v]=true;list[#list+1]={vehicle=v,track=track}
    end
    local function track(t)
        if not t or not t.replaying then return end
        for _,v in ipairs(t.recordVehicles or {t.target})do add(v,t)end
        -- Remapping may refresh entries before the cached vehicle list.
        for _,e in ipairs(t.entries or {})do if e.world and e.vehicle then add(e.vehicle,t)end end
    end
    track(c)
    for _,t in ipairs(c.liveTracks or {})do track(t)end
    local function world(w)
        for _,s in ipairs(w and w.states or {})do
            if s.returnPose and s.vehicleTrack and s.vehicleTrack.replaying then add(s.group.object,s.vehicleTrack)end
        end
    end
    world(c.worldReplay)
    for _,t in ipairs(c.liveTracks or {})do world(t.cargoReplay)end
    if #list==0 then C.clear();return end
    local platforms={}
    for _,item in ipairs(list)do
        local v=item.vehicle;item.p={getWorldTranslation(v.rootNode)};item.r={getWorldRotation(v.rootNode)}
        if platform(v)then item.beltBounds=precise and beltBounds(item)or nil;platforms[#platforms+1]=item end
    end
    local live={};local time=g_time or 0
    for _,item in ipairs(list)do
        local v,t=item.vehicle,item.track
        local previous=C.vehicles[v];local support,x,z,fastened,bestRank
        -- Strapped motorized cargo may have a mount parent. It still owns
        -- stationary tyres; ordinary attached non-motorized trailers keep rolling.
        local mountParent=attached(v)
        if not mountParent or v.spec_motorized then
            for _,deck in ipairs(platforms)do
                local d=deck.vehicle
                if d~=v and attached(d)~=v then
                    local hit,lx,lz,bound=onDeck(item,deck)
                    if hit and (not mountParent or bound)then
                        -- A motorized load can itself expose trailer/belt specs.
                        -- Prefer the actual towed deck, independently for every load.
                        local rank=(bound and 100 or 0)+(not d.spec_motorized and 20 or 0)
                            +(attached(d) and 10 or 0)+(previous and previous.deck==d and 1 or 0)
                        if not bestRank or rank>bestRank then
                            support=d;x=lx;z=lz;fastened=bound;bestRank=rank
                        end
                    end
                end
            end
        end
        if support then
            -- One carried vehicle can be rebound to another active track or
            -- rebuilt topology during Final. That is not a new tyre rotation.
            local same=previous and previous.deck==support
            local sameClock=same and previous.track==t and previous.entries==t.entries
            if not precise then same=sameClock end
            local clock=t.cargoReplayTime or t.replayTime
            local forward=same and (not sameClock or clock==nil or previous.clock==nil or clock>=previous.clock)
            local travel=0
            if forward and sameClock and previous.time~=time then
                local dx,dz=x-previous.x,z-previous.z
                local yaw=item.r[2]-select(2,getWorldRotation(support.rootNode))
                local signed=dx*math.sin(yaw)+dz*math.cos(yaw)
                -- Cancel contact/suspension sub-millimetre noise, not forward travel.
                if math.abs(signed)>.001 then travel=signed end
            end
            local state=same and previous or {wheels={}}
            state.deck=support;state.track=t;state.entries=t.entries;state.clock=clock;state.time=time;state.x=x;state.z=z
            C.vehicles[v]=state;live[v]=true
            for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do tyre(w,function(wheel)
                local node=wheel.driveNode;local held=state.wheels[node]
                if not held or not forward then held={rx=select(1,getRotation(node))};state.wheels[node]=held end
                held.rx=held.rx+travel/math.max(.001,wheel.radius or (wheel.physics and wheel.physics.radius)or 1)
                held.track=t;held.vehicle=v;C.nodes[node]=held
                local _,ry,rz=getRotation(node);setRotation(node,held.rx,ry,rz)
                wheel.lastXDrive=held.rx
            end)end
        end
    end
    for v,state in pairs(C.vehicles)do if not live[v]then
        for node in pairs(state.wheels)do if C.nodes[node]and C.nodes[node].vehicle==v then C.nodes[node]=nil end end
        C.vehicles[v]=nil
    end end
end
-- Pin only roll on owned replay wheels, including late native graphics passes.
local pin=JLRSWheelVisual.pin
JLRSWheelVisual.pin=function(state)
    local held=state and C.nodes[state.node]
    -- A shared background vehicle may be present in several selected takes.
    -- Its last wheel writer need not be the first track found by flush().
    if held and held.track.replaying and state.track.replaying then state.rx=held.rx end
    return pin(state)
end
local native=WheelsUtil and WheelsUtil.updateVisualWheel
if native then
    WheelsUtil.updateVisualWheel=function(v,w,x,y,z,roll,length,...)
        local held=C.nodes[w.driveNode]
        if held and held.vehicle==v and held.track.replaying then roll=held.rx end
        local result=native(v,w,x,y,z,roll,length,...)
        if held and held.vehicle==v and held.track.replaying then
            local _,ry,rz=getRotation(w.driveNode);setRotation(w.driveNode,held.rx,ry,rz);w.lastXDrive=held.rx
        end
        return result
    end
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...)
    -- The outer boundary below runs after Final's deferred pose pass.
    if not c.jlrsRenderBoundary then C.flush(c)end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(t,...)
    for v,state in pairs(C.vehicles)do if state.track==t then
        for node in pairs(state.wheels)do C.nodes[node]=nil end;C.vehicles[v]=nil
    end end
    return stop(t,...)
end
local release=JLRSWorld.release
JLRSWorld.release=function(state,...)
    if state.vehicleTrack then
        local v=state.group.object;local held=C.vehicles[v]
        if held and (not JLReplayStudio.preciseReplay or held.track==state.vehicleTrack)then
            for node in pairs(held.wheels)do C.nodes[node]=nil end;C.vehicles[v]=nil
        end
    end
    return release(state,...)
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)C.clear();return unload(c,...)end
