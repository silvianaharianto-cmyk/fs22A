JLRSCars={ROWS=6}
local C=JLRSCars
local function valid(v)return JLRSRecorder.valid(v)and v.spec_enterable and v.spec_motorized and not JLRSWorld.isTrain(v)end
local function name(v)return type(v.getName)=='function'and v:getName()or 'Vehicle'end
function C.items(c)
    local list={};local seen={}
    for _,v in pairs(c.mission.vehicles or {})do if valid(v)and not seen[v]then seen[v]=true;list[#list+1]=v end end
    table.sort(list,function(a,b)local aa,bb=name(a):lower(),name(b):lower();if aa~=bb then return aa<bb end;return (a.rootNode or 0)<(b.rootNode or 0)end)
    c.carsItems=list;c.carsOffset=math.max(0,math.min(c.carsOffset or 0,math.max(0,#list-C.ROWS)))
    for v in pairs(c.carsMarked or {})do if not seen[v]then c.carsMarked[v]=nil end end
end
function C.close(c)
    c.carsOpen=false;c.menu=c.carsReturnMenu or false;c.hitboxes={}
    for _,id in pairs(c.carsIcons or {})do delete(id)end;c.carsIcons={};JLRSMouse.refresh(c)
    -- Idle gameplay has no cinematic camera, so refresh alone did not hide the
    -- cursor left by the menu. Clear it immediately and let normal Alt rules resume.
    if g_inputBinding then
        g_inputBinding:setShowMouseCursor(c.menu or (g_gui and g_gui:getIsGuiVisible()) or false)
    end
    c.miniCursorShown=true
end
function C.open(c)
    if c.changePending then c:notify('Tunggu Change Cars selesai sebelum membuka Cars.');return end
    c.carsReturnMenu=c.menu;c.carsOpen=true;c.menu=true;c.carsOffset=0;c.carsMarked=c.carsMarked or {};c.carsIcons=c.carsIcons or {};C.items(c);JLRSMouse.refresh(c)
end
function C.scroll(c,delta)c.carsOffset=math.max(0,math.min(math.max(0,#(c.carsItems or {})-C.ROWS),(c.carsOffset or 0)+delta))end
function C.enter(c,v)
    if c.carsWorker or c.changePending then c:notify('Tunggu proses kendaraan selesai.');return end
    if not valid(v)or type(c.mission.requestToEnterVehicle)~='function'then c:notify('Kendaraan tidak tersedia untuk Enter Vehicle.');return end
    -- End cinematic ownership before switching to native driving input.
    c:stop();c.mission:requestToEnterVehicle(v);C.close(c)
end
function C.delete(c,list)
    if c.carsWorker or c.changePending then c:notify('Tunggu proses kendaraan selesai.');return end
    local pending={};local seen={}
    for _,v in ipairs(list)do if valid(v)and not seen[v]then seen[v]=true;pending[#pending+1]=v end end
    if #pending==0 then c:notify('Tandai kendaraan dahulu.');return end
    if type(c.mission.removeVehicle)~='function'then c:notify('API penghapusan kendaraan tidak tersedia.');return end
    for _,v in ipairs(pending)do
        if type(Vehicle and Vehicle.delete or v.delete)~='function'then c:notify('API Delete kendaraan tidak tersedia.');return end
        if c.mission.controlledVehicle==v and type(c.mission.onLeaveVehicle)~='function'then c:notify('Keluar dari kendaraan dahulu.');return end
    end
    c:stop() -- Seal active recordings; release physics and camera ownership before deletion.
    c.carsWorker=coroutine.create(function()
        local removed=0
        for _,v in ipairs(pending)do
            if valid(v)then
                if c.mission.controlledVehicle==v then
                    c.mission:onLeaveVehicle()
                    for i=1,120 do if c.mission.controlledVehicle~=v then break end;coroutine.yield()end
                    if c.mission.controlledVehicle==v then error('Keluar native dari mobil belum selesai.')end
                end
                local ok,err=JLRSChange.retire(c,v)
                if not ok then error(tostring(err))end
                removed=removed+1;c.carsMarked[v]=nil
            end
        end
        C.items(c);c:notify(removed..' kendaraan dihapus | History tetap tersedia')
    end)
end
function C.selected(c)
    local list={};for _,v in ipairs(c.carsItems or {})do if c.carsMarked[v]then list[#list+1]=v end end;return list
end
function C.draw(c)
    c.hitboxes={};JLRSMenu.rect(c,.16,.12,.68,.77,.015,.023,.037,.98)
    JLRSMenu.rect(c,.16,.81,.68,.08,.025,.16,.23);JLRSMenu.text(.18,.846,.023,'J_L Cinema Studio | Cars')
    JLRSMenu.text(.18,.819,.011,#(c.carsItems or {})..' mobil | Scroll untuk melihat daftar')
    JLRSMenu.button(c,.785,.827,.035,.035,'X',function()C.close(c)end)
    local visible={}
    for row=1,C.ROWS do local v=(c.carsItems or {})[(c.carsOffset or 0)+row]
        if v then local y=.726-(row-1)*.076
            JLRSMenu.rect(c,.176,y-.004,.648,.068,.045,.07,.105)
            JLRSMenu.button(c,.185,y+.011,.029,.033,c.carsMarked[v]and 'X'or '',function()c.carsMarked[v]=not c.carsMarked[v]end,c.carsMarked[v])
            local item=g_storeManager and g_storeManager:getItemByXMLFilename(v.configFileName or '')
            local image=item and item.imageFilename
            if image and image~=''then
                visible[image]=true;local id=c.carsIcons[image]
                if not id then id=createImageOverlay(image);if id and id~=0 then c.carsIcons[image]=id end end
                if id and id~=0 then setOverlayColor(id,1,1,1,1);renderOverlay(id,.228,y+.004,.057/(g_screenWidth and g_screenHeight and g_screenWidth/g_screenHeight or 16/9),.057)end
            else JLRSMenu.text(.23,y+.025,.009,'CAR')end
            JLRSMenu.text(.276,y+.028,.012,name(v):sub(1,35))
            JLRSMenu.button(c,.585,y+.011,.09,.033,'DELETE',function()C.delete(c,{v})end,false,{.48,.07,.13})
            JLRSMenu.button(c,.685,y+.011,.129,.033,'ENTER VEHICLE',function()C.enter(c,v)end)
        end
    end
    for image,id in pairs(c.carsIcons)do if not visible[image]then delete(id);c.carsIcons[image]=nil end end
    if #(c.carsItems or {})==0 then JLRSMenu.text(.19,.7,.016,'Tidak ada mobil di map.')end
    JLRSMenu.button(c,.18,.268,.08,.032,'UP',function()C.scroll(c,-C.ROWS)end)
    JLRSMenu.button(c,.27,.268,.09,.032,'DOWN',function()C.scroll(c,C.ROWS)end)
    JLRSMenu.button(c,.18,.217,.64,.036,c.carsWorker and 'DELETING...'or('DELETE SELECTED CARS ('..#C.selected(c)..')'),function()C.delete(c,C.selected(c))end,false,{.4,.07,.11})
    JLRSMenu.button(c,.18,.174,.64,.033,'CLOSE',function()C.close(c)end)
    JLRSMenu.text(.18,.148,.010,'Delete menghapus mobil dari map. History tetap ada; Replay perlu kendaraan pengganti.',.7,.78,.85)
    JLRSMenu.text(.18,.124,.009,'©Copyright 2023 | Jupryan Lowlight',.65,.74,.83)
end
local menu=JLRSMenu.draw
JLRSMenu.draw=function(c,...)if c.carsOpen and c.menu then return C.draw(c)end;return menu(c,...)end
local toggle=JLRSMenu.toggle
JLRSMenu.toggle=function(c,...)if c.carsOpen then return C.close(c)end;return toggle(c,...)end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.carsMarked={};c.carsItems={};c.carsIcons={};c.carsOpen=false;c.carsWorker=nil

    return result
end
local install=JLRSFinal.install
JLRSFinal.install=function(c,...)
    local result=install(c,...)
    if c.mission and not c.carsMouse then
        local previous=c.mission.mouseEvent;c.carsOldMouse=previous;c.carsFinalMouse=c.finalMouseWrapper
        c.carsMouse=function(m,x,y,down,up,button,...)
            if c.carsOpen and not(g_gui and g_gui:getIsGuiVisible())then
                c.mouseX=x;c.mouseY=y
                if down and button==Input.MOUSE_BUTTON_WHEEL_UP then C.scroll(c,-1)
                elseif down and button==Input.MOUSE_BUTTON_WHEEL_DOWN then C.scroll(c,1)
                elseif down and button==Input.MOUSE_BUTTON_LEFT then JLRSMenu.click(c,x,y,down,button)end
                return
            end
            return previous(m,x,y,down,up,button,...)
        end
        c.mission.mouseEvent=c.carsMouse
    end
    return result
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    if c.carsWorker then
        local ok,err=coroutine.resume(c.carsWorker)
        if not ok then c:notify('Cars Delete gagal: '..tostring(err));c.carsWorker=nil;C.items(c)
        elseif coroutine.status(c.carsWorker)=='dead'then c.carsWorker=nil end
    end
    if c.carsOpen and (g_time or 0)>=(c.carsRefresh or 0)then C.items(c);c.carsRefresh=(g_time or 0)+1000 end
    return draw(c,...)
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local mission=c.mission;local terminal=c.finalMouseWrapper or c.carsFinalMouse;local base=c.oldMouse
    if c.mission and c.mission.mouseEvent==c.carsMouse then c.mission.mouseEvent=c.carsOldMouse end
    for _,id in pairs(c.carsIcons or {})do delete(id)end
    c.carsIcons={};c.carsWorker=nil;c.carsOpen=false;c.carsMouse=nil
    local result=deleteMap(c,...)
    if mission and terminal and mission.mouseEvent==terminal then mission.mouseEvent=base end
    return result
end
