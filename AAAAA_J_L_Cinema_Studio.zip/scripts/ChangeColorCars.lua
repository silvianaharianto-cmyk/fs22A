-- Additive toolbar and runtime paint configuration. No recorder/physics/camera hooks.
JLRSColorCars={ROWS=6,COLORS=18}
local C=JLRSColorCars
local groups={'baseColor','baseMaterial','designColor','designMaterial','designMaterial2','designMaterial3','rimColor'}
local labels={baseColor='Body',baseMaterial='Body',designColor='Design',designMaterial='Design',designMaterial2='Design 2',designMaterial3='Design 3',rimColor='Rims'}
local function valid(v)return JLRSRecorder.valid(v) and type(v.components)=='table' and not JLRSWorld.isTrain(v)end
function C.name(v)return v.jlrsColorDisplayName or (type(v.getName)=='function' and v:getName()) or 'Vehicle'end
local function property(xml,key)return xml and type(xml.hasProperty)=='function' and xml:hasProperty(key)end
function C.items(c)
    local list,seen={},{}
    for _,v in pairs(c.mission.vehicles or {})do if valid(v) and not seen[v]then seen[v]=true;list[#list+1]=v end end
    table.sort(list,function(a,b)local x,y=C.name(a):lower(),C.name(b):lower();if x~=y then return x<y end;return a.rootNode<b.rootNode end)
    c.colorCarsItems=list;c.colorCarsOffset=math.max(0,math.min(c.colorCarsOffset or 0,math.max(0,#list-C.ROWS)))
    if c.colorCarsTarget and not seen[c.colorCarsTarget]then c.colorCarsTarget=nil;c.colorCarsGroups={};c.colorCarsChoice=nil end
    c.colorCarsRefresh=(g_time or 0)+1000
end
function C.palette(v)
    local out={};local item=g_storeManager and g_storeManager:getItemByXMLFilename(v.configFileName or v.xmlFilename or '')
    local configs=item and item.configurations or {}
    for _,group in ipairs(groups)do
        local list=configs[group];local xml=v.xmlFile
        if list then
            local base='vehicle.'..group..'Configurations'
            local material=property(xml,base..'.material(0)') and type(v.applyBaseMaterialConfiguration)=='function' and type(v.applyBaseMaterial)=='function'
            local legacy=property(xml,base..'.colorNode(0)') and ConfigurationUtil and type(ConfigurationUtil.setColor)=='function'
            if material or legacy or (group=='rimColor' and v.spec_wheels) then
                local colors={}
                for id,entry in ipairs(list)do
                    local rgb=entry.uiColor or entry.color
                    if not entry.isCustomConfig and rgb and type(rgb[1])=='number' and type(rgb[2])=='number' and type(rgb[3])=='number' then
                        colors[#colors+1]={id=id,name=type(entry.name)=='string' and entry.name~='' and entry.name or ('Color '..id),rgb=rgb}
                    end
                end
                if #colors>0 then out[#out+1]={name=group,label=labels[group],colors=colors,material=material,rim=group=='rimColor'}end
            end
        end
    end
    return out
end
function C.select(c,v)
    if not valid(v)then C.items(c);return end
    c.colorCarsTarget=v;c.colorCarsGroups=C.palette(v);c.colorCarsGroup=1;c.colorCarsColorOffset=0;c.colorCarsChoice=nil;c.colorCarsMessage=nil
end
function C.rename(c,v,text)
    if not valid(v)then return false end
    if text~=nil then
        text=tostring(text):gsub('[%c]',''):match('^%s*(.-)%s*$')
        if #text==0 then return false end
        v.jlrsColorDisplayName=text:sub(1,64);C.items(c);return true
    end
    if g_gui and g_gui.showTextInputDialog then
        g_gui:showTextInputDialog({text='Rename kendaraan di Change Color Cars',defaultText=C.name(v),maxCharacters=64,
            callback=function(result,ok)if ok then C.rename(c,v,result)end end})
    else c:notify('Dialog Rename tidak tersedia.')end
end
function C.scroll(c,delta,palette)
    if palette then
        local g=(c.colorCarsGroups or {})[c.colorCarsGroup or 1]
        c.colorCarsColorOffset=math.max(0,math.min(math.max(0,#(g and g.colors or {})-C.COLORS),(c.colorCarsColorOffset or 0)+delta*C.COLORS))
    else c.colorCarsOffset=math.max(0,math.min(math.max(0,#(c.colorCarsItems or {})-C.ROWS),(c.colorCarsOffset or 0)+delta))end
end
function C.paint(v,group,id)
        if group.material then
            if v:applyBaseMaterialConfiguration(v.xmlFile,group.name,id)==false then error('Konfigurasi material tidak dapat diterapkan.')end
            v:applyBaseMaterial()
        else ConfigurationUtil.setColor(v,v.xmlFile,group.name,id)end
        if ConfigurationUtil and ConfigurationUtil.applyConfigMaterials then ConfigurationUtil.applyConfigMaterials(v,v.xmlFile,group.name,id)end
end
function C.apply(c)
    local v=c.colorCarsTarget;local group=(c.colorCarsGroups or {})[c.colorCarsGroup or 1];local choice=c.colorCarsChoice
    C.items(c)
    if v~=c.colorCarsTarget or not valid(v)then c:notify('Kendaraan tidak tersedia.');return false end
    if not group or not choice or not v.configurations then return false end
    local member=false;for _,color in ipairs(group.colors)do if color==choice then member=true;break end end
    if not member then return false end
    if c.changePending or c.changeWorker or c.carsWorker then c:notify('Tunggu proses Change Cars / Delete selesai.');return false end
    local previous=C.snapshot and C.snapshot(v,group)or v.configurations[group.name]
    local function paint(id)return C.paint(v,group,id)end
    local ok,err=pcall(paint,choice)
    if not ok then
        if previous then pcall(paint,previous)end
        c:notify('Ganti warna gagal: '..tostring(err));return false
    end
    v.configurations[group.name]=choice.id
    if ConfigurationUtil and ConfigurationUtil.addBoughtConfiguration and v.boughtConfigurations then ConfigurationUtil.addBoughtConfiguration(v,group.name,choice.id)end
    c.colorCarsMessage=C.name(v)..' | '..choice.name
    c:notify('Warna kendaraan diganti: '..choice.name);return true
end
function C.open(c)
    if not c.mission or c.changePending then return end
    c.colorCarsReturnMenu=c.menu;c.colorCarsOpen=true;c.menu=true;c.colorCarsOffset=0;c.colorCarsTarget=nil;c.colorCarsGroups={};c.colorCarsChoice=nil
    C.items(c);JLRSMouse.syncCursor(c)
end
function C.close(c)
    c.colorCarsOpen=false;c.menu=c.colorCarsReturnMenu or false;c.hitboxes={};JLRSMouse.syncCursor(c)
end
function C.draw(c)
    if (g_time or 0)>=(c.colorCarsRefresh or 0)then C.items(c)end
    c.hitboxes={}
    local visible={}
    JLRSMenu.rect(c,.15,.12,.70,.78,.015,.023,.037,.98)
    JLRSMenu.rect(c,.15,.82,.70,.08,.025,.16,.23)
    JLRSMenu.text(.175,.861,.023,'Change Color Cars')
    JLRSMenu.text(.175,.834,.011,'Pilih kendaraan > pilih warna > SELECT')
    JLRSMenu.button(c,.797,.847,.034,.035,'X',function()C.close(c)end)
    JLRSMenu.text(.175,.786,.014,'Kendaraan di map ('..#(c.colorCarsItems or {})..')')
    for row=1,C.ROWS do
        local v=(c.colorCarsItems or {})[(c.colorCarsOffset or 0)+row]
        if v then local y=.704-(row-1)*.074
            JLRSMenu.rect(c,.17,y-.004,.337,.066,.04,.06,.09)
            if JLRSColorPreview then JLRSColorPreview.image(c,v,.179,y+.003,.044,.056,visible)end
            JLRSMenu.text(.230,y+.032,.011,C.name(v):sub(1,28))
            JLRSMenu.button(c,.230,y+.001,.124,.024,'RENAME',function()C.rename(c,v)end)
            JLRSMenu.button(c,.366,y+.001,.128,.024,c.colorCarsTarget==v and 'SELECTED' or 'SELECT',function()C.select(c,v)end,c.colorCarsTarget==v)
        end
    end
    JLRSMenu.button(c,.175,.239,.155,.032,'UP',function()C.scroll(c,-C.ROWS,false)end)
    JLRSMenu.button(c,.342,.239,.155,.032,'DOWN',function()C.scroll(c,C.ROWS,false)end)
    JLRSMenu.rect(c,.52,.224,.313,.574,.026,.043,.065)
    local v=c.colorCarsTarget;local list=c.colorCarsGroups or {};local group=list[c.colorCarsGroup or 1]
    JLRSMenu.text(.535,.772,.012,v and C.name(v):sub(1,32) or 'Pilih satu kendaraan')
    if JLRSColorPreview then JLRSColorPreview.draw(c,.536,.561,.281,.174,visible)end
    if group then
        JLRSMenu.text(.579,.522,.012,group.label..' ('..(c.colorCarsGroup or 1)..'/'..#list..')')
        local function change(d)c.colorCarsGroup=((c.colorCarsGroup or 1)-1+d)%#list+1;c.colorCarsColorOffset=0;c.colorCarsChoice=nil end
        JLRSMenu.button(c,.536,.511,.033,.032,'<',function()change(-1)end)
        JLRSMenu.button(c,.784,.511,.033,.032,'>',function()change(1)end)
        for index=1,C.COLORS do
            local color=group.colors[(c.colorCarsColorOffset or 0)+index]
            if color then local x=.537+((index-1)%6)*.047;local y=.455-math.floor((index-1)/6)*.052
                local selected=c.colorCarsChoice==color
                JLRSMenu.rect(c,x-.002,y-.003,.042,.049,selected and 1 or .12,selected and 1 or .16,selected and 1 or .20)
                JLRSMenu.button(c,x,y,.038,.043,'',function()if JLRSColorPreview then JLRSColorPreview.choose(c,color)else c.colorCarsChoice=color end end,selected,color.rgb)
            end
        end
        JLRSMenu.button(c,.536,.310,.13,.032,'COLORS <',function()C.scroll(c,-1,true)end)
        JLRSMenu.button(c,.680,.310,.137,.032,'COLORS >',function()C.scroll(c,1,true)end)
        JLRSMenu.text(.536,.286,.010,c.colorCarsChoice and c.colorCarsChoice.name:sub(1,35) or 'Klik kotak warna')
        JLRSMenu.button(c,.536,.234,.28,.038,'SELECT COLOR',function()C.apply(c)end,c.colorCarsChoice~=nil)
    elseif v then
        JLRSMenu.text(.536,.509,.011,'Kendaraan ini tidak menyediakan')
        JLRSMenu.text(.536,.483,.011,'konfigurasi warna yang didukung.')
    end
    if JLRSColorPreview then JLRSColorPreview.trimIcons(c,visible)end
    JLRSMenu.text(.175,.205,.010,(c.colorCarsMessage or 'Scroll kiri: kendaraan | Scroll kanan: warna'):sub(1,82),.7,.83,.9)
    JLRSMenu.button(c,.175,.157,.65,.035,'CLOSE',function()C.close(c)end)
    JLRSMenu.text(.175,.128,.009,'©Copyright 2023 | Jupryan Lowlight',.65,.74,.83)
end
local menu=JLRSMenu.draw
JLRSMenu.draw=function(c,...)
    if c.colorCarsOpen and c.menu then return C.draw(c)end
    local result=menu(c,...)
    return result
end
local toggle=JLRSMenu.toggle
JLRSMenu.toggle=function(c,...)if c.colorCarsOpen then return C.close(c)end;return toggle(c,...)end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.colorCarsOpen=false;c.colorCarsItems={};c.colorCarsGroups={};c.colorCarsTarget=nil
    if not c.mission then return result end
    local previous=c.mission.mouseEvent;c.colorCarsPreviousMouse=previous
    c.colorCarsMouse=function(m,x,y,down,up,button,...)
        if c.colorCarsOpen and not(g_gui and g_gui:getIsGuiVisible())then
            c.mouseX=x;c.mouseY=y
            if down and button==Input.MOUSE_BUTTON_WHEEL_UP then if not c.colorCarsPanel or x>=.755 then C.scroll(c,-1,c.colorCarsPanel or x>=.52)end
            elseif down and button==Input.MOUSE_BUTTON_WHEEL_DOWN then if not c.colorCarsPanel or x>=.755 then C.scroll(c,1,c.colorCarsPanel or x>=.52)end
            else JLRSMenu.click(c,x,y,down,button)end
            return
        end
        return previous(m,x,y,down,up,button,...)
    end
    c.mission.mouseEvent=c.colorCarsMouse;return result
end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.mission and c.mission.mouseEvent==c.colorCarsMouse then c.mission.mouseEvent=c.colorCarsPreviousMouse end
    c.colorCarsOpen=false;c.colorCarsMouse=nil;c.colorCarsPreviousMouse=nil;c.colorCarsItems={};c.colorCarsTarget=nil
    return delete(c,...)
end
-- Alias follows this vehicle in the native savegame; History identity is untouched.
if Vehicle then
    if Vehicle.xmlSchemaSavegame and XMLValueType then Vehicle.xmlSchemaSavegame:register(XMLValueType.STRING,'vehicles.vehicle(?).jlCinemaColor#name','Change Color Cars display name')end
    local vehicleLoad=Vehicle.load
    if vehicleLoad then Vehicle.load=function(v,data,...)
        local save=data and data.savegame
        if save and save.xmlFile then v.jlrsColorDisplayName=save.xmlFile:getString(save.key..'.jlCinemaColor#name')end
        return vehicleLoad(v,data,...)
    end end
    local save=Vehicle.saveToXMLFile
    if save then Vehicle.saveToXMLFile=function(v,xml,key,...)
        local result=save(v,xml,key,...)
        if v.jlrsColorDisplayName then xml:setString(key..'.jlCinemaColor#name',v.jlrsColorDisplayName)end
        return result
    end end
end
