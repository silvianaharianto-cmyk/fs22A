-- Permanent, per-savegame History. No raw engine node IDs are serialized.
JLRSPersist={revision=0,identityCounter=0}
local function number(v) return string.format('%.17g',v or 0) end
local function pack(p)
    local out={};for i,v in ipairs(p) do out[i]=number(v) end;return table.concat(out,' ')
end
local function unpackPose(text)
    local p={};for word in (text or ''):gmatch('%S+') do local v=tonumber(word);if not v then error('Pose History rusak.') end;p[#p+1]=v end;return p
end
local function saveXML(path,root,write,verify)
    local xml=XMLFile.create('jlrsPermanentHistory',path,root)
    if not xml then error('Tidak dapat membuat History: '..path) end
    local ok,err=pcall(function() write(xml);if xml:save()==false then error('Penyimpanan History gagal / disk penuh.') end end)
    xml:delete();if not ok then error(err) end
    local check=XMLFile.load('jlrsHistoryVerify',path)
    if not check then error('History tidak dapat dibaca setelah disimpan.') end
    local valid=verify(check);check:delete();if not valid then error('Verifikasi History gagal.') end
end
function JLRSPersist.identity(v)
    -- Vehicle mods can override the base save method. Wrap the actual instance
    -- method as well, so the logical recording identity reaches vehicles.xml.
    if not rawget(v,'jlrsIdentitySaveHook') and type(v.saveToXMLFile)=='function' then
        local native=v.saveToXMLFile
        v.jlrsIdentitySaveHook=true
        v.saveToXMLFile=function(object,xml,key,...)
            local result=native(object,xml,key,...)
            if xml and type(xml.setString)=='function' and type(key)=='string' then
                xml:setString(key..'.jlCinema#identity',object.jlrsPersistentId)
                object.jlrsIdentitySaved=true
                if JLReplayStudio then JLReplayStudio.jlrsSaveDirty=true end
            end
            return result
        end
    end
    if not v.jlrsPersistentId then
        JLRSPersist.identityCounter=JLRSPersist.identityCounter+1
        local stamp=type(getDate)=='function' and getDate('%Y%m%d%H%M%S') or tostring(g_time or 0)
        v.jlrsPersistentId='jlrs_'..stamp..'_'..tostring(v.rootNode or 0)..'_'..JLRSPersist.identityCounter
    end
    return v.jlrsPersistentId
end
-- FS22's own vehicle save/load carries the identity alongside the normal vehicle data.
if Vehicle then
    if Vehicle.xmlSchemaSavegame and XMLValueType then
        Vehicle.xmlSchemaSavegame:register(XMLValueType.STRING,'vehicles.vehicle(?).jlCinema#identity','Cinema History vehicle identity')
    end
    local load=Vehicle.load
    if load then Vehicle.load=function(v,data,...)
        local sg=data and data.savegame
        if sg and sg.xmlFile then
            v.jlrsPersistentId=sg.xmlFile:getString(sg.key..'.jlCinema#identity')
            v.jlrsIdentitySaved=v.jlrsPersistentId~=nil
            v.jlrsLoadedSaveId=sg.xmlFile:getInt(sg.key..'#id')
        end
        return load(v,data,...)
    end end
    local save=Vehicle.saveToXMLFile
    if save then Vehicle.saveToXMLFile=function(v,xml,key,...)
        local result=save(v,xml,key,...)
        xml:setString(key..'.jlCinema#identity',JLRSPersist.identity(v));v.jlrsIdentitySaved=true
        if JLReplayStudio and JLReplayStudio.mission then JLReplayStudio.jlrsSaveDirty=true end
        return result
    end end
end
local function localEntries(v)
    local out,seen={},{}
    local function add(node,world,ci)
        if node and node~=0 and entityExists(node) and not seen[node] then
            seen[node]=true;out[#out+1]={node=node,world=world,parent=getParent(node),vehicle=ci and v or nil,componentIndex=ci}
        end
    end
    for i,comp in ipairs(v.components or {}) do add(comp.node,true,i) end
    add(v.rootNode,true)
    local function wheel(w)
        add(w.repr,false);add(w.driveNode,false)
        for _,child in ipairs(w.additionalWheels or {}) do wheel(child) end
    end
    for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {}) do wheel(w) end
    return out
end
-- Railroad Locomotives can leave legacy wheel-local rows without a slot.
-- Such a local transform must never fall back to a world-space component root.
local function railroadVehicle(object)
    local config=(object.configFileName or object.xmlFilename or ''):gsub('\\','/'):lower()
    return config:find('/fs22_railroad_locomotives/',1,true)~=nil
end
local function railLocalPath(object,node)
    if not entityExists(node)or not getNumOfChildren or not getChildAt then return end
    local path={};local current=node
    for depth=1,128 do
        for i,component in ipairs(object.components or {})do
            if current==component.node then
                if #path==0 then return end
                return 'railLocal:'..i..':'..table.concat(path,'/')
            end
        end
        local parent=getParent(current)
        if not parent or parent==0 or not entityExists(parent)then return end
        local index
        for i=0,getNumOfChildren(parent)-1 do if getChildAt(parent,i)==current then index=i;break end end
        if index==nil then return end
        table.insert(path,1,tostring(index));current=parent
    end
end
local function railLocalNode(object,key)
    local component,path=(key or ''):match('^railLocal:(%d+):([%d/]+)$')
    local part=component and (object.components or {})[tonumber(component)]
    local node=part and part.node
    if not node or not getChildAt or not getNumOfChildren then return end
    for item in path:gmatch('%d+')do
        local index=tonumber(item)
        if not entityExists(node)or index>=getNumOfChildren(node)then return end
        node=getChildAt(node,index)
    end
    return node
end
local function objectDesc(object)
    local node=object.rootNode or object.nodeId or object.node
    local vehicle=object.components~=nil
    local pose=node and entityExists(node) and {getWorldTranslation(node)} or {0,0,0}
    return {object=object,vehicle=vehicle,prop=object.jlrsDynamicProp==true,id=vehicle and JLRSPersist.identity(object) or '',
        saved=object.jlrsIdentitySaved and 1 or 0,
        saveId=object.currentSavegameId or object.jlrsLoadedSaveId or object.saveId or 0,
        config=object.configFileName or object.xmlFilename or object.filename or '',
        name=node and type(getName)=='function' and getName(node) or '',anchor=pose,
        nodes=vehicle and #localEntries(object) or 1}
end
JLRSPersist.objectDesc=objectDesc
local function refresh(d)
    if d.object then
        local node=d.object.rootNode or d.object.nodeId
        if node and entityExists(node) then local updated=objectDesc(d.object);for k,v in pairs(updated) do d[k]=v end end
    end
end
local function writeDesc(x,key,d)
    refresh(d)
    x:setString(key..'#id',d.id);x:setInt(key..'#vehicle',d.vehicle and 1 or 0);x:setInt(key..'#prop',d.prop and 1 or 0)
    x:setInt(key..'#saved',d.saved);x:setInt(key..'#saveId',d.saveId)
    x:setString(key..'#config',d.config);x:setString(key..'#name',d.name)
    x:setString(key..'#anchor',pack(d.anchor));x:setInt(key..'#nodes',d.nodes)
    if d.remapped then x:setInt(key..'#remapped',1)end
end
local function readDesc(x,key)
    return {id=x:getString(key..'#id',''),vehicle=x:getInt(key..'#vehicle',0)==1,prop=x:getInt(key..'#prop',0)==1,
        saved=x:getInt(key..'#saved',0),saveId=x:getInt(key..'#saveId',0),config=x:getString(key..'#config',''),
        name=x:getString(key..'#name',''),anchor=unpackPose(x:getString(key..'#anchor')),nodes=x:getInt(key..'#nodes',1),remapped=x:getInt(key..'#remapped',0)==1}
end
local function resolve(d,candidates)
    if d.object and (d.object.rootNode or d.object.nodeId or d.object.node) and entityExists(d.object.rootNode or d.object.nodeId or d.object.node) then return d.object end
    local found
    for _,o in ipairs(candidates) do
        local node=o.rootNode or o.nodeId or o.node
        if node and entityExists(node) and (o.components~=nil)==d.vehicle then
            local config=o.configFileName or o.xmlFilename or o.filename or ''
            local match=false
            if config==d.config then
                if d.vehicle and not d.prop then
                    match=o.jlrsPersistentId==d.id
                    if not match and d.saved==0 and not o.jlrsIdentitySaved and d.saveId~=0 then
                        match=(o.jlrsLoadedSaveId or o.currentSavegameId)==d.saveId
                    end
                else
                    local name=type(getName)=='function' and getName(node) or ''
                    local px,py,pz=getWorldTranslation(node)
                    local saveId=o.currentSavegameId or o.jlrsLoadedSaveId or o.saveId or 0
                    local stable=d.prop and d.id~='' and o.jlrsPersistentId==d.id
                    local savedId=d.prop and d.saveId~=0 and saveId==d.saveId
                    match=stable or savedId or (name==d.name and #d.anchor==3 and math.abs(px-d.anchor[1])<0.05 and math.abs(py-d.anchor[2])<0.05 and math.abs(pz-d.anchor[3])<0.05)
                end
            end
            if match then if found and found~=o then return nil end;found=o end
        end
    end
    if not found and d.vehicle and not d.prop and d.saved==0 and d.saveId==0 then
        -- Legacy takes made before a vehicle's identity was saved. A unique
        -- compatible model is recoverable; identical models require a unique
        -- match at the last saved anchor. Never choose by list order.
        local compatible,anchored={},{}
        for _,o in ipairs(candidates) do
            local node=o.rootNode
            if o.components and node and entityExists(node) and not o.jlrsIdentitySaved
                and (o.configFileName or '')==d.config and #localEntries(o)==d.nodes
                and (d.name=='' or type(getName)~='function' or getName(node)==d.name) then
                compatible[#compatible+1]=o
                if #d.anchor==3 then
                    local x,y,z=getWorldTranslation(node)
                    if (x-d.anchor[1])^2+(y-d.anchor[2])^2+(z-d.anchor[3])^2<1 then anchored[#anchored+1]=o end
                end
            end
        end
        if #compatible==1 then found=compatible[1]
        elseif #anchored==1 then found=anchored[1] end
        if found then d.legacyRecovered=true end
    end
    if found then d.object=found;if d.prop then found.jlrsDynamicProp=true end;if d.vehicle and not d.legacyRecovered and not found.jlrsPersistentId then found.jlrsPersistentId=d.id end end
    return found
end
local function candidates()
    local list,seen={},{}
    local function add(o) if type(o)=='table' and not seen[o] then seen[o]=true;list[#list+1]=o end end
    local m=g_currentMission
    for o in pairs(JLRSWorld.vehicleSet()) do add(o) end
    add(m.controlledVehicle)
    for _,o in pairs(m.itemsToSave or {}) do if type(o)=='table' then add(o.item or o.object or o) end end
    for _,o in pairs(m.nodeToObject or {}) do add(o) end
    if JLRSProps then for _,o in ipairs(JLRSProps.candidates())do add(o)end end
    return list
end
-- Old remaps could preserve all sparse streams but drop their scene clock.
-- The main take already owns the shared clock; no pose decoding/resampling.
function JLRSPersist.sceneClock(clip)
    local d=clip.saved
    if not d or #(d.groups or {})==0 then return end
    if (d.sceneCount or 0)<2 then
        local count=JLRSFrames.count(clip.frames)
        for _,g in ipairs(d.groups)do for _,e in ipairs(g.entries or {})do
            count=math.max(count,JLRSFrames.count(e.samples))
        end end
        if count>1 then d.sceneCount=count end
    end
    if (d.sceneDuration or 0)<=0 then d.sceneDuration=clip.duration or 0 end
    if clip.worldScene then
        clip.worldScene.sampleCount=d.sceneCount or 0
        clip.worldScene.duration=d.sceneDuration or clip.duration
    end
end
function JLRSPersist.describe(clip)
    if clip.saved then JLRSPersist.sceneClock(clip);return clip.saved end
    local saved={vehicles={},entries={},groups={}}
    local nodeMap={}
    for vi,v in ipairs(clip.vehicles or {clip.target}) do
        saved.vehicles[vi]=objectDesc(v)
        for ni,e in ipairs(localEntries(v)) do nodeMap[e.node]={vehicle=vi,slot=ni} end
        if v==clip.target then saved.target=vi end
    end
    for i,e in ipairs(clip.entries) do
        local map=nodeMap[e.node];if not map then error('Node record tidak dapat dihubungkan ke kendaraan.') end
        saved.entries[i]={vehicle=map.vehicle,slot=map.slot,world=e.world and 1 or 0,
            name=type(getName)=='function' and getName(e.node) or ''}
    end
    local scene=clip.worldScene
    if scene then
        saved.sceneCount=scene.sampleCount;saved.sceneDuration=scene.duration
        for gi,group in ipairs(scene.groups) do
            local desc={object=objectDesc(group.object),entries={},cargo=group.cargo and 1 or 0,prop=group.prop and 1 or 0}
            local slots={}
            if group.object.components then for index,e in ipairs(localEntries(group.object)) do slots[e.node]=index end end
            for ei,e in ipairs(group.entries) do
                local field=e.propField
                if not e.world and not slots[e.node] and railroadVehicle(group.object)then
                    field=railLocalPath(group.object,e.node)or field
                end
                desc.entries[ei]={component=e.componentIndex or 0,slot=slots[e.node] or 0,world=e.world and 1 or 0,samples=e.samples,propField=field}
            end
            saved.groups[gi]=desc
        end
    end
    clip.saved=saved;return saved
end
function JLRSPersist.checkpoint(frames)
    local s=frames._jlrs;if not s then error('Stream History tidak tersedia.') end
    if s.savedCount==s.count then return end
    local tail=math.max(0,s.count-s.sealed*s.chunkSize)
    if tail>0 then
        local path=JLRSFrames.directory..'take_'..s.id..'_tail.xml'
        saveXML(path,'record',function(x)
            x:setInt('record#count',tail)
            for i=1,tail do x:setString('record.frame('..(i-1)..')#data',number(frames[i].t)..' '..pack(frames[i].pose)) end
        end,function(x) return x:getInt('record#count')==tail end)
    end
    s.savedCount=s.count
end
local function writeStream(x,key,f)
    JLRSPersist.checkpoint(f)
    local s=f._jlrs
    x:setInt(key..'#id',s.id);x:setInt(key..'#count',s.count);x:setInt(key..'#sealed',s.sealed);x:setInt(key..'#chunkSize',s.chunkSize)
    if f.jlrsRecordAll then x:setInt(key..'#recordAll',1) end
    if f.jlrsRemapped then
        x:setInt(key..'#remapped',1)
        local owners={};for id,on in pairs(f.jlrsRemappedOwners or {})do if on then owners[#owners+1]=id end end
        table.sort(owners);x:setString(key..'#remappedOwners',table.concat(owners,' '))
    end
end
local function readRemapped(x,key,f,reloaded)
    if x:getInt(key..'#remapped',0)~=1 then return end
    f.jlrsRemapped=true;f.jlrsRemappedOwners=f.jlrsRemappedOwners or {}
    for id in x:getString(key..'#remappedOwners',''):gmatch('%S+')do
        f.jlrsRemappedOwners[id]=true
        if reloaded then
            f.jlrsRemapReloadOwners=f.jlrsRemapReloadOwners or {};f.jlrsRemapReloadOwners[id]=true
        end
    end
end
local function readStream(x,key)
    local id=x:getInt(key..'#id');if not id then error('Stream History tanpa ID.') end
    JLRSFrames.nextId=math.max(JLRSFrames.nextId,id)
    if JLRSFrames.stores[id] then
        local f=JLRSFrames.stores[id]
        readRemapped(x,key,f,false)
        return f
    end
    local count=x:getInt(key..'#count',0);local sealed=x:getInt(key..'#sealed',0);local size=x:getInt(key..'#chunkSize',0)
    if count<1 or size<2 or sealed<0 then error('Metadata stream History rusak.') end
    local f={_jlrs={id=id,count=count,sealed=sealed,chunkSize=size,cache={},order={},bounds={},persistent=true,savedCount=count}}
    if x:getInt(key..'#recordAll',0)==1 then f.jlrsRecordAll=true end
    readRemapped(x,key,f,true)
    local tail=math.max(0,count-sealed*size)
    if tail>=size+1 then error('Buffer History tidak valid.') end
    if tail>0 then
        local file=XMLFile.load('jlrsHistoryTail',JLRSFrames.directory..'take_'..id..'_tail.xml')
        if not file then error('File akhir History hilang.') end
        local ok,err=pcall(function()
            if file:getInt('record#count')~=tail then error('Jumlah frame akhir History berbeda.') end
            for i=1,tail do
                local nums=unpackPose(file:getString('record.frame('..(i-1)..')#data'))
                local time=table.remove(nums,1);-- Legacy frames: 6 values per node. Motor frames append RPM/load/on.
                local remainder=#nums%6
                if not time or #nums<6 or (remainder~=0 and remainder~=3) then error('Frame History rusak: jumlah nilai '..#nums..'.') end
                f[i]={t=time,pose=nums}
            end
        end)
        file:delete();if not ok then error(err) end
    end
    JLRSFrames.stores[id]=f;JLRSFrames.nextId=math.max(JLRSFrames.nextId,id);return f
end
JLRSPersist.writeStream=writeStream;JLRSPersist.readStream=readStream
-- Idle added props fit in the catalog itself: avoid one separate XML file per pallet/bale.
local function writeSceneStream(x,key,e,prop)
    local f=e.samples
    if prop==1 and JLRSFrames.count(f)==1 then
        local frame=JLRSFrames.get(f,1);local state=f._jlrs
        x:setInt(key..'#id',state.id);x:setInt(key..'#count',1);x:setInt(key..'#sealed',0);x:setInt(key..'#chunkSize',state.chunkSize)
        x:setString(key..'#idlePose',pack(frame.pose));x:setString(key..'#idleTime',number(frame.t));state.savedCount=1
    else writeStream(x,key,f)end
end
local function readSceneStream(x,key)
    local idle=x:getString(key..'#idlePose')
    if not idle then return readStream(x,key)end
    local id=x:getInt(key..'#id');local size=x:getInt(key..'#chunkSize',0)
    local pose=unpackPose(idle);local time=tonumber(x:getString(key..'#idleTime'))
    if not id or size<2 or #pose~=6 or not time or x:getInt(key..'#count')~=1 then error('Pose awal objek dinamis rusak.')end
    JLRSFrames.nextId=math.max(JLRSFrames.nextId,id)
    local f=JLRSFrames.stores[id]
    if not f then
        f={{t=time,pose=pose},_jlrs={id=id,count=1,sealed=0,chunkSize=size,cache={},order={},bounds={},persistent=true,savedCount=1}}
        JLRSFrames.stores[id]=f
    end
    return f
end
function JLRSPersist.save(c)
    local ok,err=JLRSFrames.prepare();if not ok then error(err) end
    local revision=JLRSPersist.revision+1
    local path=JLRSFrames.directory..(c.jlrsRecovery and 'history_recovery_' or 'history_')..(revision%2==0 and 'A.xml' or 'B.xml')
    saveXML(path,'history',function(x)
        x:setInt('history#revision',revision);x:setInt('history#count',#c.history)
        x:setInt('history#nextId',JLRSFrames.nextId);x:setInt('history#historyId',c.historyNextId)
        for ci,clip in ipairs(c.history) do
            local key='history.clip('..(ci-1)..')';local d=JLRSPersist.describe(clip)
            x:setInt(key..'#id',clip.id);x:setString(key..'#name',clip.name);x:setString(key..'#duration',number(clip.duration))
            x:setInt(key..'#target',d.target or 1);writeStream(x,key..'.frames',clip.frames)
            if JLRSActivities then JLRSActivities.write(x,key,clip.frames) end
            x:setInt(key..'#vehicles',#d.vehicles);x:setInt(key..'#entries',#d.entries);x:setInt(key..'#groups',#d.groups)
            x:setInt(key..'#sceneCount',d.sceneCount or 0);x:setString(key..'#sceneDuration',number(d.sceneDuration))
            for vi,v in ipairs(d.vehicles) do writeDesc(x,key..'.vehicle('..(vi-1)..')',v) end
            for ei,e in ipairs(d.entries) do
                local ek=key..'.entry('..(ei-1)..')';x:setInt(ek..'#vehicle',e.vehicle);x:setInt(ek..'#slot',e.slot)
                x:setInt(ek..'#world',e.world);x:setString(ek..'#name',e.name)
            end
            for gi,g in ipairs(d.groups) do
                local gk=key..'.group('..(gi-1)..')';writeDesc(x,gk..'.object',g.object);x:setInt(gk..'#entries',#g.entries);x:setInt(gk..'#cargo',g.cargo or 0);x:setInt(gk..'#prop',g.prop or 0)
                for ei,e in ipairs(g.entries) do local ek=gk..'.entry('..(ei-1)..')';x:setInt(ek..'#component',e.component);x:setInt(ek..'#slot',e.slot or 0);x:setInt(ek..'#world',e.world==nil and 1 or e.world);x:setString(ek..'#propField',e.propField or '');writeSceneStream(x,ek..'.samples',e,g.prop) end
            end
        end
        x:setString('history#complete','JLRS_1')
    end,function(x) return x:getInt('history#revision')==revision and x:getInt('history#count')==#c.history and x:getString('history#complete')=='JLRS_1' end)
    JLRSPersist.revision=revision
    for _,clip in ipairs(c.history) do
        clip.frames._jlrs.persistent=true
        if JLRSActivities then JLRSActivities.commit(clip.frames) end
        for _,g in ipairs(clip.saved.groups) do for _,e in ipairs(g.entries) do e.samples._jlrs.persistent=true end end
    end
    c.jlrsSaveDirty=false
end
function JLRSPersist.bind(clip,force)
    if not clip.restored then return end
    JLRSPersist.sceneClock(clip)
    if clip.bound then
        if clip.worldScene and (clip.missingWorld or 0)==0 then return end
        if not force and (g_time or 0)<(clip.nextWorldBind or 0) then return end
    end
    clip.nextWorldBind=(g_time or 0)+1000
    local d=clip.saved;local choices=candidates();local vehicles,locals={},{}
    for i,desc in ipairs(d.vehicles) do
        local v=resolve(desc,choices);if not v then return end
        vehicles[i]=v;locals[i]=localEntries(v);if #locals[i]~=desc.nodes then return end
    end
    local entries={}
    for i,e in ipairs(d.entries) do
        local node=locals[e.vehicle] and locals[e.vehicle][e.slot]
        if not node or (node.world and 1 or 0)~=e.world or (e.name~='' and type(getName)=='function' and getName(node.node)~=e.name) then return end
        entries[i]=node
    end
    if not vehicles[d.target] then return end
    for i,desc in ipairs(d.vehicles) do
        if desc.legacyRecovered and desc.id~='' and not vehicles[i].jlrsIdentitySaved then
            vehicles[i].jlrsPersistentId=desc.id;JLRSPersist.identity(vehicles[i]);desc.legacyRecovered=nil
        end
    end
    local scene={entries={},groups={},sampleCount=d.sceneCount or 0,duration=d.sceneDuration or clip.duration}
    local missing=0
    for _,g in ipairs(d.groups) do
        local object=resolve(g.object,choices)
        if object then
            local group={object=object,vehicle=g.object.vehicle,cargo=g.cargo==1,prop=g.prop==1,entries={},first=#scene.entries+1,remapReload=g.object.remapped}
            local slots=object.components and localEntries(object) or {}
            local railroad=railroadVehicle(object)
            for _,e in ipairs(g.entries) do
                local bound=(e.slot or 0)>0 and slots[e.slot]
                local node=bound and bound.node or object.components and e.component>0 and object.components[e.component] and object.components[e.component].node or (e.propField and e.propField~='' and (JLRSProps and JLRSProps.fieldNode and JLRSProps.fieldNode(object,e.propField) or object[e.propField])) or (object.rootNode or object.nodeId or object.node)
                if e.propField and (e.propField:match('^pickObjects:') or e.propField:match('^placeableMotion:')) then
                    node=JLRSProps and JLRSProps.fieldNode(object,e.propField)
                end
                if railroad and e.world==0 then
                    -- An unresolved legacy local row previously used the root
                    -- fallback above, moving the locomotive body away from its bogies.
                    node=bound and not bound.world and bound.node or railLocalNode(object,e.propField)
                    if node==object.rootNode then node=nil end
                    for _,component in ipairs(object.components or {})do if node==component.node then node=nil;break end end
                end
                if node and entityExists(node) then
                    local entry={node=node,world=e.world~=0,parent=getParent(node),vehicle=g.object.vehicle and object or nil,componentIndex=e.component>0 and e.component or nil,samples=e.samples,sampleIndex=1,prop=g.prop==1,propField=e.propField}
                    group.entries[#group.entries+1]=entry;scene.entries[#scene.entries+1]=entry
                end
            end
            if #group.entries>0 then
                if g.object.legacyRecovered and g.object.id~='' and not object.jlrsIdentitySaved then
                    object.jlrsPersistentId=g.object.id;JLRSPersist.identity(object);g.object.legacyRecovered=nil
                end
                scene.groups[#scene.groups+1]=group
            end
        else missing=missing+1 end
    end
    clip.entries=entries;clip.vehicles=vehicles;clip.target=vehicles[d.target];clip.worldScene=scene;clip.bound=true;clip.missingWorld=missing
end
function JLRSPersist.recover(c,message)
    if c.jlrsRecovery then
        c.jlrsHistoryReadFailed=true;c.jlrsLoadPending=false
        c:notify('History pemulihan juga tidak dapat dibaca; file asli tetap dilindungi. '..tostring(message));return
    end
    c.jlrsPrimaryDamaged=true;c.jlrsRecovery=true;c.jlrsHistoryReadFailed=false
    c.history={};JLRSPersist.revision=0;c.jlrsLoadPending=true
    c:notify('History lama tidak lengkap; Record memakai penyimpanan pemulihan. File asli tidak ditimpa. '..tostring(message))
    JLRSPersist.load(c)
end
-- Recognize pre-marker Change Cars history from the other intact catalog.
-- Compare identities/clock/shared activity provenance only, never take an old
-- pose stream or infer a vehicle from its display name/list order.
function JLRSPersist.remappedCatalog(clip,x,key,other)
    -- Secondary vehicles use independent sparse streams, not the main stream.
    for oi=1,other:getInt('history#count',0)do
        local k='history.clip('..(oi-1)..')'
        if other:getInt(k..'#id')==clip.id
            and other:getInt(k..'.activities.frames#id')==x:getInt(key..'.activities.frames#id')then
            local old={}
            for gi=1,other:getInt(k..'#groups',0)do
                local gk=k..'.group('..(gi-1)..')'
                old[other:getString(gk..'.object#id','')]={config=other:getString(gk..'.object#config',''),stream=other:getInt(gk..'.entry(0).samples#id')}
            end
            for gi,g in ipairs(clip.saved.groups or {})do
                local previous=old[g.object.id]
                local stream=x:getInt(key..'.group('..(gi-1)..').entry(0).samples#id')
                if g.object.vehicle and not g.object.prop and previous and previous.stream and stream
                    and previous.stream~=stream and previous.config~=g.object.config then g.object.remapped=true end
            end
        end
    end
    if clip.frames.jlrsRemapped then return end
    local target=clip.saved.vehicles[clip.saved.target or 1]
    local activity=x:getInt(key..'.activities.frames#id')
    if not target or target.id==''or not activity then return end
    local motion=x:getInt(key..'.frames#id')
    for i=1,other:getInt('history#count',0)do
        local k='history.clip('..(i-1)..')'
        local ti=other:getInt(k..'#target',1)
        local v=k..'.vehicle('..(ti-1)..')'
        if other:getInt(k..'#id')==clip.id and other:getString(v..'#id')==target.id
            and other:getString(v..'#config','')~=target.config
            and other:getInt(k..'.activities.frames#id')==activity
            and other:getInt(k..'.frames#id')~=motion
            and other:getInt(k..'.frames#count',0)==JLRSFrames.count(clip.frames)
            and math.abs((tonumber(other:getString(k..'#duration','-1'))or -1)-clip.duration)<1e-6 then
            clip.frames.jlrsRemapped=true
            clip.frames.jlrsRemappedOwners=clip.frames.jlrsRemappedOwners or {}
            clip.frames.jlrsRemapReloadOwners=clip.frames.jlrsRemapReloadOwners or {}
            clip.frames.jlrsRemappedOwners[target.id]=true;clip.frames.jlrsRemapReloadOwners[target.id]=true
            return
        end
    end
end
function JLRSPersist.load(c)
    if not c.jlrsLoadPending then return end
    local ok,err=JLRSFrames.prepare();if not ok then c:notify('History belum dimuat: '..tostring(err));return end
    local catalogs={};local sawCatalog=false
    for _,suffix in ipairs({'A.xml','B.xml'}) do
        local name=(c.jlrsRecovery and 'history_recovery_' or 'history_')..suffix
        local path=JLRSFrames.directory..name
        local exists=not fileExists or fileExists(path)
        if exists then sawCatalog=true end
        local x=exists and XMLFile.load('jlrsHistoryLoad',path) or nil
        if x then
            -- Reserve IDs even when the original catalog cannot load its streams.
            JLRSFrames.nextId=math.max(JLRSFrames.nextId,x:getInt('history#nextId',0))
            c.historyNextId=math.max(c.historyNextId or 0,x:getInt('history#historyId',0))
            if x:getString('history#complete')=='JLRS_1' then catalogs[#catalogs+1]={xml=x,revision=x:getInt('history#revision',0)} else x:delete() end
        end
    end
    table.sort(catalogs,function(a,b)return a.revision>b.revision end)
    if #catalogs==0 then
        c.jlrsLoadPending=false
        if sawCatalog then JLRSPersist.recover(c,'Katalog History tidak valid.') end
        return
    end
    local loaded,lastError
    for _,catalog in ipairs(catalogs) do
        local x=catalog.xml
        local success,clips=pcall(function()
            local list={}
            for ci=1,x:getInt('history#count',0) do
                local key='history.clip('..(ci-1)..')';local d={vehicles={},entries={},groups={},target=x:getInt(key..'#target',1),sceneCount=x:getInt(key..'#sceneCount',0),sceneDuration=tonumber(x:getString(key..'#sceneDuration','0'))}
                local clip={id=x:getInt(key..'#id'),name=x:getString(key..'#name','Kendaraan'),duration=tonumber(x:getString(key..'#duration','0')),frames=readStream(x,key..'.frames'),saved=d,restored=true,entries={},vehicles={}}
                if not clip.id or clip.id<1 or not clip.duration or clip.duration<0 then error('Identitas/durasi History tidak valid.') end
                for vi=1,x:getInt(key..'#vehicles',0) do d.vehicles[vi]=readDesc(x,key..'.vehicle('..(vi-1)..')') end
                for ei=1,x:getInt(key..'#entries',0) do local ek=key..'.entry('..(ei-1)..')';d.entries[ei]={vehicle=x:getInt(ek..'#vehicle'),slot=x:getInt(ek..'#slot'),world=x:getInt(ek..'#world'),name=x:getString(ek..'#name','')} end
                for gi=1,x:getInt(key..'#groups',0) do
                    local gk=key..'.group('..(gi-1)..')';local g={object=readDesc(x,gk..'.object'),entries={},cargo=x:getInt(gk..'#cargo',0),prop=x:getInt(gk..'#prop',0)}
                    for ei=1,x:getInt(gk..'#entries',0) do local ek=gk..'.entry('..(ei-1)..')';g.entries[ei]={component=x:getInt(ek..'#component',0),slot=x:getInt(ek..'#slot',0),world=x:getInt(ek..'#world',1),propField=x:getString(ek..'#propField',''),samples=readSceneStream(x,ek..'.samples')} end
                    d.groups[gi]=g
                end
                if JLRSActivities then JLRSActivities.read(x,key,clip.frames) end
                for _,previous in ipairs(catalogs)do
                    if previous.revision<catalog.revision then JLRSPersist.remappedCatalog(clip,x,key,previous.xml)end
                end
                list[#list+1]=clip
            end
            return list
        end)
        if success then
            loaded=clips;JLRSPersist.revision=catalog.revision;JLRSFrames.nextId=math.max(JLRSFrames.nextId,x:getInt('history#nextId',0));c.historyNextId=x:getInt('history#historyId',0);break
        else lastError=clips end
    end
    for _,catalog in ipairs(catalogs) do catalog.xml:delete() end
    c.jlrsLoadPending=false
    if not loaded then JLRSPersist.recover(c,lastError);return end
    c.history=loaded
    for _,clip in ipairs(loaded) do JLRSPersist.bind(clip);c.historyNextId=math.max(c.historyNextId,clip.id) end
    c:notify('History dimuat dari disk | '..#loaded..' record')
end
function JLRSPersist.safeSave(c)
    if c.jlrsHistoryReadFailed then c:notify('History lama rusak: penyimpanan diblokir untuk melindungi file asli.');return false end
    local ok,err=pcall(JLRSPersist.save,c)
    if not ok then c:notify('History masih tersedia dalam sesi, tetapi belum tersimpan ke disk: '..tostring(err)) end
    return ok
end
local loadMap=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=loadMap(c,...);JLRSPersist.revision=0;c.jlrsLoadPending=c.mission~=nil;c.jlrsHistoryReadFailed=false;c.jlrsRecovery=nil;c.jlrsPrimaryDamaged=nil;return result
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c==JLReplayStudio then JLRSPersist.load(c);if c.jlrsHistoryReadFailed then c:notify('Record diblokir karena History lama gagal dibaca.');return end end
    return start(c,...)
end
local archive=JLRSHistory.archive
JLRSHistory.archive=function(c,...)
    local before=#(c.history or {});local result=archive(c,...)
    if c==JLReplayStudio and #c.history>before then JLRSPersist.safeSave(c) end
    return result
end
local valid=JLRSHistory.valid
JLRSHistory.valid=function(clip) JLRSPersist.bind(clip);return valid(clip) end
local replay=JLRSHistory.replay
JLRSHistory.replay=function(c,clip,...)
    JLRSPersist.bind(clip,true)
    if (clip.missingWorld or 0)>0 then c:notify('Sebagian objek dunia tidak tersedia di savegame ini: '..clip.missingWorld) end
    return replay(c,clip,...)
end
local remove=JLRSHistory.delete
JLRSHistory.delete=function(c,clip,...)
    local index;for i,v in ipairs(c.history) do if v==clip then index=i;break end end
    if not index then return end
    -- Commit the removal first; never delete chunks referenced by the current catalog on failure.
    table.remove(c.history,index)
    if not JLRSPersist.safeSave(c) then table.insert(c.history,index,clip);return end
    table.insert(c.history,index,clip)
    clip.frames._jlrs.persistent=false
    for _,g in ipairs(clip.saved and clip.saved.groups or {}) do for _,e in ipairs(g.entries) do e.samples._jlrs.persistent=false end end
    return remove(c,clip,...)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    if c.mission then
        JLRSPersist.load(c)
        if c.jlrsSaveDirty and not c.recording then JLRSPersist.safeSave(c) end
    end
    return draw(c,...)
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.mission then
        JLRSPersist.load(c)
        if c.recording then JLRSRecorder.stopRecord(c) end
        c:stop();JLRSPersist.safeSave(c)
    end
    return deleteMap(c,...)
end
