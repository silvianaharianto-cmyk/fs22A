-- Optional visual adapter for the supplied AAAAA_Fly_Chain_Cargo V1.2.30.
-- Four scalar channels per vehicle, not 80 link transforms per sample.
-- No flying controls, vehicle poses, cargo physics or source asset edits.
JLRSFlyChain={states={},snapshots={},identities={}}
local C=JLRSFlyChain
local asset=g_currentModDirectory..'assets/flyChain/rantai_runtime.i3d'
local centers={0.353265,0.832981,1.284172,1.763885,2.215075,2.694790,3.145980,3.625695,4.076890,4.556600,5.007791,5.487507,5.938698,6.418411,6.869601,7.349316,7.800506,8.280221,8.731416,9.211126,9.662317,10.142033,10.593224,11.072938,11.524127,12.003842,12.455032,12.934748,13.385942,13.865652,14.316843,14.796559,15.247750,15.727464,16.178654,16.658369,17.109559,17.589274,18.040469,18.520179,18.971370,19.451086,19.902276,20.381990,20.833180,21.312895,21.764085,22.243800,22.694995,23.174705,23.625896,24.105612,24.556803,25.036516,25.487706,25.967421,26.418611,26.898326,27.349521,27.829231,28.280422,28.760138,29.211329,29.691042,30.142232,30.621948,31.073138,31.552853,32.004047,32.483758,32.934948,33.414664,33.865855,34.345569,34.796759,35.276474,35.727664,36.207379,36.658574,37.138284}
local function valid(n)return n and n~=0 and entityExists(n)end
local function root(v)return v and ((v.components and v.components[1]and v.components[1].node)or v.rootNode)end
local function clamp(x,a,b)return math.max(a,math.min(b,x))end
local function anchorPosition(node)
    local x,y,z=localToWorld(node,0,.98,0)
    local ux,uy,uz=localDirectionToWorld(node,0,1,0)
    local length=math.sqrt(ux*ux+uy*uy+uz*uz)
    if length>.001 then ux,uy,uz=ux/length,uy/length,uz/length else ux,uy,uz=0,1,0 end
    return x+ux*.933,y+uy*.933,z+uz*.933
end
local function sourceLike(s)
    return type(s)=='table'and type(s.update)=='function'and type(s.draw)=='function'
        and type(s.maxRope)=='number'and type(s.minCargoRope)=='number'
end
function C.playing(v)
    if not v then return false end
    local c=JLReplayStudio
    if c.recording and c.target==v then return false end
    return C.states[v]~=nil
end
function C.hideSource(s)
    if valid(s.chainRoot)then
        if C.sourceHidden==nil then C.sourceHidden=getVisibility(s.chainRoot)end
        setVisibility(s.chainRoot,false)
    end
end
function C.restoreSource()
    if C.sourceHidden~=nil then
        local s=C.source;if s and valid(s.chainRoot)then setVisibility(s.chainRoot,C.sourceHidden)end
        C.sourceHidden=nil
    end
end
function C.bind(s)
    C.source=s
    if C.hooks then return s end
    local hooks={};C.hooks=hooks
    for _,name in ipairs({'update','draw','keyEvent'})do
        local original=s[name]
        if type(original)=='function'then
            local wrapper=function(self,...)
                if C.playing(self.carrier)then C.hideSource(self);return end
                C.restoreSource();return original(self,...)
            end
            hooks[name]={original=original,wrapper=wrapper};s[name]=wrapper
        end
    end
    return s
end
function C.find()
    if C.source then return C.source end
    if sourceLike(HMFlyingVehicle)then return C.bind(HMFlyingVehicle)end
    for k,v in pairs(g_modEventListeners or {})do
        local candidate=type(v)=='table'and v or k
        if sourceLike(candidate)then return C.bind(candidate)end
    end
    -- Mod-local globals can also be exposed through their environment table.
    for _,environment in pairs(_G)do if type(environment)=='table'then
        local candidate=rawget(environment,'HMFlyingVehicle')
        if sourceLike(candidate)then return C.bind(candidate)end
    end end
end
local function identity(v)
    if not v then return 0,0 end
    local id=v.jlrsPersistentId
    if not id and JLRSPersist then id=JLRSPersist.identity(v)end
    if not id then return 0,0 end
    local saved=C.identities[v]
    if saved and saved.id==id then return saved.a,saved.b end
    local a,b=5381,2166136261
    for i=1,#id do local c=id:byte(i);a=(a*257+c)%4294967296;b=(b*65599+c)%4294967296 end
    C.identities[v]={id=id,a=a,b=b};return a,b
end
local function snapshot(v,fresh)
    local previous=C.snapshots[v];local tick=g_time or 0
    if not fresh and previous and previous.tick==tick then return previous end
    local p={tick=tick,state={0,0,0,0,0,0},length={0,0,0,0,0,0},top={0,0,0,0,0,0},anchor={0,0,0,0,0,0}}
    C.snapshots[v]=p
    local s=C.find();local n=root(v)
    if not s or not s.active or s.carrier~=v or not valid(n)then return p end
    local rope=math.max(0,s.rope or 0)
    local cargo=s.cargo and valid(s.lastCargoNode)
    if rope<=.025 and not cargo then return p end
    local ax,ay,az=localToWorld(n,0,1.05,0)
    local cx,cy,cz=getWorldTranslation(n)
    p.top[1],p.top[2],p.top[3]=0,1.05,0
    p.top[4],p.top[5],p.top[6]=worldToLocal(n,cx,cy-rope,cz)
    local dx,dy,dz=cx-ax,cy-rope-ay,cz-az
    local length=cargo and (rope+.07)or math.sqrt(dx*dx+dy*dy+dz*dz)
    if not cargo and length<.6 then return p end
    local count=clamp(math.floor(1+(length-1.944700-.353265)/.4655+.5),1,80)
    p.state[1],p.state[2],p.state[3]=1,cargo and 1 or 0,count;p.length[1]=length
    if cargo then
        local node=s.lastCargoNode
        p.anchor[1],p.anchor[2],p.anchor[3]=anchorPosition(node)
        p.anchor[4],p.anchor[5],p.anchor[6]=getWorldRotation(node)
        p.state[4],p.state[5]=identity(s.cargo)
    end
    return p
end
local function drop(state)
    if state and valid(state.scene)then delete(state.scene)end
end
function C.release(v,ch)
    local s=C.states[v]
    if s and (not ch or s.owner==ch)then drop(s);C.states[v]=nil end
    if C.source and not C.playing(C.source.carrier)then C.restoreSource()end
end
local function ensure(s)
    if valid(s.scene)then return true end
    if s.failed then return false end
    local scene=loadI3DFile(asset,false,false,true)
    if not valid(scene)then s.failed=true;print('[J_L Cinema Studio] Rantai replay gagal dimuat.');return false end
    link(getRootNode(),scene)
    local group=scene
    if getNumOfChildren(group)~=81 and getNumOfChildren(group)>0 then group=getChildAt(group,0)end
    if getNumOfChildren(group)~=81 then delete(scene);s.failed=true;return false end
    s.scene=scene;s.group=group;s.links={}
    for i=1,80 do s.links[i]=getChildAt(group,i-1)end
    s.anchor=getChildAt(group,80);setVisibility(scene,false)
    return true
end
local function cargoFor(s,a,b)
    if a==0 and b==0 then return end
    local cached=s.cargo
    if cached and valid(root(cached))then
        local x,y=identity(cached);if x==a and y==b then return cached end
    end
    local tick=g_time or 0
    if s.cargoA==a and s.cargoB==b and s.cargoLookupTime and tick>=s.cargoLookupTime and tick-s.cargoLookupTime<1000 then return end
    s.cargoA=a;s.cargoB=b;s.cargoLookupTime=tick
    for _,v in ipairs(g_currentMission and g_currentMission.vehicles or {})do
        local x,y=identity(v)
        if x==a and y==b then s.cargo=v;return v end
    end
end
local function render(v,s)
    local p=s.parts;local flags=p.state
    if not flags or flags[1]<.5 or not C.playing(v)then if valid(s.scene)then setVisibility(s.scene,false)end;return end
    if not p.top or not p.length or not p.anchor or not valid(root(v))or not ensure(s)then return end
    local count=clamp(math.floor(flags[3]+.5),1,80);local attached=flags[2]>=.5
    local ax,ay,az=localToWorld(root(v),p.top[1],p.top[2],p.top[3])
    local rx,ry,rz=0,0,0;local length=p.length[1]
    local bx,by,bz
    -- All links use world transforms, so changing attachment/free-hang modes
    -- cannot leave a previous group transform applied a second time.
    setTranslation(s.group,0,0,0);setRotation(s.group,0,0,0)
    if attached then
        bx,by,bz=p.anchor[1],p.anchor[2],p.anchor[3]
        rx,ry,rz=p.anchor[4],p.anchor[5],p.anchor[6]
        local cargo=cargoFor(s,flags[4],flags[5])
        if cargo and C.playing(cargo)and valid(root(cargo))then
            bx,by,bz=anchorPosition(root(cargo));rx,ry,rz=getWorldRotation(root(cargo))
        end
        setWorldTranslation(s.anchor,bx,by,bz);setWorldRotation(s.anchor,rx,ry,rz)
        local ex,ey,ez=localToWorld(s.anchor,0,.865,0)
        local dx,dy,dz=ex-ax,ey-ay,ez-az;local distance=math.sqrt(dx*dx+dy*dy+dz*dz)
        if distance<.05 then setVisibility(s.scene,false);return end
        local horizontal=math.sqrt(dx*dx+dz*dz)
        local pitch=math.atan2(horizontal,-dy);local yaw=horizontal>.00001 and math.atan2(-dx,-dz)or 0
        local first=math.min(.353265,distance*.45)
        local last=math.max(first,distance-math.min(.26,distance*.35))
        for i=1,count do
            local offset=count>1 and first+(last-first)*(i-1)/(count-1)or (first+last)*.5
            local t=offset/distance;local node=s.links[i]
            setWorldTranslation(node,ax+dx*t,ay+dy*t,az+dz*t);setWorldRotation(node,pitch,yaw,0)
        end
    else
        bx,by,bz=localToWorld(root(v),p.top[4],p.top[5],p.top[6])
        local dx,dy,dz=bx-ax,by-ay,bz-az;local distance=math.sqrt(dx*dx+dy*dy+dz*dz)
        if distance<.1 or length<.6 then setVisibility(s.scene,false);return end
        local horizontal=math.sqrt(dx*dx+dz*dz)
        rx=math.atan2(horizontal,-dy);ry=horizontal>.0001 and math.atan2(-dx,-dz)or 0
        setWorldTranslation(s.group,ax,ay,az);setWorldRotation(s.group,rx,ry,0)
        local lastSource=centers[count];local last=math.max(.353265,length-1.944700)
        local stretch=count>1 and clamp((last-.353265)/(lastSource-.353265),.82,1.18)or 1
        for i=1,count do
            setTranslation(s.links[i],0,-(.353265+(centers[i]-.353265)*stretch),0);setRotation(s.links[i],0,0,0)
        end
        setTranslation(s.anchor,0,-length+.933,0);setRotation(s.anchor,0,0,0)
    end
    if s.count~=count then for i=1,80 do setVisibility(s.links[i],i<=count)end;s.count=count end
    setVisibility(s.anchor,true);setVisibility(s.scene,true);setVisibility(s.group,true)
end
function C.flush()
    for v,s in pairs(C.states)do
        if valid(root(v))then render(v,s)else C.release(v)end
    end
    if C.source and C.playing(C.source.carrier)then C.hideSource(C.source)end
end
JLRSActivities.registerAdapter('jlrsFlyChain',{
    discover=function(v)
        if not C.find()then return {}end
        return {{name='state',mode='step'},{name='length',mode='linear'},
            {name='top',mode='linear'},{name='anchor',mode='transform'}}
    end,
    read=function(v,ch)return snapshot(v,true)[ch.name]end,
    readInto=function(v,ch,out)
        local p=snapshot(v,false)[ch.name]
        for i=1,6 do out[i]=p[i]end;return out
    end,
    write=function(v,ch,values,paused,restoring)
        if restoring then if ch.name=='state'then C.release(v,ch)end;return end
        local s=C.states[v]
        if ch.name=='state'then
            if not s then s={parts={}};C.states[v]=s end
            if s.owner~=ch then s.parts={};s.owner=ch end
        end
        if s then s.parts[ch.name]=values end
    end
})
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...)
    if not c.jlrsRenderBoundary then C.flush()end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);C.find();return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    for v in pairs(C.states)do C.release(v)end;C.restoreSource()
    if C.source and C.hooks then for name,h in pairs(C.hooks)do
        if C.source[name]==h.wrapper then C.source[name]=h.original end
    end end
    C.source=nil;C.hooks=nil;C.snapshots={};C.identities={}
    return unload(c,...)
end
