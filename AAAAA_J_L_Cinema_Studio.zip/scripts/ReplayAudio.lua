-- Three scalar audio channels share the existing streamed pose frame.
JLRSAudio={owners=setmetatable({},{__mode='k'}),idleOwners=setmetatable({},{__mode='k'})}
local function clamp(x,a,b) return math.max(a,math.min(b,x)) end
local capture=JLRSRecorder.capture
JLRSRecorder.capture=function(entries)
    local pose=capture(entries)
    local v=entries[1] and entries[1].vehicle
    local spec=v and v.spec_motorized;local motor=spec and spec.motor
    if pose and motor and motor.getLastModulatedMotorRpm then
        local low=motor.minRpm or 0;local high=motor.maxRpm or low+1
        pose[#pose+1]=clamp((motor:getLastModulatedMotorRpm()-low)/math.max(1,high-low),0,1)
        pose[#pose+1]=clamp(spec.smoothedLoadPercentage or spec.rawLoadPercentage or 0,-1,1)
        pose[#pose+1]=spec.isMotorStarted and 1 or 0
    end
    return pose
end
-- Suppress only a separate, identified idle layer when this engine also has
-- a running layer. A GLS containing the whole engine must never be muted.
local function idleSample(sample)
    if type(sample)~='table'or sample.isGlsFile or (sample.filename or ''):lower():match('%.gls$')then return false end
    local filename=(sample.filename or ''):match('[^/\\]+$')or ''
    local label=' '..((sample.templateName or '')..' '..(sample.sampleName or '')..' '..filename):lower():gsub('[^%w]',' ')..' '
    return label:find(' idle ',1,true)~=nil
end
function JLRSAudio.installMix()
    local manager=g_soundManager
    if not manager or JLRSAudio.mixManager==manager or type(manager.getModifierFactor)~='function'then return end
    local previous=manager.getModifierFactor
    JLRSAudio.mixManager=manager;JLRSAudio.mixRaw=rawget(manager,'getModifierFactor')
    local wrapper=function(owner,sample,attribute,...)
        local value=previous(owner,sample,attribute,...)
        local state=attribute=='volume'and JLRSAudio.idleOwners[sample]
        if state and type(value)=='number'then return value*(state.idleGain or 1)end
        return value
    end
    JLRSAudio.mixWrapper=wrapper;manager.getModifierFactor=wrapper
end
function JLRSAudio.classify(state)
    local idle={};local running=false
    for _,sample in pairs(state.spec.motorSamples or {})do
        if idleSample(sample)then idle[#idle+1]=sample
        elseif type(sample)=='table'then
            local label=(sample.templateName or ''):upper()
            local filename=(sample.filename or ''):lower()
            if sample.isGlsFile or filename:match('%.gls$')or label:find('MOTOR_ONLOAD',1,true)
                or label:find('MOTOR_OFFLOAD',1,true)or label:find('MOTOR_RUN',1,true)
                or filename:match('[^/\\]*run[^/\\]*$')or filename:match('[^/\\]*load[^/\\]*$')then running=true end
        end
    end
    state.idleSamples=running and idle or {}
    for _,sample in ipairs(state.idleSamples)do JLRSAudio.idleOwners[sample]=state end
end
local function stopStarter(state)
    if state.starter and g_soundManager and g_soundManager.stopSample then g_soundManager:stopSample(state.starter)end
    state.starter=nil
end
function JLRSAudio.restore(track)
    local state=track.audioState
    if not state then return end
    stopStarter(state)
    for _,sample in ipairs(state.idleSamples or {})do
        if JLRSAudio.idleOwners[sample]==state then JLRSAudio.idleOwners[sample]=nil end
    end
    if JLRSAudio.owners[track.target]==track then JLRSAudio.owners[track.target]=nil end
    for name,hook in pairs(state.hooks) do
        if state.motor[name]==hook.wrapper then state.motor[name]=hook.raw end
    end
    state.spec.smoothedLoadPercentage=state.load
    state.spec.isMotorStarted=state.engineStarted
    if g_soundManager and g_soundManager.updateSampleModifiers then
        for _,sample in ipairs(state.idleSamples or {})do
            g_soundManager:updateSampleModifiers(sample)
            if g_soundManager.updateSampleAttributes then g_soundManager:updateSampleAttributes(sample)end
        end
    end
    if g_soundManager and state.spec.motorSamples and state.playing~=nil then
        if state.playing and g_soundManager.playSamples then JLRSAudio.resumeLoops(state.spec)
        elseif not state.playing and g_soundManager.stopSamples then g_soundManager:stopSamples(state.spec.motorSamples) end
    end
    track.audioState=nil;track.replayAudioPose=nil;track.replayAudioTime=nil
end
-- Run the vehicle's own sound curves against the recorded RPM/load before the
-- next render. GLS parameters alone do not update separate idle/run WAV layers.
function JLRSAudio.updateMix(state,rpm,load,playing)
    local manager=g_soundManager
    JLRSAudio.installMix()
    -- Fade out the separate idle layer as recorded RPM rises. Never increase
    -- the running layers or replace the vehicle's own pitch/load curves.
    local fade=clamp((rpm-.02)/.10,0,1)
    state.idleGain=playing and (1-fade*fade*(3-2*fade))or 1
    if not manager or not manager.updateSampleModifiers then return end
    if state.mixRpm==rpm and state.mixLoad==load and state.mixOn==playing then return end
    state.mixRpm=rpm;state.mixLoad=load;state.mixOn=playing
    for _,sample in pairs(state.spec.motorSamples or {})do
        manager:updateSampleModifiers(sample)
        if manager.updateSampleAttributes then manager:updateSampleAttributes(sample)end
    end
end
-- Resume continuous samples directly: do not retrigger ignition or its predecessor.
function JLRSAudio.resumeLoops(spec,afterSample)
    local manager=g_soundManager;local transient=spec.samples or {}
    if afterSample and manager.playSamples then
        local loops={}
        for _,sample in pairs(spec.motorSamples or {})do
            if sample~=transient.motorStart and sample~=transient.motorStop then loops[#loops+1]=sample end
        end
        if manager.stopSamples then manager:stopSamples(loops)end
        manager:playSamples(loops,0,afterSample)
        return
    end
    if manager.playSample then
        for _,sample in pairs(spec.motorSamples or {})do
            if sample~=transient.motorStart and sample~=transient.motorStop then
                if not manager.getIsSamplePlaying or not manager:getIsSamplePlaying(sample) then
                    manager:playSample(sample,0,nil)
                end
            end
        end
    elseif manager.playSamples then
        local loops={}
        for _,sample in pairs(spec.motorSamples or {})do
            if sample~=transient.motorStart and sample~=transient.motorStop then loops[#loops+1]=sample end
        end
        manager:playSamples(loops,0,nil)
    end
end
function JLRSAudio.tick(track)
    local v=track.target;local spec=v and v.spec_motorized;local motor=spec and spec.motor
    if not motor or not g_soundManager or not spec.motorSamples then return end
    local owner=JLRSAudio.owners[v]
    local rank=track.frames and 2 or 1
    if owner and owner~=track and owner.audioState then
        local otherRank=owner.frames and 2 or 1
        if otherRank>=rank then return end
        JLRSAudio.restore(owner)
    end
    JLRSAudio.owners[v]=track
    if not track.audioState then
        local state={spec=spec,motor=motor,hooks={},load=spec.smoothedLoadPercentage,engineStarted=spec.isMotorStarted}
        if g_soundManager.getIsSamplePlaying and spec.motorSamples[1] then state.playing=g_soundManager:getIsSamplePlaying(spec.motorSamples[1]) end
        for _,name in ipairs({'getLastModulatedMotorRpm','getLastMotorRpm','getEqualizedMotorRpm'}) do
            if type(motor[name])=='function' then
                local hook={raw=rawget(motor,name)}
                local previous=motor[name]
                hook.wrapper=function(self,...)return state.rpm or previous(self,...)end
                state.hooks[name]=hook;motor[name]=hook.wrapper
            end
        end
        JLRSAudio.classify(state)
        track.audioState=state
    end
    local pose=track.replayAudioTime==track.replayTime and track.replayAudioPose
        or JLRSRecorder.sample(track,track.replayTime)
    local n=#track.entries*6;local rpm,load,on=pose[n+1],pose[n+2],pose[n+3]
    if rpm==nil then
        -- Older History has no recorded audio. Estimate from recorded speed;
        -- exact engine/load playback requires a new recording.
        local t=math.min(track.duration,track.replayTime+0.05)
        local future=JLRSRecorder.sample(track,t);local span=t-track.replayTime
        local speed=span>0 and math.sqrt((future[1]-pose[1])^2+(future[2]-pose[2])^2+(future[3]-pose[3])^2)/span or 0
        rpm=clamp(speed/25,0,1);load=rpm;on=1
    end
    local state=track.audioState
    state.rpm=(motor.minRpm or 0)+rpm*((motor.maxRpm or 1)-(motor.minRpm or 0))
    spec.smoothedLoadPercentage=load
    -- Pause freezes timeline/physics, not the engine. Keep its continuous sound
    -- and recorded RPM/load alive; no stop/start edge is introduced by Pause.
    local playing=on>=0.5
    spec.isMotorStarted=playing
    JLRSAudio.updateMix(state,rpm,load,playing)
    if state.active~=playing then
        if playing then
            local c=JLReplayStudio
            local paused=track.paused or (c and (c.paused or c.livePaused or (c.mission and c.mission.isPaused)))
            local starter=spec.samples and spec.samples.motorStart
            -- Only a recorded OFF -> ON edge is ignition. Starting an already
            -- running clip, seeking, ownership takeover and Pause are not.
            local ignition=state.active==false and not paused and not JLRSAudio.seeking
                and starter and g_soundManager.playSample
            if ignition then
                local stopping=spec.samples and spec.samples.motorStop
                if stopping and g_soundManager.stopSample then g_soundManager:stopSample(stopping)end
                local already=g_soundManager.getIsSamplePlaying and g_soundManager:getIsSamplePlaying(starter)
                if not already then g_soundManager:playSample(starter);state.starter=starter end
                JLRSAudio.resumeLoops(spec,starter)
            else JLRSAudio.resumeLoops(spec)end
        else
            stopStarter(state)
            if g_soundManager.stopSamples then g_soundManager:stopSamples(spec.motorSamples)end
        end
        state.active=playing
    end
    if playing and g_soundManager.setSamplesLoopSynthesisParameters then
        g_soundManager:setSamplesLoopSynthesisParameters(spec.motorSamples,rpm,load)
    end
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    local result=tick(track,...)
    if track.replaying then JLRSAudio.tick(track) else JLRSAudio.restore(track) end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    JLRSAudio.restore(track);return stop(track,...)
end

-- This also covers allMotor activity proxies dispatched during a seek.
local seek=JLRSRecorder.seek
JLRSRecorder.seek=function(track,...)
    local previous=JLRSAudio.seeking;JLRSAudio.seeking=true
    local ok,result=pcall(seek,track,...)
    JLRSAudio.seeking=previous
    if not ok then error(result,0)end
    return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=unload(c,...)
    JLRSAudio.idleOwners=setmetatable({},{__mode='k'})
    local manager=JLRSAudio.mixManager
    if manager and manager.getModifierFactor==JLRSAudio.mixWrapper then
        manager.getModifierFactor=JLRSAudio.mixRaw;JLRSAudio.mixManager=nil
    end
    return result
end
