JLRSVehicleScope={}
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c==JLReplayStudio and JLRSWorld.isTrain(g_currentMission.controlledVehicle) then c:notify('Kereta api tidak termasuk Record kendaraan.');return end
    return start(c,...)
end
local valid=JLRSHistory.valid
JLRSHistory.valid=function(clip,...)
    if JLRSWorld.isTrain(clip.target) then return false end
    for _,vehicle in ipairs(clip.vehicles or {}) do if JLRSWorld.isTrain(vehicle) then return false end end
    return valid(clip,...)
end

local play=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if JLRSWorld.isTrain(c.target) then c:notify('Kereta api tidak termasuk Replay kendaraan.');return end
    for _,v in ipairs(c.recordVehicles or {}) do if JLRSWorld.isTrain(v) then c:notify('Record mengandung kereta; tidak dijalankan.');return end end
    return play(c,...)
end
