-- Optional adapters for the supplied Instant Fire / Instant Wash specializations.
-- Persist scalar status in the existing activity stream, never particle node IDs.
JLRSInstantEffects={owners=setmetatable({},{__mode='k'}),playback=setmetatable({},{__mode='k'}),observed=setmetatable({},{__mode='k'})}
local E=JLRSInstantEffects
local definitions={'instantFire','instantWash','instantWashRed'}
local function specFor(v,name) return v and v['spec_'..name] end
-- Emission edges can be shorter than the motion sample interval. Insert only
-- the changed six-scalar activity row, preserving the existing motion scheduler.
function E.edge(binding,on)
    local c=JLReplayStudio;local state=c and c.activityRecording
    if not c or not c.recording or not state or not state.last or E.writing or c.instantEffectWriteError then return end
    if binding.data~=state.data then
        binding.data=state.data;binding.index=nil
        for i,ch in ipairs(state.data.schema)do
            if ch.kind=='custom' and ch.getter=='jlrsInstantEffects_'..binding.name
                and ch.owner==binding.vehicle.jlrsPersistentId then binding.index=i;binding.channel=ch;break end
        end
    end
    if not binding.index then return end
    local pending=math.max(0,c.pendingRecordDt or 0)
    if c.lastClock and g_time and g_time>=c.lastClock then pending=math.max(pending,(g_time-c.lastClock)/1000)end
    local time=(c.recordTime or 0)+pending
    if state.lastSampleTime and time<=state.lastSampleTime then return end
    local pose={};for i,value in ipairs(state.last)do pose[i]=value end
    local adapter=JLRSActivities.adapters['jlrsInstantEffects_'..binding.name]
    local values=adapter.read(binding.vehicle,binding.channel)
    local n=(binding.index-1)*6
    for j=1,6 do pose[n+j]=values[j]or 0 end
    if state.lastTime and state.lastSampleTime and state.lastTime>state.lastSampleTime then
        JLRSFrames.push(state.data.frames,{t=state.lastTime,pose=state.last})
    end
    JLRSFrames.push(state.data.frames,{t=time,pose=pose})
    state.last=pose;state.lastTime=time;state.lastSampleTime=time
end
function E.install()
    if not ParticleUtil or type(ParticleUtil.setEmittingState)~='function' or E.installed then return end
    local setter=ParticleUtil.setEmittingState
    ParticleUtil.setEmittingState=function(effect,on,...)
        local owner=E.playback[effect]
        if owner~=nil then on=owner end
        local previous=E.observed[effect]
        local result=setter(effect,on,...)
        local binding=E.owners[effect]
        if binding or owner~=nil then
            E.observed[effect]=on==true
            if binding and owner==nil and previous~=(on==true)then
                local ok,why=pcall(E.edge,binding,on==true)
                if not ok then JLReplayStudio.instantEffectWriteError=tostring(why)end
            end
        end
        return result
    end
    E.installed=true
end
-- Report storage errors through the recorder's existing safe Stop/History
-- handling, never by throwing from a foreign vehicle's particle callback.
local record=JLRSActivities.record
JLRSActivities.record=function(c,...)
    if c.instantEffectWriteError then
        local why=c.instantEffectWriteError;c.instantEffectWriteError=nil
        error('Cache efek tidak dapat ditulis: '..why)
    end
    return record(c,...)
end
local function read(v,ch)
    local s=specFor(v,ch.name);local effect=s and s.washEffect
    if not effect then return {0,0,0,0,0,0} end
    local emitting=E.observed[effect]
    if emitting==nil then emitting=effect.isEmitting==true end
    return {effect.isActive and 1 or 0,emitting and 1 or 0,s.washTime or 0,0,0,0}
end
for _,name in ipairs(definitions) do
    local adapterName='jlrsInstantEffects_'..name
    JLRSActivities.registerAdapter(adapterName,{
        discover=function(v)
            local s=specFor(v,name)
            E.install()
            if s and s.washEffect then
                E.owners[s.washEffect]={vehicle=v,name=name}
                return {{name=name,mode='step',index=1}}
            end
            return {}
        end,
        read=read,
    reuseReplayValues=true,
        write=function(v,ch,values,paused,restoring)
            local s=specFor(v,ch.name);local effect=s and s.washEffect
            if not effect then return end -- Replacement without the specialization / mod removed.
            local active=values[1]>=0.5
            -- Older takes can contain active/timer but no emitter flag because
            -- some PS utility versions do not update effect.isEmitting.
            local emitting=values[2]>=0.5 or ((ch.index or 0)==0 and active and values[3]>0)
            -- Native onUpdate counts down in frames, not milliseconds. During replay
            -- the recorded clock owns termination, including inactive vehicles.
            s.washTime=restoring and values[3] or ((active or emitting) and 1000000000 or 0)
            effect.isActive=active
            if paused and not restoring then emitting=false end
            if restoring then E.playback[effect]=nil else E.playback[effect]=emitting end
            if ParticleUtil and ParticleUtil.setEmittingState then
                E.install()
                if E.observed[effect]~=emitting or effect.isEmitting~=emitting then
                    local previous=E.writing;E.writing=true
                    local ok,err=pcall(ParticleUtil.setEmittingState,effect,emitting)
                    E.writing=previous
                    if not ok then error(err,0)end
                    effect.isEmitting=emitting
                end
                -- Enforce the native geometry state on transitions, including
                -- legacy generic-particle ownership left in an old History.
                if effect.geometry and setEmittingState and E.nativeState==nil then E.nativeState=setmetatable({},{__mode='k'})end
                if effect.geometry and setEmittingState and E.nativeState[effect]~=emitting then
                    setEmittingState(effect.geometry,emitting);E.nativeState[effect]=emitting
                end
            end
        end
    })
end
