-- Record actual sound triggers, independently of the much shorter particle timers.
JLRSInstantAudio={providers={},sounds={},voices=setmetatable({},{__mode='k'})}
local S=JLRSInstantAudio
S.INNER_RADIUS=5;S.OUTER_RADIUS=60
local names={'instantFire','instantWash','instantWashRed'}
local methods={instantFire='sendinstantFireEvent',instantWash='sendInstantWashEvent',instantWashRed='sendinstantWashRedEvent'}
S.bindings=setmetatable({},{__mode='k'})
function S.bind(v,name,p)
    local spec=v['spec_'..name];if not spec then return end
    spec._jlrsSoundProvider=p
    local method=methods[name];local original=v[method]
    if type(original)~='function' then return end
    local bindings=S.bindings[v];if not bindings then bindings={};S.bindings[v]=bindings end
    if bindings[name] then return end
    local hook={raw=rawget(v,method),method=method}
    hook.wrapper=function(self,active,time,...)
        local owner=self.getRootVehicle and self:getRootVehicle() or self
        local state=owner['spec_'..name]
        local wasActive=state and state.washEffect and state.washEffect.isActive
        local result=original(self,active,time,...)
        local c=JLReplayStudio
        -- This registered vehicle method is shared across mod environments.
        -- The originating mod has already played its sound before invoking it.
        if c and c.recording and state and active and not wasActive and isSamplePlaying and isSamplePlaying(p.washSound) then
            if state._jlrsSoundIntercepted then state._jlrsSoundIntercepted=nil
            else state._jlrsSoundSequence=(state._jlrsSoundSequence or 0)+1;state._jlrsSoundStart=c.recordTime or 0 end
            state._jlrsSoundProvider=p
            local sound=S.sounds[p.washSound];if sound then sound.owner=owner end
        end
        return result
    end
    bindings[name]=hook;v[method]=hook.wrapper
end
local function register(env)
    if type(env)~='table' then return end
    for _,name in ipairs(names) do
        local p=rawget(env,name)
        if type(p)=='table' and p.washSound and p.modDirectory then
            S.providers[name]=S.providers[name] or p
            S.sounds[p.washSound]={name=name,provider=p}
        end
    end
end
function S.find(v,name)
    local spec=v and v['spec_'..name]
    if spec and spec._jlrsSoundProvider then return spec._jlrsSoundProvider end
    local list=v and v.specializations
    if not list and v and g_vehicleTypeManager and g_vehicleTypeManager.types then
        local definition=g_vehicleTypeManager.types[v.typeName];list=definition and definition.specializations
    end
    for _,p in pairs(list or {}) do
        if type(p)=='table' and p.washSound and p.modDirectory and type(p[methods[name]])=='function' then
            S.providers[name]=p;S.sounds[p.washSound]=S.sounds[p.washSound] or {name=name,provider=p}
            S.bind(v,name,p);return p
        end
    end
    if S.providers[name]==nil then
        register(_G)
        for _,env in pairs(_G) do register(env) end
        for _,p in pairs(v.specializations or {}) do
            if type(p)=='table' and p.washSound and p.modDirectory then
                -- Specializations can also be available only through their mod namespace.
                for _,env in pairs(_G) do
                    if type(env)=='table' and rawget(env,name)==p then register(env) end
                end
            end
        end
    end
        S.providers[name]=S.providers[name] or false
    local p=S.providers[name] or nil
    if p then S.bind(v,name,p) end
    return p
end
local function root(v)
    if v and v.getRootVehicle then return v:getRootVehicle() end
    return v
end
local nativePlay=playSample
if type(nativePlay)=='function' then
    playSample=function(sample,...)
        local result=nativePlay(sample,...)
        local sound=S.sounds[sample];local c=JLReplayStudio
        if sound and c and c.recording then
            local v=root(g_currentMission and g_currentMission.controlledVehicle)
            local spec=v and v['spec_'..sound.name]
            if spec then
                spec._jlrsSoundSequence=(spec._jlrsSoundSequence or 0)+1
                spec._jlrsSoundStart=c.recordTime or 0
                spec._jlrsSoundIntercepted=true
                spec._jlrsSoundProvider=sound.provider
                sound.owner=v
            end
        end
        return result
    end
end
function S.release(v,name)
    local voices=S.voices[v];local voice=voices and voices[name]
    if not voice then return end
    if stopSample then pcall(stopSample,voice.sample,0,0) end
    -- AudioSource owns its sample. Delete the node once, not both handles.
    if delete then pcall(delete,voice.node or voice.sample) end
    voices[name]=nil
end
for _,name in ipairs(names) do
    local adapter=JLRSActivities.adapters['jlrsInstantEffects_'..name]
    local discover,read,write=adapter.discover,adapter.read,adapter.write
    adapter.discover=function(v)
        local channels=discover(v)
        if #channels>0 then
            local p=S.find(v,name);local spec=v['spec_'..name]
            spec._jlrsSoundSequence=0;spec._jlrsSoundStart=0
            spec._jlrsSoundIntercepted=nil
            if p and isSamplePlaying and isSamplePlaying(p.washSound) and root(g_currentMission and g_currentMission.controlledVehicle)==v then
                spec._jlrsSoundSequence=1;S.sounds[p.washSound].owner=v
            end
        end
        return channels
    end
    adapter.read=function(v,ch)
        local values=read(v,ch);local spec=v and v['spec_'..name]
        local p=spec and (spec._jlrsSoundProvider or S.providers[name]);local sound=p and S.sounds[p.washSound]
        if p and sound and sound.owner==v then
            values[4]=spec._jlrsSoundSequence or 0;values[5]=spec._jlrsSoundStart or 0
            values[6]=(isSamplePlaying and isSamplePlaying(p.washSound)) and 1 or 0
        end
        return values
    end
    adapter.write=function(v,ch,values,paused,restoring)
        write(v,ch,values,paused,restoring)
        if restoring then S.release(v,name);return end
        if not v['spec_'..name] then return end
        local voices=S.voices[v];local voice=voices and voices[name]
        local token=values[4];local active=values[6]>=0.5 and token>0
        if not voice and not active then return end
        local p=S.find(v,name)
        if not p or not createAudioSource or not getAudioSourceSample or not playSample then return end
        if not voices then voices={};S.voices[v]=voices end
        if not voice then
            local parent=v.rootNode or(v.components and v.components[1]and v.components[1].node)
            if not parent or not entityExists(parent)then return end
            local node=createAudioSource('jlrs_'..name,p.modDirectory..(name=='instantFire'and 'washSound1.ogg'or 'washSound.ogg'),S.OUTER_RADIUS,S.INNER_RADIUS,1,1)
            if not node or node==0 then return end
            if setAudioSourceAutoPlay then setAudioSourceAutoPlay(node,false)end
            link(parent,node);setTranslation(node,0,0,0)
            local sample=getAudioSourceSample(node)
            if not sample or sample==0 then delete(node);return end
            voice={sample=sample,node=node,parent=parent};voices[name]=voice
            -- A provider can still have the old, non-positional Record sound
            -- playing. Retire only this vehicle's owned copy, never another
            -- currently driven vehicle's shared provider sample in Live Drive.
            local native=S.sounds[p.washSound]
            if native and native.owner==v and stopSample then pcall(stopSample,p.washSound,0,0)end
        end
        local changed=voice.token~=token or voice.start~=values[5]
        if S.time and voice.time and S.time<voice.time then changed=true end
        if paused or not active then
            if voice.active and stopSample then stopSample(voice.sample,0,0) end
            voice.resume=paused and active
            voice.active=false
        elseif changed or voice.resume or not voice.recordedActive then
            if voice.active and stopSample then stopSample(voice.sample,0,0) end
            playSample(voice.sample,1,1,0,0,0)
            voice.active=true;voice.resume=false
        end
        voice.token=token;voice.start=values[5];voice.recordedActive=active
        voice.time=S.time
    end
end
local tick=JLRSActivities.tick
JLRSActivities.tick=function(track,...)
    S.time=track.replayTime or 0
    local ok,result=pcall(tick,track,...)
    S.time=nil
    if not ok then error(result,0) end
    return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=deleteMap(c,...)
    for v,voices in pairs(S.voices) do for name in pairs(voices) do S.release(v,name) end end
    for v,bindings in pairs(S.bindings) do for _,hook in pairs(bindings) do if v[hook.method]==hook.wrapper then v[hook.method]=hook.raw end end end
    S.bindings=setmetatable({},{__mode='k'})
    S.providers={};S.sounds={}
    return result
end
