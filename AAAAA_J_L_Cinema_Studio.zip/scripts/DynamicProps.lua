-- Add only loose dynamic bodies. Never traverse the terrain/building scenegraph.
JLRSProps={IDLE_BUDGET=8,CELL=40}
local P=JLRSProps
function P.isPallet(o)
    return type(o)=='table' and (o.spec_pallet~=nil or o.isPallet==true
        or (not o.spec_enterable and not o.spec_motorized and tostring(o.typeName or ''):lower():find('pallet',1,true)~=nil))
end
function P.isActor(o)
    if o==(g_currentMission or {}).player or o.isPlayer==true or o.isAnimal==true then return true end
    if type(o.isa)=='function' then
        for _,class in ipairs({Player or false,Animal or false,NPC or false})do
            if class then local ok,yes=pcall(o.isa,o,class);if ok and yes then return true end end
        end
    end
    return false
end
function P.entries(o,exclude)
    local entries,seen={},{}
    if type(o)~='table' or o.isDeleted or P.isActor(o) or JLRSWorld.isTrain(o) then return entries end
    local function add(node,index,field)
        if node and node~=0 and not seen[node] and not (exclude and exclude[node]) and entityExists(node)
            and getRigidBodyType(node)==RigidBodyType.DYNAMIC then
            seen[node]=true;entries[#entries+1]={node=node,world=true,parent=getParent(node),componentIndex=index,prop=true,propField=field}
        end
    end
    for index,comp in ipairs(o.components or {})do if type(comp)=='table' then add(comp.node,index)end end
    add(o.rootNode,nil,'rootNode');add(o.nodeId,nil,'nodeId');add(o.node,nil,'node')
    -- FS22 Placeable already collects its physical children into pickObjects.
    -- Use that bounded registry, never walk the map scene graph each frame.
    for i,node in ipairs(o.pickObjects or {}) do
        add(node,nil,'pickObjects:'..i)
    end
    return entries
end
function P.fieldNode(object,field)
    local index=field and field:match('^pickObjects:(%d+)$')
    if index then return object.pickObjects and object.pickObjects[tonumber(index)] end
    return field and object[field]
end
function P.candidates()
    local list,seen={},{};local m=g_currentMission or {}
    local function add(o)
        if type(o)=='table' and not seen[o] then seen[o]=true;list[#list+1]=o end
    end
    local function scan(source,wrapped)
        if type(source)~='table' then return end
        -- Foreign mods can expose proxy registries. A bad registry must not stop Record.
        pcall(function()for key,value in pairs(source)do
            if type(value)=='table' then add(wrapped and (value.item or value.object or value) or value)end
            if type(key)=='table' then add(key)end
        end end)
    end
    scan(m.itemsToSave,true);scan(m.itemSystem and m.itemSystem.itemsToSave,true)
    scan(m.placeableSystem and m.placeableSystem.placeables)
    scan(m.nodeToObject)
    return list
end
function P.safeGroup(group)
    if not group.prop then return false end
    if type(group.object)~='table' or group.object.isDeleted or P.isActor(group.object) or JLRSWorld.isTrain(group.object) then return false end
    local physical=false
    for _,e in ipairs(group.entries or {})do
        if not entityExists(e.node) or getParent(e.node)~=e.parent then return false end
        local body=getRigidBodyType(e.node)
        if body==RigidBodyType.DYNAMIC or body==RigidBodyType.KINEMATIC then physical=true
        elseif body~=RigidBodyType.NONE or not P.isPallet(group.object) then return false end
    end
    return physical
end
function P.attach(state)
    if not P.safeGroup(state.group) or type(removeFromPhysics)~='function' or type(addToPhysics)~='function' then return false end
    state.propBodies={}
    -- A precise replay owns stationary obstacles too. Leaving their bodies
    -- dynamic lets contact create a new path while the stationary fast path
    -- deliberately stops writing their recorded pose. Live recording still
    -- keeps the original contact handoff to native physics.
    local c=JLReplayStudio
    state.visualOnly=c.preciseReplay and not c.recording or false
    local nativeStationary=state.stationary==true and not(c.preciseReplay and not c.recording)
    local ok,err=pcall(function()
        for _,e in ipairs(state.group.entries)do
            local kind=getRigidBodyType(e.node)
            if kind~=RigidBodyType.NONE then
            local body={node=e.node,type=kind};state.propBodies[#state.propBodies+1]=body
            -- Registration changes happen only at Replay start/Stop. Live
            -- contact playback keeps shapes; pure precision stays visual-only.
            removeFromPhysics(e.node);body.removed=true
            local replayKind=nativeStationary and kind or RigidBodyType.KINEMATIC
            setRigidBodyType(e.node,replayKind)
            if getRigidBodyType(e.node)~=replayKind then error('Objek menolak mode replay kinematic.')end
            -- Pure precision playback owns transforms only. Keeping the body
            -- registered as KINEMATIC still builds contacts and broadphase pairs.
            if not state.visualOnly then addToPhysics(e.node);body.removed=false end
            end
        end
        local root=state.group.object.rootNode or state.group.object.nodeId or state.group.object.node
        local standalone=root and entityExists(root) and getRigidBodyType(root)==RigidBodyType.KINEMATIC
        local methods=standalone and {'update','updateTick','updateInterpolation','updateEnd','addToPhysics'} or {'updateInterpolation'}
        for _,name in ipairs(methods)do
            if type(state.group.object[name])=='function' then
                local hook={raw=rawget(state.group.object,name),wrapper=function()end}
                state.hooks[name]=hook;state.group.object[name]=hook.wrapper
            end
        end
    end)
    if not ok then P.release(state);print('[J_L Cinema Studio] PROP REPLAY SKIP: '..tostring(err));return false end
    return true
end
-- Transition existing Live-contact obstacle streams to playback ownership at
-- Stop/Final boundaries. Do not reset poses or replace streams during handoff.
function P.isolatePlayback(state)
    if state.visualOnly then return end
    for _,body in ipairs(state.propBodies or {})do
        if not body.removed and entityExists(body.node) then
            removeFromPhysics(body.node);body.removed=true
        end
    end
    local object=state.group.object
    local root=object.rootNode or object.nodeId or object.node
    for _,body in ipairs(state.propBodies or {})do
        if body.node==root then
            state.hooks=state.hooks or {}
            for _,name in ipairs({'update','updateTick','updateInterpolation','updateEnd','addToPhysics'})do
                if not state.hooks[name] and type(object[name])=='function' then
                    local hook={raw=rawget(object,name),wrapper=function()end}
                    state.hooks[name]=hook;object[name]=hook.wrapper
                end
            end
            break
        end
    end
    state.visualOnly=true
end
function P.release(state)
    if not state.propBodies then return end
    for _,body in ipairs(state.propBodies)do
        if entityExists(body.node)then
            local ok,err=pcall(function()
                if not body.removed then removeFromPhysics(body.node)end
                setRigidBodyType(body.node,body.type)
                if type(setLinearVelocity)=='function' then setLinearVelocity(body.node,0,0,0)end
                if type(setAngularVelocity)=='function' then setAngularVelocity(body.node,0,0,0)end
                addToPhysics(body.node)
            end)
            if not ok then print('[J_L Cinema Studio] PROP RESTORE: '..tostring(err))end
        end
    end
    state.propBodies=nil;state.visualOnly=nil
end
local collect=JLRSWorld.collect
JLRSWorld.collect=function(c,...)
    local scene=collect(c,...);local vehicles=JLRSWorld.vehicleSet();local exclude,seen={},{}
    local owned={}
    for _,track in ipairs(c.liveTracks or {})do
        for _,e in ipairs(track.entries or {})do owned[e.node]=true end
        for _,state in ipairs(track.cargoReplay and track.cargoReplay.states or {})do for _,e in ipairs(state.group.entries)do owned[e.node]=true end end
    end
    local groups={};local entries={}
    for _,group in ipairs(scene.groups)do
        local overlap=false
        if P.isPallet(group.object)then for _,e in ipairs(group.entries)do if owned[e.node]then overlap=true end end end
        if not overlap then
            groups[#groups+1]=group;group.first=#entries+1
            for _,e in ipairs(group.entries)do entries[#entries+1]=e end
        end
    end
    scene.groups=groups;scene.entries=entries
    for _,e in ipairs(scene.entries)do exclude[e.node]=true end
    for _,e in ipairs(c.entries or {})do exclude[e.node]=true end
    for _,track in ipairs(c.liveTracks or {})do
        for _,e in ipairs(track.entries or {})do exclude[e.node]=true end
        for _,s in ipairs(track.cargoReplay and track.cargoReplay.states or {})do for _,e in ipairs(s.group.entries)do exclude[e.node]=true end end
    end
    for _,group in ipairs(scene.groups)do
        seen[group.object]=true
        if P.isPallet(group.object)then
            group.prop=true;group.object.jlrsDynamicProp=true
            for _,e in ipairs(group.entries)do e.prop=true end
        end
    end
    for _,o in ipairs(P.candidates())do
        if not seen[o] and not vehicles[o] then
            seen[o]=true;local entries=P.entries(o,exclude)
            if #entries>0 then
                local cargo=false
                for _,carrier in ipairs(c.recordVehicles or {})do
                    for _,data in pairs(carrier.spec_tensionBelts and carrier.spec_tensionBelts.objectsToJoint or {})do if type(data)=='table' and data.object==o then cargo=true end end
                    for key,value in pairs(carrier.spec_dynamicMountAttacher and carrier.spec_dynamicMountAttacher.dynamicMountedObjects or {})do if key==o or value==o then cargo=true end end
                end
                local group={object=o,entries=entries,prop=true,cargo=cargo,first=#scene.entries+1}
                o.jlrsDynamicProp=true;scene.groups[#scene.groups+1]=group
                for _,e in ipairs(entries)do scene.entries[#scene.entries+1]=e;exclude[e.node]=true end
            end
        end
    end
    return scene
end
-- Full rate near vehicles / after motion; bounded round-robin probes for distant idle bodies.
-- Pose samples are still written only when they actually change.
local function cell(x,z)return math.floor(x/P.CELL)..':'..math.floor(z/P.CELL)end
function P.index(scene,e)
    local p=e.lastPose;if not p then return end
    -- Idle props are indexed every capture. Keep exact coordinates so a still
    -- object does not allocate a cell string or recompute its grid membership.
    if e.propGridOwner==scene and e.propIndexX==p[1] and e.propIndexZ==p[3] then return end
    e.propGridOwner=scene;e.propIndexX=p[1];e.propIndexZ=p[3]
    local key=cell(p[1],p[3]);if key==e.propCell then return end
    if e.propCell and scene.propGrid[e.propCell]then scene.propGrid[e.propCell][e]=nil end
    scene.propGrid[key]=scene.propGrid[key]or {};scene.propGrid[key][e]=true;e.propCell=key
end
function P.prepare(scene)
    if not scene.propEntries then
        scene.propEntries={};scene.propGrid={};scene.propCursor=1
        for _,e in ipairs(scene.entries)do if e.prop then scene.propEntries[#scene.propEntries+1]=e;P.index(scene,e)end end
    end
    scene.propEpoch=(scene.propEpoch or 0)+1;local epoch=scene.propEpoch
    local visited=scene.propVisitedCells or {};scene.propVisitedCells=visited
    -- Use existing vehicle root entries, including AI/NPC vehicles in the scene.
    local function near(node)
        if not node or not entityExists(node)then return end
        local x,_,z=getWorldTranslation(node);local cx,cz=math.floor(x/P.CELL),math.floor(z/P.CELL)
        for ix=cx-1,cx+1 do for iz=cz-1,cz+1 do
            local key=ix..':'..iz
            if visited[key]~=epoch then
                visited[key]=epoch
                local bucket=scene.propGrid[key]
                if bucket then for e in pairs(bucket)do e.propProbe=epoch end end
            end
        end end
    end
    for _,v in ipairs((JLReplayStudio or {}).recordVehicles or {})do if not P.isPallet(v)then near(v.rootNode)end end
    for _,group in ipairs(scene.groups)do if not group.prop then near(group.object.rootNode or group.object.nodeId)end end
    local count=#scene.propEntries
    for _=1,math.min(P.IDLE_BUDGET,count)do
        local e=scene.propEntries[scene.propCursor];e.propProbe=epoch;scene.propCursor=scene.propCursor%count+1
    end
end
local capture=JLRSWorld.capture
JLRSWorld.capture=function(scene,...)
    P.prepare(scene)
    -- The original sampler honors a cached pose for idle entries through this flag.
    local pose=capture(scene,...)
    for _,e in ipairs(scene.propEntries)do P.index(scene,e)end
    return pose
end
local release=JLRSWorld.release
JLRSWorld.release=function(state,...)
    P.release(state);return release(state,...)
end
-- Pallets remain recorded, but use the sparse object channel rather than a
-- full vehicle pose row in Record All. Tractors/trailers/implements are unchanged.
local collectAll=JLRSRecordAll.collect
JLRSRecordAll.collect=function(primary,mission,...)
    local entries,vehicles=collectAll(primary,mission,...);local excluded,kept={},{}
    for _,v in ipairs(vehicles)do
        if v~=primary and P.isPallet(v)then
            local nodes=JLRSRecorder.topology(v)
            for _,e in ipairs(nodes)do excluded[e.node]=true end
        else kept[#kept+1]=v end
    end
    local result={};for _,e in ipairs(entries)do if not excluded[e.node]then result[#result+1]=e end end
    return result,kept
end
