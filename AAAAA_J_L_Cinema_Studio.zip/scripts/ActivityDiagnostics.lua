-- Sparse diagnostics only; no frame skipping or state/data changes.
JLRSActivityDiag={calls=0,groups={},samples=0}
local D=JLRSActivityDiag
local A=JLRSActivities
local function measure(label,start)
    local s=D.groups[label]
    if not s then s={ms=0,count=0};D.groups[label]=s end
    s.ms=s.ms+math.max(0,(getTimeSec()-start)*1000);s.count=s.count+1
end
local at=A.at
A.at=function(...)
    if not D.sampling then return at(...) end
    local previous=D.reading;D.reading=true
    local start=getTimeSec();local result=at(...)
    D.reading=previous;measure('interpolation',start);return result
end
-- Include private-buffer reads and header searches in the same measured scope.
for _,name in ipairs({'get','time','readInto'})do
    local get=JLRSFrames[name]
    if get then JLRSFrames[name]=function(...)
        if not D.sampling or not D.reading or D.readDepth then return get(...) end
        local start=getTimeSec();D.readDepth=true
        local ok,result=pcall(get,...);D.readDepth=nil
        if not ok then error(result,0) end
        measure('frameRead',start);return result
    end end
end
local apply=A.apply
A.apply=function(ch,...)
    if not D.sampling then return apply(ch,...) end
    local start=getTimeSec();local result=apply(ch,...)
    measure(ch.kind=='custom' and ch.getter or ch.kind,start)
    return result
end
local tick=A.tick
A.tick=function(track,...)
    D.calls=D.calls+1
    if D.calls%120~=1 or type(getTimeSec)~='function' then return tick(track,...) end
    local previous=D.sampling;D.sampling=true
    local ok,result=pcall(tick,track,...);D.sampling=previous;D.reading=nil
    D.samples=D.samples+1
    local now=g_time or 0
    if not D.start then D.start=now end
    if now-D.start>=10000 and D.samples>0 then
        local names={};for name in pairs(D.groups) do names[#names+1]=name end
        table.sort(names);local parts={}
        for _,name in ipairs(names) do
            local s=D.groups[name]
            parts[#parts+1]=string.format('%s=%.3fms/tick %.0f calls/tick',name,s.ms/D.samples,s.count/D.samples)
        end
        print('[JLRS ACTIVITY DETAIL V1.18.79] sampledTicks='..D.samples..' '..table.concat(parts,' | '))
        D.start=now;D.groups={};D.samples=0
    end
    if not ok then error(result,0) end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    D.calls=0;D.groups={};D.samples=0;D.sampling=nil;D.reading=nil;D.start=nil
    return load(c,...)
end
