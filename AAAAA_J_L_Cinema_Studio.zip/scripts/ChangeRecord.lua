JLRSChangeRecord={ROWS=7}
local R=JLRSChangeRecord
local function name(c,v)return JLRSCurva.name(c,v)end
local function editable(c)return not(c.recording or c.replaying or c.finalRecording or c.finalPlaying or c.changePending or c.historyRepair or #(c.liveTracks or {})>0)end
local function owns(clip,v)
 local roles=JLRSChange.wheelRoles(v)
 for _,e in ipairs(clip.entries or {})do if e.vehicle==v or e.node==v.rootNode or roles[e.node]then return true end end
 return false
end
local function swapped(v,a,b)if v==a then return b elseif v==b then return a end;return v end
local function activities(frames,a,b)
 local data=frames.jlrsActivities;if not data then return end
 local copy={frames=data.frames,reference=data.reference,schema={}}
 local ai,bi=JLRSPersist.identity(a),JLRSPersist.identity(b)
 for i,ch in ipairs(data.schema or {})do local row=JLRSChange.copy(ch)
  if row.owner==ai then row.owner=bi elseif row.owner==bi then row.owner=ai end
  copy.schema[i]=row
 end
 frames.jlrsActivities=copy
end
function R.plan(context,source,a,b)
 local first=JLRSChange.plan(context,a,b)
 local second=JLRSChange.plan(context,b,a,false,true)
 local byClip={};for _,p in ipairs(first.clips)do byClip[p.clip]=p.mapped end
 local plan={old=a,new=b,clips={},groups={}}
 for _,clip in ipairs(context.history)do
  local mapped=byClip[clip];local hasB=owns(clip,b)
  if hasB then
   if mapped then
    local original={};for _,e in ipairs(clip.entries)do original[e]=true end
    local ignore={};for _,e in ipairs(mapped.entries)do if not original[e]then ignore[e]=true end end
    mapped=JLRSChange.adapt(mapped.entries,mapped.frames,b,a,false,context,ignore)
   else mapped=JLRSChange.adapt(clip.entries,clip.frames,b,a,false,context)end
  end
  if mapped then
   local vehicles={};for i,v in ipairs(clip.vehicles or {clip.target})do vehicles[i]=swapped(v,a,b)end
   activities(mapped.frames,a,b)
   plan.clips[#plan.clips+1]={clip=clip,mapped=mapped,vehicles=vehicles,target=swapped(clip.target,a,b)}
  end
 end
 for _,p in ipairs(first.groups)do p.vehicle=b;plan.groups[#plan.groups+1]=p end
 for _,p in ipairs(second.groups)do p.vehicle=a;plan.groups[#plan.groups+1]=p end
 return plan
end
local function vehiclePose(entries,pose,v)
 local out,values={},{};local roles=JLRSChange.wheelRoles(v)
 for i,e in ipairs(entries)do if e.vehicle==v or e.node==v.rootNode or roles[e.node]then
  out[#out+1]=e;for j=1,6 do values[#values+1]=pose[(i-1)*6+j]end
 end end
 return out,values
end
function R.apply(c)
 if c.changeRecordJob then return end
 if not editable(c)then c:notify('Stop Record / Replay sebelum Change Record.');return end
 local b,source=c.changeRecordVehicle,c.changeRecordClip
 if not JLRSRecorder.valid(b)or not source or not JLRSHistory.valid(source)then c:notify('Pilih kendaraan dan rekaman yang tersedia dahulu.');return end
 local present=false;for _,clip in ipairs(c.history or {})do if clip==source then present=true;break end end
 if not present then c:notify('Rekaman pilihan tidak tersedia di History.');return end
 local a=source.target
 if a==b then c:notify('Kendaraan sudah menggunakan rekaman ini.');return end
 for _,v in ipairs({a,b})do
  if not JLRSRecorder.valid(v)or(v.getAttachedImplements and #v:getAttachedImplements()>0)or(v.getAttacherVehicle and v:getAttacherVehicle())then c:notify('Lepaskan trailer/implement kedua kendaraan sebelum Change Record.');return end
 end
 local clips={source}
 if not owns(source,b)then
  for i=#c.history,1,-1 do local clip=c.history[i]
   if clip~=source and JLRSHistory.valid(clip)and owns(clip,b)then clips[#clips+1]=clip;break end
  end
 end
 local context={mission=c.mission,history=clips,changePending={helpers={},streams={},done=0}}
 local job={context=context,a=a,b=b,source=source,names={},poses={}}
 for _,clip in ipairs(clips)do job.names[clip]=clip.name end
 for _,v in ipairs({a,b})do local es=JLRSRecorder.topology(v);job.poses[v]={entries=es,pose=JLRSRecorder.capture(es)};if not job.poses[v].pose then c:notify('Posisi kendaraan tidak tersedia.');return end end
 job.worker=coroutine.create(function()
  local plan=R.plan(context,source,a,b)
  local parked=JLRSChange.adapt(job.poses[b].entries,{{t=0,pose=job.poses[b].pose}},b,a,false,context)
  job.undo=JLRSChange.applyPlan(context,plan)
  for clip,n in pairs(job.names)do clip.name=n end
  if not JLRSPersist.safeSave(c)then error('History Change Record belum tersimpan.')end
  job.committed=true
  a:removeFromPhysics();b:removeFromPhysics()
  local es,pose=vehiclePose(source.entries,JLRSFrames.get(source.frames,1).pose,b)
  local ok=JLRSRecorder.apply(parked.entries,JLRSFrames.get(parked.frames,1).pose,true)and JLRSRecorder.apply(es,pose,true)
  a:addToPhysics();b:addToPhysics();if not ok then error('Posisi pertukaran kendaraan gagal diterapkan.')end
  c.target=source.target;c.entries=source.entries;c.recordVehicles=source.vehicles;c.frames=source.frames
  c.duration=source.duration;c.recordTime=source.duration;c.replayTime=0;c.frameIndex=1;c.historySelected=source.id
 end)
 c.changeRecordJob=job;c:notify('CHANGE RECORD | memetakan pertukaran jalur...')
end
function R.tick(c)
 local job=c.changeRecordJob;if not job then return end
 local ok,err=coroutine.resume(job.worker)
 if not ok then
  if job.undo then JLRSChange.rollback(job.context,job.undo);JLRSPersist.safeSave(c)end
  for v,p in pairs(job.poses)do pcall(function()JLRSRecorder.apply(p.entries,p.pose,true);if not v.isAddedToPhysics then v:addToPhysics()end end)end
  JLRSChange.clean(job.context,job.context.changePending);c.changeRecordJob=nil
  c:notify('Change Record gagal; rekaman asli dipertahankan: '..tostring(err));return
 end
 if coroutine.status(job.worker)=='dead'then
  JLRSChange.clean(job.context,job.context.changePending);c.changeRecordJob=nil
  JLRSCurva.catalog(c);c.changeRecordClip=nil;c.changeRecordStage='cars';c.changeRecordOffset=0
  c:notify('CHANGE RECORD BERHASIL | '..name(c,job.b)..' memakai jalur #'..job.source.id..' | '..name(c,job.a)..' pindah ke posisi kendaraan pilihan.')
 end
end
function R.close(c)
 if c.changeRecordJob then c:notify('Tunggu Change Record selesai.');return end
 c.changeRecordOpen=false
 for _,overlay in pairs(c.changeRecordIcons or {})do delete(overlay)end;c.changeRecordIcons={}
end
function R.open(c)
 c.changeRecordOpen=true;c.changeRecordStage='cars';c.changeRecordOffset=0;c.changeRecordIcons=c.changeRecordIcons or {};c.changeRecordVehicle=nil;c.changeRecordClip=nil
end
function R.list(c)
 local list={}
 if c.changeRecordStage=='records'then for _,clip in ipairs(c.history or {})do list[#list+1]=clip end
 else for _,v in pairs(c.mission.vehicles or {})do if JLRSRecorder.valid(v)and v.spec_motorized and not JLRSWorld.isTrain(v)and(not Vehicle or v.propertyState~=Vehicle.PROPERTY_STATE_SHOP_CONFIG)then list[#list+1]=v end end
  table.sort(list,function(a,b)local an,bn=name(c,a),name(c,b);if an==bn then return JLRSPersist.identity(a)<JLRSPersist.identity(b)end;return an<bn end)
 end
 return list
end
function R.draw(c)
 if c.changeRecordStage=='records'and not JLRSRecorder.valid(c.changeRecordVehicle)then c.changeRecordStage='cars';c.changeRecordOffset=0;c.changeRecordClip=nil end
 local M=JLRSMenu;local list=R.list(c);local offset=math.max(0,math.min(c.changeRecordOffset or 0,math.max(0,#list-R.ROWS)));c.changeRecordOffset=offset;c.hitboxes={}
 M.rect(c,.72,.13,.27,.73,.015,.025,.04,.98);M.text(.734,.825,.019,'CHANGE RECORD');M.text(.734,.795,.011,c.changeRecordStage=='records'and ('Record untuk '..name(c,c.changeRecordVehicle)):sub(1,35)or 'Pilih kendaraan di map')
 for row=1,R.ROWS do local item=list[offset+row];local y=.722-(row-1)*.07
  if item then
   if c.changeRecordStage=='records'then
    M.button(c,.731,y,.246,.062,'',function()if not c.changeRecordJob then c.changeRecordClip=item end end,c.changeRecordClip==item)
    M.text(.742,y+.036,.012,(c.changeRecordClip==item and '[X] 'or '[ ] ')..('#%03d %s'):format(item.id,item.name):sub(1,30));M.text(.742,y+.012,.010,JLRSFinalEditing.time(item.duration))
   else
    M.button(c,.731,y,.196,.062,'',function()if not c.changeRecordJob then c.changeRecordVehicle=item;c.changeRecordStage='records';c.changeRecordOffset=0 end end,c.changeRecordVehicle==item)
    local store=g_storeManager and g_storeManager:getItemByXMLFilename(item.configFileName or '');local path=store and store.imageFilename
    if path and path~=''then local overlay=c.changeRecordIcons[path];if not overlay then overlay=createImageOverlay(path);c.changeRecordIcons[path]=overlay end
     if overlay and overlay~=0 then setOverlayColor(overlay,1,1,1,1);renderOverlay(overlay,.738,y+.005,.041,.048)end
    end
    M.text(.784,y+.028,.011,(c.changeRecordVehicle==item and '[X] 'or '[ ] ')..name(c,item):sub(1,20))
    M.button(c,.932,y+.016,.046,.03,'RENAME',function()JLRSCurva.rename(c,item)end)
   end
  end
 end
 M.text(.735,.24,.009,('Scroll mouse | %d item'):format(#list))
 M.button(c,.732,.186,.116,.034,c.changeRecordJob and 'PROSES...'or 'APPLY',function()R.apply(c)end)
 M.button(c,.858,.186,.116,.034,'KEMBALI',function()if not c.changeRecordJob then c.changeRecordStage='cars';c.changeRecordOffset=0 end end)
 M.button(c,.732,.14,.242,.033,'CLOSE',function()R.close(c)end)
end
local historyDraw=JLRSHistory.draw
JLRSHistory.draw=function(c,...)
 if c.changeRecordOpen then return R.draw(c)end
 local result=historyDraw(c,...);JLRSMenu.button(c,.475,.821,.158,.032,'CHANGE RECORD',function()R.open(c)end);return result
end
local historyClose=JLRSHistory.close
JLRSHistory.close=function(c,...)if c.changeRecordJob then return end;R.close(c);return historyClose(c,...)end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)local result=draw(c,...);R.tick(c);return result end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)if c.changeRecordJob then c:notify('Tunggu Change Record selesai.');return end;return start(c,...)end
local replay=JLRSHistory.replay
JLRSHistory.replay=function(c,...)if c.changeRecordJob then return end;return replay(c,...)end
local startReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)if JLReplayStudio.changeRecordJob then return end;return startReplay(c,...)end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
 local job=c.changeRecordJob
 if job then
  if job.undo and not job.committed then JLRSChange.rollback(job.context,job.undo)end
  JLRSChange.clean(job.context,job.context.changePending);c.changeRecordJob=nil
 end
 R.close(c);return unload(c,...)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
 local result=load(c,...);c.changeRecordOpen=false;c.changeRecordJob=nil;c.changeRecordIcons={}
 if c.mission then local mouse=c.mission.mouseEvent
  c.mission.mouseEvent=function(m,x,y,down,up,button,...)
   if c.changeRecordOpen and c.menu and not(g_gui and g_gui:getIsGuiVisible())then
    c.mouseX=x;c.mouseY=y
    if down and button==Input.MOUSE_BUTTON_WHEEL_UP then c.changeRecordOffset=math.max(0,(c.changeRecordOffset or 0)-1)
    elseif down and button==Input.MOUSE_BUTTON_WHEEL_DOWN then c.changeRecordOffset=(c.changeRecordOffset or 0)+1
    else JLRSMenu.click(c,x,y,down,button)end
    return
   end
   return mouse(m,x,y,down,up,button,...)
  end
 end
 return result
end
