-- Render interpolation only for Final playback. No recording/history mutation.
JLRSFinalSmooth={}
local S=JLRSFinalSmooth
local function slope(a,b)if a*b<=0 then return 0 end;return 2*a*b/(a+b)end
function S.channel(before,a,b,after,time,index,angle)
    local span=b.t-a.t;if span<=0 then return a.pose[index]end
    local function difference(x,y)
        local delta=y-x;if angle then delta=(delta+math.pi)%(2*math.pi)-math.pi end;return delta
    end
    local start=a.pose[index];local delta=difference(start,b.pose[index]);local secant=delta/span
    local left,right=secant,secant
    if before and before.t<a.t then left=slope(difference(before.pose[index],start)/(a.t-before.t),secant)end
    if after and after.t>b.t then right=slope(secant,difference(b.pose[index],after.pose[index])/(after.t-b.t))end
    -- Bound endpoint tangents: no new overshoot or reverse movement between poses.
    local alpha=math.max(0,math.min(1,(time-a.t)/span));local squared=alpha*alpha;local cubed=squared*alpha
    return start+(-2*cubed+3*squared)*delta+(cubed-2*squared+alpha)*span*left+(cubed-squared)*span*right
end
function S.frames(frames,index)
    local count=JLRSFrames.count(frames)
    return index>1 and JLRSFrames.get(frames,index-1)or nil,
        JLRSFrames.get(frames,index),JLRSFrames.get(frames,math.min(count,index+1)),
        index+2<=count and JLRSFrames.get(frames,index+2)or nil
end
-- Vehicle sampling is identical during Record Final and Replay Final. The
-- native physics replay controller already smooths velocities; a second Final-
-- only body filter changed vehicle/camera alignment and allocated full poses.
-- Final camera and vehicle poses now use the same linear timeline fraction.
-- A separate cubic camera curve changed framing between the exact keys even
-- when the recording was smooth. Native Final.sample retains angle unwrap,
-- exact keyframes and immediate shot cuts without a second spatial filter.
-- Keep the original shared replay clock. Never seek vehicles again after camera
-- rendering: camera source timestamps wrap at loops and are discontinuous at cuts.

-- Restore Cinema cursor policy after our draw wrappers, without changing global
-- InputBinding methods or input contexts belonging to another mod.
local mouseDraw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=mouseDraw(c,...)
    if c.mission and g_inputBinding and (c.active or c.menu or c.finalPlaying) then
        JLRSMouse.syncCursor(c)
    end
    return result
end
