-- Final-only exclusion ranges. Motion streams and camera source frames stay intact.
JLRSFinalCuts={undoHistory=setmetatable({},{__mode='k'})}
local H=JLRSFinalCuts
local rawSample=JLRSFinal.sample
local function take(c)return c.finalRecording or (c.finalPlaying and c.finalPlaying.take)or (c.finalTakes or {})[c.finalSelected or 0]end
function H.length(t)
    local d=t.cutSourceDuration or t.duration or 0
    for _,r in ipairs(t.finalCuts or {})do d=d-(r.b-r.a)end
    return math.max(0,d)
end
function H.source(t,time)
    local removed=0
    for i,r in ipairs(t.finalCuts or {})do
        if time<r.a-removed then return time+removed,i end
        removed=removed+r.b-r.a
    end
    return math.min(t.cutSourceDuration or t.duration,time+removed),#(t.finalCuts or {})+1
end
function H.output(t,time)
    local removed=0
    for _,r in ipairs(t.finalCuts or {})do
        if time<r.a then break end
        removed=removed+math.min(time,r.b)-r.a
    end
    return math.max(0,time-removed)
end
function H.merge(list,a,b)
    local out={};for _,r in ipairs(list or {})do out[#out+1]={a=r.a,b=r.b}end
    out[#out+1]={a=math.min(a,b),b=math.max(a,b)};table.sort(out,function(x,y)return x.a<y.a end)
    local result={}
    for _,r in ipairs(out)do local last=result[#result];if last and r.a<=last.b then last.b=math.max(last.b,r.b)else result[#result+1]=r end end
    return result
end
function H.write(x,k,t)
    if not t.finalCuts or #t.finalCuts==0 then return end
    x:setString(k..'.cuts#sourceDuration',string.format('%.17g',t.cutSourceDuration));x:setInt(k..'.cuts#count',#t.finalCuts)
    for i,r in ipairs(t.finalCuts)do local p=k..'.cuts.range('..(i-1)..')';x:setString(p..'#a',string.format('%.17g',r.a));x:setString(p..'#b',string.format('%.17g',r.b))end
end
function H.read(x,k,t)
    local count=x:getInt(k..'.cuts#count',0);if count==0 then return end
    if count<0 or count>10000 then error('Metadata cut Final rusak.')end
    t.cutSourceDuration=tonumber(x:getString(k..'.cuts#sourceDuration'));t.finalCuts={}
    if not t.cutSourceDuration or t.cutSourceDuration~=t.cutSourceDuration or t.cutSourceDuration>=math.huge or t.cutSourceDuration<=0 then error('Durasi sumber cut Final rusak.')end
    local last=0
    for i=1,count do
        local p=k..'.cuts.range('..(i-1)..')';local a,b=tonumber(x:getString(p..'#a')),tonumber(x:getString(p..'#b'))
        if not a or not b or a~=a or b~=b or a<last or b<=a or b>t.cutSourceDuration then error('Rentang cut Final rusak.')end
        t.finalCuts[i]={a=a,b=b};last=b
    end
    if math.abs(H.length(t)-t.duration)>.001 then error('Durasi cut Final tidak cocok.')end
end
local function tracks(c)
    local list={};if c.replaying then list[#list+1]=c end
    for _,t in ipairs(c.liveTracks or {})do if t.replaying then list[#list+1]=t end end;return list
end
function H.place(c,t,source)
    local p=rawSample(t,source);local clock=p[8]
    local masterStart=t.starts[t.masterId]or t.sourceStart
    for _,track in ipairs(tracks(c))do
        for _,id in ipairs(t.clips or {})do
            for _,clip in ipairs(c.history or {})do if clip.id==id and clip.frames==track.frames then
                local time=(t.starts[id]or t.sourceStart)+clock-masterStart
                if t.loop and track.duration>0 then time=time%track.duration else time=math.max(0,math.min(track.duration,time))end
                JLRSRecorder.seek(track,time)
                if track.collisionReplay and JLRSCollision then JLRSCollision.place(track,JLRSRecorder.sample(track,time))end
                if track.cargoReplay then JLRSWorld.tick(c,track.replayTime,track.cargoReplay)end
            end end
        end
    end
    if c.worldReplay and c.worldReplay.owner then JLRSWorld.tick(c,c.worldReplay.owner.replayTime)end
    return p
end
JLRSFinal.sample=function(t,time,...)return rawSample(t,H.source(t,time))end
local tick=JLRSFinal.tick
JLRSFinal.tick=function(c,...)
    if c.jlrsRenderBoundary then return tick(c,...)end
    if c.finalRecording and c.finalRecording.finalCuts then c.finalRecording.cutSourceDuration=c.finalRecording.duration end
    local p=c.finalPlaying
    if p and p.take.finalCuts and #p.take.finalCuts>0 and not p.ended then
        if c.finalCutPreviewRestore and (c.paused or c.livePaused)then p.lastSource=p.master.replayTime end
        local delta=p.master.replayTime-p.lastSource
        if delta<0 and p.take.loop then delta=delta+p.master.duration end
        local advance=math.max(0,delta)/(p.take.speed or 1)
        local time=math.min(p.take.duration,p.time+advance)
        local source,segment=H.source(p.take,time)
        if segment~=(p.cutSegment or 1)then
            H.place(c,p.take,source)
            -- The seek skips source time, but the output clock must advance
            -- only by the frame elapsed, never by the deleted duration.
            p.lastSource=p.master.replayTime-advance*(p.take.speed or 1);p.cutSegment=segment
        end
    end
    local result=tick(c,...)
    if c.finalRecording and c.finalRecording.finalCuts then c.finalRecording.cutSourceDuration=c.finalRecording.duration end
    local preview=c.finalCutPreviewPose
    if preview and (c.paused or c.livePaused)then
        local camera=c.finalPlaying and c.finalPlaying.camera or getCamera()
        if camera and entityExists(camera)then setWorldTranslation(camera,preview[1],preview[2],preview[3]);setWorldRotation(camera,preview[4],preview[5],preview[6]);setFovY(camera,preview[7])end
    end
    return result
end
local finish=JLRSFinal.finish
JLRSFinal.finish=function(c,...)
    local t=c.finalRecording
    if t and not(t.slowRanges and #t.slowRanges>0) and t.finalCuts and #t.finalCuts>0 then t.cutSourceDuration=t.duration;t.duration=H.length(t)end
    return finish(c,...)
end
local play=JLRSFinal.play
JLRSFinal.play=function(c,...)
    local result=play(c,...);local p=c.finalPlaying
    if p and p.take.finalCuts then
        local source,segment=H.source(p.take,0);p.cutSegment=segment
        if source>0 then H.place(c,p.take,source);p.lastSource=p.master.replayTime end
    end
    return result
end
function H.mark(c)
    local t=take(c);if not t or c.recording or c.changePending or c.historyRepair then return end
    if t.editingFilm or t.editingPlan then c:notify('Cut langsung tersedia untuk Record Final biasa.');return end
    local time=c.finalCutCursor or H.length(t)
    if not c.finalCutMark or c.finalCutMark.take~=t or c.finalCutMark.b then c.finalCutMark={take=t,a=time}
    else c.finalCutMark.b=time end
end
local function copyCuts(cuts)
    if not cuts then return nil end
    local out={};for i,r in ipairs(cuts)do out[i]={a=r.a,b=r.b}end;return out
end
local function history(t)
    local state=H.undoHistory[t]
    if not state then state={undo={},redo={}};H.undoHistory[t]=state end
    return state
end
function H.undo(c,redo)
    local t=take(c)
    if not t or c.recording or c.changePending or c.historyRepair or c.finalCutDrag then return end
    local state=history(t);local from=redo and state.redo or state.undo;local to=redo and state.undo or state.redo
    local edit=from[#from];if not edit then return end
    local oldCuts,oldRaw,oldDuration=t.finalCuts,t.cutSourceDuration,t.duration
    local raw=c.finalRecording==t and t.duration or t.cutSourceDuration or t.duration
    local desired=redo and edit.after or edit.before
    t.finalCuts=copyCuts(desired.cuts)
    t.cutSourceDuration=((t.finalCuts and #t.finalCuts>0)or(t.slowRanges and #t.slowRanges>0))and raw or nil
    if c.finalRecording~=t then
        t.duration=H.length(((t.finalCuts and #t.finalCuts>0)or(t.slowRanges and #t.slowRanges>0))and t or {duration=raw})
        if not JLRSFinal.save(c)then t.finalCuts=oldCuts;t.cutSourceDuration=oldRaw;t.duration=oldDuration;return end
    end
    table.remove(from);to[#to+1]=edit
    c.finalCutMark=nil;c.finalCutCursor=math.min(desired.cursor or 0,H.length(t))
    c:notify(redo and 'REDO potongan Final berhasil' or 'UNDO potongan Final berhasil')
end
function H.remove(c)
    local mark=c.finalCutMark;local t=take(c)
    if not mark or mark.take~=t or mark.b==nil or c.recording or c.changePending or c.historyRepair then return end
    local a,b=H.source(t,math.min(mark.a,mark.b)),H.source(t,math.max(mark.a,mark.b))
    if b-a<.001 then c:notify('Pilih rentang cut yang lebih panjang.');return end
    local raw=c.finalRecording==t and t.duration or t.cutSourceDuration or t.duration
    local before=t.finalCuts;local duration=t.duration;local original=t.cutSourceDuration
    t.finalCuts=H.merge(t.finalCuts,a,b);t.cutSourceDuration=raw
    if H.length(t)<.01 then t.finalCuts=before;t.cutSourceDuration=original;c:notify('Sisakan sebagian durasi Final.');return end
    if c.finalRecording~=t then
        t.duration=H.length(t)
        if not JLRSFinal.save(c)then t.finalCuts=before;t.cutSourceDuration=original;t.duration=duration;return end
    end
    local state=history(t)
    state.undo[#state.undo+1]={before={cuts=copyCuts(before),cursor=math.min(mark.a,mark.b)},after={cuts=copyCuts(t.finalCuts),cursor=H.output(t,a)}}
    state.redo={}
    c.finalCutMark=nil;c.finalCutCursor=H.output(t,a);c:notify('CUT Final tersimpan | bagian dipilih dilewati saat Replay Final')
end
local function cursor(c,x)
    local t=take(c);local bar=c.finalCutBar;if not t or not bar then return end
    c.finalCutCursor=math.max(0,math.min(H.length(t),(x-bar.x)/bar.w*H.length(t)))
    if c.finalRecording or c.finalPlaying then
        c.finalCutPreviewRestore=c.finalCutPreviewRestore or {}
        for _,track in ipairs(tracks(c))do if c.finalCutPreviewRestore[track]==nil then c.finalCutPreviewRestore[track]=track.replayTime end end
        local p=H.place(c,t,H.source(t,c.finalCutCursor))
        c.finalCutPreviewPose=p
        local camera=c.finalPlaying and c.finalPlaying.camera or getCamera()
        if camera and entityExists(camera)and not c.finalCutPreviewCamera then
            local x,y,z=getWorldTranslation(camera);local rx,ry,rz=getWorldRotation(camera)
            c.finalCutPreviewCamera={node=camera,pose={x,y,z,rx,ry,rz,type(getFovY)=='function'and getFovY(camera)or math.rad(c.fov or 60)}}
        end
        if camera and entityExists(camera)then setWorldTranslation(camera,p[1],p[2],p[3]);setWorldRotation(camera,p[4],p[5],p[6]);setFovY(camera,p[7])end
    end
end
local pause=JLReplayStudio.togglePause
JLReplayStudio.togglePause=function(c,...)
    if c.finalCutPreviewRestore and (c.livePaused or c.paused)then
        for track,time in pairs(c.finalCutPreviewRestore)do if track.replaying then JLRSRecorder.seek(track,time);if track.cargoReplay then JLRSWorld.tick(c,time,track.cargoReplay)end end end
        local t=c.finalRecording or c.finalPlaying;if t then t.lastSource=t.master.replayTime end
        local camera=c.finalCutPreviewCamera
        if camera and entityExists(camera.node)then local p=camera.pose;setWorldTranslation(camera.node,p[1],p[2],p[3]);setWorldRotation(camera.node,p[4],p[5],p[6]);setFovY(camera.node,p[7])end
        c.finalCutPreviewRestore=nil;c.finalCutPreviewPose=nil;c.finalCutPreviewCamera=nil
    end
    return pause(c,...)
end
-- Numeric Timecode owns all mouse/keyboard editing UI (UnifiedTimecode.lua).
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)c.finalCutDrag=nil;c.finalCutFocus=nil;c.finalCutPreviewRestore=nil;c.finalCutPreviewPose=nil;c.finalCutPreviewCamera=nil;c.finalCutMark=nil;c.finalCutCursor=nil;return stop(c,...)end
if JLRSFinalEditing then JLRSFinalEditing.open=function(c)c:notify('Gunakan Timecode pada Mini HUD untuk Cut.')end end
