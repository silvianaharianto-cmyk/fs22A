-- Final-only, non-destructive edit decision lists. History is an internal dependency.
JLRSFinalClips={}
local C,E,F=JLRSFinalClips,JLRSFinalEditing,JLRSFinal
local function find(list,id)for _,v in ipairs(list or {})do if v.id==id then return v end end end
local function final(c,id)return find(c.finalTakes,id)end
local function history(c,id)return find(c.history,id)end
local copy=E.copyPlan
E.copyPlan=function(plan)local p=copy(plan);p.kind=plan and plan.kind;return p end
local write,read=E.writePlan,E.readPlan
E.writePlan=function(x,k,p)write(x,k,p);if p.kind=='final'then x:setString(k..'#sourceType','final')end end
E.readPlan=function(x,k)local p=read(x,k);if p and x:getString(k..'#sourceType')=='final'then p.kind='final'end;return p end
local writeTake,readTake=E.writeTake,E.readTake
E.writeTake=function(x,k,t)writeTake(x,k,t);if t.editingFilm then E.writePlan(x,k..'.finalClips',t.editingFilm)end end
E.readTake=function(x,k,t)readTake(x,k,t);t.editingFilm=E.readPlan(x,k..'.finalClips')end
function E.editorSources(c)return c.finalTakes or {}end
local vehicle=E.vehicle
E.vehicle=function(c,row)
    if c.editingPlan and c.editingPlan.kind=='final'and row then
        local t=final(c,row.ids[1]);local seen={}
        while t and t.editingFilm and not seen[t.id]do seen[t.id]=true;local first=t.editingFilm.rows[1];t=first and final(c,first.ids[1])end
        local source=t and history(c,(t.clips or {})[1]);return source and source.target,t
    end
    return vehicle(c,row)
end
local validate=E.validate
function C.check(c,plan,stack,refs)
    if not plan or plan.kind~='final'then return nil,'Timeline bukan hasil Record Final.'end
    stack=stack or {};refs=refs or {};local count=0
    for _,r in ipairs(plan.rows)do
        if r.start~=r.start or r.start<0 or r.sourceIn~=r.sourceIn or r.sourceIn<0 or r.length~=r.length or r.length<=0 or r.start==math.huge or r.length==math.huge then return nil,'Waktu clip tidak valid.'end
        if r.enabled~=false then
            count=count+1;local t=final(c,r.ids[1])
            if not t or r.sourceIn+r.length>t.duration+.00001 then return nil,'Record Final / durasi clip tidak tersedia.'end
            if stack[t.id]then return nil,'Referensi Final berulang.'end
            local nesting=0;for _ in pairs(stack)do nesting=nesting+1 end;if nesting>=32 then return nil,'Susunan Final terlalu dalam.'end
            stack[t.id]=true
            if t.editingFilm then local ok,why=C.check(c,t.editingFilm,stack,refs);if not ok then return nil,why end
            elseif t.editingPlan then local sources,why=validate(c,t.editingPlan);if not sources then return nil,why end;for id,s in pairs(sources)do refs[id]=s end
            else
                if JLRSFrames.count(t.frames)<2 then return nil,'Data kamera Final belum tersedia.'end
                for _,id in ipairs(t.clips or {})do local s=history(c,id);if not s or not JLRSHistory.valid(s)then return nil,'History kendaraan untuk Final #'..t.id..' belum tersedia.'end;refs[id]=s end
            end
            stack[t.id]=nil
        end
    end
    if count==0 then return nil,'Tambahkan minimal satu hasil Record Final.'end
    return refs
end
E.validate=function(c,p)if p.kind=='final'then return C.check(c,p)end;return validate(c,p)end
local limit=E.limit
E.limit=function(c,r)if c.editingPlan.kind=='final'then local t=final(c,r.ids[1]);return t and t.duration or 0 end;return limit(c,r)end
E.addChecked=function(c)
    if c.recording or c.finalRecording or c.finalPlaying or c.editingReadFailed then return end
    if c.editingSession then c.editingSeekTime=c.editingSession.time;c:stop()end
    local start=E.duration(c.editingPlan);local n=0
    for _,t in ipairs(c.finalTakes or {})do if c.editingSourceMarked[t.id]and t.duration>0 then
        c.editingPlan.rows[#c.editingPlan.rows+1]={ids={t.id},name=t.name or ('Final #'..t.id),start=start,sourceIn=0,length=t.duration,enabled=true};start=start+t.duration;n=n+1
    end end
    c.editingSelected=#c.editingPlan.rows;c.editingSourceMarked={};c.editingOffset=math.max(0,#c.editingPlan.rows-E.ROWS);c.editingSpan=math.max(1,start)
    c:notify(n>0 and 'Record Final ditambahkan | geser clip / Cut / Delete' or 'Centang hasil Record Final dahulu.')
end
function E.split(c)
    local r=c.editingPlan.rows[c.editingSelected or 0];local time=c.editingSession and c.editingSession.time or c.editingSeekTime or 0
    if not r or time<=r.start+.00001 or time>=r.start+r.length-.00001 then c:notify('Letakkan playhead di dalam clip yang dipilih.');return false end
    if c.finalRecording or c.finalPlaying or c.recording then return false end
    if c.editingSession then c.editingSeekTime=time;c:stop()end
    local delta=time-r.start;local right=E.copyPlan({rows={r},kind='final'}).rows[1]
    right.start=time;right.sourceIn=r.sourceIn+delta;right.length=r.length-delta;r.length=delta
    table.insert(c.editingPlan.rows,c.editingSelected+1,right);c.editingSelected=c.editingSelected+1
    c:notify('CUT | clip terbagi; Record Final asli tetap utuh');return true
end
-- Resolve source camera + vehicle clock, including source loops and older edited takes.
local function pick(plan,time)
    local chosen,index
    for i,r in ipairs(plan.rows)do if r.enabled~=false and time>=r.start and (not chosen or r.start>chosen.start or r.start==chosen.start and i>index)then chosen,index=r,i end end
    return chosen,index
end
function C.resolve(c,plan,time,path,depth)
    depth=depth or 0;if depth>32 then error('Susunan Final terlalu dalam.')end
    local result={}
    local camera,cameraKey
    for i,r in ipairs(plan.rows)do if r.enabled~=false and time>=r.start then
        local t=assert(final(c,r.ids[1]),'Sumber Final hilang')
        local localTime=r.sourceIn+math.min(r.length,math.max(0,time-r.start));localTime=math.min(t.duration,localTime)
        local key=(path or '')..i..'/'
        local poses,p,ck
        if t.editingFilm then poses,p,ck=C.resolve(c,t.editingFilm,localTime,key,depth+1)
        else
            p=F.sample(t,localTime);ck=key..t.id..':'..tostring(p[9]);poses={}
            if t.editingPlan then
                local sources=c.editingSession and c.editingSession.filmSources or assert(validate(c,t.editingPlan));local desired=E.owners({plan=t.editingPlan,sources=sources},p[8])
                for k,d in pairs(desired)do
                    poses[key..k]={clip=d.clip,allowed=d.allowed,time=math.min(d.clip.duration,d.row.sourceIn+math.min(d.row.length,math.max(0,p[8]-d.row.start)))}
                end
            else for _,id in ipairs(t.clips)do
                local s=assert(history(c,id));local at=(t.starts[id]or t.sourceStart)+localTime*(t.speed or 1)
                if t.loop and s.duration>0 then at=at%s.duration end
                local allowed={};for _,v in ipairs(s.vehicles or {s.target})do allowed[v]=true end
                poses[key..id]={clip=s,allowed=allowed,time=math.max(0,math.min(s.duration,at))}
            end end
        end
        for k,d in pairs(poses)do d.priority=r.start;d.index=i;result[k]=d end
        local top,topIndex=pick(plan,time);if topIndex==i then camera,cameraKey=p,ck end
    end end
    -- Latest clip owns shared cars; independent vehicles may overlap.
    local owners={}
    for k,d in pairs(result)do for v in pairs(d.allowed)do local old=owners[v];if not old or d.priority>old.d.priority or d.priority==old.d.priority and d.index>old.d.index then owners[v]={key=k,d=d}end end end
    local projected={}
    for v,o in pairs(owners)do local d=projected[o.key];if not d then d={clip=o.d.clip,allowed={},time=o.d.time};projected[o.key]=d end;d.allowed[v]=true end
    return projected,camera,cameraKey
end
local owners=E.owners
E.owners=function(s,time)
    if not s.filmPlan then return owners(s,time)end
    local out={}
    for key,d in pairs(s.filmDesired or {})do out[key]={clip=d.clip,allowed=d.allowed,index=1,row={start=s.time,sourceIn=d.time,length=math.max(.001,d.clip.duration-d.time)}}end
    return out
end
local reconcile=E.reconcile
E.reconcile=function(c,s)
    if s.filmPlan then
        local desired,p,key=C.resolve(c,s.filmPlan,s.time);s.filmDesired=desired;s.filmPose=p;s.filmCameraKey=key
        local changed=false;local count=0
        for k,d in pairs(desired)do count=count+1;local old=s.filmPrevious and s.filmPrevious[k];if not old then changed=true else for v in pairs(d.allowed)do if not old.allowed[v]then changed=true end end;for v in pairs(old.allowed)do if not d.allowed[v]then changed=true end end end end
        local oldCount=0;for _ in pairs(s.filmPrevious or {})do oldCount=oldCount+1 end
        if changed or oldCount~=count then s.rangeEnd=-1;s.forceScene=true end
        for _,track in ipairs(c.liveTracks or {})do local d=desired[track.editingKey];if d then
            track.editingRow={start=s.time,sourceIn=d.time,length=math.max(.001,d.clip.duration-d.time)}
            if track.filmTime and (d.time<track.filmTime-.0001 or d.time-track.filmTime>1)then
                track.frameIndex=1;track.changeWheelReplay=nil;track.allWheelReplay=nil;JLRSWheelVisual.clear(track);JLRSRecorder.seek(track,d.time)
            end
            track.filmTime=d.time
        end end
        s.filmPrevious=desired
    end
    return reconcile(c,s)
end
local start=E.start
E.start=function(c,plan,time)
    if plan.kind~='final'then return start(c,plan,time)end
    local sources,why=C.check(c,plan);if not sources then c:notify(why);return false end
    local runtime={rows={}};for id,s in pairs(sources)do runtime.rows[#runtime.rows+1]={ids={id},start=0,sourceIn=0,length=s.duration,enabled=true,name=s.name}end
    if not start(c,runtime,0)then return false end
    local s=c.editingSession;s.filmPlan=E.copyPlan(plan);s.filmSources=sources;s.time=math.max(0,math.min(E.duration(plan),time or 0));s.duration=E.duration(plan);s.master.duration=s.duration;s.master.replayTime=s.time;s.rangeEnd=-1
    E.reconcile(c,s);E.seek(c,s.time);return true
end
local seek=E.seek
E.seek=function(c,time)
    local result=seek(c,time);local s=c.editingSession
    if s and s.filmPlan and c.editingPreviewCamera and s.filmPose then local p=s.filmPose;setTranslation(c.editingPreviewCamera,p[1],p[2],p[3]);setRotation(c.editingPreviewCamera,p[4],p[5],p[6]);setFovY(c.editingPreviewCamera,p[7])end
    return result
end
local sample=F.sample
F.sample=function(t,time,...)
    if t.editingFilm then local _,p=C.resolve(JLReplayStudio,t.editingFilm,time);if p then return p end;local first=JLRSFrames.get(t.frames,1);return first.pose end
    return sample(t,time,...)
end
function E.exportFinal(c)
    if c.recording or c.finalRecording or c.finalPlaying then return end
    local sources,why=C.check(c,c.editingPlan);if not sources then c:notify(why);return false end
    if c.editingSession then c.editingSeekTime=c.editingSession.time;c:stop()end
    if not E.apply(c) or not F.save(c)then return false end
    local ids={};for id in pairs(sources)do ids[#ids+1]=id end;table.sort(ids)
    local t={id=c.finalNextId or 1,name='Edited Final #'..(c.finalNextId or 1),duration=E.duration(c.editingPlan),sourceStart=0,speed=1,loop=false,shot=1,clips=ids,starts={},masterId=ids[1],frames=JLRSFrames.new(12),editingFilm=E.copyPlan(c.editingPlan)}
    for _,id in ipairs(ids)do t.starts[id]=0 end
    local _,p=C.resolve(c,t.editingFilm,0);p=p or {0,5,0,0,0,0,math.rad(55),0,1,1,0,0}
    JLRSFrames.push(t.frames,{t=0,pose=p});local _,last=C.resolve(c,t.editingFilm,t.duration);JLRSFrames.push(t.frames,{t=t.duration,pose=last or p})
    c.finalTakes[#c.finalTakes+1]=t
    local before={applied=c.finalApplied,draft=c.finalDraft,ready=c.finalListReady,selected=c.finalSelected,nextId=c.finalNextId}
    -- Replay Final must start the complete export, not the previous checked takes.
    c.finalApplied={[t.id]=true};c.finalDraft={[t.id]=true};c.finalListReady=true;c.finalSelected=#c.finalTakes;c.finalNextId=t.id+1
    if not F.save(c)then
        table.remove(c.finalTakes);JLRSFrames.release(t.frames)
        c.finalApplied=before.applied;c.finalDraft=before.draft;c.finalListReady=before.ready;c.finalSelected=before.selected;c.finalNextId=before.nextId
        return false
    end
    c:notify('Semua clip aktif terexport | Edited Final READY | klik Replay Final');return t
end
function C.playTake(c,t)
    local refs,why=C.check(c,t.editingFilm);if not refs then c:notify(why);return end
    if c.recording or c.finalRecording then c:notify('Stop Record dahulu.');return end
    local settings={physics=c.physicsReplay,speed=c.replaySpeed,loop=c.loop,mode=c.mode,lock=c.lock,angle=c.angleEnabled,live=c.liveDrive,keys=c.nativeShortcuts,x=c.x,y=c.y,z=c.z,yaw=c.yaw,pitch=c.pitch,fov=c.fov}
    c:stop();E.releaseVisual(c);c.editingOpen=false;c.physicsReplay=not c.preciseReplay
    if not E.start(c,t.editingFilm,0)then c.physicsReplay=settings.physics;return end
    local node=createCamera('JLRS_Final_Edit',math.rad(55),.1,6000);link(getRootNode(),node)
    c.finalPlaying={take=t,time=0,master=c.editingSession.master,lastSource=0,camera=node,previousCamera=getCamera(),settings=settings};c.angleEnabled=false;E.camera(c,c.finalPlaying)
end
local play=F.play
F.play=function(c,...)
    F.load(c)
    if c.finalListReady then
        for _,t in ipairs(c.finalTakes or {})do if (c.finalApplied or {})[t.id]and t.editingFilm then
            local valid,why=C.check(c,t.editingFilm);if not valid then c:notify(why);return end
        end end
    end
    return play(c,...)
end
-- Apply the recorded camera to the render overlay before it is drawn.
local editorDraw=E.draw
E.draw=function(c,...)
    local session=c.editingSession
    if session and session.filmPlan and c.editingPreviewCamera and session.filmPose then
        local p=session.filmPose;setTranslation(c.editingPreviewCamera,p[1],p[2],p[3]);setRotation(c.editingPreviewCamera,p[4],p[5],p[6]);setFovY(c.editingPreviewCamera,p[7])
    end
    return editorDraw(c,...)
end
local select=E.select
E.select=function(c,index,frame)
    if c.editingPlan.kind=='final'then c.editingSelected=index;return end
    return select(c,index,frame)
end
local frameSelected=E.frameSelected
E.frameSelected=function(c,...)
    if c.editingPlan.kind~='final'then return frameSelected(c,...)end
    local row=c.editingPlan.rows[c.editingSelected or 0];if not row then return end
    local time=c.editingSession and c.editingSession.time or c.editingSeekTime or row.start
    time=math.max(row.start,math.min(row.start+row.length,time));c.editingSeekTime=time
    return E.editorPreview(c,time,false)
end
local record=E.record
E.record=function(c,...)if c.editingSession and c.editingSession.filmPlan then c:notify('Gunakan Export Final untuk menyimpan susunan clip.');return end;return record(c,...)end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...);local s=c.editingSession
    if s and s.filmPlan and c.editingOpen and c.editingPreviewCamera and s.filmPose then
        local p=s.filmPose;setTranslation(c.editingPreviewCamera,p[1],p[2],p[3]);setRotation(c.editingPreviewCamera,p[4],p[5],p[6]);setFovY(c.editingPreviewCamera,p[7]);E.hold(c)
    end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.editingFinalOnly=true;c.editingPlan={kind='final',rows={}};return result
end
local open=E.open
E.open=function(c,...)
    c.editingFinalOnly=true
    if c.editingPlan and c.editingPlan.kind~='final'then c.editingPlan={kind='final',rows={}};c.editingLoaded=false end
    return open(c,...)
end
local delete=JLRSFinalList.delete
JLRSFinalList.delete=function(c,t,...)
    for _,take in ipairs(c.finalTakes or {})do if take~=t and take.editingFilm then for _,r in ipairs(take.editingFilm.rows)do if r.ids[1]==t.id then c:notify('Final ini dipakai Edited Final #'..take.id..'; hapus hasil edit dahulu.');return end end end end
    return delete(c,t,...)
end
