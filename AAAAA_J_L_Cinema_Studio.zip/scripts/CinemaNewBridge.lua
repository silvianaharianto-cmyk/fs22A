-- Cinema New 0.1.6 integration into the unchanged 1.18.86.70 feature graph.
-- Preserve History/Final formats, body modes, Change Cars and all UI callbacks.
JLRSCinemaNewBridge={STEP=.080}
local B=JLRSCinemaNewBridge
JLRSRecorder.STEP=B.STEP

-- Motion and activity share the same real timestamps; the replay/render clock
-- is never throttled. Forced start/Stop samples bypass this capture scheduler.
local record=JLRSActivities.record
JLRSActivities.record=function(c,force)
 local state=c.activityRecording
 if not state then return record(c,force)end
 local count=JLRSFrames.count(c.frames)
 if not force and state.cinemaMotionCount==count then return end
 local result=record(c,force)
 state.cinemaMotionCount=count
 return result
end

-- World streams are indexed by primary motion frames. Preparing/capturing them
-- on frames with no new motion key only repeats native reads without saving data.
local fill=JLRSWorld.fill
JLRSWorld.fill=function(c,...)
 local scene=c.worldRecord
 if c.recording and scene and not c.cacheFault and scene.sampleCount
  and scene.sampleCount>=JLRSFrames.count(c.frames)then return end
 return fill(c,...)
end

for _,name in ipairs({'jlrsSuspension','jlrsVehicleParticles','jlrsVehicleDirt'})do
 local adapter=JLRSActivities.adapters[name]
 if adapter and adapter.readInto then adapter.cinemaNumericReadInto=true end
end

-- Reset scheduler state only with the existing lifecycle. No duration/frame cap.
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
 local result=start(c,...)
 if c.recording and c.activityRecording then
  c.activityRecording.cinemaMotionCount=JLRSFrames.count(c.frames)
 end
 return result
end
