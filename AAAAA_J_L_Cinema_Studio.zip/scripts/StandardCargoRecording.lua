-- Standard transport takes own their carried vehicles in the primary fixed
-- topology, just as Record All does. Discovery happens once at Record start.
-- No extra draw/tick pose writer, follower, world scan or resampling is installed.
JLRSStandardCargo={}
local S=JLRSStandardCargo
local topology=JLRSRecorder.topology
-- Root origin height is not the physical support height. Native/visual mount
-- data and an actual downward support hit decide loose cargo at this boundary.
function S.isLoaded(object,carriers)
 if JLRSWorld.isCargo(object,carriers)then return true end
 local previous=JLRSCargoWheels and JLRSCargoWheels.vehicles[object]
 for _,deck in ipairs(carriers)do
  local mounts=deck.spec_dynamicMountAttacher and deck.spec_dynamicMountAttacher.dynamicMountedObjects or {}
  for key,value in pairs(mounts)do if key==object or value==object or (type(value)=='table'and value.object==object)then return true end end
  for key,value in pairs(deck.spec_tensionBelts and deck.spec_tensionBelts.objectsToJoint or {})do if key==object or value==object or (type(value)=='table'and value.object==object)then return true end end
  for _,objects in pairs(JLRSTrailerReplay and JLRSTrailerReplay.visual[deck]or {})do if type(objects)=='table'and objects[object]then return true end end
  if previous and previous.deck==deck and previous.track and previous.track.replaying then return true end
 end
 if type(raycastAll)~='function'or type(worldToLocal)~='function'then return false end
 local x,y,z=getWorldTranslation(object.rootNode)
 for _,deck in ipairs(carriers)do
  local lx,ly,lz=worldToLocal(deck.rootNode,x,y,z);local size=deck.size or {}
  if math.abs(ly)<=8 and math.abs(lx-(size.widthOffset or 0))<=(size.width or deck.sizeWidth or 3)/2+.35 and math.abs(lz-(size.lengthOffset or 0))<=(size.length or deck.sizeLength or 10)/2+.5 then
   local probe={distance=math.huge,hit=false}
   function probe:standardCargoHit(node,hx,hy,hz,distance)
    local mission=g_currentMission;local owner=mission.getNodeObject and mission:getNodeObject(node)or (mission.nodeToObject or {})[node]
    local own,belongs=owner==object,owner==deck;local current=node
    for depth=1,24 do
     if not current or current==0 or not entityExists(current)then break end
     if current==object.rootNode then own=true;break end
     for _,comp in ipairs(object.components or {})do if current==comp.node then own=true;break end end
     if own then break end
     if current==deck.rootNode then belongs=true;break end
     for _,comp in ipairs(deck.components or {})do if current==comp.node then belongs=true;break end end
     if belongs then break end
     current=getParent(current)
    end
    if not own and distance<self.distance then self.distance=distance;self.hit=belongs end
    return true
   end
   local ok=pcall(raycastAll,x,y+2,z,0,-1,0,'standardCargoHit',12,probe,nil,false,false)
   if ok and probe.hit then return true end
  end
 end
 return false
end
local function ownedTrack(track,owned)
 if not track.replaying then return false end
 local vehicles=track.recordVehicles or {track.target}
 if #vehicles==0 then return false end
 for _,v in ipairs(vehicles)do if not owned[v]then return false end end
 return true
end
function S.releaseWorld(replay,owned)
 local count=0
 for i=#(replay and replay.states or {}),1,-1 do
  local state=replay.states[i]
  if owned[state.group.object]then
   local pose=JLRSRecorder.capture(state.group.entries)
   if pose then
    JLRSWorld.release(state)
    JLRSRecorder.apply(state.group.entries,pose,true)
    table.remove(replay.states,i);count=count+1
   end
  end
 end
 return count
end
function S.collect(c,primary)
 local plan=c.standardCargoPlan;if plan and plan.primary==primary then return plan.entries,plan.vehicles end
 local entries,vehicles=topology(primary)
 local carriers={};local seenNodes,seenVehicles={},{}
 for _,e in ipairs(entries)do seenNodes[e.node]=true end
 for _,v in ipairs(vehicles)do
  seenVehicles[v]=true
  if v.spec_tensionBelts or v.spec_dynamicMountAttacher or v.spec_trailer then carriers[#carriers+1]=v end
 end
 if #carriers==0 then c.standardCargoPlan={primary=primary,entries=entries,vehicles=vehicles,carriers=0,cargo=0,tracks=0,world=0};return entries,vehicles end
 local candidates={}
 for v in pairs(JLRSWorld.vehicleSet())do
  if not seenVehicles[v]and JLRSRecorder.valid(v)and not JLRSWorld.isTrain(v)and S.isLoaded(v,carriers)then candidates[#candidates+1]=v end
 end
 table.sort(candidates,function(a,b)return JLRSPersist.identity(a)<JLRSPersist.identity(b)end)
 local cargo={}
 for _,v in ipairs(candidates)do
  local nodes,chain=topology(v)
  for _,object in ipairs(chain)do if not seenVehicles[object]then seenVehicles[object]=true;vehicles[#vehicles+1]=object;cargo[object]=true end end
  for _,e in ipairs(nodes)do if not seenNodes[e.node]then seenNodes[e.node]=true;entries[#entries+1]=e end end
 end
 -- Starting a transport take explicitly hands its loaded chain to native driving.
 -- Release sparse cargo/body owners too, including paused loading takes which
 -- have not reached their recorded end. Other live vehicles keep their tracks.
 local worldReleased=S.releaseWorld(c.worldReplay,seenVehicles);local tracksReleased=0
 for _,track in ipairs(c.liveTracks or {})do worldReleased=worldReleased+S.releaseWorld(track.cargoReplay,seenVehicles)end
 for i=#(c.liveTracks or {}),1,-1 do
  local track=c.liveTracks[i]
  if ownedTrack(track,seenVehicles)then
   local pose=JLRSRecorder.capture(track.entries)
   if pose then JLRSRecorder.stopReplay(track);JLRSRecorder.apply(track.entries,pose,true);table.remove(c.liveTracks,i);tracksReleased=tracksReleased+1 end
  end
 end
 c.standardCargoVehicles=next(cargo)and cargo or nil
 local count=0;for _ in pairs(cargo)do count=count+1 end
 c.standardCargoPlan={primary=primary,entries=entries,vehicles=vehicles,carriers=#carriers,cargo=count,tracks=tracksReleased,world=worldReleased}
 return entries,vehicles
end
JLRSRecorder.topology=function(v)
 local c=JLReplayStudio
 if c.standardCargoBuilding and not c.recordAllBuilding and v==g_currentMission.controlledVehicle then return S.collect(c,v)end
 return topology(v)
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
 if c~=JLReplayStudio or c.recording or c.recordAllActive or c.recordAllBuilding then return start(c,...)end
 c.standardCargoBuilding=true;c.standardCargoVehicles=nil;c.standardCargoPlan=nil
 local ok,result=pcall(start,c,...)
 local report=c.standardCargoPlan
 c.standardCargoBuilding=nil;c.standardCargoPlan=nil
 if c.recording and report then print(string.format('[J_L Cinema Studio] STANDARD CARGO | carriers=%d cargo=%d replayReleased=%d worldReleased=%d',report.carriers,report.cargo,report.tracks,report.world))end
 if not c.recording then c.standardCargoVehicles=nil end
 if not ok then error(result)end
 return result
end
-- Reuse the existing All-vehicle motor activity adapter for carried engines.
local discover=JLRSActivities.discover
JLRSActivities.discover=function(vehicles)
 local schema=discover(vehicles);local c=JLReplayStudio
 if not c.standardCargoBuilding or c.recordAllActive or not c.standardCargoVehicles then return schema end
 for _,v in ipairs(vehicles or {})do
  local motor=v.spec_motorized and v.spec_motorized.motor
  if c.standardCargoVehicles[v]and motor and type(motor.getLastModulatedMotorRpm)=='function'then
   schema[#schema+1]={owner=JLRSPersist.identity(v),config=v.configFileName or v.xmlFilename or '',kind='allMotor',name='',index=0,mode='linear',getter='',setter='',object=v}
  end
 end
 return schema
end

-- Live Drive normally rewinds independent tracks before starting a take.
-- Transfer completed loading takes before that rewind can move cargo off the deck.
local resetClock=JLRSLive.resetClock
JLRSLive.resetClock=function(c,...)
 if c.standardCargoBuilding and not c.standardCargoPlan and JLRSRecorder.valid(g_currentMission.controlledVehicle)then S.collect(c,g_currentMission.controlledVehicle)end
 return resetClock(c,...)
end
