-- Optional integration with the installed Color Configurator. UI actions only;
-- no recording, replay, physics or per-frame vehicle traversal.
local C=JLRSColorCars
local function environment()
    local env=_G.FS22_colorConfigurator
    if env and env.g_colorConfigurator then return env end
    if _G.g_colorConfigurator then return _G end
end
local function copy(t)
    if type(t)~='table'then return t end
    local out={};for k,v in pairs(t)do out[k]=copy(v)end;return out
end
function C.snapshot(v,group)
    return {id=(v.configurations or {})[group.name]or 1,
        custom=type(v.getCustomConfigurationByName)=='function'and copy(v:getCustomConfigurationByName(group.name))or nil}
end
local paint=C.paint
function C.paint(v,group,value)
    local id=type(value)=='table'and value.id or value
    local custom=type(value)=='table'and value.custom or nil
    if type(v.setCustomConfigurationsData)=='function'then
        local data=copy(v:getCustomConfigurations()or {})
        data[group.name]=copy(custom)
        -- Native wheel recoloring reads the current configuration ID.
        local previous=v.configurations[group.name];v.configurations[group.name]=id
        local ok,err=pcall(v.setCustomConfigurationsData,v,data)
        v.configurations[group.name]=previous
        if not ok then error(err)end
    elseif custom then error('Aktifkan mod Color Configuration untuk warna custom.')end
    if not group.rim then return paint(v,group,id)end
    local env=environment();local util=env and env.ColorConfiguratorUtil
    if util and type(util.updateWheelsConfiguration)=='function'then
        local previous=v.configurations[group.name];v.configurations[group.name]=id
        local ok,err=pcall(util.updateWheelsConfiguration,v)
        v.configurations[group.name]=previous
        if not ok then error(err)end
        return
    end
    local rgb=ConfigurationUtil.getColorByConfigId(v,'rimColor',id)
    if not rgb then error('Warna velg tidak tersedia.')end
    local function wheel(w)
        for _,field in ipairs({'wheelOuterRim','wheelInnerRim'})do
            local node=w[field]
            if node and entityExists(node)then
                local _,_,_,mat=I3DUtil.getShaderParameterRec(node,'colorMat0')
                I3DUtil.setShaderParameterRec(node,'colorMat0',rgb[1],rgb[2],rgb[3],w.material or rgb[4]or mat,false)
            end
        end
        for _,extra in pairs(w.additionalWheels or {})do wheel(extra)end
    end
    for _,w in pairs(v.spec_wheels.wheels or {})do wheel(w)end
    for _,w in pairs(v.spec_wheels.dynamicallyLoadedWheels or {})do wheel(w)end
end
function C.custom(c)
    local v=c.colorCarsTarget;local group=(c.colorCarsGroups or {})[c.colorCarsGroup or 1]
    if not group or not JLRSRecorder.valid(v)then return end
    local env=environment();local cc=env and env.g_colorConfigurator
    if not cc or not v.setCustomConfigurationsData then c:notify('Aktifkan mod FS22 Color Configuration terlebih dahulu.');return end
    local item=g_storeManager:getItemByXMLFilename(v.configFileName or v.xmlFilename or '')
    local configs=item and item.configurations[group.name]
    local customId
    for i,entry in ipairs(configs or {})do if entry.isCustomConfig then customId=entry.index or i;break end end
    if not customId then c:notify('Konfigurasi ini tidak mendukung warna custom di Store.');return end
    local proxy={storeItem=item,configurations=copy(v.configurations),licensePlateData={colorConfiguratorData=copy(v:getCustomConfigurations()or {})}}
    function proxy:onPickColor(index,args)
        if c.colorCarsTarget~=v or not c.colorCarsPanel then return end
        local data=self.licensePlateData.colorConfiguratorData[group.name]
        local original=configs[index]
        local color
        if index==customId and data then
            color={id=customId,name='Custom Color',rgb=copy(data.color),custom=copy(data)}
        elseif original then color={id=index,name=original.name or 'Color',rgb=original.uiColor or original.color}end
        if color then
            group.colors[#group.colors+1]=color
            JLRSColorMapPanel.choose(c,color)
        end
    end
    local dialog=g_gui:showDialog('ColorConfiguratorPickerDialog')
    if not dialog or not dialog.target then return end
    dialog.target:setCallback(proxy.onPickColor,proxy,{configName=group.name,colorOptionIndex=1})
    dialog.target:setColors(configs,v.configurations[group.name])
end
