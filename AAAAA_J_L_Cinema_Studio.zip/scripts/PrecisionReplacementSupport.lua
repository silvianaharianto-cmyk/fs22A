-- Fit remapped wheel centres using the donor's recorded contact-height change
-- and the replacement's own tyre radii. Preserve lift/cargo height and immutable
-- recordings. Original models, Physics On and edited Curva are untouched.
JLRSPrecisionSupport={}
local S=JLRSPrecisionSupport
local function finite(x)return type(x)=='number'and x==x and math.abs(x)<1e20 end
local function terrain(x,y,z)
    local m=g_currentMission
    if not m or not m.terrainRootNode or type(getTerrainHeightAtWorldPos)~='function'then return end
    return getTerrainHeightAtWorldPos(m.terrainRootNode,x,y,z)
end
-- Native tyre contact may be on a static platform above the terrain mesh.
-- Boundary-only probes; exclude the vehicle itself and dynamic obstacles/cargo.
function S.surface(v,x,y,z)
    local h=terrain(x,y,z)
    if not raycastAll or not getRigidBodyType then return h end
    local probe={height=nil}
    function probe:hit(node,hx,hy,hz,distance,nx,ny,nz)
        local cursor=node;local solid=node==g_currentMission.terrainRootNode
        for depth=1,64 do
            if not cursor or cursor==0 or not entityExists(cursor)then break end
            if cursor==v.rootNode then return true end
            for _,component in ipairs(v.components or {})do if cursor==component.node then return true end end
            local body=getRigidBodyType(cursor)
            if body==RigidBodyType.DYNAMIC or body==RigidBodyType.KINEMATIC then return true end
            if body==RigidBodyType.STATIC then solid=true end
            cursor=getParent(cursor)
        end
        if solid and (not ny or ny>.25)and (not self.height or hy>self.height)then self.height=hy end
        return true
    end
    local ok=pcall(raycastAll,x,y+2,z,0,-1,0,'hit',5,probe,nil,false,false)
    return ok and probe.height or h
end
local function tyres(v,fn)
    local function visit(w,index)
        local n=w.driveNode or w.repr;local r=w.radius or (w.physics and w.physics.radius)
        if n and entityExists(n)and finite(r)and r>0 then fn(n,r,index,w)end
        for _,extra in ipairs(w.additionalWheels or {})do visit(extra,index)end
    end
    for i,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do visit(w,i)end
end
function S.clear(track)
    local state=track.precisionSupport
    for i=state and #(state.probes or {})or 0,1,-1 do
        local node=state.probes[i];if entityExists(node)then delete(node)end
    end
    track.precisionSupport=nil
end
local function pin(parents)
    for node,p in pairs(parents or {})do if entityExists(node)then
        local x,y,z=getTranslation(node)
        if x~=p[1]or y~=p[2]or z~=p[3]then setTranslation(node,p[1],p[2],p[3])end
        local rx,ry,rz=getRotation(node)
        if rx~=p[4]or ry~=p[5]or rz~=p[6]then setRotation(node,p[4],p[5],p[6])end
    end end
end
function S.scenePose(track,pose)
    local state=track.precisionSupport
    if not state then return end
    for _,ch in ipairs(state.channels)do
        if ch.localDelta then for i=1,3 do pose[ch.offset+i]=pose[ch.offset+i]+ch.localDelta[i]end
        else pose[ch.offset+2]=pose[ch.offset+2]+ch.delta end
    end
    pin(state.parents)
end
function S.reference(track)
    local c=JLReplayStudio
    if not c.preciseReplay or c.recording or (c.curvaEnabled and c.curvaHasEdits)then return end
    local data=track.frames and track.frames.jlrsActivities
    if not data or not track.entries then return end
    local first=JLRSFrames.get(track.frames,1);if not first or not first.pose then return end
    local ref={first=first.pose,offsets={},roots={},owners={},vehicles={},parents={},locals={},sourceWheels={}}
    for i,e in ipairs(track.entries)do
        ref.offsets[e.node]={offset=(i-1)*6,world=e.world,vehicle=e.vehicle}
        if e.world and e.vehicle and e.node==e.vehicle.rootNode then ref.roots[e.vehicle]=(i-1)*6 end
    end
    -- topology() adds a separate root without an owner on models whose root
    -- differs from component 1. Recover ownership without modifying entries.
    local vehicles={}
    for _,v in ipairs(track.recordVehicles or {track.target})do if v then vehicles[v]=true end end
    for _,e in ipairs(track.entries)do if e.vehicle then vehicles[e.vehicle]=true end end
    for v in pairs(vehicles)do
        local e=ref.offsets[v.rootNode]
        if e and e.world then e.vehicle=v;ref.roots[v]=e.offset end
        for _,component in ipairs(v.components or {})do
            local body=ref.offsets[component.node]
            if body and body.world then body.vehicle=v end
        end
    end
    for i,ch in ipairs(data.schema or {})do
        if ch.owner and ch.config and ch.config~=''then ref.owners[ch.owner]=ch.config end
        if ch.getter=='jlrsSuspension'and ch.name=='wheel'and ch.index then
            local wheels=ref.sourceWheels[ch.owner]or {};ref.sourceWheels[ch.owner]=wheels
            wheels[ch.index]=(i-1)*6
        end
    end
    if data.frames and JLRSFrames.count(data.frames)>0 then
        local frame=JLRSFrames.get(data.frames,1);ref.activityFirst=frame and frame.pose
    end
    for v,root in pairs(ref.roots)do
        local donor=ref.owners[v.jlrsPersistentId]
        -- A take can return to its original model through Change Cars. Its
        -- converted bind still needs the replacement fit after a fresh load;
        -- matching filenames alone do not make it an untouched recording.
        if donor and (donor~=(v.configFileName or v.xmlFilename or '')
            or (track.frames.jlrsRemapReloadOwners or {})[v.jlrsPersistentId])
            and JLRSRecorder.valid(v)then
            local info={groups={},wheels={}};local grounded=false
            tyres(v,function(node,radius,index,wheel)
                local cursor=node;local body
                while cursor and cursor~=0 and cursor~=getRootNode()do
                    local e=ref.offsets[cursor]
                    if e and e.world then if e.vehicle==v then body=cursor end;break end
                    cursor=getParent(cursor)
                end
                if body then
                    local x,y,z=getWorldTranslation(node);local h=S.surface(v,x,y,z)
                    if finite(h)then
                        local group=info.groups[body]or {};info.groups[body]=group
                        local gap=y-radius-h;group.gap=group.gap and math.min(group.gap,gap)or gap
                        -- Old remaps can already leave the native graphics
                        -- slightly above ground. Do not treat that as a valid
                        -- contact target, or repeat it in every subsequent replay.
                        if math.abs(gap)<=.5 then grounded=true end
                        info.wheels[#info.wheels+1]={node=node,radius=radius,body=body,gap=gap,index=index,wheel=wheel}
                    end
                    cursor=node
                    while cursor and cursor~=body do
                        local e=ref.offsets[cursor]
                        local x,y,z=getTranslation(cursor);local rx,ry,rz=getRotation(cursor)
                        if e and not e.world then
                            local n=e.offset;ref.locals[cursor]={x-ref.first[n+1],y-ref.first[n+2],z-ref.first[n+3]}
                        elseif not e then ref.parents[cursor]={x,y,z,rx,ry,rz}end
                        cursor=getParent(cursor)
                    end
                end
            end)
            local x,y,z=getWorldTranslation(v.rootNode);local h=S.surface(v,x,y,z)
            local p=ref.first;local startH
            if finite(p[root+1])and finite(p[root+2])and finite(p[root+3])then startH=S.surface(v,p[root+1],p[root+2],p[root+3])end
            local delta=finite(h)and finite(startH)and (y-h)-(p[root+2]-startH)
            -- A grounded replacement can differ by much more than 50 cm from
            -- the donor's origin. Native tyre contact validates the reference;
            -- the old fixed cap silently disabled the entire fit for big swaps.
            if grounded and finite(delta)then
                info.rootDelta=delta;ref.vehicles[v]=info
            end
            local details={}
            for body,g in pairs(info.groups)do details[#details+1]=tostring(ref.offsets[body].offset/6+1)..':'..string.format('%.4f',g.gap)end
            table.sort(details)
            print('[JLRS PRECISION FIT V1.18.86.59] native | '..tostring(v.getName and v:getName()or v.configFileName or v.xmlFilename or 'Vehicle')..
                ' | contact='..tostring(grounded)..' | rootDelta='..tostring(delta)..' | bodyGaps='..table.concat(details,','))
        end
    end
    for node in pairs(ref.parents)do
        local cursor=node;local eligible=false
        while cursor and cursor~=0 and cursor~=getRootNode()do
            local e=ref.offsets[cursor]
            if e and e.world then eligible=ref.vehicles[e.vehicle]~=nil;break end
            cursor=getParent(cursor)
        end
        if not eligible then ref.parents[node]=nil end
    end
    return ref
end
function S.prepare(track,ref)
    S.clear(track)
    if not ref or not next(ref.vehicles)then return end
    -- removeFromPhysics can reset unrecorded visual ancestors. Restore the
    -- replacement's native bind before predicting its isolated replay pose.
    pin(ref.parents)
    local cache,created={},{}
    local function probe(node)
        if node==0 or node==getRootNode()then return getRootNode()end
        if cache[node]then return cache[node]end
        local proxy=createTransformGroup('JLRS_Clearance_Probe');cache[node]=proxy;created[#created+1]=proxy
        local entry=ref.offsets[node]
        if entry and entry.world then link(getRootNode(),proxy)else link(probe(getParent(node)),proxy)end
        local scale=entry and entry.world and type(getWorldScale)=='function'and getWorldScale or getScale
        if type(scale)=='function'and type(setScale)=='function'then
            local x,y,z=scale(node);if finite(x)and finite(y)and finite(z)then setScale(proxy,x,y,z)end
        end
        if entry then
            local n=entry.offset;local p=ref.first;local d=ref.locals[node]or {0,0,0}
            for i=1,6 do if not finite(p[n+i])then error('Pose awal kendaraan tidak lengkap')end end
            setTranslation(proxy,p[n+1]+d[1],p[n+2]+d[2],p[n+3]+d[3]);setRotation(proxy,p[n+4],p[n+5],p[n+6])
        else
            local p=ref.parents[node]
            if p then setTranslation(proxy,p[1],p[2],p[3]);setRotation(proxy,p[4],p[5],p[6])
            else local x,y,z=getTranslation(node);local rx,ry,rz=getRotation(node);setTranslation(proxy,x,y,z);setRotation(proxy,rx,ry,rz)end
        end
        return proxy
    end
    local channels={};local parents={};local contact={};local bodies={}
    local ok,err=pcall(function()
        for v,info in pairs(ref.vehicles)do
            for _,w in ipairs(info.wheels)do
                local x,y,z=getWorldTranslation(probe(w.node));local h=S.surface(v,x,y,z)
                if finite(h)then
                    local group=info.groups[w.body];local gap=y-w.radius-h
                    w.stored=gap
                    group.stored=group.stored and math.min(group.stored,gap)or gap
                end
            end
            -- The remapped stream freezes wheel translations. Recover the
            -- donor's recorded physical wheel-centre trajectory instead of
            -- freezing a ground correction in the first steering/pitch axes.
            -- Native wheel centres are component-relative. Only use this path
            -- for a single-body replacement; keep the established fallback for
            -- articulated models whose donor component frame is not available.
            local source=ref.sourceWheels[v.jlrsPersistentId]
            if source and ref.activityFirst and #(v.components or {})==1
                and not ((track.frames.jlrsRemapReloadOwners or {})[v.jlrsPersistentId])then
                local start=#contact
                local count=0;for i in pairs(source)do count=math.max(count,i)end
                for _,w in ipairs(info.wheels)do
                    local entry=ref.offsets[w.node]
                    local index=source[w.index]and w.index or
                        (count>=2 and math.max(1,count-1)+(w.index-1)%2 or 1)
                    local offset=source[index];local p=ref.activityFirst
                    if entry and not entry.world and offset and finite(p[offset+1])
                        and finite(p[offset+2])and finite(p[offset+3])then
                        local root=probe(v.rootNode)
                        local x,y,z=localToWorld(root,p[offset+1],p[offset+2],p[offset+3])
                        local h=terrain(x,y,z)
                        if finite(h)then contact[#contact+1]={node=w.node,radius=w.radius,wheel=w.wheel,vehicle=v,
                            offset=entry.offset,sourceOffset=offset,rootOffset=ref.roots[v],
                            sourceHeight=y-h,root=root}end
                    end
                end
                if #contact>start and v.components[1].node==v.rootNode then
                    bodies[v]={node=v.rootNode,offset=ref.roots[v]}
                end
            end
            for _,group in pairs(info.groups)do
                local delta=finite(group.stored)and -group.stored
                -- A converted axle can be almost a metre below its support.
                -- Fit that component from its own recorded contact gap, rather
                -- than reusing the chassis offset (which differs on articulation).
                -- Keep the airborne-start guard: never lower a high source pose.
                if math.abs(group.gap)<=.5 and finite(delta)and (delta>=0 or math.abs(delta)<=.5)then group.delta=delta end
            end
            -- The chassis bind height belongs to the replacement. A low front
            -- tyre must not lift the whole chassis by its minimum contact gap.
            -- Separate rigid axle components retain their individual body fit.
            if info.groups[v.rootNode] and info.groups[v.rootNode].delta==nil then
                info.groups[v.rootNode].delta=info.rootDelta
            end
            -- One chassis/axle may carry tyres with different radii and centre
            -- heights. Its minimum contact gap cannot fit every individual tyre.
            -- Correct only each recorded tyre centre's remaining bind error,
            -- expressed in its actual parent's local axes (including pitch/scale).
            local wheelExtras={};local wheelDetails={}
            for _,w in ipairs(info.wheels)do
                local e=ref.offsets[w.node];local group=info.groups[w.body]
                local bodyDelta=group and group.delta or info.rootDelta
                local residual=finite(w.stored)and -w.stored-bodyDelta
                if e and not e.world and math.abs(w.gap)<=.5 and finite(residual)
                    and math.abs(residual)<=.5 and math.abs(residual)>1e-7 then
                    local proxy=probe(w.node);local parent=getParent(proxy)
                    local x,y,z=getWorldTranslation(proxy)
                    local ax,ay,az=worldToLocal(parent,x,y,z)
                    local bx,by,bz=worldToLocal(parent,x,y+residual,z)
                    wheelExtras[w.node]={bx-ax,by-ay,bz-az}
                    wheelDetails[#wheelDetails+1]=tostring(e.offset/6+1)..':'..tostring(residual)
                end
            end
            local details={}
            for body,g in pairs(info.groups)do details[#details+1]=tostring(ref.offsets[body].offset/6+1)..':'..
                tostring(g.delta)..' (poseGap='..tostring(g.stored)..')'end
            table.sort(details)
            print('[JLRS PRECISION FIT V1.18.86.59] replay | '..tostring(v.getName and v:getName()or v.configFileName or 'Vehicle')..
                ' | bodyCorrections='..table.concat(details,',')..' | wheelCorrections='..table.concat(wheelDetails,','))
            for i,e in ipairs(track.entries)do
                if e.world and ref.offsets[e.node].vehicle==v then
                    local group=info.groups[e.node];local delta=group and group.delta or info.rootDelta
                    if math.abs(delta)>1e-7 then channels[#channels+1]={offset=(i-1)*6,delta=delta}end
                elseif not e.world and ref.locals[e.node]then
                    -- Local bind translation changes; all recorded steering and
                    -- wheel spin rotations remain byte-for-byte unchanged.
                    local belongs=false;local cursor=e.node
                    while cursor and cursor~=0 and cursor~=getRootNode()do
                        local parent=ref.offsets[cursor]
                        if parent and parent.world then belongs=parent.vehicle==v;break end
                        cursor=getParent(cursor)
                    end
                    local bind=ref.locals[e.node]
                    -- A single-body replacement keeps its native wheel bind.
                    -- Contact fitting moves the complete rigid assembly instead.
                    local extra=not bodies[v] and wheelExtras[e.node]or {0,0,0}
                    local d={bind[1]+extra[1],bind[2]+extra[2],bind[3]+extra[3]}
                    if belongs and (math.abs(d[1])>1e-7 or math.abs(d[2])>1e-7 or math.abs(d[3])>1e-7)then
                        channels[#channels+1]={offset=(i-1)*6,localDelta=d}
                    end
                end
            end
        end
        for node,p in pairs(ref.parents)do
            local cursor=node
            while cursor and cursor~=0 and cursor~=getRootNode()do
                local e=ref.offsets[cursor]
                if e and e.world then if ref.vehicles[e.vehicle]then parents[node]=p end;break end
                cursor=getParent(cursor)
            end
        end
    end)
    if not ok or #contact==0 then
        for i=#created,1,-1 do if entityExists(created[i])then delete(created[i])end end
    end
    if not ok then print('[J_L Cinema Studio] Clearance probe tidak tersedia: '..tostring(err));return end
    if #channels>0 or next(parents)or #contact>0 then track.precisionSupport={entries=track.entries,channels=channels,
        parents=parents,contact=contact,probes=#contact>0 and created or nil,graph=cache,offsets=ref.offsets,
        activity=track.frames.jlrsActivities,bodies=bodies}end
end
-- Interpolate only the required centre coordinates. This avoids a second
-- interpolation/allocation of every activity channel on each render frame.
local function activityInterval(state,time)
    local frames=state.activity.frames;local interval=state.interval
    if interval and time>=interval.a.t and time<=interval.b.t then return interval end
    local count=JLRSFrames.count(frames);if count==0 then return end
    local index=interval and interval.index or 1
    local steps=0
    while index>1 and steps<8 do
        local frame=JLRSFrames.get(frames,index);if not frame or frame.t<=time then break end
        index=index-1;steps=steps+1
    end
    steps=0
    while index<count and steps<8 do
        local frame=JLRSFrames.get(frames,index+1);if not frame or frame.t>=time then break end
        index=index+1;steps=steps+1
    end
    local a,b=JLRSFrames.get(frames,index),JLRSFrames.get(frames,math.min(index+1,count))
    if not a or not b then return end
    if not(time>=a.t and (index==count or time<=b.t))then
        local low,high=1,count
        while low<=high do
            local mid=math.floor((low+high)/2);local frame=JLRSFrames.get(frames,mid)
            if not frame then return end
            if frame.t<=time then index=mid;low=mid+1 else high=mid-1 end
        end
        a,b=JLRSFrames.get(frames,index),JLRSFrames.get(frames,math.min(index+1,count))
        if not a or not b then return end
    end
    interval={a=a,b=b,index=index}
    state.interval=interval;return interval
end
function S.contactPose(state,source,out,time)
    if not state.probes or #state.contact==0 then return end
    -- Update private probes, never the game vehicle during sampling. Parents
    -- retain the replacement's native hierarchy and scales.
    for node,proxy in pairs(state.graph)do
        local entry=state.offsets[node]
        if entry then local n=entry.offset
            setTranslation(proxy,out[n+1],out[n+2],out[n+3])
            setRotation(proxy,out[n+4],out[n+5],out[n+6])
        end
    end
    local interval=activityInterval(state,time);if not interval then return end
    local a,b=interval.a,interval.b
    local alpha=b.t>a.t and math.max(0,math.min(1,(time-a.t)/(b.t-a.t)))or 0
    local heights={};local targets={};local lift={};local weights={};local air={}
    for _,w in ipairs(state.contact)do
        local key=w.rootOffset..':'..w.sourceOffset;local delta=heights[key]
        if delta==nil then
            local n=w.sourceOffset
            local valid=true;for j=1,3 do if not finite(a.pose[n+j])or not finite(b.pose[n+j])then valid=false;break end end
            if valid then
            local px=a.pose[n+1]+(b.pose[n+1]-a.pose[n+1])*alpha
            local py=a.pose[n+2]+(b.pose[n+2]-a.pose[n+2])*alpha
            local pz=a.pose[n+3]+(b.pose[n+3]-a.pose[n+3])*alpha
            -- Use the uncorrected remapped root. Its constant Change Cars
            -- height offset cancels in the initial-relative source clearance.
            local r=w.rootOffset;local root=w.root
            local x,y,z=getTranslation(root);local rx,ry,rz=getRotation(root)
            setTranslation(root,source[r+1],source[r+2],source[r+3])
            setRotation(root,source[r+4],source[r+5],source[r+6])
            local sx,sy,sz=localToWorld(root,px,py,pz);local h=terrain(sx,sy,sz)
            setTranslation(root,x,y,z);setRotation(root,rx,ry,rz)
            if finite(h)then
                -- A donor's compression/penetration must not place a smaller
                -- replacement under terrain. Positive lift (jumps/deck height)
                -- is preserved, rather than snapping all replays to the road.
                delta=math.max(0,sy-h-w.sourceHeight)
                -- Tiny donor contact offsets are not a jump. Preserve genuine
                -- lift above 8 cm, with a smooth contact transition in between.
                local contact=math.max(0,math.min(1,(delta-.03)/.05))
                delta=delta*contact*contact*(3-2*contact);heights[key]=delta
            end
            end
        end
        if finite(delta)then
            local proxy=state.graph[w.node];local x,y,z=getWorldTranslation(proxy);local h=terrain(x,y,z)
            if finite(h)then
                local deformation=w.vehicle.spec_wheels.wheelVisualPressureActive and w.wheel.deformation or 0
                deformation=finite(deformation)and math.max(0,math.min(deformation,w.radius*.25))or 0
                local target=h+w.radius-deformation+delta
                targets[#targets+1]={wheel=w,x=x,y=target,z=z}
                -- Lift a low single-body chassis before applying the individual
                -- axle residuals. Moving only its tyres leaves the body buried
                -- and creates excessive visual suspension offsets after a swap.
                if state.bodies[w.vehicle]then
                    local v=w.vehicle
                    lift[v]=math.max(lift[v]or -math.huge,target-y)
                    air[v]=math.max(air[v]or 0,delta)
                    if weights[v]==nil then
                        local up=1
                        if type(localDirectionToWorld)=='function'then local _,uy=localDirectionToWorld(w.root,0,1,0);up=uy end
                        weights[v]=math.max(0,math.min(1,(up-.94)/.045))
                    end
                end
            end
        end
    end
    for v,dy in pairs(lift)do
        -- Fade ground fitting out before a flip or jump. The immutable path
        -- remains authoritative in the air; tyre nodes are never ground-clamped.
        local weight=(weights[v]or 0)*math.max(0,math.min(1,(.25-(air[v]or 0))/.20))
        dy=dy*weight
        if math.abs(dy)>1e-7 then
            local body=state.bodies[v];local n=body.offset
            out[n+2]=out[n+2]+dy
            setTranslation(state.graph[body.node],out[n+1],out[n+2],out[n+3])
        end
    end
    for _,target in ipairs(targets)do
        local w=target.wheel;local proxy=state.graph[w.node];local parent=getParent(proxy)
        if not state.bodies[w.vehicle]then
            local x,y,z=worldToLocal(parent,target.x,target.y,target.z)
            local n=w.offset;out[n+1],out[n+2],out[n+3]=x,y,z
            setTranslation(proxy,x,y,z)
        end
    end
end
local detach=JLRSLive.detachPhysics
JLRSLive.detachPhysics=function(track,...)
    S.clear(track)
    local ok,ref=pcall(S.reference,track)
    if not ok then print('[J_L Cinema Studio] Clearance reference tidak tersedia: '..tostring(ref));ref=nil end
    local result=detach(track,...)
    if result~=false and track.livePhysics and not track.collisionReplay then S.prepare(track,ref)end
    return result
end
local sample=JLRSRecorder.sample
JLRSRecorder.sample=function(track,time,...)
    local pose=sample(track,time,...);local state=track.precisionSupport;local c=JLReplayStudio
    if not state or not track.replaying or not track.livePhysics or track.collisionReplay
        or not c.preciseReplay or c.recording or (c.curvaEnabled and c.curvaHasEdits)
        or state.entries~=track.entries then return pose end
    if #state.channels==0 and #(state.contact or {})==0 then return pose end
    if state.time==time and state.source==pose then return state.pose end
    local out={};for i,v in ipairs(pose)do out[i]=v end
    for _,ch in ipairs(state.channels)do
        if ch.localDelta then for i=1,3 do out[ch.offset+i]=out[ch.offset+i]+ch.localDelta[i]end
        else local i=ch.offset+2;out[i]=out[i]+ch.delta end
    end
    S.contactPose(state,pose,out,time)
    state.time=time;state.source=pose;state.pose=out
    return out
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    local result=tick(track,...);local c=JLReplayStudio;local state=track.precisionSupport
    if state and track.replaying and track.livePhysics and not track.collisionReplay
        and c.preciseReplay and not c.recording and not (c.curvaEnabled and c.curvaHasEdits)then pin(state.parents)end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    S.clear(track);return stop(track,...)
end
local unload=JLReplayStudio.deleteMap
if type(unload)=='function'then
    JLReplayStudio.deleteMap=function(c,...)
        local function clear(track)
            if not track then return end;S.clear(track)
            for _,w in ipairs({track.worldReplay or {},track.cargoReplay or {}})do
                for _,state in ipairs(w.states or {})do if state.vehicleTrack then S.clear(state.vehicleTrack)end end
            end
        end
        clear(c);for _,track in ipairs(c.liveTracks or {})do clear(track)end
        return unload(c,...)
    end
end
