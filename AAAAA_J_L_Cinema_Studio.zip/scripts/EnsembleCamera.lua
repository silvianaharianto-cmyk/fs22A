JLRSGroup={}
function JLRSGroup.camera(c)
    if not c.liveDrive or #(c.liveTracks or {})==0 then c:notify('Mulai Live Replay dahulu.');return end
    if c.groupCamera then
        c.groupCamera=false;c.cameraTarget=nil;JLRSCamera.deactivate(c)
        c:notify('Kamera normal | kendaraan live dapat dikemudikan');return
    end
    c.groupCamera=true;c.cameraTarget=c.liveTracks[1].target;c.groupIndex=1
    JLRSCamera.activate(c);c.mode=1;c.lock=false;JLRSCamera.choose(c,1)
    c.menu=false;c.historyOpen=false;JLRSMouse.refresh(c)
    c:notify('REPLAY CAMERA | WASDQE + mouse + scroll | Tab target berikut | F8 kamera normal')
end
function JLRSGroup.targets(c)
    local list,seen={},{}
    local function add(v)
        if JLRSRecorder.valid(v) and not JLRSWorld.isTrain(v) and not seen[v] then seen[v]=true;list[#list+1]=v end
    end
    for _,track in ipairs(c.liveTracks or {}) do add(track.target) end
    if c.replaying then add(c.target) end
    for _,v in pairs((c.mission and c.mission.vehicles) or {}) do
        if v.spec_enterable and not v.isDeleted then add(v) end
    end
    return list
end
function JLRSGroup.next(c)
    local targets=JLRSGroup.targets(c)
    if #targets==0 then return end
    local current=c.cameraTarget or c.target;local index=0
    for i,v in ipairs(targets) do if v==current then index=i;break end end
    c.groupIndex=index%#targets+1;c.cameraTarget=targets[c.groupIndex]
    if not c.groupCamera then
        c.groupCamera=true;JLRSCamera.activate(c)
    end
    local x,y,z=getWorldTranslation(c.cameraTarget.rootNode)
    c.x=x+8;c.y=y+4;c.z=z+10
    JLRSCamera.choose(c,c.mode)
    c:notify('Target kamera: '..tostring(c.groupIndex)..' / '..#targets)
end
function JLRSGroup.all(c,selection)
    if c.recording then JLRSRecorder.stopRecord(c) end
    if not c.liveDrive then JLRSLive.toggle(c) end
    -- Newest valid take wins per physical vehicle; overlapping implements
    -- are excluded so no two tracks can write the same component.
    local clips,used={},{}
    for i=#c.history,1,-1 do
        local clip=c.history[i];local overlap=false
        for _,v in ipairs(clip.vehicles or {clip.target}) do if used[v] then overlap=true end end
        if (not selection or selection[clip.id]) and JLRSHistory.valid(clip) and not overlap then
            table.insert(clips,1,clip)
            for _,v in ipairs(clip.vehicles or {clip.target}) do used[v]=true end
        end
    end
    if #clips==0 then c:notify('Tidak ada record valid untuk Replay All.');return end
    c:stop()
    -- Reserve all replay vehicles before selecting the background scene.
    -- A world snapshot must never detach a vehicle owned by another live track.
    c.worldBatch=true
    local ok,err=pcall(function()
        for _,clip in ipairs(clips) do JLRSHistory.replay(c,clip) end
    end)
    c.worldBatch=nil
    if not ok then c:stop();c:notify('Replay All gagal: '..tostring(err));return end
    if #c.liveTracks>0 then
        JLRSLive.resetClock(c)

        JLRSHistory.close(c);c.menu=false;JLRSGroup.camera(c)
        c:notify('REPLAY ALL | '..#c.liveTracks..' track | Tab target kamera | F8 kamera/drive')
    end
end
local focus=JLRSCamera.focus
JLRSCamera.focus=function(c)
    if c.groupCamera and JLRSRecorder.valid(c.cameraTarget) then
        local x,y,z=getWorldTranslation(c.cameraTarget.rootNode);return x,y+c.focusHeight,z
    end
    return focus(c)
end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)
    if not c.groupCamera then return choose(c,...) end
    local target=c.target;c.target=c.cameraTarget
    local result=choose(c,...);c.target=target;return result
end
local cameraTick=JLRSCamera.tick
JLRSCamera.tick=function(c,...)
    if not c.groupCamera then return cameraTick(c,...) end
    local target=c.target;c.target=c.cameraTarget
    local result=cameraTick(c,...);c.target=target;return result
end
local locked=JLRSInputGuard.isLocked
JLRSInputGuard.isLocked=function()
    local c=JLReplayStudio
    if c.groupCamera and c.active then return true end
    return locked()
end
local own=JLRSInputGuard.isOwn
JLRSInputGuard.isOwn=function(target,action)
    local c=JLReplayStudio
    if c.groupCamera then
        for _,name in ipairs({'AXIS_ACCELERATE_VEHICLE','AXIS_BRAKE_VEHICLE','AXIS_MOVE_SIDE_VEHICLE','AXIS_MOVE_FORWARD_PLAYER','AXIS_MOVE_SIDE_PLAYER'}) do
            if action==name or (InputAction and action==InputAction[name]) then return false end
        end
    end
    return own(target,action)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local now=g_time or 0;local dt=c.groupClock and math.max(0,(now-c.groupClock)/1000) or 0;c.groupClock=now
    draw(c,...)
    if not c.mission then return end
    c.groupKeys=c.groupKeys or {}
    local gui=g_gui and g_gui:getIsGuiVisible()
    for _,key in ipairs({'KEY_f8','KEY_tab','KEY_f9','KEY_l'}) do
        local code=Input[key] or (key=='KEY_tab' and Input.KEY_TAB)
        local held=code and Input.isKeyPressed(code) or false
        local edge=held and not c.groupKeys[key];c.groupKeys[key]=held
        if edge and not gui and not c.menu then
            if key=='KEY_f8' then JLRSGroup.camera(c)
            elseif key=='KEY_tab' and (c.groupCamera or c.replaying or #(c.liveTracks or {})>0) then JLRSGroup.next(c)
            elseif c.groupCamera then
                if key=='KEY_tab' then JLRSGroup.next(c)
                elseif key=='KEY_f9' then JLRSCamera.choose(c,c.mode%#JLRSCamera.names+1)
                else JLRSCamera.toggleLock(c) end
            end
        end
    end
    if c.groupCamera then
        if #c.liveTracks==0 and not c.replaying and not c.editingSession then c.groupCamera=false;c.cameraTarget=nil;JLRSCamera.deactivate(c)
        elseif not gui and not c.mission.isPaused then
            if not JLRSRecorder.valid(c.cameraTarget) then c.cameraTarget=(c.liveTracks[1] and c.liveTracks[1].target) or c.target end
            JLRSCamera.tick(c,math.min(dt,0.1))
        end
    end
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    if c.groupCamera then c.groupCamera=false;c.cameraTarget=nil;JLRSCamera.deactivate(c) end
    return stop(c,...)
end
local toggle=JLRSLive.toggle
JLRSLive.toggle=function(c,...)
    if c.groupCamera then c.groupCamera=false;c.cameraTarget=nil;JLRSCamera.deactivate(c) end
    return toggle(c,...)
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c.groupCamera then c.groupCamera=false;c.cameraTarget=nil;JLRSCamera.deactivate(c) end
    return start(c,...)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    load(c,...);c.groupCamera=false;c.cameraTarget=nil;c.groupKeys={};c.groupClock=nil
end
