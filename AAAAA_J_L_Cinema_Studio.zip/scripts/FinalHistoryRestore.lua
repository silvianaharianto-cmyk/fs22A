-- Resolve persistent vehicle dependencies before the Final player's early
-- validation. Reuse the established asynchronous History repair, never delete
-- a take or silently substitute a different vehicle/recording.
JLRSFinalHistoryRestore={}
local R=JLRSFinalHistoryRestore
-- Some vehicle mods rebuild wheel/visual nodes when physics is restored after
-- Change Cars. Rebind the saved replacement slots, without converting a second
-- time or changing any recorded pose, wheel geometry, activity or camera data.
function R.rebind(c,clip)
    local saved=clip.saved
    if not saved or not saved.target then return false end
    local vehicles,slots={},{}
    for vi,desc in ipairs(saved.vehicles or {})do
        local found
        for _,v in pairs(c.mission and c.mission.vehicles or {})do
            if JLRSRecorder.valid(v) and desc.id~='' and v.jlrsPersistentId==desc.id
                and (v.configFileName or v.xmlFilename or '')==desc.config then
                if found and found~=v then return false end
                found=v
            end
        end
        if not found then return false end
        vehicles[vi]=found
        local list,seen={},{}
        local function add(node,world,ci)
            if node and node~=0 and entityExists(node)and not seen[node]then
                seen[node]=true;list[#list+1]={node=node,world=world,parent=getParent(node),vehicle=ci and found or nil,componentIndex=ci}
            end
        end
        for ci,component in ipairs(found.components or {})do add(component.node,true,ci)end
        add(found.rootNode,true)
        local function wheel(w)
            add(w.repr,false);add(w.driveNode,false)
            for _,extra in ipairs(w.additionalWheels or {})do wheel(extra)end
        end
        for _,w in ipairs(found.spec_wheels and found.spec_wheels.wheels or {})do wheel(w)end
        slots[vi]=list
    end
    local entries,used={},{}
    for i,desc in ipairs(saved.entries or {})do
        local list=slots[desc.vehicle]or {};local entry=list[desc.slot]
        local function matches(e)
            return e and (e.world and 1 or 0)==desc.world
                and (desc.name==''or (type(getName)=='function'and getName(e.node)==desc.name))
        end
        if not matches(entry)then
            entry=nil
            -- A named unique node can survive extra mod-created visual slots.
            if desc.name and desc.name~=''then
                for _,candidate in ipairs(list)do if matches(candidate)then
                    if entry then return false end;entry=candidate
                end end
            end
        end
        if not entry or used[entry.node]then return false end
        used[entry.node]=true;entries[i]=entry
    end
    if #entries==0 or not vehicles[saved.target]or not JLRSRecorder.capture(entries)then return false end
    -- Commit only once every vehicle and node has passed validation.
    clip.entries=entries;clip.vehicles=vehicles;clip.target=vehicles[saved.target]
    clip.bound=true
    return true
end
function R.prepare(c,resume)
    JLRSPersist.load(c);JLRSFinal.load(c)
    if c.jlrsLoadPending or c.finalLoadPending then c:notify('Replay Final belum siap: History / Final sedang dimuat.');return false end
    if c.historyRepair then c:notify('History sedang dipulihkan; tunggu sampai selesai.');return false end
    local takes={}
    if c.finalListReady then
        for _,t in ipairs(c.finalTakes or {})do if (c.finalApplied or {})[t.id]then takes[#takes+1]=t end end
    else
        local t=(c.finalTakes or {})[c.finalSelected or 0];if t then takes[1]=t end
    end
    local seen={}
    for _,t in ipairs(takes)do
        for _,id in ipairs(t.clips or {})do
            if not seen[id]then
                seen[id]=true;local clip
                for _,item in ipairs(c.history or {})do if item.id==id then clip=item;break end end
                if not clip then c:notify('Replay Final gagal: History #'..tostring(id)..' belum tersedia. Final tetap disimpan.');return false end
                JLRSPersist.bind(clip,true)
                if not JLRSHistory.valid(clip)then R.rebind(c,clip)end
                if not JLRSHistory.valid(clip)then
                    local selected=c.finalSelected
                    if JLRSHistoryRepair and JLRSHistoryRepair.start(c,clip)then
                        if c.historyRepair and c.historyRepair.clip==clip then
                            c.historyRepair.continue=function()
                                c.finalSelected=selected;resume()
                            end
                        end
                    else c:notify('Replay Final belum pulih: kendaraan/node History #'..tostring(id)..' belum cocok. Rekaman asli dipertahankan.')end
                    return false
                end
            end
        end
    end
    return true
end
local play=JLRSFinal.play
JLRSFinal.play=function(c,...)
    if c.recording or c.finalRecording then return play(c,...)end
    if not R.prepare(c,function()JLRSFinal.play(c)end)then return end
    return play(c,...)
end
