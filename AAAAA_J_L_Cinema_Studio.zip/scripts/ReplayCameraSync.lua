-- Resolve the camera after all native/local replay visual writers have finished.
-- No extra replay tick, frame sampling, physics setter or mouse integration.
JLRSReplayCameraSync={}
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
 local result=draw(c,...)
 if c.mission and c.active and c.camera and not c.finalPlaying and not c.editingOpen
  and not c.curvaOpen and not c.objectRunning and (c.replaying or c.groupCamera)
  and not (g_gui and g_gui:getIsGuiVisible())then
  JLRSCamera.tick(c,0)
 end
 return result
end
