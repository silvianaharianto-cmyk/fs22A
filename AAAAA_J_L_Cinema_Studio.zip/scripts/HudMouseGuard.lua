-- One mouse ownership policy for every Cinema HUD. Native menus still receive
-- clicks; only camera look/zoom input is gated while Cinema owns the cursor.
local M=JLRSMouse
function M.hudOwns(c)
    if not c or not c.mission then return false end
    -- List/editor HUDs are drawn only when menu is true. Do not let stale
    -- list selection flags block gameplay after a shortcut hides the menu.
    return c.menu==true or c.miniScrub==true or (JLRSMiniHud and JLRSMiniHud.cursor(c))==true
        or (JLRSObject and JLRSObject.cursor(c))==true or (JLRSChange and JLRSChange.cursor(c))==true
end
local function clear(c)
    c.compatMouse=nil;c.cameraInput=nil
    local mission=c.mission;local vehicle=mission and mission.controlledVehicle
    local enterable=vehicle and vehicle.spec_enterable
    for _,camera in pairs(enterable and enterable.cameras or {})do
        if camera.lastInputValues then camera.lastInputValues.leftRight=0;camera.lastInputValues.upDown=0 end
    end
    local info=mission and mission.player and mission.player.inputInformation
    if info then info.yawCamera=0;info.pitchCamera=0 end
end
local sync=M.syncCursor
M.syncCursor=function(c,...)
    local owned=M.hudOwns(c)
    if owned and JLRSMouseCompatibility then JLRSMouseCompatibility.install(c)end
    if owned or c.hudMouseWasOwned then clear(c)end
    c.hudMouseWasOwned=owned
    return sync(c,...)
end
local axis=JLRSCamera.mouseAxis
JLRSCamera.mouseAxis=function(c,...)if M.hudOwns(c)then clear(c);return end;return axis(c,...)end
local scroll=JLRSCamera.scroll
JLRSCamera.scroll=function(c,...)if M.hudOwns(c)then clear(c);return end;return scroll(c,...)end
local input=JLRSCamera.applyInput
JLRSCamera.applyInput=function(c,...)if M.hudOwns(c)then clear(c);return end;return input(c,...)end
local queue=JLRSMouseCompatibility.queue
JLRSMouseCompatibility.queue=function(c,...)if M.hudOwns(c)then clear(c);return end;return queue(c,...)end
