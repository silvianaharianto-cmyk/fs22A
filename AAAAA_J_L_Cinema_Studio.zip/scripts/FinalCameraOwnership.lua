-- Final's private camera is reasserted after previously registered mod draw
-- listeners. Do not block or replace the global setCamera API of other mods.
JLRSFinalCameraOwner={cameraSwitches=0,poseChanges=0}
local O=JLRSFinalCameraOwner
local sample=JLRSFinal.sample
JLRSFinal.sample=function(t,time,...)
    local pose=sample(t,time,...)
    local p=JLReplayStudio.finalPlaying
    if p and p.take==t and p.time==time then p.jlrsRenderedCameraPose=pose end
    return pose
end
function O.draw()
    local c=JLReplayStudio;local p=c.finalPlaying
    if not c.mission or not p or not p.camera or not entityExists(p.camera)
        or (g_gui and g_gui:getIsGuiVisible())then return end
    if p.take.editingFilm or p.take.editingPlan then return end
    local pose=(c.paused or c.livePaused)and c.finalCutPreviewPose or p.jlrsRenderedCameraPose
    if not pose then return end
    local changed=getCamera()~=p.camera
    if changed then O.cameraSwitches=O.cameraSwitches+1 end
    local x,y,z=getWorldTranslation(p.camera)
    local rx,ry,rz=getWorldRotation(p.camera)
    -- Native scene nodes may use float precision; avoid chasing roundoff on a
    -- large map. A full angle-wrap is also the same camera orientation.
    local function angle(a,b)return math.abs((a-b+math.pi)%(2*math.pi)-math.pi)end
    local rotation=angle(rx,pose[4])>.0001 or angle(ry,pose[5])>.0001 or angle(rz,pose[6])>.0001
    if rotation and type(mathEulerToQuaternion)=='function'then
        local ax,ay,az,aw=mathEulerToQuaternion(rx,ry,rz)
        local bx,by,bz,bw=mathEulerToQuaternion(pose[4],pose[5],pose[6])
        rotation=1-math.abs(ax*bx+ay*by+az*bz+aw*bw)>1e-8
    end
    local moved=math.abs(x-pose[1])>.002 or math.abs(y-pose[2])>.002 or math.abs(z-pose[3])>.002
        or rotation
        or (type(getFovY)=='function'and math.abs(getFovY(p.camera)-pose[7])>.0001)
    if moved then
        O.poseChanges=O.poseChanges+1
        setWorldTranslation(p.camera,pose[1],pose[2],pose[3])
        setWorldRotation(p.camera,pose[4],pose[5],pose[6]);setFovY(p.camera,pose[7])
    end
    if changed then setCamera(p.camera)end
end
function O.install()
    if O.listener or type(addModEventListener)~='function'then return end
    local function idle()end
    O.listener={draw=O.draw,loadMap=idle,deleteMap=idle,update=idle,mouseEvent=idle,keyEvent=idle}
    addModEventListener(O.listener)
end
local play=JLRSFinal.play
JLRSFinal.play=function(c,...)
    local value=play(c,...)
    if c.finalPlaying then O.install()end
    return value
end
local update=JLReplayStudio.update
JLReplayStudio.update=function(c,...)
    local value=update(c,...)
    if c.finalPlaying then O.install()end
    return value
end
local ending=JLRSFinal.endPlay
JLRSFinal.endPlay=function(c,...)
    if c.finalPlaying then c.finalPlaying.jlrsRenderedCameraPose=nil end
    return ending(c,...)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    O.cameraSwitches=0;O.poseChanges=0
    return load(c,...)
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if O.listener and type(removeModEventListener)=='function'then removeModEventListener(O.listener);O.listener=nil end
    return unload(c,...)
end
