-- Resolve the incoming shot using the same preset/lock/FOV/terrain pipeline
-- as normal rendering. A generic choose/place pose is not a rendered preset.
JLRSCameraCuts={}
function JLRSCameraCuts.resolve(c)
    if not c.angleEnabled or not c.active or not c.camera or c.finalPlaying or c.resolvingCameraCut then return end
    c.resolvingCameraCut=true
    local phase=c.phase
    -- Zero dt consumes no mouse input and advances neither movement nor replay.
    -- The pending flag bypasses stabilization of the outgoing shot.
    c.angleCutPending=true
    local ok,err=pcall(JLRSCamera.tick,c,0)
    c.phase=phase;c.resolvingCameraCut=nil
    -- The next render may follow an updated vehicle pose. Snap it too, instead
    -- of blending toward the old target position used during the key event.
    c.angleCutPending=true
    if not ok then error(err) end
end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)
    local result=choose(c,...)
    JLRSCameraCuts.resolve(c)
    return result
end
-- Enabling Angle calls place directly rather than choose; resolve that path too.
local toggle=JLRSAngle.toggle
JLRSAngle.toggle=function(c,...)
    local result=toggle(c,...)
    if c.angleEnabled then JLRSCameraCuts.resolve(c) end
    return result
end
