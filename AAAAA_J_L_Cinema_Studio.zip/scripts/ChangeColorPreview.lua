-- Only Change Color Cars owns these resources. No mission vehicle is spawned,
-- registered, driven, moved or painted by the preview.
JLRSColorPreview={}
local P=JLRSColorPreview
local C=JLRSColorCars
local directory=g_currentModDirectory
local function copy(t,seen)
    if type(t)~='table'then return t end
    seen=seen or {};if seen[t]then return seen[t]end
    local out={};seen[t]=out;for k,v in pairs(t)do out[k]=copy(v,seen)end;return out
end
local function exists(n)return n and n~=0 and entityExists(n)end
function P.clear(c,icons)
    local p=c.colorCarsPreview
    if p then
        if p.overlay and p.overlay~=0 then delete(p.overlay)end
        if exists(p.scene)then delete(p.scene)end
    end
    c.colorCarsPreview=nil;c.colorCarsPreviewAttempt=nil
    if icons then
        for _,id in pairs(c.colorCarsIcons or {})do if id and id~=0 then delete(id)end end
        c.colorCarsIcons={}
    end
end
function P.image(c,v,x,y,w,h,visible)
    local item=g_storeManager and g_storeManager:getItemByXMLFilename(v.configFileName or v.xmlFilename or '')
    local image=item and item.imageFilename
    if not image or image==''then JLRSMenu.text(x,y+h*.45,.009,'NO IMAGE',.65,.74,.83);return end
    visible[image]=true;c.colorCarsIcons=c.colorCarsIcons or {}
    local id=c.colorCarsIcons[image]
    if id==nil then local ok,result=pcall(createImageOverlay,image);id=ok and result or 0;c.colorCarsIcons[image]=id end
    if id and id~=0 then
        local aspect=g_screenAspectRatio or ((g_screenWidth or 1920)/(g_screenHeight or 1080))
        local width=math.min(w,h/aspect);local height=width*aspect
        setOverlayColor(id,1,1,1,1);renderOverlay(id,x+(w-width)*.5,y+(h-height)*.5,width,height)
    end
end
function P.trimIcons(c,visible)
    for image,id in pairs(c.colorCarsIcons or {})do if not visible[image]then if id and id~=0 then delete(id)end;c.colorCarsIcons[image]=nil end end
end
-- Parallel tree traversal maps XML node references to cloned nodes. Node values
-- are mapped explicitly, never by guessing integer IDs inside material tables.
local function mapTree(source,target,p)
    p.nodeMap[source]=target
    if RigidBodyType and getRigidBodyType and setRigidBodyType and getRigidBodyType(target)~=RigidBodyType.NONE then setRigidBodyType(target,RigidBodyType.NONE)end
    if getHasClassId and ClassIds and ClassIds.LIGHT_SOURCE and getHasClassId(target,ClassIds.LIGHT_SOURCE)then setVisibility(target,false)end
    local count=getNumOfChildren(source)
    if count~=getNumOfChildren(target)then error('Preview hierarchy mismatch')end
    for i=0,count-1 do mapTree(getChildAt(source,i),getChildAt(target,i),p)end
end
function P.build(c,v)
    P.clear(c,false);c.colorCarsPreviewAttempt=v
    if not (clone and loadI3DFile and createRenderOverlay and updateRenderOverlay and getNumOfChildren and getChildAt)then return nil end
    local p={nodeMap={},baseline={},materials={}}
    c.colorCarsPreview=p
    local ok=pcall(function()
        p.scene=loadI3DFile(directory..'assets/colorPreview.i3d')
        if not exists(p.scene)then error('Preview scene missing')end
        link(getRootNode(),p.scene);setTranslation(p.scene,0,-10000,0);setVisibility(p.scene,false)
        p.camera=getChildAt(p.scene,0)
        local components={};local root=v.components[1] and v.components[1].node or v.rootNode
        for i,component in ipairs(v.components or {})do
            local node=clone(component.node,false,false,false)
            if not exists(node)then error('Preview clone failed')end
            -- Link immediately: partial failure is reclaimed by P.clear.
            link(p.scene,node);components[i]={node=node};mapTree(component.node,node,p)
            local x,y,z=localToLocal(component.node,root,0,0,0)
            local dx,dy,dz=localDirectionToLocal(component.node,root,0,0,1)
            local ux,uy,uz=localDirectionToLocal(component.node,root,0,1,0)
            setTranslation(node,x,y,z);setDirection(node,dx,dy,dz,ux,uy,uz)
        end
        local mappings={};for name,node in pairs(v.i3dMappings or {})do if p.nodeMap[node]then mappings[name]=p.nodeMap[node]end end
        local object={components=components,i3dMappings=mappings,configFileName=v.configFileName,xmlFile=v.xmlFile,configurations=copy(v.configurations or {}),spec_baseMaterial=copy(v.spec_baseMaterial)}
        -- Use the native specialization methods, never mod wrappers bound to v.
        if BaseMaterial then
            object.applyBaseMaterialConfiguration=BaseMaterial.applyBaseMaterialConfiguration
            object.applyBaseMaterial=BaseMaterial.applyBaseMaterial
            object.setBaseMaterialColor=BaseMaterial.setBaseMaterialColor
        end
        p.object=object;p.baseSpec=copy(object.spec_baseMaterial)
        -- Snapshot clone shader overrides/material bindings for reversible swatch
        -- selection; only renderable clone shapes are addressed.
        for _,node in pairs(p.nodeMap)do
            if getHasClassId and ClassIds and getHasClassId(node,ClassIds.SHAPE)then
                local record={node=node,material=getMaterial(node,0),parameters={}}
                local names={colorScale=true}
                for _,material in ipairs((object.spec_baseMaterial or {}).baseMaterials or {})do
                    for _,parameter in ipairs(material.shaderParameters or {})do names[parameter.name]=true end
                end
                for name in pairs(names)do if getHasShaderParameter(node,name)then record.parameters[name]={getShaderParameter(node,name)}end end
                p.baseline[#p.baseline+1]=record
            end
        end
        local size=v.size or {};local width=math.max(1,size.width or 2.5);local length=math.max(1,size.length or 6);local height=math.max(1,size.height or 3)
        local aspect=.281*(g_screenAspectRatio or 16/9)/.174
        local radius=math.sqrt(width*width+height*height+length*length)*.5
        local halfFov=math.min(math.rad(35)*.5,math.atan(math.tan(math.rad(35)*.5)*aspect))
        local distance=radius/math.sin(halfFov)*1.12
        p.centerY=height*.45;p.distance=distance;p.angle=math.rad(40)
        P.camera(p)
        local rw=512;local rh=math.max(128,math.floor(rw/aspect))
        p.overlay=createRenderOverlay(p.camera,aspect,rw,rh,true,255,67108864)
        if not p.overlay or p.overlay==0 then error('Preview render failed')end
        p.dirty=true;p.vehicle=v
    end)
    if not ok then P.clear(c,false);c.colorCarsPreviewAttempt=v;return nil end
    return p
end
function P.camera(p)
    local x,z=math.sin(p.angle)*p.distance,math.cos(p.angle)*p.distance
    local rise=p.distance*.22
    setTranslation(p.camera,x,p.centerY+rise,z)
    setRotation(p.camera,-math.atan(rise/p.distance),p.angle,0)
end
function P.choose(c,color)
    c.colorCarsChoice=color
    local p=c.colorCarsPreview;if p then p.dirty=true end
end
function P.paint(c,p)
    local object=p.object
    object.spec_baseMaterial=copy(p.baseSpec)
    for _,record in ipairs(p.baseline)do
        setMaterial(record.node,record.material,0)
        for name,value in pairs(record.parameters)do setShaderParameter(record.node,name,value[1],value[2],value[3],value[4],false)end
    end
    local group=(c.colorCarsGroups or {})[c.colorCarsGroup or 1];local choice=c.colorCarsChoice
    if group and choice then
        if group.material then
            if not object.applyBaseMaterialConfiguration or not object.spec_baseMaterial then error('Preview material unsupported')end
            if object:applyBaseMaterialConfiguration(object.xmlFile,group.name,choice.id)==false then error('Preview material rejected')end
            object:applyBaseMaterial()
        else ConfigurationUtil.setColor(object,object.xmlFile,group.name,choice.id)end
        if ConfigurationUtil.applyConfigMaterials then ConfigurationUtil.applyConfigMaterials(object,object.xmlFile,group.name,choice.id)end
    end
end
function P.draw(c,x,y,w,h,visible)
    local v=c.colorCarsTarget
    JLRSMenu.rect(c,x,y,w,h,.012,.019,.028)
    if not v or not JLRSRecorder.valid(v)then P.clear(c,false);return end
    local p=c.colorCarsPreview
    if p and p.vehicle~=v then P.clear(c,false);p=nil end
    if not p and c.colorCarsPreviewAttempt~=v then p=P.build(c,v)end
    if p then
        local key=tostring(c.colorCarsGroup)..':'..tostring(c.colorCarsChoice and c.colorCarsChoice.id)
        if p.key~=key then p.dirty=true end
        if p.dirty then
            local ok=pcall(function()
                P.paint(c,p);setVisibility(p.scene,true);updateRenderOverlay(p.overlay)
            end)
            setVisibility(p.scene,false)
            p.key=key;p.dirty=false;p.paintFailed=not ok
        end
        if not p.paintFailed then setOverlayColor(p.overlay,1,1,1,1);renderOverlay(p.overlay,x,y,w,h)
        else JLRSMenu.text(x+.012,y+h*.5,.010,'Preview warna tidak tersedia')end
    else
        P.image(c,v,x+.015,y+.02,w-.03,h-.04,visible)
        JLRSMenu.text(x+.01,y+.006,.009,'Preview 3D tidak tersedia',.65,.74,.83)
    end
end
local select=C.select
C.select=function(c,v,...)P.clear(c,false);return select(c,v,...)end
local apply=C.apply
C.apply=function(c,...)local result=apply(c,...);if result then P.clear(c,false)end;return result end
local close=C.close
C.close=function(c,...)P.clear(c,true);return close(c,...)end
local open=C.open
C.open=function(c,...)P.clear(c,true);return open(c,...)end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)P.clear(c,true);return deleteMap(c,...)end
