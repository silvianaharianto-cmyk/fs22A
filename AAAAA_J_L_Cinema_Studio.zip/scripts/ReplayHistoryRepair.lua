-- Repair a restored take whose logical vehicle survived but whose model/node
-- layout differs from the saved donor. Runs only on an explicit Replay click.
JLRSHistoryRepair={}
local R=JLRSHistoryRepair
function R.vehicle(c,clip)
 if not clip or not clip.restored or not clip.saved or JLRSFrames.count(clip.frames)<2 then return end
 local desc=clip.saved.vehicles[clip.saved.target or 1];if not desc or desc.id=='' then return end
 local found
 for _,v in pairs(c.mission.vehicles or {}) do
  if JLRSRecorder.valid(v) and v.jlrsPersistentId==desc.id then
   if found and found~=v then return end;found=v
  end
 end
 return found
end
function R.start(c,clip)
 local v=R.vehicle(c,clip);if not v then return false end
 if c.historyRepair then c:notify('History sedang dipulihkan; tunggu sampai selesai.');return true end
 if c.recording or c.changePending then c:notify('Stop Record / Change Cars sebelum memulihkan Replay.');return true end
 c:stop()
 local context={mission=c.mission,history={clip},changePending={helpers={},streams={},done=0}}
 local job={clip=clip,context=context,name=clip.name,undos={},stage='pemetaan kendaraan utama'}
 job.worker=coroutine.create(function()
  local plan=JLRSChange.plan(context,v,v,true)
  if #plan.clips~=1 then error('Rekaman sumber belum dapat dipetakan.') end
  local plans={plan};local seen={[v]=true}
  for _,g in ipairs(clip.saved.groups or {}) do
   if g.object.vehicle then
    local other,ambiguous
    for _,candidate in pairs(c.mission.vehicles or {}) do
     if JLRSRecorder.valid(candidate) and candidate.jlrsPersistentId==g.object.id then
      if other and other~=candidate then ambiguous=true end;other=candidate
     end
    end
    if other and not ambiguous and not seen[other] and other.configFileName~=g.object.config then
     job.stage='pemetaan world kendaraan '..tostring(g.object.id)
     seen[other]=true;plans[#plans+1]=JLRSChange.plan(context,other,other,true)
    end
   end
  end
  job.stage='penerapan metadata History'
  for _,p in ipairs(plans) do job.undos[#job.undos+1]=JLRSChange.applyPlan(context,p) end
  clip.name=job.name
  -- Rebuild the sparse world/cargo scene too; an unbound restored take did
  -- not have a live worldScene before the remap.
  job.stage='pencocokan node hasil pemulihan'
  clip.restored=true;clip.bound=false;JLRSPersist.bind(clip,true)
  if not JLRSHistory.valid(clip) then error('Node hasil pemulihan belum dapat dipasangkan.') end
  job.stage='penyimpanan History'
  if not JLRSPersist.safeSave(c) then error('History hasil pemulihan belum tersimpan.') end
  job.committed=true
 end)
 c.historyRepair=job;c:notify('MEMULIHKAN REPLAY | menyesuaikan rekaman tersimpan ke kendaraan saat ini...')
 return true
end
function R.tick(c)
 local job=c.historyRepair;if not job then return end
 local present=false;for _,clip in ipairs(c.history or {}) do if clip==job.clip then present=true;break end end
 if job.cancelled or not present then
  if not job.committed then for i=#job.undos,1,-1 do JLRSChange.rollback(job.context,job.undos[i]) end end
  JLRSChange.clean(job.context,job.context.changePending);c.historyRepair=nil;return
 end
 local ok,err=coroutine.resume(job.worker)
 if not ok then
  for i=#job.undos,1,-1 do JLRSChange.rollback(job.context,job.undos[i]) end
  JLRSChange.clean(job.context,job.context.changePending);c.historyRepair=nil
  -- "gagal" is intentionally included: notify filters routine HUD messages.
  c:notify('Pemulihan Replay gagal | History #'..tostring(job.clip.id)..' | tahap='..tostring(job.stage)..' | '..tostring(err)..' | Rekaman asli dipertahankan.');return
 end
 if coroutine.status(job.worker)=='dead' then
  JLRSChange.clean(job.context,job.context.changePending);c.historyRepair=nil
  if job.continue then job.continue() else JLRSHistory.replay(c,job.clip) end
 end
end
local replay=JLRSHistory.replay
JLRSHistory.replay=function(c,clip,...)
 JLRSPersist.bind(clip,true)
 if not JLRSHistory.valid(clip) and R.start(c,clip) then return end
 return replay(c,clip,...)
end
local all=JLRSGroup.all
JLRSGroup.all=function(c,selection,...)
 for _,clip in ipairs(c.history or {}) do
  if (not selection or selection[clip.id]) and not JLRSHistory.valid(clip) and R.vehicle(c,clip) then
   if R.start(c,clip) then
    if c.historyRepair and c.historyRepair.clip==clip then
     local marked;if selection then marked={};for key,value in pairs(selection) do marked[key]=value end end
     c.historyRepair.continue=function()JLRSGroup.all(c,marked)end
    end
    return
   end
  end
 end
 return all(c,selection,...)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)local result=draw(c,...);R.tick(c);return result end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)if c.historyRepair then c.historyRepair.cancelled=true end;return stop(c,...)end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)if c.historyRepair then c:notify('Tunggu pemulihan Replay selesai.');return end;return start(c,...)end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
 if c.historyRepair then c.historyRepair.cancelled=true;R.tick(c) end
 return unload(c,...)
end
