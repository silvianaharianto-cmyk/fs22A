-- Replay-only callback gate. Native events stay registered/active: no input
-- context replacement, no binding file edits, and no mouse-axis rebuild.
JLRSInputGuard={wrapped=setmetatable({},{__mode='k'})}
function JLRSInputGuard.isLocked()
    local c=JLReplayStudio
    return c~=nil and c.mission~=nil and c.replaying==true
end
function JLRSInputGuard.isOwn(target,action)
    if target==JLReplayStudio or (type(target)=='table' and target.controller==JLReplayStudio) then return true end
    return type(action)=='string' and action:sub(1,5)=='JLRS_'
end
function JLRSInputGuard.wrap(callback)
    if type(callback)~='function' or JLRSInputGuard.wrapped[callback] then return callback end
    local wrapped=function(target,action,value,state,isAnalog,isMouse,...)
        if JLRSInputGuard.isLocked() and not isMouse and not JLRSInputGuard.isOwn(target,action) then
            return
        end
        return callback(target,action,value,state,isAnalog,isMouse,...)
    end
    JLRSInputGuard.wrapped[wrapped]=callback
    return wrapped
end
function JLRSInputGuard.existing(binding)
    local count=0
    for _,event in pairs(binding.events or {}) do
        if type(event)=='table' then
            for _,key in ipairs({'callback','eventCallback'}) do
                local old=event[key]
                if type(old)=='function' and not JLRSInputGuard.wrapped[old] then
                    event[key]=JLRSInputGuard.wrap(old);count=count+1
                end
            end
        end
    end
    return count
end
function JLRSInputGuard.installRegistration()
    if JLRSInputGuard.registrationOwner then return end
    local owner=InputBinding
    if not owner or type(owner.registerActionEvent)~='function' then owner=g_inputBinding end
    if not owner or type(owner.registerActionEvent)~='function' then return end
    local old=owner.registerActionEvent
    local wrapper=function(binding,action,target,callback,...)
        return old(binding,action,target,JLRSInputGuard.wrap(callback),...)
    end
    JLRSInputGuard.registrationOwner=owner
    JLRSInputGuard.oldRegistration=old;JLRSInputGuard.registrationWrapper=wrapper
    owner.registerActionEvent=wrapper
end
-- Install before the vehicle/player/mission register their input callbacks.
JLRSInputGuard.installRegistration()
local oldLoad=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    oldLoad(c,...)
    if not c.mission then return end
    JLRSInputGuard.installRegistration()
    local count=g_inputBinding and JLRSInputGuard.existing(g_inputBinding) or 0
    c.guardOldKey=c.mission.keyEvent
    c.guardKeyWrapper=function(mission,unicode,sym,modifier,isDown,...)
        -- Camera movement, Alt/Shift and mod hotkeys are read through the
        -- unchanged raw polling path. Do not forward them to native gameplay.
        if JLRSInputGuard.isLocked() then return end
        if c.guardOldKey then return c.guardOldKey(mission,unicode,sym,modifier,isDown,...) end
    end
    c.mission.keyEvent=c.guardKeyWrapper
end
local oldStart=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if g_inputBinding then JLRSInputGuard.existing(g_inputBinding) end
    return oldStart(c,...)
end
local oldDelete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.mission and c.mission.keyEvent==c.guardKeyWrapper then c.mission.keyEvent=c.guardOldKey end
    oldDelete(c,...)
    if g_inputBinding then
        for _,event in pairs(g_inputBinding.events or {}) do
            if type(event)=='table' then
                for _,key in ipairs({'callback','eventCallback'}) do
                    local original=JLRSInputGuard.wrapped[event[key]]
                    if original then event[key]=original end
                end
            end
        end
    end
    local owner=JLRSInputGuard.registrationOwner
    if owner and owner.registerActionEvent==JLRSInputGuard.registrationWrapper then
        owner.registerActionEvent=JLRSInputGuard.oldRegistration
    end
    JLRSInputGuard.registrationOwner=nil
    c.guardOldKey=nil;c.guardKeyWrapper=nil
end
