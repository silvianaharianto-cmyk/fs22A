-- Separate canonical T shots. Never write a T pose into R's angle memory.
JLRSFixedAngles={interval=5,shots={
    {'Samping Kanan',-1,0,0},{'Samping Kiri',1,0,0},
    {'Belakang Kanan',-.70710678,0,-.70710678},{'Belakang Kiri',.70710678,0,-.70710678},
    {'Depan',0,0,1},{'Depan Kanan',-.70710678,0,.70710678},
    {'Depan Kiri',.70710678,0,.70710678},{'Atas',0,1,.03},{'Belakang Rendah',0,0,-1}}}
local F=JLRSFixedAngles
local fields={'angleEnabled','angleIndex','lock','distance','height','x','y','z','yaw','pitch',
    'fov','motionFov','baseFov','phase','fixedX','fixedY','fixedZ','anchorX','anchorY','anchorZ',
    'anchorYaw','anchorPitch','panYaw','manualX','manualY','manualZ','offsetYaw','offsetPitch',
    'trackingHeading','levelHeading','angleStable','angleMoveGoal','renderAim'}
local function target(c)return JLRSAngle.target(c)end
local function held(name)return Input[name]and Input.isKeyPressed(Input[name])or false end
local function distance(c)
    local v=target(c);local size=v.size or {}
    return math.max(12,(tonumber(size.length or v.sizeLength)or 0)*.75,
        (tonumber(size.width or v.sizeWidth)or 0)*1.5)
end
function F.available(c)
    return not c.finalPlaying and not c.objectRunning and not c.menu
        and not (g_gui and g_gui:getIsGuiVisible())
        and not (JLRSMouse and JLRSMouse.hudOwns and JLRSMouse.hudOwns(c))
        and JLRSRecorder.valid(target(c))
end
function F.begin(c)
    if c.fixedAngleActive then return true end
    if not F.available(c)or not JLRSAngle.ensureCamera(c)then return false end
    JLRSAngle.save(c)
    local before={};for _,name in ipairs(fields)do before[name]=c[name]end
    c.fixedAngleBefore=before;c.fixedAngleDistance=distance(c)
    c.fixedAngleActive=true;c.angleEnabled=true
    return true
end
function F.leave(c)
    if not c.fixedAngleActive then c.fixedAngleAuto=false;return end
    local before=c.fixedAngleBefore or {}
    c.fixedAngleActive=false;c.fixedAngleAuto=false;c.fixedAngleElapsed=0;c.fixedAngleLastTime=nil
    for _,name in ipairs(fields)do c[name]=before[name]end
    c.fixedAngleBefore=nil;c.fixedAngleDistance=nil
    JLRSCamera.clearInput(c)
end
function F.vector(c,distance,height,phase,heading)
    local shot=F.shots[c.fixedAngleIndex or 1]
    local x,y,z=shot[2]*distance,shot[3]*distance+height,shot[4]*distance
    if (c.fixedAngleIndex or 1)==9 then y=y-.45 end
    if phase then
        local a,b=x,z;x=a*math.cos(phase)+b*math.sin(phase);z=b*math.cos(phase)-a*math.sin(phase)
    end
    if heading then return math.cos(heading)*x+math.sin(heading)*z,y,-math.sin(heading)*x+math.cos(heading)*z end
    return JLRSCamera.levelOffset(c,x,y,z)
end
function F.next(c)
    if not F.begin(c)then return false end
    c.fixedAngleDistance=distance(c)
    c.fixedAngleIndex=(c.fixedAngleIndex or 0)%#F.shots+1
    c.fixedAngleElapsed=0
    -- Canonical entry every time: no saved manual offsets or movement phase.
    -- Preserve the existing zoom goal/velocity across the instantaneous cut.
    local input=c.cameraInput;local zoom=input and input.zoom;local velocity=input and input.zoomVelocity
    c.distance=c.fixedAngleDistance;c.height=0;c.lock=true;c.angleEnabled=true
    JLRSCamera.choose(c,c.mode)
    if c.mode==10 then
        -- Start Crane at its lowest point, on the requested level shot.
        c.phase=-math.pi/2;JLRSCameraCuts.resolve(c)
    end
    if zoom and (zoom~=0 or (velocity or 0)~=0)then
        c.cameraInput={x=0,y=0,zoom=zoom,zoomVelocity=velocity or 0}
    end
    c:notify('Angle T: '..F.shots[c.fixedAngleIndex][1]..(c.fixedAngleAuto and
        string.format(' | AUTO %.0fs',c.fixedAngleInterval or F.interval)or ' | MANUAL'))
    return true
end
function F.press(c,automatic)
    if not F.available(c)then return end
    if automatic then
        if not F.begin(c)then return end
        c.fixedAngleAuto=true;F.next(c)
    elseif c.fixedAngleActive and c.fixedAngleAuto then
        c.fixedAngleAuto=false;c.fixedAngleElapsed=0
        c:notify('Angle T MANUAL | T = angle berikutnya')
    else F.next(c)end
end
local saved=JLRSAngle.saved
JLRSAngle.saved=function(c,...)
    if c.fixedAngleActive then return nil end
    return saved(c,...)
end
local save=JLRSAngle.save
JLRSAngle.save=function(c,...)
    if c.fixedAngleActive then return end
    return save(c,...)
end
local vector=JLRSAngle.vector
JLRSAngle.vector=function(c,...)
    if c.fixedAngleActive then return F.vector(c,...)end
    return vector(c,...)
end
local tracking=JLRSCamera.trackingOffset
JLRSCamera.trackingOffset=function(c,dt)
    if not c.fixedAngleActive then return tracking(c,dt)end
    local v=target(c);local fx,_,fz=localDirectionToWorld(v.rootNode,0,0,1)
    local heading=math.atan2(fx,fz);local state=c.trackingHeading
    if not state or state.target~=v or c.angleCutPending then state={target=v,yaw=heading};c.trackingHeading=state
    else state.yaw=JLRSRecorder.angle(state.yaw,heading,1-math.exp(-math.max(0,dt)/.035))end
    return F.vector(c,c.distance,c.height,nil,state.yaw)
end
local random=JLRSAngle.random
JLRSAngle.random=function(c,...)
    if c.fixedAngleActive then
        F.leave(c);c.angleEnabled=true
        -- Restore R's actual saved pose before its native outgoing save.
        JLRSAngle.place(c)
    end
    return random(c,...)
end
local toggle=JLRSAngle.toggle
JLRSAngle.toggle=function(c,...)
    if c.fixedAngleActive then F.leave(c);c.angleEnabled=true;JLRSAngle.place(c)end
    return toggle(c,...)
end
local deactivate=JLRSCamera.deactivate
JLRSCamera.deactivate=function(c,...)
    F.leave(c);return deactivate(c,...)
end
if JLRSReset and JLRSReset.angle then
    local reset=JLRSReset.angle
    JLRSReset.angle=function(c,...)
        F.leave(c);return reset(c,...)
    end
end
function F.poll(c)
    local down=held('KEY_t');local edge=down and not c.fixedAngleHeld;c.fixedAngleHeld=down
    if edge then F.press(c,held('KEY_lctrl')or held('KEY_rctrl'))end
    local now=g_time or 0;local previous=c.fixedAngleLastTime;c.fixedAngleLastTime=now
    if not c.fixedAngleActive or not c.active or not c.fixedAngleAuto or not F.available(c)
        or c.paused or c.livePaused or (c.mission and c.mission.isPaused)then return end
    local dt=previous and math.max(0,math.min(.25,(now-previous)/1000))or 0
    c.fixedAngleElapsed=(c.fixedAngleElapsed or 0)+dt
    if c.fixedAngleElapsed+1e-8>=math.max(1,c.fixedAngleInterval or F.interval)then F.next(c)end
end
local apply=JLRSMenu.applyShot
JLRSMenu.applyShot=function(c,...)
    local result=apply(c,...)
    c.fixedAngleElapsed=0;c.fixedAngleLastTime=g_time or 0
    return result
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    if not c.jlrsRenderBoundary then F.poll(c)end
    return draw(c,...)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...)
    c.fixedAngleActive=false;c.fixedAngleAuto=false;c.fixedAngleHeld=false;c.fixedAngleIndex=nil
    c.fixedAngleBefore=nil;c.fixedAngleElapsed=0;c.fixedAngleLastTime=nil
    c.fixedAngleInterval=F.interval
    return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    F.leave(c);return unload(c,...)
end
