-- Add requested top-row shortcuts around the stable V1.4 implementation.
JLRSShortcuts={}
function JLRSShortcuts.context(c)
    return c.mission~=nil and not (g_gui and g_gui:getIsGuiVisible())
        and (c.replaying or c.recording or c.menu or c.miniHudEnabled
            or JLRSRecorder.valid(g_currentMission.controlledVehicle) or JLRSFrames.count(c.frames)>1)
end
function JLRSShortcuts.codes()
    return {replay=Input.KEY_2,
        stopRecord=Input.KEY_esc or Input.KEY_escape,
        pause=Input.KEY_space,hud=Input.KEY_0}
end
function JLRSShortcuts.reserved(c)
    if not c or not c.shortcutKeys then return false end
    if c.mission and not (g_gui and g_gui:getIsGuiVisible()) and Input.KEY_0
        and (Input.isKeyPressed(Input.KEY_0) or c.shortcutKeys.hud) then return true end
    if not JLRSShortcuts.context(c) then return false end
    for name,code in pairs(JLRSShortcuts.codes()) do
        local enabled=name=='replay' or name=='hud'
            or (name=='pause' and c.replaying) or (name=='stopRecord' and (c.recording or c.shortcutKeys.stopRecord))
        if enabled and (Input.isKeyPressed(code) or c.shortcutKeys[name]) then return true end
    end
    return false
end
local oldLock=JLRSInputGuard.isLocked
JLRSInputGuard.isLocked=function()
    return oldLock() or JLRSShortcuts.reserved(JLReplayStudio)
end
local oldLoad=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    oldLoad(c,...)
    if not c.mission then return end
    c.shortcutKeys={};c.shortcutHudHidden=false
    local hud=c.mission.hud
    if hud and type(hud.draw)=='function' then
        c.shortcutGameHud=hud;c.shortcutOldHudDraw=hud.draw
        c.shortcutHudWrapper=function(self,...)
            if c.replaying and c.shortcutHudHidden then return end
            return c.shortcutOldHudDraw(self,...)
        end
        hud.draw=c.shortcutHudWrapper
    end
    c:notify('V1.6 | Record via HUD | 2 Replay | Esc Stop Record | Space Pause | 0 HUD')
end
function JLRSShortcuts.toggleHud(c)
    -- The first press shows a disabled Mini HUD. Thereafter 0 alternates
    -- showing/hiding Mini HUD, mod status HUD and native gameplay HUD.
    local show=not c.miniHudEnabled or c.shortcutHudHidden
    c.miniHudEnabled=show;c.shortcutHudHidden=not show;c.miniHudHits={}
    c:notify(show and 'HUD + Mini HUD : SHOW' or 'HUD + Mini HUD : HIDE')
end
-- HUD visibility is available even on foot with no recordings and no visible HUD.
-- Shared edge state prevents update + draw from toggling twice on one press.
function JLRSShortcuts.pollHud(c)
    c.shortcutKeys=c.shortcutKeys or {}
    local code=Input.KEY_0
    local down=code and Input.isKeyPressed(code) or false
    local allowed=c.mission~=nil and not (g_gui and g_gui:getIsGuiVisible())
    if allowed and down and not c.shortcutKeys.hud then JLRSShortcuts.toggleHud(c) end
    c.shortcutKeys.hud=down
end
local oldUpdate=JLReplayStudio.update
JLReplayStudio.update=function(c,dt,...)
    JLRSShortcuts.pollHud(c)
    return oldUpdate(c,dt,...)
end
local oldPoll=JLReplayStudio.poll
JLReplayStudio.poll=function(c,...)
    c.shortcutKeys=c.shortcutKeys or {}
    local context=JLRSShortcuts.context(c)
    local press={}
    JLRSShortcuts.pollHud(c)
    for name,code in pairs(JLRSShortcuts.codes()) do
        local down=code and Input.isKeyPressed(code) or false
        press[name]=name~='hud' and context and down and not c.shortcutKeys[name]
        if name~='hud' then c.shortcutKeys[name]=down end
    end
    -- Record state is captured before actions; Escape stops only recording.
    local wasRecording=c.recording
    if press.stopRecord and wasRecording then JLRSStopLoading.request(c,false) end
    if press.replay then JLRSRecorder.startReplay(c) end
    if press.pause then c:togglePause() end
    -- Keep all legacy shortcuts. Escape's old menu-close behavior must not
    -- execute when this same press has been used to stop recording.
    if press.stopRecord and wasRecording then
        local code=Input.KEY_escape
        if code then c.keyState.KEY_escape=true end
    end
    return oldPoll(c,...)
end
local oldMenuDraw=JLRSMenu.draw
JLRSMenu.draw=function(c,...)
    if c.shortcutHudHidden and not c.menu then return end
    return oldMenuDraw(c,...)
end
local oldMiniDraw=JLRSMiniHud.draw
JLRSMiniHud.draw=function(c,...)
    if c.shortcutHudHidden then c.miniHudHits={};return end
    return oldMiniDraw(c,...)
end
local oldToggleMini=JLRSMiniHud.toggle
JLRSMiniHud.toggle=function(c,...)
    c.shortcutHudHidden=false
    return oldToggleMini(c,...)
end
local oldStop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    local results={oldStop(c,...)}
    c.shortcutHudHidden=false
    return unpack(results)
end
local oldDelete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.shortcutGameHud and c.shortcutGameHud.draw==c.shortcutHudWrapper then
        c.shortcutGameHud.draw=c.shortcutOldHudDraw
    end
    oldDelete(c,...)
    c.shortcutGameHud=nil;c.shortcutOldHudDraw=nil;c.shortcutHudWrapper=nil
    c.shortcutKeys=nil;c.shortcutHudHidden=false
end
