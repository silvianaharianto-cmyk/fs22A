-- Timestamped pose replay. V1.1: synchronize component poses and temporarily
-- hand dynamic bodies to kinematic playback; wheel shapes are never recreated.
JLRSRecorder={STEP=1/60}
function JLRSRecorder.valid(v)
    return v~=nil and v.rootNode~=nil and entityExists(v.rootNode)
end
function JLRSRecorder.angle(a,b,t)
    return a+((b-a+math.pi)%(2*math.pi)-math.pi)*t
end
function JLRSRecorder.blend(a,b,t)
    local out={}
    for i=1,#a do
        if a[i]==b[i] then out[i]=a[i]
        elseif (i-1)%6<3 then out[i]=a[i]+(b[i]-a[i])*t
        else out[i]=JLRSRecorder.angle(a[i],b[i],t) end
    end
    return out
end
function JLRSRecorder.topology(v)
    local entries,seen,vehicles={},{},{}
    local function add(node,world,vehicle,componentIndex)
        if node~=nil and node~=0 and entityExists(node) and not seen[node] then
            seen[node]=true; entries[#entries+1]={node=node,world=world,parent=getParent(node),vehicle=vehicle,componentIndex=componentIndex}
        end
    end
    local visited={}
    local function visit(vehicle)
        if visited[vehicle] then return end
        visited[vehicle]=true;vehicles[#vehicles+1]=vehicle
        for index,component in ipairs(vehicle.components or {}) do add(component.node,true,vehicle,index) end
        add(vehicle.rootNode,true)
        local wheels=vehicle.spec_wheels and vehicle.spec_wheels.wheels or {}
        local function wheelNodes(wheel)
            add(wheel.repr,false);add(wheel.driveNode,false)
            for _,child in ipairs(wheel.additionalWheels or {}) do wheelNodes(child) end
        end
        for _,wheel in ipairs(wheels) do wheelNodes(wheel) end
        if vehicle.getAttachedImplements~=nil then
            for _,implement in ipairs(vehicle:getAttachedImplements()) do
                if implement.object~=nil then visit(implement.object) end
            end
        end
    end
    visit(v)
    return entries,vehicles
end
function JLRSRecorder.capture(entries)
    local pose={}
    for _,entry in ipairs(entries) do
        if not entityExists(entry.node) or getParent(entry.node)~=entry.parent then return nil end
        local x,y,z,rx,ry,rz
        if entry.world then
            x,y,z=getWorldTranslation(entry.node);rx,ry,rz=getWorldRotation(entry.node)
        else x,y,z=getTranslation(entry.node);rx,ry,rz=getRotation(entry.node) end
        pose[#pose+1]=x;pose[#pose+1]=y;pose[#pose+1]=z
        pose[#pose+1]=rx;pose[#pose+1]=ry;pose[#pose+1]=rz
    end
    return pose
end
function JLRSRecorder.apply(entries,pose,allowMissing,isolatedScene)
    -- Validate the whole topology first, so a bad wheel cannot leave a body
    -- halfway through a pose. Cleanup may still restore surviving nodes.
    if not allowMissing then
        for _,entry in ipairs(entries) do
            if not entityExists(entry.node) or getParent(entry.node)~=entry.parent then return false end
        end
    end
    for i,entry in ipairs(entries) do
        if entityExists(entry.node) and getParent(entry.node)==entry.parent then
            local n=(i-1)*6
            if entry.world then
                local guard=JLRSReplayWriteGuard
                if not (guard and guard.skip(entry,pose,n)) then
                local owner=entry.vehicle
                local index=entry.componentIndex
                local component=owner and index and owner.components and owner.components[index]
                local isolated=isolatedScene or (guard and guard.track and guard.track.livePhysics and not guard.track.collisionReplay)
                if isolated then
                    -- Same authoritative pose writer as Cinema New. Do not run
                    -- a second vehicle positioning controller on detached bodies.
                    setWorldTranslation(entry.node,pose[n+1],pose[n+2],pose[n+3])
                    setWorldRotation(entry.node,pose[n+4],pose[n+5],pose[n+6])
                    local interp=component and component.networkInterpolators
                    if interp and interp.position and interp.position.setPosition then interp.position:setPosition(pose[n+1],pose[n+2],pose[n+3])end
                    if interp and interp.quaternion and interp.quaternion.setQuaternion and mathEulerToQuaternion then
                        interp.quaternion:setQuaternion(mathEulerToQuaternion(pose[n+4],pose[n+5],pose[n+6]))
                    end
                elseif component and component.node==entry.node and type(owner.setWorldPosition)=='function' then
                    -- The native setter also resets the component position and
                    -- quaternion interpolators. Direct node writes did not.
                    local interp=component.networkInterpolators
                    local sync=interp~=nil and interp.position~=nil and interp.quaternion~=nil
                    owner:setWorldPosition(pose[n+1],pose[n+2],pose[n+3],
                        pose[n+4],pose[n+5],pose[n+6],index,sync)
                else
                    setWorldTranslation(entry.node,pose[n+1],pose[n+2],pose[n+3])
                    setWorldRotation(entry.node,pose[n+4],pose[n+5],pose[n+6])
                end
                if guard then guard.remember(entry,pose,n)end
                end
            else
                -- Preserve the confirmed local-space wheel/suspension replay.
                if JLRSFinalReplayPerf and JLRSFinalReplayPerf.localTranslation then JLRSFinalReplayPerf.localTranslation(entry.node,pose[n+1],pose[n+2],pose[n+3]) else setTranslation(entry.node,pose[n+1],pose[n+2],pose[n+3]) end
                if JLRSFinalReplayPerf and JLRSFinalReplayPerf.localRotation then JLRSFinalReplayPerf.localRotation(entry.node,pose[n+4],pose[n+5],pose[n+6]) else setRotation(entry.node,pose[n+4],pose[n+5],pose[n+6]) end
            end
        end
    end
    return true
end
function JLRSRecorder.unlockBodies(c)
    for _,state in ipairs(c.bodyStates or {}) do
        if state.changed and entityExists(state.node) then
            local ok,err=pcall(setRigidBodyType,state.node,state.bodyType)
            if not ok then print('[J_L Cinema Studio] BODY RESTORE ERROR: '..tostring(err)) end
        end
        if state.component then
            state.component.isDynamic=state.isDynamic
            state.component.isKinematic=state.isKinematic
        end
    end
    c.bodyStates=nil
end
function JLRSRecorder.lockBodies(c)
    if c.bodyStates~=nil then return true end
    if type(getRigidBodyType)~='function' or type(setRigidBodyType)~='function' or RigidBodyType==nil then
        c:notify('Replay tidak dimulai: API rigid body tidak tersedia.');return false
    end
    c.bodyStates={}
    local ok,err=pcall(function()
        for _,entry in ipairs(c.entries) do
            if entry.world then
                if not entityExists(entry.node) then error('component node missing') end
                local component=entry.vehicle and entry.componentIndex and entry.vehicle.components[entry.componentIndex]
                local state={node=entry.node,bodyType=getRigidBodyType(entry.node),component=component}
                if component then state.isDynamic=component.isDynamic;state.isKinematic=component.isKinematic end
                c.bodyStates[#c.bodyStates+1]=state
                if state.bodyType==RigidBodyType.DYNAMIC then
                    state.changed=true
                    setRigidBodyType(entry.node,RigidBodyType.KINEMATIC)
                    if component then component.isDynamic=false;component.isKinematic=true end
                end
            end
        end
    end)
    if not ok then
        JLRSRecorder.unlockBodies(c)
        c:notify('Replay batal: kontrol badan kendaraan gagal. '..tostring(err));return false
    end
    return true
end
function JLRSRecorder.start(c)
    if c.replaying then JLRSRecorder.stopReplay(c) end
    local v=g_currentMission.controlledVehicle
    if not JLRSRecorder.valid(v) then c:notify('Masuk kendaraan dahulu.');return end
    c.target=v;c.entries,c.recordVehicles=JLRSRecorder.topology(v)
    c.frames=JLRSFrames.new(#c.entries*6+3);c.recordTime=0;c.duration=0;c.nextSample=JLRSRecorder.STEP
    c.previousPose=JLRSRecorder.capture(c.entries);c.previousTime=0
    if c.previousPose==nil then c:notify('Node kendaraan tidak tersedia.');return end
    JLRSFrames.push(c.frames,{t=0,pose=c.previousPose});c.recording=true;c.recordStartPose=c.previousPose;c.recordTravel=0;c.cacheFault=nil
    c:notify('RECORD aktif | kendaraan + komponen + roda')
end
function JLRSRecorder.recordTick(c,dt)
    if not c.recording then return end
    -- Standard recording retains its fixed vehicle topology when the player
    -- switches/exits vehicles. Only explicit Stop or existing error handling
    -- ends the take; no rescan or extra vehicle channels are added here.
    if dt<=0 then return end
    -- Cinema New: the real clock advances every update, but native capture is
    -- performed once per sample interval. Never generate catch-up pose bursts.
    local now=c.recordTime+dt
    c.recordTime=now
    if now+0.000000001<c.nextSample then return end
    local current=JLRSRecorder.capture(c.entries)
    if current==nil then JLRSRecorder.stopRecord(c);c:notify('Record berhenti: node kendaraan berubah.');return end
    local initial=c.recordStartPose or current
    c.recordTravel=math.max(c.recordTravel or 0,math.sqrt((current[1]-initial[1])^2+(current[2]-initial[2])^2+(current[3]-initial[3])^2))
    if now<=c.previousTime then return end
    JLRSFrames.push(c.frames,{t=now,pose=current})
    c.nextSample=c.nextSample+JLRSRecorder.STEP
    if c.nextSample<=now then c.nextSample=now+JLRSRecorder.STEP end
    c.previousTime=now;c.previousPose=current
end
function JLRSRecorder.stopRecord(c)
    if not c.recording then return end
    -- Finish with the actual end pose even when Stop falls between samples.
    if c.recordTime>(c.previousTime or 0) then
        local current=JLRSRecorder.capture(c.entries)
        if current then c.previousPose=current;c.previousTime=c.recordTime end
    end
    c.recording=false
    if c.previousPose~=nil and c.recordTime>JLRSFrames.get(c.frames,JLRSFrames.count(c.frames)).t+0.0001 then
        JLRSFrames.push(c.frames,{t=c.recordTime,pose=c.previousPose})
    end
    c.duration=JLRSFrames.get(c.frames,JLRSFrames.count(c.frames)).t;c.replayTime=0
    c:notify(string.format('Record selesai | %.2f detik | %d frames',c.duration,JLRSFrames.count(c.frames)))
end
function JLRSRecorder.startReplay(c)
    if c.recording then JLRSRecorder.stopRecord(c) end
    if JLRSFrames.count(c.frames)<2 or not JLRSRecorder.valid(c.target) then c:notify('Belum ada rekaman yang dapat di-replay.');return end
    if not c.replaying then
        c.returnPose=JLRSRecorder.capture(c.entries)
        if c.returnPose==nil then c:notify('Kendaraan berubah. Buat rekaman baru.');return end
    end
    if not JLRSRecorder.lockBodies(c) then c.returnPose=nil;return end
    c.replaying=true;c.paused=false;c.replayTime=0;c.frameIndex=1;c.lastBodyLog=-1
    JLRSRecorder.apply(c.entries,JLRSFrames.get(c.frames,1).pose)
    JLRSCamera.activate(c);JLRSCamera.choose(c,c.mode)
    c:notify('REPLAY aktif | dunia dijeda | mouse kamera tetap aktif')
end
function JLRSRecorder.sample(c,time)
    local i=c.frameIndex or 1
    local count=JLRSFrames.count(c.frames)
    -- Final often samples an immutable key interval more than once for motion,
    -- sound and sparse world objects. Reuse keys, never a mutable output pose.
    local final=JLReplayStudio and JLReplayStudio.finalPlaying
    local interval=final and c.jlrsFinalInterval
    if interval and interval.frames==c.frames and interval.count==count
        and time>=interval.a.t and time<=interval.b.t then
        c.frameIndex=interval.index
        local span=interval.b.t-interval.a.t
        local alpha=span>0 and math.max(0,math.min(1,(time-interval.a.t)/span))or 0
        return JLRSRecorder.blend(interval.a.pose,interval.b.pose,alpha)
    end
    i=math.max(1,math.min(i,count))
    -- Sequential playback reads nearby frames; use binary search only for seeks.
    -- Physics look-behind and audio sampling revisit nearby earlier frames.
    -- Walk locally in both directions before doing a disk-spanning binary seek.
    local backwards=0
    while i>1 and backwards<8 and JLRSFrames.get(c.frames,i).t>time do i=i-1;backwards=backwards+1 end
    local advanced=0
    while i<count and advanced<8 and JLRSFrames.get(c.frames,i+1).t<time do i=i+1;advanced=advanced+1 end
    if not (JLRSFrames.get(c.frames,i).t<=time and (i==count or JLRSFrames.get(c.frames,i+1).t>=time)) then
        local low,high=1,count
        while low<=high do
            local mid=math.floor((low+high)/2)
            if JLRSFrames.get(c.frames,mid).t<=time then i=mid;low=mid+1 else high=mid-1 end
        end
    end
    c.frameIndex=i
    local a,b=JLRSFrames.get(c.frames,i),JLRSFrames.get(c.frames,math.min(i+1,JLRSFrames.count(c.frames)))
    if final then c.jlrsFinalInterval={frames=c.frames,count=count,index=i,a=a,b=b}
    else c.jlrsFinalInterval=nil end
    local alpha=b.t>a.t and math.max(0,math.min(1,(time-a.t)/(b.t-a.t))) or 0
    return JLRSRecorder.blend(a.pose,b.pose,alpha)
end
function JLRSRecorder.replayTick(c,dt)
    if not c.replaying then return end
    if not JLRSRecorder.valid(c.target) then JLRSRecorder.stopReplay(c);c:notify('Replay berhenti: kendaraan tidak tersedia.');return end
    if not c.paused then
        c.replayTime=c.replayTime+dt*c.replaySpeed
        if c.replayTime>=c.duration then
            if c.loop and c.duration>0 then c.replayTime=c.replayTime%c.duration
            else c.replayTime=c.duration;c.paused=true;c:notify('Replay selesai | Replay untuk ulang, Stop untuk normal.') end
        end
    end
    local pose=JLRSRecorder.sample(c,c.replayTime)
    c.replayAudioPose=pose;c.replayAudioTime=c.replayTime
    if not JLRSRecorder.apply(c.entries,pose) then
        JLRSRecorder.stopReplay(c);c:notify('Replay berhenti: node berubah.');return
    end

end
function JLRSRecorder.seek(c,time)
    if not c.replaying then return end
    c.jlrsFinalInterval=nil
    c.replayTime=math.max(0,math.min(c.duration,time))
    JLRSRecorder.replayTick(c,0)
end
function JLRSRecorder.stopReplay(c)
    c.jlrsFinalInterval=nil
    if not c.replaying then return end
    -- Restore pose and interpolation before releasing kinematic control.
    if c.returnPose~=nil then JLRSRecorder.apply(c.entries,c.returnPose,true) end
    JLRSRecorder.unlockBodies(c)
    if c.returnPose~=nil then JLRSRecorder.apply(c.entries,c.returnPose,true) end
    c.replaying=false;c.paused=false;c.returnPose=nil
    JLRSCamera.deactivate(c)
    c:notify('STOP | kendaraan dan kamera kembali normal')
end
