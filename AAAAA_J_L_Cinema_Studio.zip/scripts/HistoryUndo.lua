-- Session edit history holds existing stream references, never copies frame samples.
local F,H=JLRSHistoryGroups,JLRSHistory
local function copy(t)local out={};for k,v in pairs(t or {})do out[k]=v end;return out end
local function snapshot(c)
 local s={history=copy(c.history),names={},groups={},members=copy(c.historyMembership),collapsed=copy(c.historyCollapsed),marked=copy(c.historyMarked),groupMarked=copy(c.historyGroupMarked),next=c.historyGroupNext}
 for _,clip in ipairs(c.history or {})do s.names[clip]=clip.name end
 for i,g in ipairs(c.historyGroups or {})do s.groups[i]={id=g.id,name=g.name}end
 return s
end
local function apply(c,s)
 c.history=copy(s.history);c.historyGroups={};for i,g in ipairs(s.groups)do c.historyGroups[i]={id=g.id,name=g.name}end
 for clip,name in pairs(s.names)do clip.name=name end
 c.historyMembership=copy(s.members);c.historyCollapsed=copy(s.collapsed);c.historyMarked=copy(s.marked);c.historyGroupMarked=copy(s.groupMarked);c.historyGroupNext=s.next
 F.scroll(c,0)
end
local function push(c,before)
 c.historyUndo=c.historyUndo or {};c.historyUndo[#c.historyUndo+1]={before=before,after=snapshot(c)};c.historyRedo={}
end
local function edit(c,fn)
 if c.historyEditDepth then return fn()end
 local before=snapshot(c);c.historyEditDepth=true
 local ok,result=pcall(fn);c.historyEditDepth=nil
 if not ok then error(result)end
 if result then push(c,before)end;return result
end
for _,key in ipairs({'assign','add','rename'})do local original=F[key];F[key]=function(c,...)local args={...};return edit(c,function()return original(c,unpack(args))end)end end
function F.renameGroup(c,g,name)
 local id=g.id;g=nil;for _,item in ipairs(c.historyGroups)do if item.id==id then g=item;break end end;if not g then return false end
 return edit(c,function()local old=g.name;g.name=name;if F.save(c)then return true end;g.name=old;return false end)
end
function F.groupSelected(c,id)
 local n=0;for _,clip in ipairs(c.history or {})do if (c.historyMembership[clip.id]or 0)==id then n=n+1;if not(c.historyMarked and c.historyMarked[clip.id])then return false end end end
 return n>0 or (c.historyGroupMarked and c.historyGroupMarked[id])or false
end
function F.selectGroup(c,id)
 return edit(c,function()local on=not F.groupSelected(c,id);c.historyMarked=c.historyMarked or {};c.historyGroupMarked=c.historyGroupMarked or {};c.historyGroupMarked[id]=on or nil
 for _,clip in ipairs(c.history or {})do if (c.historyMembership[clip.id]or 0)==id then c.historyMarked[clip.id]=on or nil end end;return true end)
end
function F.checkAll(c)
 return edit(c,function()c.historyMarked=c.historyMarked or {};local on=H.markedCount(c)<#c.history;for _,clip in ipairs(c.history or {})do c.historyMarked[clip.id]=on or nil end;return true end)
end
local mark=H.mark
H.mark=function(c,clip)return edit(c,function()mark(c,clip);return true end)end
-- Keep native Delete protections/stop logic while retaining chunks for session Undo.
local remove=H.delete
H.delete=function(c,clip,...)
 if c.recording then c:notify('Stop Record sebelum menghapus History.');return end
 local args={...}
 return edit(c,function()
  local released={};local release=JLRSFrames.release
  JLRSFrames.release=function(frames)released[#released+1]=frames end
  local ok,err=pcall(remove,c,clip,unpack(args));JLRSFrames.release=release
  for _,frames in ipairs(released)do if frames._jlrs then frames._jlrs.persistent=true end end
  if clip.frames and clip.frames._jlrs then clip.frames._jlrs.persistent=true end
  if not ok then error(err)end
  for _,v in ipairs(c.history)do if v==clip then return false end end
  c.historyMembership[clip.id]=nil;F.save(c);return true
 end)
end
local bulk=F.deleteChecked
F.deleteChecked=function(c)return edit(c,function()local n=#c.history;bulk(c);return #c.history<n end)end
function F.deleteGroup(c,id)
 if c.recording then c:notify('Stop Record sebelum menghapus grup.');return false end
 return edit(c,function()
  local index;for i,g in ipairs(c.historyGroups)do if g.id==id then index=i;break end end;if not index then return false end
  local clips={};for _,clip in ipairs(c.history)do if c.historyMembership[clip.id]==id then clips[#clips+1]=clip end end
  local changed=false
  for _,clip in ipairs(clips)do if not H.delete(c,clip)then return changed end;changed=true end
  local g=table.remove(c.historyGroups,index);local collapsed=c.historyCollapsed[id];c.historyCollapsed[id]=nil
  if not F.save(c)then table.insert(c.historyGroups,index,g);c.historyCollapsed[id]=collapsed;return changed end
  return true
 end)
end
local function restore(c,from,to,side)
 if c.recording or c.replaying or #(c.liveTracks or {})>0 or c.editingSession or c.changePending then c:notify('Stop Record / Replay sebelum Undo atau Redo.');return false end
 local source=c[from]or {};local item=source[#source];if not item then return false end
 local target=item[side];local retained={};for _,clip in ipairs(target.history)do retained[clip.id]=true end
 for _,clip in ipairs(c.history)do if not retained[clip.id]then
  for _,take in ipairs(c.finalTakes or {})do if take.editingPlan then for _,row in ipairs(take.editingPlan.rows)do for _,id in ipairs(row.ids)do if id==clip.id then c:notify('History dipakai Final Editing #'..take.id..'; hapus Final itu dahulu.');return false end end end end end
 end end
 local old=snapshot(c);apply(c,target)
 if not JLRSPersist.safeSave(c)then apply(c,old);return false end
 if not F.save(c)then apply(c,old);JLRSPersist.safeSave(c);return false end
 table.remove(source);c[to]=c[to]or {};c[to][#c[to]+1]=item;return true
end
function F.undo(c)return restore(c,'historyUndo','historyRedo','before')end
function F.redo(c)return restore(c,'historyRedo','historyUndo','after')end
local archive=H.archive
H.archive=function(c,...)local result=archive(c,...);c.historyUndo={};c.historyRedo={};return result end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)local result=load(c,...);c.historyUndo={};c.historyRedo={};c.historyGroupMarked={};return result end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)c.historyUndo={};c.historyRedo={};c.historyGroupMarked={};return unload(c,...)end
