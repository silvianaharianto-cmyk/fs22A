-- Explicit, savegame-local camera cleanup. Never sweep unclassified cache IDs.
JLRSFinalCacheCleanup={}
local C=JLRSFinalCacheCleanup
local function integer(n)return type(n)=='number' and n>=0 and n==math.floor(n) and n<100000000 end
local function count(x,key)
    local n=x:getInt(key,-1);if not integer(n) or n>100000 then error('Katalog tidak lengkap: '..key)end;return n
end
local function stream(x,key,out,optional)
    local id=x:getInt(key..'#id')
    if id==nil and optional then return end
    local sealed=x:getInt(key..'#sealed',-1)
    if not integer(id) or id<1 or not integer(sealed) then error('Referensi cache rusak: '..key)end
    out[id]=math.max(out[id] or 0,sealed)
end
local function read(path,fn)
    local x=XMLFile.load('jlrsFinalCleanupRead',path);if not x then error('Katalog tidak dapat dibaca: '..path)end
    local ok,why=pcall(fn,x);x:delete();if not ok then error(why)end
end
function C.plan(c)
    local ready,why=JLRSFrames.prepare();if not ready then error(why)end
    local dir=JLRSFrames.directory;local protect,cameras,paths={},{},{}
    -- Both History backups remain protected, including world and activity streams.
    for _,name in ipairs({'history_A.xml','history_B.xml','history_recovery_A.xml','history_recovery_B.xml'})do
        local path=dir..name
        if fileExists(path)then read(path,function(x)
            if x:getString('history#complete')~='JLRS_1' then error('History tidak lengkap; cache dilindungi.')end
            for i=0,count(x,'history#count')-1 do
                local k='history.clip('..i..')';stream(x,k..'.frames',protect)
                stream(x,k..'.activities.frames',protect,true)
                for g=0,count(x,k..'#groups')-1 do
                    local p=k..'.group('..g..')'
                    for e=0,count(x,p..'#entries')-1 do stream(x,p..'.entry('..e..').samples',protect)end
                end
            end
        end)end
    end
    local function catalog(prefix)
        local found=false
        for _,suffix in ipairs({'A.xml','B.xml'})do
            local path=dir..prefix..suffix
            if fileExists(path)then found=true;paths[#paths+1]=path;read(path,function(x)
                for i=0,count(x,'final#count')-1 do stream(x,'final.take('..i..').frames',cameras)end
            end)end
        end
        return found
    end
    catalog('final_')
    -- Match Final.load: gaps are legal. Classify every recovery catalog before
    -- planning explicit cleanup, so a later generation is never left dangling.
    for generation=1,1000 do catalog('final_recovery_'..generation..'_')end
    local journal=dir..'final_cache_cleanup.xml'
    if fileExists(journal)then read(journal,function(x)
        for i=0,count(x,'cleanup#count')-1 do stream(x,'cleanup.stream('..i..')',cameras)end
    end)end
    for _,t in ipairs(c.finalTakes or {})do local s=t.frames and t.frames._jlrs;if s then cameras[s.id]=math.max(cameras[s.id]or 0,s.sealed or 0)end end
    local visited={}
    local function memory(value)
        if type(value)~='table' or visited[value]then return end;visited[value]=true
        if value._jlrs then protect[value._jlrs.id]=0;memory(value.jlrsActivities);return end
        for k,v in pairs(value)do if k~='vehicle' and k~='object' and k~='target' then memory(v)end end
    end
    memory(c.history);memory(c.frames)
    -- A loaded camera can share its object with a catalog. Only noncamera stores
    -- add protection; all History catalog references above always take priority.
    for id in pairs(JLRSFrames.stores or {})do if not cameras[id]then protect[id]=0 end end
    local queue={}
    for id,sealed in pairs(cameras)do
        if not protect[id]then
            for i=1,sealed do queue[#queue+1]=dir..'take_'..id..'_'..i..'.xml' end
            queue[#queue+1]=dir..'take_'..id..'_tail.xml'
        end
    end
    return {directory=dir,paths=paths,cameras=cameras,protect=protect,queue=queue,index=1,deleted=0,failed=0}
end
function C.run(c)
    if c.recording or c.replaying or #(c.liveTracks or {})>0 or c.finalRecording or c.finalPlaying or c.editingSession or c.finalCacheJob then
        c:notify('Stop Record, Replay, dan Editing dahulu.');return
    end
    JLRSFinal.load(c)
    if c.finalLoadPending or c.jlrsLoadPending or c.finalReadFailed then c:notify('Katalog belum siap; cache dilindungi.');return end
    local ok,job=pcall(C.plan,c)
    if not ok then c:notify('Cache Final belum dihapus: '..tostring(job));return end
    -- Preserve the classified IDs if the player exits during batched deletion.
    local journal=job.directory..'final_cache_cleanup.xml'
    local written,why=pcall(function()
        local x=XMLFile.create('jlrsFinalCleanupJournal',journal,'cleanup');if not x then error('Jurnal tidak dapat ditulis.')end
        local good,err=pcall(function()
            local i=0
            for id,sealed in pairs(job.cameras)do
                local k='cleanup.stream('..i..')';x:setInt(k..'#id',id);x:setInt(k..'#sealed',sealed);i=i+1
            end
            x:setInt('cleanup#count',i);if x:save()==false then error('Jurnal gagal disimpan.')end
        end)
        x:delete();if not good then error(err)end
    end)
    if not written then c:notify('Cache belum dihapus: '..tostring(why));return end
    local takes,applied,selected=c.finalTakes,c.finalApplied,c.finalSelected
    c.finalTakes={};c.finalApplied={};c.finalSelected=0
    -- Commit both active backups before retiring older Final catalogs/chunks.
    if not JLRSFinal.save(c) or not JLRSFinal.save(c)then
        c.finalTakes=takes;c.finalApplied=applied;c.finalSelected=selected
        JLRSFinal.save(c);c:notify('Penyimpanan belum berhasil; cache tidak dihapus.');return
    end
    local active=job.directory..(c.finalCatalogPrefix or 'final_')
    for _,path in ipairs(job.paths)do
        if path~=active..'A.xml' and path~=active..'B.xml' then
            pcall(deleteFile,path)
            if fileExists(path)then c:notify('Katalog lama belum terhapus; cache tetap dilindungi.');return end
        end
    end
    c.finalDraft={};c.finalListReady=false;c.finalQueue=nil
    for id in pairs(job.cameras)do
        if not job.protect[id]then local f=JLRSFrames.stores[id];if f then f._jlrs.persistent=true;JLRSFrames.release(f)end end
    end
    c.finalCacheJob=job;c:notify('Menghapus cache kamera Final...')
end
function C.ask(c)
    if not g_gui or type(g_gui.showYesNoDialog)~='function'then c:notify('Dialog konfirmasi tidak tersedia.');return end
    g_gui:showYesNoDialog({title='Hapus Cache Final',text='Hapus SEMUA Record Final dan cache kameranya pada savegame ini? Tidak dapat Undo. Record Standar dan Record All Vehicle tetap disimpan.',callback=function(yes)if yes then C.run(c)end end})
end
local update=JLReplayStudio.update
JLReplayStudio.update=function(c,...)
    local result=update(c,...);local job=c.finalCacheJob
    if job then
        -- Small batches prevent thousands of synchronous deletes in one frame.
        for n=1,8 do
            local path=job.queue[job.index];if not path then break end
            if fileExists(path)then pcall(deleteFile,path);if fileExists(path)then job.failed=job.failed+1 else job.deleted=job.deleted+1 end end
            job.index=job.index+1
        end
        if job.index>#job.queue then
            if job.failed==0 then pcall(deleteFile,job.directory..'final_cache_cleanup.xml')end
            c.finalCacheJob=nil;c:notify('Cache Final selesai | '..job.deleted..' berkas dihapus | '..job.failed..' gagal | History tetap tersedia')
        end
    end
    return result
end
local draw=JLRSFinalList.draw
JLRSFinalList.draw=function(c,...)
    local result=draw(c,...)
    JLRSMenu.button(c,.21,.245,.28,.027,'HAPUS CACHE FINAL',function()C.ask(c)end,false,{.48,.07,.13})
    return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)c.finalCacheJob=nil;return deleteMap(c,...)end
