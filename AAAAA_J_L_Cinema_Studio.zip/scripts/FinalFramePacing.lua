-- Final-only camera representation repair and sparse timing. All source frames,
-- cut IDs, source clocks, physics and activity application remain authoritative.
JLRSFinalFramePacing={stats={},frame=0}
local P=JLRSFinalFramePacing
local sample=JLRSFinal.sample
JLRSFinal.sample=function(t,time,...)
    local pose=sample(t,time,...)
    local play=JLReplayStudio.finalPlaying
    if not play or play.take~=t or type(mathEulerToQuaternion)~='function'
        or type(mathQuaternionToEuler)~='function' or not JLRSRotationContinuity then return pose end
    local i=t.cameraIndex or 1
    local a=JLRSFrames.get(t.frames,i)
    local b=JLRSFrames.get(t.frames,math.min(i+1,JLRSFrames.count(t.frames)))
    if not a or not b or b.t<=a.t then return pose end
    local ap,bp=a.pose,b.pose
    if ap[9]~=bp[9]then return pose end -- hard cut, never a rotation transition
    local source=JLRSFinalCuts and JLRSFinalCuts.source(t,time)or time
    if source<=a.t or source>=b.t then return pose end
    local pair=t.jlrsFinalCameraPair
    if not pair or pair.a~=a or pair.b~=b then
        pair={a=a,b=b};t.jlrsFinalCameraPair=pair
        local flip=false
        for n=4,6 do if math.abs((bp[n]-ap[n]+math.pi)%(2*math.pi)-math.pi)>1 then flip=true end end
        if flip then
            local qa={mathEulerToQuaternion(ap[4],ap[5],ap[6])}
            local qb={mathEulerToQuaternion(bp[4],bp[5],bp[6])}
            local dot=0;for n=1,4 do dot=dot+qa[n]*qb[n]end
            -- Only repair a large Euler jump for a small actual orientation
            -- change. Ordinary turns keep their original recorded camera path.
            if math.abs(dot)>.97 then pair.qa=qa;pair.qb=qb end
        end
    end
    if pair.qa then
        local q=JLRSRotationContinuity.interpolate(pair.qa,pair.qb,(source-a.t)/(b.t-a.t))
        pose[4],pose[5],pose[6]=mathQuaternionToEuler(q[1],q[2],q[3],q[4])
    end
    return pose
end
local ending=JLRSFinal.endPlay
JLRSFinal.endPlay=function(c,...)
    if c.finalPlaying then c.finalPlaying.take.jlrsFinalCameraPair=nil end
    return ending(c,...)
end
local function elapsed(label,start)
    local ms=math.max(0,(getTimeSec()-start)*1000)
    local s=P.stats[label]or {sum=0,max=0,n=0};P.stats[label]=s
    s.sum=s.sum+ms;s.max=math.max(s.max,ms);s.n=s.n+1
    if P.frameTotals then P.frameTotals[label]=(P.frameTotals[label]or 0)+ms end
end
local function timed(owner,name,label)
    local native=owner[name]
    owner[name]=function(...)
        if not P.collect then return native(...)end
        local start=getTimeSec();local value=native(...);elapsed(label,start);return value
    end
end
timed(JLRSRecorder,'replayTick','motion')
timed(JLRSActivities,'tick','activity')
timed(JLRSWorld,'tick','world')
timed(JLRSCargoWheels,'flush','cargoWheels')
timed(JLRSWheelVisual,'refresh','wheelVisual')
timed(JLRSVehicleDirt,'flush','dirtVisual')
timed(JLRSFinal,'tick','finalCamera')
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local replaying=c.finalPlaying or c.replaying or #(c.liveTracks or {})>0
    if not replaying or c.paused or c.livePaused or (c.mission and c.mission.isPaused)
        or type(getTimeSec)~='function'then return draw(c,...)end
    local session=c.finalPlaying or 'replay'
    if P.play~=session then P.play=session;P.stats={};P.frame=0;P.start=nil end
    P.frame=P.frame+1
    if P.frame%60~=1 then return draw(c,...)end
    P.collect=true;P.frameTotals={}
    local start=getTimeSec();local ok,value=pcall(draw,c,...)
    elapsed('draw',start);P.collect=nil
    P.totals=P.totals or {}
    for label,ms in pairs(P.frameTotals)do
        local item=P.totals[label]or {sum=0,max=0};P.totals[label]=item
        item.sum=item.sum+ms;item.max=math.max(item.max,ms)
    end
    P.samples=(P.samples or 0)+1;P.frameTotals=nil
    if not ok then error(value,0)end
    local now=g_time or 0;P.start=P.start or now
    if now-P.start>=10000 then
        local out={}
        for _,name in ipairs({'draw','motion','activity','world','cargoWheels','wheelVisual','dirtVisual','finalCamera'})do
            local s=P.stats[name]
            if s then out[#out+1]=string.format('%s=%.2f/%.2fms',name,s.sum/s.n,s.max)end
        end
        for label,item in pairs(P.totals or {})do
            out[#out+1]=string.format('frameTotal_%s=%.2f/%.2fms',label,item.sum/math.max(1,P.samples or 0),item.max)
        end
        out[#out+1]='tracks='..tostring((c.replaying and 1 or 0)+#(c.liveTracks or {}))
        local owner=JLRSFinalCameraOwner
        if owner then
            out[#out+1]='cameraSwitches='..tostring(owner.cameraSwitches)..' poseChanges='..tostring(owner.poseChanges)
            owner.cameraSwitches=0;owner.poseChanges=0
        end
        local large=0
        for _,frames in pairs(JLRSFrames.stores or {})do
            for _,chunk in pairs(frames._jlrs and frames._jlrs.cache or {})do
                for index,frame in pairs(chunk)do
                    local pose=type(frame)=='table'and rawget(frame,'pose')
                    if type(index)=='number'and pose and #pose>=4096 then large=large+1 end
                end
            end
        end
        out[#out+1]='decodedLargeKeys='..large
        local buffers=0
        local function countBuffers(track)
            local sample=track.activityReplay and track.activityReplay.sample
            local keys=sample and sample.finalActivityKeys
            if keys then buffers=buffers+#keys end
        end
        countBuffers(c);for _,track in ipairs(c.liveTracks or {})do countBuffers(track)end
        out[#out+1]='activityBuffers='..buffers
        print('[JLRS RACE V1.18.86.112] sampled mean/max '..table.concat(out,' | '))
        P.stats={};P.totals={};P.samples=0;P.start=now
    end
    return value
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    P.stats={};P.totals={};P.samples=0;P.frame=0;P.start=nil;P.collect=nil;P.play=nil
    return load(c,...)
end
