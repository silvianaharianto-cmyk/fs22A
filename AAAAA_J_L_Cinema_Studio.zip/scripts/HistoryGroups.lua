-- History organization only. Recording streams and replay bindings are untouched.
JLRSHistoryGroups={ROWS=9}
local F=JLRSHistoryGroups
local H=JLRSHistory
local function clean(s)return tostring(s or ''):gsub('[%c]',''):match('^%s*(.-)%s*$'):sub(1,64)end
local function contains(c,clip)for _,v in ipairs(c.history or {})do if v==clip then return true end end end
local function init(c)
 c.historyGroups=c.historyGroups or {};c.historyMembership=c.historyMembership or {};c.historyGroupNext=c.historyGroupNext or 0
 c.historyScroll=c.historyScroll or 0;c.historyCollapsed=c.historyCollapsed or {}
end
function F.save(c)
 init(c);local ok,err=pcall(function()
  assert(JLRSFrames.directory,'Folder History belum tersedia.')
  local revision=(c.historyGroupRevision or 0)+1
  local path=JLRSFrames.directory..'history_groups_'..(revision%2==0 and 'A.xml' or 'B.xml')
  local x=assert(XMLFile.create('jlrsGroups',path,'groups'))
  local written,why=pcall(function()
   x:setInt('groups#revision',revision);x:setInt('groups#nextId',c.historyGroupNext);x:setInt('groups#count',#c.historyGroups)
   for i,g in ipairs(c.historyGroups)do local k='groups.group('..(i-1)..')';x:setInt(k..'#id',g.id);x:setString(k..'#name',g.name);x:setInt(k..'#collapsed',c.historyCollapsed[g.id] and 1 or 0)end
   local n=0
   for _,clip in ipairs(c.history or {})do local id=c.historyMembership[clip.id]
    if id then local k='groups.member('..n..')';x:setInt(k..'#clip',clip.id);x:setInt(k..'#group',id);n=n+1 end
   end
   x:setInt('groups#members',n);x:setString('groups#complete','JLRS_GROUPS_1');assert(x:save()~=false,'Gagal menyimpan grup.')
  end)
  x:delete();if not written then error(why)end
  local check=assert(XMLFile.load('jlrsGroupsCheck',path))
  local valid=check:getString('groups#complete')=='JLRS_GROUPS_1' and check:getInt('groups#revision')==revision
  check:delete();assert(valid,'Verifikasi grup gagal.');c.historyGroupRevision=revision
 end)
 if not ok then c:notify('Grup belum tersimpan: '..tostring(err))end
 return ok
end
function F.load(c)
 init(c);if c.historyGroupsLoaded or c.jlrsLoadPending or not JLRSFrames.directory then return end
 local best
 for _,suffix in ipairs({'A.xml','B.xml'})do
  local path=JLRSFrames.directory..'history_groups_'..suffix
  if not fileExists or fileExists(path)then
   local x=XMLFile.load('jlrsGroupsRead',path)
   if x then
    local ok,data=pcall(function()
     assert(x:getString('groups#complete')=='JLRS_GROUPS_1')
     local d={revision=x:getInt('groups#revision',0),nextId=x:getInt('groups#nextId',0),groups={},members={},collapsed={}};local seen={}
     local count=x:getInt('groups#count',0);assert(count>=0 and count<=10000)
     for i=0,count-1 do local k='groups.group('..i..')';local id=x:getInt(k..'#id',0);local name=clean(x:getString(k..'#name',''));assert(id>0 and not seen[id] and #name>0);seen[id]=true;d.groups[#d.groups+1]={id=id,name=name};d.collapsed[id]=x:getInt(k..'#collapsed',0)==1 end
     local members=x:getInt('groups#members',0);assert(members>=0 and members<=1000000)
     for i=0,members-1 do local k='groups.member('..i..')';local id=x:getInt(k..'#group',0);if seen[id]then d.members[x:getInt(k..'#clip',0)]=id end end
     return d
    end)
    x:delete();if ok and (not best or data.revision>best.revision)then best=data end
   end
  end
 end
 if best then c.historyGroups=best.groups;c.historyMembership=best.members;c.historyCollapsed=best.collapsed;c.historyGroupNext=best.nextId;c.historyGroupRevision=best.revision end
 c.historyGroupsLoaded=true
end
function F.assign(c,clips,id)
 init(c);local old={}
 for _,clip in ipairs(clips)do if contains(c,clip)then old[#old+1]={clip=clip,value=c.historyMembership[clip.id]};c.historyMembership[clip.id]=id~=0 and id or nil end end
 if F.save(c)then return true end
 for _,s in ipairs(old)do c.historyMembership[s.clip.id]=s.value end;return false
end
function F.add(c,name,clips)
 init(c);name=clean(name);if #name==0 then return false end
 local previous=c.historyGroupNext;c.historyGroupNext=previous+1;local group={id=c.historyGroupNext,name=name};c.historyGroups[#c.historyGroups+1]=group
 if not F.assign(c,clips or {},group.id)then table.remove(c.historyGroups);c.historyGroupNext=previous;return false end
 c.historyCollapsed[group.id]=false;return group
end
function F.checked(c)local list={};for _,clip in ipairs(c.history or {})do if c.historyMarked and c.historyMarked[clip.id]then list[#list+1]=clip end end;return list end
function F.prompt(c,label,value,callback)
 if g_gui and g_gui.showTextInputDialog then g_gui:showTextInputDialog({text=label,defaultText=value,maxCharacters=64,callback=function(text,ok)if ok then callback(clean(text))end end})
 else c:notify('Dialog teks tidak tersedia.')end
end
function F.rename(c,clip,name)
 if not contains(c,clip)then return false end;name=clean(name);if #name==0 then return false end
 local old=clip.name;clip.name=name
 if JLRSPersist.safeSave(c)then return true end;clip.name=old;return false
end
function F.deleteChecked(c)
 if c.recording then c:notify('Stop Record sebelum menghapus History.');return false end
 local clips=F.checked(c);if #clips==0 then c:notify('Centang record yang ingin dihapus.');return false end
 local count=0
 -- Existing persistent delete owns reference protection, disk commits and rollback.
 for _,clip in ipairs(clips)do H.delete(c,clip);if not contains(c,clip)then c.historyMembership[clip.id]=nil;count=count+1 else break end end
 F.save(c);c:notify(string.format('%d / %d record ditandai dihapus.',count,#clips));return count==#clips
end
function F.rows(c)
 init(c);local rows={};local known={}
 local function group(id,name)
  rows[#rows+1]={group=id,name=name}
  if not c.historyCollapsed[id]then for _,clip in ipairs(c.history or {})do if (c.historyMembership[clip.id] or 0)==id then rows[#rows+1]={clip=clip}end end end
 end
 for _,g in ipairs(c.historyGroups)do known[g.id]=true end
 for id in pairs(c.historyMembership)do if not known[c.historyMembership[id]]then c.historyMembership[id]=nil end end
 group(0,'Ungrouped');for _,g in ipairs(c.historyGroups)do group(g.id,g.name)end
 return rows
end
function F.scroll(c,delta)
 c.historyScroll=math.max(0,math.min(math.max(0,#F.rows(c)-F.ROWS),(c.historyScroll or 0)+delta))
end
function F.drop(c,clip,row)
 if not contains(c,clip)or not row then return false end
 if row.group~=nil then return F.assign(c,{clip},row.group)end
 if row.clip==clip then return false end
 local group=c.historyMembership[row.clip.id]
 if group then return F.assign(c,{clip},group)end
 return F.add(c,'Group '..((c.historyGroupNext or 0)+1),{row.clip,clip})~=false
end
local function shorten(s,n)s=tostring(s or '');return #s>n and s:sub(1,n-3)..'...' or s end
-- Fit the visible label to its own box; the full stored name is unchanged.
function F.fitName(value,size,width)
 local text=tostring(value or '')
 local function measure(s)
  if getTextWidth then local ok,w=pcall(getTextWidth,size,s);if ok and type(w)=='number' then return w end end
  return #s*size -- conservative fallback if native text metrics are unavailable
 end
 if measure(text)<=width then return text end
 while #text>0 and measure(text..'...')>width do
  local trimmed=text:gsub('[%z\1-\127\194-\244][\128-\191]*$','')
  text=trimmed~=text and trimmed or text:sub(1,-2)
 end
 return measure('...')<=width and text..'...' or ''
end
function H.draw(c)
 if not c.overlay then return end
 F.load(c);local rows=F.rows(c);F.scroll(c,0);c.hitboxes={};c.historyRowAreas={}
 local M=JLRSMenu
 M.rect(c,.12,.12,.76,.76,.015,.023,.037,.98);M.rect(c,.12,.79,.76,.09,.025,.16,.23)
 M.text(.14,.835,.025,'J_L Cinema Studio | History / Replay')
 M.text(.14,.804,.011,'Drag nama record ke grup, atau ke record lain untuk membuat grup.')
 M.button(c,.645,.821,.10,.032,'SAVE',function()JLRSManualSave.save(c,false);F.save(c)end)
 M.button(c,.757,.821,.10,.032,'CLOSE',function()H.close(c)end)
 M.button(c,.14,.745,.15,.034,'ADD GROUP',function()F.prompt(c,'Nama grup','Group '..((c.historyGroupNext or 0)+1),function(name)F.add(c,name,F.checked(c))end)end)
 M.button(c,.30,.745,.23,.034,'REPLAY CHECKED ('..H.markedCount(c)..')',function()H.replayMarked(c)end)
 M.button(c,.54,.745,.18,.034,'REPLAY ALL',function()JLRSGroup.all(c)end)
 M.button(c,.73,.745,.13,.034,'CHECK ALL',function()F.checkAll(c)end)
 for r=1,F.ROWS do
  local row=rows[c.historyScroll+r];local y=.691-(r-1)*.047
  if row then
   M.rect(c,.14,y-.004,.715,.044,row.group~=nil and .025 or .05,row.group~=nil and .14 or .075,row.group~=nil and .19 or .105)
   c.historyRowAreas[#c.historyRowAreas+1]={x=.14,y=y-.004,w=.715,h=.044,row=row}
   if row.group~=nil then
    local id=row.group
    local marked=F.groupSelected(c,id)
    M.button(c,.205,y,.035,.033,marked and 'X' or '',function()F.selectGroup(c,id)end,marked)
    M.button(c,.15,y,.035,.033,c.historyCollapsed[id] and '+' or '-',function()c.historyCollapsed[id]=not c.historyCollapsed[id];F.scroll(c,0);F.save(c)end)
    M.rect(c,.26,y,.38,.033,.018,.08,.12)
    M.text(.27,y+.013,.014,F.fitName(row.name,.014,.36),.2,.88,.9)
    if id~=0 then
     M.button(c,.65,y,.09,.033,'RENAME',function()for _,g in ipairs(c.historyGroups)do if g.id==id then F.prompt(c,'Nama grup',g.name,function(name)if #name>0 then F.renameGroup(c,g,name) end end);break end end end)
     M.button(c,.75,y,.09,.033,'DELETE',function()F.deleteGroup(c,id)end,false,{.48,.07,.13})
    end
   else
    local clip=row.clip;local checked=c.historyMarked and c.historyMarked[clip.id]
    M.button(c,.24,y,.04,.033,checked and 'X' or '',function()H.mark(c,clip)end,checked)
    M.text(.29,y+.022,.013,shorten(string.format('#%03d %s',clip.id,clip.name),30))
    M.text(.29,y+.005,.010,string.format('%.2fs | %d frames',clip.duration,JLRSFrames.count(clip.frames)),.65,.74,.83)
    M.button(c,.57,y,.085,.033,'RENAME',function()F.prompt(c,'Nama record',clip.name,function(name)F.rename(c,clip,name)end)end)
    M.button(c,.665,y,.085,.033,'REPLAY',function()H.replay(c,clip)end,c.historySelected==clip.id)
    M.button(c,.76,y,.085,.033,'DELETE',function()if c.recording then c:notify('Stop Record sebelum menghapus History.');return end;H.delete(c,clip)end,false,{.48,.07,.13})
   end
  end
 end
 local max=math.max(0,#rows-F.ROWS);local knob=.425*math.min(1,F.ROWS/math.max(F.ROWS,#rows))
 M.rect(c,.862,.31,.009,.425,.08,.12,.16)
 local ky=.735-knob-(max>0 and c.historyScroll/max*(.425-knob)or 0)
 M.rect(c,.862,ky,.009,knob,.2,.7,.8);c.historyScrollbar={x=.858,y=.31,w=.02,h=.425,knob=knob,max=max}
 M.button(c,.14,.235,.21,.034,'DELETE CHECKED',function()F.deleteChecked(c)end,false,{.48,.07,.13})
 M.button(c,.36,.235,.25,.034,c.preciseReplay and 'REPLAY PRESISI' or ('PHYSICS '..(c.physicsReplay and 'ON' or 'OFF')),function()JLRSCollision.toggle(c)end,c.physicsReplay)
 M.button(c,.62,.235,.10,.034,'CAMERA',function()JLRSGroup.camera(c)end,c.groupCamera)
 M.button(c,.73,.235,.13,.034,'NEXT CAR',function()JLRSGroup.next(c)end)
 M.button(c,.62,.19,.11,.032,'UNDO',function()F.undo(c)end)
 M.button(c,.74,.19,.11,.032,'REDO',function()F.redo(c)end)
 M.text(.14,.20,.011,string.format('%d record | %d grup',#c.history,#c.historyGroups))
 M.button(c,.39,.19,.21,.032,'RESET VEHICLE',function()JLRSHistoryReset.open(c)end)
 M.text(.14,.167,.011,shorten(c.notice or '',105),1,.75,.35)
 M.text(.14,.137,.009,'©Copyright 2023 | Jupryan Lowlight',.65,.74,.83)
 if c.historyDrag and c.mouseX then M.text(c.mouseX+.012,c.mouseY+.012,.013,shorten(c.historyDrag.clip.name,32),.3,1,.8)end
 setTextColor(1,1,1,1);setTextAlignment(RenderText.ALIGN_LEFT)
end
local close=H.close
H.close=function(c,...)c.historyDrag=nil;c.historyScrollDrag=nil;return close(c,...)end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
 local result=load(c,...);c.historyGroups={};c.historyMembership={};c.historyGroupNext=0;c.historyGroupsLoaded=false;c.historyGroupRevision=0;c.historyScroll=0;c.historyCollapsed={}
 if not c.mission then return result end
 local previous=c.mission.mouseEvent;c.historyGroupsPreviousMouse=previous
 c.historyGroupsMouse=function(m,x,y,down,up,button,...)
  if c.historyOpen and c.menu and not(g_gui and g_gui:getIsGuiVisible())then
   c.mouseX=x;c.mouseY=y
   if down and button==Input.MOUSE_BUTTON_WHEEL_UP then F.scroll(c,-1);return end
   if down and button==Input.MOUSE_BUTTON_WHEEL_DOWN then F.scroll(c,1);return end
   if c.historyScrollDrag then
    local b=c.historyScrollbar;if b and b.max>0 then c.historyScroll=math.floor(math.max(0,math.min(1,(b.y+b.h-b.knob/2-y)/math.max(.001,b.h-b.knob)))*b.max+.5)end
    if up then c.historyScrollDrag=nil end;return
   end
   local row
   for _,area in ipairs(c.historyRowAreas or {})do if x>=area.x and x<=area.x+area.w and y>=area.y and y<=area.y+area.h then row=area.row;break end end
   if c.historyDrag then
    local d=c.historyDrag;if math.abs(x-d.x)+math.abs(y-d.y)>.008 then d.moved=true end
    if up then c.historyDrag=nil;if d.moved then F.drop(c,d.clip,row)end end;return
   end
   if down and button==Input.MOUSE_BUTTON_LEFT then
    local b=c.historyScrollbar
    if b and x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h then c.historyScrollDrag=true;return end
    if row and row.clip and x>=.29 and x<.56 then c.historySelected=row.clip.id;c.historyDrag={clip=row.clip,x=x,y=y};return end
   end
   JLRSMenu.click(c,x,y,down,button);return
  end
  return previous(m,x,y,down,up,button,...)
 end
 c.mission.mouseEvent=c.historyGroupsMouse;return result
end
local persistedLoad=JLRSPersist.load
JLRSPersist.load=function(c,...)local result=persistedLoad(c,...);F.load(c);return result end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
 if c.mission and c.mission.mouseEvent==c.historyGroupsMouse then c.mission.mouseEvent=c.historyGroupsPreviousMouse end
 c.historyDrag=nil;c.historyScrollDrag=nil
 return delete(c,...)
end
