-- Replay motion remapping. Processing is streamed to disk and yields between batches.
JLRSChange={ROWS=6}
function JLRSChange.copy(t) local out={};for k,v in pairs(t or {}) do out[k]=v end;return out end
-- Keep bind geometry of the replacement. Only recorded motion is transferred.
function JLRSChange.wheelRoles(vehicle)
    local roles={};local wheels=vehicle.spec_wheels and vehicle.spec_wheels.wheels or {}
    local function add(wheel,index)
        local radius=wheel.radius or (wheel.physics and wheel.physics.radius) or 1
        if wheel.repr then roles[wheel.repr]={kind='repr',index=index,radius=radius} end
        if wheel.driveNode then roles[wheel.driveNode]={kind='drive',index=index,radius=radius} end
        for _,extra in ipairs(wheel.additionalWheels or {}) do add(extra,index) end
    end
    for i,wheel in ipairs(wheels) do add(wheel,i) end
    return roles,#wheels
end
function JLRSChange.contains(entries,old)
    for _,e in ipairs(entries or {}) do if e.vehicle==old or e.node==old.rootNode then return true end end
    return false
end
function JLRSChange.adapt(entries,frames,old,new,worldOnly,c,ignore)
    if not JLRSChange.contains(entries,old) then return nil end
    if not frames or JLRSFrames.count(frames)==0 then error('Frame record kosong.') end
    local replacement=JLRSRecorder.topology(new)
    if worldOnly then local filtered={};for _,e in ipairs(replacement) do if e.world then filtered[#filtered+1]=e end end;replacement=filtered end
    local output,maps={},{};local inserted=false;local rootIndex
    local oldRoles,oldWheelCount=JLRSChange.wheelRoles(old);local newRoles=JLRSChange.wheelRoles(new)
    local function belongs(e)
        return not (ignore and ignore[e]) and (e.vehicle==old or e.node==old.rootNode or oldRoles[e.node])
    end
    local oldWorld,oldWheel={},{repr={},drive={}}
    for i,e in ipairs(entries) do
        if e.node==old.rootNode and belongs(e) then rootIndex=i end
        if belongs(e) then
            if e.world then oldWorld[e.componentIndex or 1]=i end
            local role=oldRoles[e.node];if role then oldWheel[role.kind][role.index]=i end
        end
    end
    rootIndex=rootIndex or oldWorld[1];if not rootIndex then error('Root record kendaraan tidak ditemukan.') end
    local base=JLRSFrames.get(frames,1).pose;local rootOffset=(rootIndex-1)*6
    local helper=createTransformGroup('JLRS_Change_Root');link(getRootNode(),helper)
    local child=createTransformGroup('JLRS_Change_Component');link(helper,child)
    if c and c.changePending then c.changePending.helpers[helper]=true;c.changePending.helpers[child]=true end
    local function clearance(vehicle)
        -- repr may be an axle/suspension pivot, not the tyre centre. Read the
        -- drive node and reconstruct the donor's initial nested transforms on
        -- private helpers; its current/end suspension is not the recorded bind.
        local offsets,locals,cache,created={},{},{},{}
        if vehicle==old then
            for i,e in ipairs(entries)do offsets[e.node]={n=(i-1)*6,world=e.world}end
            local data=frames.jlrsActivities
            if data and data.frames and JLRSFrames.count(data.frames)>0 then
                local activity=JLRSFrames.get(data.frames,1).pose
                for i,ch in ipairs(data.schema or {})do
                    if ch.getter=='jlrsSuspension' and ch.owner==vehicle.jlrsPersistentId
                        and ch.config==(vehicle.configFileName or vehicle.xmlFilename or '')then
                        local depth=tonumber((ch.name or ''):match('^wheelParent(%d+)$'))
                        local wheel=depth and vehicle.spec_wheels and vehicle.spec_wheels.wheels[ch.index]
                        local node=wheel and wheel.repr
                        for d=1,depth or 0 do if node and entityExists(node)then node=getParent(node)else node=nil;break end end
                        if node and node~=0 and entityExists(node)and not offsets[node]then
                            local pose={};for j=1,6 do pose[j]=activity[(i-1)*6+j]end
                            locals[node]=pose
                        end
                    end
                end
            end
        end
        local function recorded(node)
            if node==0 or node==getRootNode()then return getRootNode()end
            if cache[node]then return cache[node]end
            local proxy=createTransformGroup('JLRS_Change_Clearance')
            created[#created+1]=proxy;cache[node]=proxy
            if c and c.changePending then c.changePending.helpers[proxy]=true end
            local offset=offsets[node]
            if offset and offset.world then
                link(getRootNode(),proxy)
                local n=offset.n;setTranslation(proxy,base[n+1],base[n+2],base[n+3]);setRotation(proxy,base[n+4],base[n+5],base[n+6])
            else
                link(recorded(getParent(node)),proxy)
                local p=locals[node]
                if offset then local n=offset.n;p={};for j=1,6 do p[j]=base[n+j]end end
                if p then setTranslation(proxy,p[1],p[2],p[3]);setRotation(proxy,p[4],p[5],p[6])
                else local x,y,z=getTranslation(node);local rx,ry,rz=getRotation(node);setTranslation(proxy,x,y,z);setRotation(proxy,rx,ry,rz)end
            end
            return proxy
        end
        local function measure()
            local minimum;local root=vehicle==old and recorded(vehicle.rootNode)or vehicle.rootNode
            local function inspect(wheel)
                local node=wheel.driveNode or wheel.repr
                local radius=wheel.radius or (wheel.physics and wheel.physics.radius)
                if node and entityExists(node)and type(radius)=='number'and radius>0 then
                    local point=vehicle==old and recorded(node)or node
                    local x,y,z=getWorldTranslation(point)
                    local _,localY=worldToLocal(root,x,y,z)
                    local contact=localY-radius
                    minimum=minimum and math.min(minimum,contact)or contact
                end
                for _,extra in ipairs(wheel.additionalWheels or {})do inspect(extra)end
            end
            for _,wheel in ipairs(vehicle.spec_wheels and vehicle.spec_wheels.wheels or {})do inspect(wheel)end
            return minimum
        end
        local ok,result=pcall(measure)
        for _,node in ipairs(created)do
            if entityExists(node)then delete(node)end
            if c and c.changePending then c.changePending.helpers[node]=nil end
        end
        if not ok then error(result)end
        return result
    end
    local oldClearance,newClearance=clearance(old),clearance(new)
    local heightOffset=oldClearance and newClearance and oldClearance-newClearance or 0
    local function rootPose(p)
        setTranslation(helper,p[rootOffset+1],p[rootOffset+2]+heightOffset,p[rootOffset+3])
        setRotation(helper,p[rootOffset+4],p[rootOffset+5],p[rootOffset+6])
    end
    local function relative(p,index)
        local n=(index-1)*6
        setWorldTranslation(child,p[n+1],p[n+2],p[n+3]);setWorldRotation(child,p[n+4],p[n+5],p[n+6])
        local x,y,z=getTranslation(child);local rx,ry,rz=getRotation(child);return {x,y,z,rx,ry,rz}
    end
    local function pushReplacement()
        if inserted then return end;inserted=true
        for _,e in ipairs(replacement) do
            output[#output+1]=e
            local map={entry=e,base={}}
            if e.world then
                link(new.rootNode,child)
                local x,y,z=getWorldTranslation(e.node);local rx,ry,rz=getWorldRotation(e.node)
                setWorldTranslation(child,x,y,z);setWorldRotation(child,rx,ry,rz)
                local bx,by,bz=getTranslation(child);local brx,bry,brz=getRotation(child)
                map.base={bx,by,bz,brx,bry,brz};link(helper,child)
                map.source=oldWorld[e.componentIndex or 1]
                map.root=e.node==new.rootNode
                if map.source then rootPose(base);map.sourceBase=relative(base,map.source) end
            else
                local x,y,z=getTranslation(e.node);local rx,ry,rz=getRotation(e.node);map.base={x,y,z,rx,ry,rz}
                local role=newRoles[e.node]
                if role then map.kind=role.kind;map.radius=math.max(0.001,role.radius) end
                if role and oldWheelCount>0 then
                    local fallback=oldWheelCount>=2 and (math.max(1,oldWheelCount-1)+(role.index-1)%2) or 1
                    map.source=oldWheel[role.kind][role.index] or oldWheel[role.kind][fallback]
                    local sourceRole=map.source and oldRoles[entries[map.source].node]
                    map.spinScale=role.kind=='drive' and sourceRole and sourceRole.radius/math.max(0.001,role.radius) or 1
                    map.kind=role.kind;map.radius=math.max(0.001,role.radius)
                    if not map.source then
                        for _,index in pairs(oldWheel[role.kind]) do map.source=index;break end
                    end
                end
            end
            maps[#maps+1]=map
        end
    end
    local function convert()
        for i,e in ipairs(entries) do
            if belongs(e) then pushReplacement()
            else output[#output+1]=e;maps[#maps+1]={copy=i} end
        end
        local adapted=JLRSChange.stream(c,#output*6+3)
        for fi=1,JLRSFrames.count(frames) do
            local frame=JLRSFrames.get(frames,fi)
            local pose={};rootPose(frame.pose)
            local previous=fi>1 and JLRSFrames.get(frames,fi-1).pose or frame.pose
            local dx=frame.pose[rootOffset+1]-previous[rootOffset+1]
            local dz=frame.pose[rootOffset+3]-previous[rootOffset+3]
            local yaw=frame.pose[rootOffset+5]
            local travel=math.sqrt(dx*dx+dz*dz)*((dx*math.sin(yaw)+dz*math.cos(yaw))<0 and -1 or 1)
            for _,map in ipairs(maps) do
                local values={}
                if map.copy then local n=(map.copy-1)*6;for j=1,6 do values[j]=frame.pose[n+j] end
                elseif map.entry.world then
                    if map.root then for j=1,6 do values[j]=frame.pose[rootOffset+j] end;values[2]=values[2]+heightOffset
                    else
                        local localPose=JLRSChange.copy(map.base)
                        if map.source and old.configFileName==new.configFileName then
                            local current=relative(frame.pose,map.source)
                            for j=1,3 do localPose[j]=localPose[j]+current[j]-map.sourceBase[j] end
                            for j=4,6 do localPose[j]=localPose[j]+JLRSRecorder.angle(map.sourceBase[j],current[j],1)-map.sourceBase[j] end
                        end
                        setTranslation(child,localPose[1],localPose[2],localPose[3]);setRotation(child,localPose[4],localPose[5],localPose[6])
                        local x,y,z=getWorldTranslation(child);local rx,ry,rz=getWorldRotation(child);values={x,y,z,rx,ry,rz}
                    end
                else
                    values=JLRSChange.copy(map.base)
                    if map.source then
                        local n=(map.source-1)*6
                        -- Wheel geometry belongs to the replacement; do not transplant donor suspension displacement.
                        if not map.kind then for j=1,3 do values[j]=values[j]+frame.pose[n+j]-base[n+j] end end
                        for j=4,6 do
                            local delta
                            if map.kind=='drive' then
                                map.lastSource=map.lastSource or {};map.unwrapped=map.unwrapped or {}
                                local previous=map.lastSource[j] or base[n+j]
                                delta=(map.unwrapped[j] or 0)+JLRSRecorder.angle(previous,frame.pose[n+j],1)-previous
                                map.lastSource[j]=frame.pose[n+j];map.unwrapped[j]=delta
                            else delta=JLRSRecorder.angle(base[n+j],frame.pose[n+j],1)-base[n+j] end
                            values[j]=values[j]+delta*((map.kind=='drive' and j==4) and (map.spinScale or 1) or 1)
                        end
                    end
                end
                if map.kind=='drive' then
                    map.travel=(map.travel or 0)+travel
                    -- A donor can have a stationary or absent visual spin node.
                    -- Use displacement for that wheel, preserving donor spin when present.
                    local spin=0
                    for j=4,6 do spin=spin+math.abs((map.unwrapped or {})[j] or 0) end
                    if spin<0.00001 then values[4]=map.base[4]+map.travel/map.radius end
                end
                for j=1,6 do pose[#pose+1]=values[j] end
            end
            -- Motor sound state follows the recording across Change Cars.
            for j=#entries*6+1,#frame.pose do pose[#pose+1]=frame.pose[j] end
            JLRSFrames.push(adapted,{t=frame.t,pose=pose})
            if c then JLRSChange.progress(c) end
        end
        adapted.jlrsRemapped=true
        adapted.jlrsRemappedOwners=JLRSChange.copy(frames.jlrsRemappedOwners)
        if new.jlrsPersistentId then adapted.jlrsRemappedOwners[new.jlrsPersistentId]=true end
        return {entries=output,frames=adapted}
    end
    local result=convert()
    delete(child);delete(helper)
    if c and c.changePending then c.changePending.helpers[child]=nil;c.changePending.helpers[helper]=nil end
    return result
end
function JLRSChange.stream(c,values)
    local f=JLRSFrames.new(values)
    if c and c.changePending then c.changePending.streams[#c.changePending.streams+1]=f end
    return f
end
function JLRSChange.progress(c)
    local t=c.changePending;if not t then error('Change Cars dibatalkan.') end
    t.done=t.done+1
    if not t.sync and t.done%64==0 then coroutine.yield() end
end
local function worldGroup(c,group,new)
    local old=group.object;local combined=JLRSChange.stream(c,#group.entries*6)
    local pointers,contexts={},{}
    for i,e in ipairs(group.entries) do pointers[i]=1;contexts[i]={frames=e.samples,frameIndex=1} end
    while true do
        local nextTime
        for i,e in ipairs(group.entries) do
            local frame=JLRSFrames.get(e.samples,pointers[i])
            if frame and (not nextTime or frame.t<nextTime) then nextTime=frame.t end
        end
        if not nextTime then break end
        local pose={}
        for i,e in ipairs(group.entries) do
            local sample=JLRSRecorder.sample(contexts[i],nextTime)
            for j=1,6 do pose[#pose+1]=sample[j] end
            while pointers[i]<=JLRSFrames.count(e.samples) and JLRSFrames.get(e.samples,pointers[i]).t<=nextTime+0.00000001 do pointers[i]=pointers[i]+1 end
        end
        JLRSFrames.push(combined,{t=nextTime,pose=pose});JLRSChange.progress(c)
    end
    local mapped=JLRSChange.adapt(group.entries,combined,old,new,false,c)
    local result={object=new,vehicle=true,entries={}}
    local replacementId=JLRSPersist.identity(new)
    for i,e in ipairs(mapped.entries) do
        local entry=JLRSChange.copy(e);entry.samples=JLRSChange.stream(c,6);entry.sampleIndex=1
        entry.samples.jlrsRemapped=true;entry.samples.jlrsRemappedOwners={[replacementId]=true}
        result.entries[i]=entry
    end
    for fi=1,JLRSFrames.count(mapped.frames) do
        local f=JLRSFrames.get(mapped.frames,fi)
        for i,e in ipairs(result.entries) do
            local pose={};for j=1,6 do pose[j]=f.pose[(i-1)*6+j] end
            -- Keep the sparse motion boundaries; static new components only need their start pose.
            local count=JLRSFrames.count(e.samples);local previous=count>0 and JLRSFrames.get(e.samples,count) or nil
            local changed=not previous
            if previous then for j=1,6 do if previous.pose[j]~=pose[j] then changed=true;break end end end
            if changed then
                if previous and e.lastTime and previous.t<e.lastTime-0.00000001 then JLRSFrames.push(e.samples,{t=e.lastTime,pose=previous.pose}) end
                JLRSFrames.push(e.samples,{t=f.t,pose=pose})
            end
            e.lastTime=f.t
        end
        JLRSChange.progress(c)
    end
    JLRSFrames.release(combined);JLRSFrames.release(mapped.frames)
    return result
end
-- Change-only repair: saved slots remain authoritative. Extra current nodes or
-- renamed i3d nodes must not block transferring otherwise compatible takes.
function JLRSChange.resolveSavedVehicle(c,desc,old)
    if desc.id==old.jlrsPersistentId then return old end
    if desc.object and JLRSRecorder.valid(desc.object) then return desc.object end
    local exact,bySave,ambiguous
    for _,v in pairs(c.mission.vehicles or {})do
        if JLRSRecorder.valid(v) then
            if desc.id and desc.id~='' and v.jlrsPersistentId==desc.id then
                if exact and exact~=v then return nil,'ID kendaraan duplikat' end;exact=v
            end
            local saveId=v.jlrsLoadedSaveId or v.currentSavegameId or v.saveId
            if desc.saveId and desc.saveId~=0 and saveId==desc.saveId
                and (v.configFileName or '')==desc.config then
                if bySave and bySave~=v then ambiguous=true end;bySave=v
            end
        end
    end
    if exact then return exact end
    if bySave and not ambiguous then return bySave end
    return nil,'kendaraan sumber tidak tersedia: saveId='..tostring(desc.saveId)..' id='..tostring(desc.id)
end
function JLRSChange.rebind(c,clip,old)
    local saved=clip.saved;if not saved then return false end
    local vehicles,slots={},{}
    for i,desc in ipairs(saved.vehicles or {}) do
        local v,reason=JLRSChange.resolveSavedVehicle(c,desc,old)
        if not v then clip.changeBindReason=reason;return false end
        vehicles[i]=v
        if v then
            local list,seen={},{}
            local function add(node,world,index)
                if node and node~=0 and entityExists(node) and not seen[node] then
                    seen[node]=true;list[#list+1]={node=node,world=world,parent=getParent(node),vehicle=v,componentIndex=index}
                end
            end
            for index,component in ipairs(v.components or {}) do add(component.node,true,index) end
            add(v.rootNode,true)
            local function wheel(w)
                add(w.repr,false);add(w.driveNode,false)
                for _,extra in ipairs(w.additionalWheels or {}) do wheel(extra) end
            end
            for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {}) do wheel(w) end
            slots[i]=list
        end
    end
    local entries={}
    for i,desc in ipairs(saved.entries or {}) do
        local list=slots[desc.vehicle] or {}
        local entry=list[desc.slot]
        -- Slot order describes the current vehicle, not the coordinate space
        -- used by the saved take. Restore that space from the take itself.
        -- A uniquely named node can also survive a changed slot order.
        local named,ambiguous
        if desc.name and desc.name~='' and type(getName)=='function' then
            for _,candidate in ipairs(list) do
                if getName(candidate.node)==desc.name then
                    if named then ambiguous=true end;named=candidate
                end
            end
        end
        if named and not ambiguous then entry=named end
        if not entry or (desc.world~=0 and desc.world~=1 and type(desc.world)~='boolean') then
            clip.changeBindReason="slot "..tostring(desc.slot).." kendaraan "..tostring(desc.vehicle).." tidak tersedia";return false
        end
        entries[i]=JLRSChange.copy(entry)
        entries[i].world=desc.world==1 or desc.world==true
    end
    if #entries==0 or not JLRSChange.contains(entries,old) then return false end
    clip.entries=entries;clip.vehicles=vehicles;clip.target=vehicles[saved.target]
    clip.editingOwners=nil
    return true
end
-- Reconstruct the donor layout for a saved take whose original wheel/component
-- nodes no longer exist. These temporary nodes never receive physics or replay
-- updates. They only expose the recorded pose channels to the existing remapper.
function JLRSChange.savedDonor(c,clip,old)
    local saved=clip.saved
    if not saved or not c.changePending then return nil end
    local first=JLRSFrames.get(clip.frames,1)
    if not first or not first.pose then return nil end
    local vehicles,donors,layouts={},{},{}
    for vi,desc in ipairs(saved.vehicles or {}) do
        local v,reason=JLRSChange.resolveSavedVehicle(c,desc,old)
        if not v then clip.changeBindReason=reason;return nil end
        vehicles[vi]=v
        if v==old then
            donors[vi]={rootNode=old.rootNode,configFileName=desc.config,components={},spec_wheels={wheels={}}}
            layouts[vi]={}
        end
    end
    local entries={};local source
    for i,desc in ipairs(saved.entries or {}) do
        local donor=donors[desc.vehicle]
        if not donor then
            -- Other vehicles keep their actual, individually resolved nodes.
            local v=vehicles[desc.vehicle];local slots,seen={},{}
            local function add(n,w,ci)
                if n and n~=0 and entityExists(n) and not seen[n] then seen[n]=true;slots[#slots+1]={node=n,world=w,parent=getParent(n),vehicle=v,componentIndex=ci} end
            end
            for ci,comp in ipairs(v.components or {}) do add(comp.node,true,ci) end
            add(v.rootNode,true)
            local function wheel(w) add(w.repr,false);add(w.driveNode,false);for _,child in ipairs(w.additionalWheels or {}) do wheel(child) end end
            for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {}) do wheel(w) end
            local e=slots[desc.slot]
            if not e or (e.world and 1 or 0)~=desc.world then clip.changeBindReason='node kendaraan lain tidak tersedia';return nil end
            entries[i]=e
        else
            if type(desc.slot)~='number' or desc.slot<1 or desc.slot%1~=0 or desc.slot>math.max(saved.vehicles[desc.vehicle].nodes or 0,#saved.entries)
                or (desc.world~=0 and desc.world~=1) then clip.changeBindReason='slot tersimpan tidak valid';return nil end
            local n=(i-1)*6
            for j=1,6 do if type(first.pose[n+j])~='number' then clip.changeBindReason='pose tersimpan tidak lengkap';return nil end end
            local layout=layouts[desc.vehicle];local e=layout[desc.slot]
            if e then clip.changeBindReason='slot rekaman duplikat';return nil end
            local root=desc.slot==1 and desc.world==1
            local node=root and old.rootNode or createTransformGroup('JLRS_Change_Saved_'..desc.slot)
            if not root then
                c.changePending.helpers[node]=true;link(old.rootNode,node)
                if desc.world==1 then
                    setWorldTranslation(node,first.pose[n+1],first.pose[n+2],first.pose[n+3]);setWorldRotation(node,first.pose[n+4],first.pose[n+5],first.pose[n+6])
                else
                    setTranslation(node,first.pose[n+1],first.pose[n+2],first.pose[n+3]);setRotation(node,first.pose[n+4],first.pose[n+5],first.pose[n+6])
                end
            end
            e={node=node,world=desc.world==1,parent=getParent(node),vehicle=donor,savedName=desc.name,slot=desc.slot}
            entries[i]=e;layout[desc.slot]=e;source=donor
        end
    end
    for vi,donor in pairs(donors) do
        local layout=layouts[vi];local localNodes={}
        local maxSlot=saved.vehicles[vi].nodes or 0
        for slot in pairs(layout) do maxSlot=math.max(maxSlot,slot) end
        for slot=1,maxSlot do
            local e=layout[slot]
            if e then
                if e.world then donor.components[#donor.components+1]={node=e.node};e.componentIndex=#donor.components
                else localNodes[#localNodes+1]=e end
            end
        end
        if not layout[1] or not layout[1].world then clip.changeBindReason='root tersimpan tidak tersedia';return nil end
        for wi=1,#localNodes,2 do
            local repr,drive=localNodes[wi],localNodes[wi+1]
            local actual=(old.spec_wheels and old.spec_wheels.wheels or {})[math.ceil(wi/2)]
            donor.spec_wheels.wheels[#donor.spec_wheels.wheels+1]={repr=repr.node,driveNode=drive and drive.node,radius=actual and (actual.radius or (actual.physics and actual.physics.radius)) or 1}
        end
    end
    if not source then return nil end
    return {entries=entries,source=source,vehicles=vehicles,target=vehicles[saved.target]}
end
function JLRSChange.savedWorldDonor(c,saved,old)
    local donor={rootNode=old.rootNode,configFileName=saved.object.config,components={},spec_wheels={wheels={}}}
    local locals={}
    local group={object=donor,vehicle=true,entries={}}
    local root
    for i,e in ipairs(saved.entries or {}) do
        if e.world==1 and e.component==0 then root=i;break end
    end
    if not root then for i,e in ipairs(saved.entries or {}) do if e.world==1 and e.component==1 then root=i;break end end end
    if not root then error('Root world History lama tidak tersedia.') end
    for i,e in ipairs(saved.entries) do
        local first=JLRSFrames.get(e.samples,1)
        if not first or not first.pose or #first.pose<6 then error('Sampel world History lama tidak lengkap.') end
        local node=old.rootNode
        if i~=root then
            node=createTransformGroup('JLRS_Change_Saved_World_'..i)
            c.changePending.helpers[node]=true;link(getRootNode(),node)
            if e.world==1 then
                setWorldTranslation(node,first.pose[1],first.pose[2],first.pose[3])
                setWorldRotation(node,first.pose[4],first.pose[5],first.pose[6])
            else
                link(old.rootNode,node)
                setTranslation(node,first.pose[1],first.pose[2],first.pose[3])
                setRotation(node,first.pose[4],first.pose[5],first.pose[6])
            end
        end
        local entry={node=node,world=e.world==1,parent=getParent(node),vehicle=donor,componentIndex=e.component,samples=e.samples}
        group.entries[#group.entries+1]=entry
        if e.world==1 and (e.component or 0)>0 then donor.components[e.component]={node=node}end
        if e.world~=1 then locals[#locals+1]={entry=entry,slot=e.slot or i}end
    end
    -- Saved world groups now include wheel local slots, just like main takes.
    -- Reconstruct the conventional repr/drive pairs on private donor helpers.
    table.sort(locals,function(a,b)return a.slot<b.slot end)
    for i=1,#locals,2 do
        local repr,drive=locals[i].entry,locals[i+1]and locals[i+1].entry
        local actual=(old.spec_wheels and old.spec_wheels.wheels or {})[math.ceil(i/2)]
        donor.spec_wheels.wheels[#donor.spec_wheels.wheels+1]={repr=repr.node,driveNode=drive and drive.node,
            radius=actual and (actual.radius or (actual.physics and actual.physics.radius))or 1}
    end
    return group
end
function JLRSChange.plan(c,old,new,restoreSaved,groupsOnly)
    local plan={clips={},groups={},old=old,new=new};local mappedByFrames={};local groups={}
    for _,clip in ipairs(c.history or {}) do
        JLRSPersist.bind(clip,true)
        if not groupsOnly then
        local ownsRecording=false
        for vi,d in ipairs(clip.saved and clip.saved.vehicles or {}) do
            if d.id==old.jlrsPersistentId then
                for _,entry in ipairs(clip.saved.entries or {}) do if entry.vehicle==vi then ownsRecording=true;break end end
            end
        end
        local donor
        if restoreSaved and ownsRecording then donor=JLRSChange.savedDonor(c,clip,old)
        elseif ownsRecording and not JLRSChange.contains(clip.entries,old) then JLRSChange.rebind(c,clip,old) end
        if not donor and ownsRecording and not JLRSChange.contains(clip.entries,old) then donor=JLRSChange.savedDonor(c,clip,old) end
        if ownsRecording and not JLRSChange.contains(clip.entries,old) and not donor then error('History #'..clip.id..' belum dapat dipasangkan ke mobil lama: '..tostring(clip.changeBindReason or 'node record tidak tersedia')..'. Mobil lama dipertahankan.') end
        if donor or JLRSChange.contains(clip.entries,old) then
            local mapped=mappedByFrames[clip.frames]
            if not mapped then mapped=JLRSChange.adapt(donor and donor.entries or clip.entries,clip.frames,donor and donor.source or old,new,false,c);mappedByFrames[clip.frames]=mapped end
            plan.clips[#plan.clips+1]={clip=clip,mapped=mapped,donor=donor}
        end
        end
        for gi,group in ipairs(clip.worldScene and clip.worldScene.groups or {}) do
            if group.object==old then
                local replacement=groups[group]
                if not replacement then replacement=worldGroup(c,group,new);groups[group]=replacement end
                local savedIndex=gi
                for si,g in ipairs(clip.saved and clip.saved.groups or {}) do if g.object.vehicle and g.object.id==old.jlrsPersistentId then savedIndex=si;break end end
                plan.groups[#plan.groups+1]={clip=clip,index=gi,savedIndex=savedIndex,group=replacement,scene=clip.worldScene}
            end
        end
        -- History whose main vehicle is missing can still retain a recorded background vehicle.
        if not clip.worldScene and clip.saved then
            for gi,g in ipairs(clip.saved.groups) do
                if g.object.id==old.jlrsPersistentId and g.object.vehicle then
                    if restoreSaved then
                        -- Saved world slots describe donor rigid bodies. A slot
                        -- can now be a wheel on the replacement; reconstruct the
                        -- donor instead of binding it to the current node list.
                        local group=JLRSChange.savedWorldDonor(c,g,old)
                        plan.groups[#plan.groups+1]={clip=clip,index=gi,group=worldGroup(c,group,new),savedOnly=true}
                    else
                    local group={object=old,vehicle=true,entries={}}
                    local topology=JLRSRecorder.topology(old)
                    for _,e in ipairs(g.entries) do
                        local bound
                        if (e.slot or 0)>0 then
                            bound=topology[e.slot]
                            if not bound or (bound.world and 1 or 0)~=(e.world or 1) then error('Slot world History lama tidak cocok.') end
                        elseif (e.component or 0)>0 then
                            local component=(old.components or {})[e.component]
                            if component then bound={node=component.node,world=true,componentIndex=e.component} end
                        else
                            -- Legacy component 0 is a separate root, not components[0].
                            bound={node=old.rootNode,world=true}
                        end
                        if not bound or not bound.node or not entityExists(bound.node) then error('Komponen world History lama tidak cocok.') end
                        local entry=JLRSChange.copy(bound)
                        entry.parent=getParent(entry.node);entry.vehicle=old;entry.samples=e.samples
                        group.entries[#group.entries+1]=entry
                    end
                    plan.groups[#plan.groups+1]={clip=clip,index=gi,group=worldGroup(c,group,new),savedOnly=true}
                    end
                end
            end
        end
    end
    return plan
end
local function listReplace(list,old,new)
    local out={};for i,v in ipairs(list or {}) do out[i]=v==old and new or v end;return out
end
local function sceneRebuild(scene)
    scene.entries={}
    for _,g in ipairs(scene.groups) do
        g.first=#scene.entries+1
        for _,e in ipairs(g.entries) do scene.entries[#scene.entries+1]=e end
    end
end
-- Keep native root/component/local-node slots when a world group is persisted.
function JLRSChange.describeGroup(vehicle,group)
    local slots={};for index,entry in ipairs(JLRSRecorder.topology(vehicle)) do slots[entry.node]=index end
    local saved={object=JLRSPersist.objectDesc(vehicle),entries={}}
    saved.object.remapped=true
    for _,entry in ipairs(group.entries) do
        local slot=slots[entry.node]
        if not slot then error('Node world mobil pengganti tidak dapat disimpan.') end
        saved.entries[#saved.entries+1]={component=entry.componentIndex or 0,slot=slot,world=entry.world and 1 or 0,samples=entry.samples}
    end
    return saved
end
function JLRSChange.applyPlan(c,plan)
    local undo={clips={},scenes={}}
    local old,new=plan.old,plan.new
    local function capture(clip)
        if undo.clips[clip] then return end
        undo.clips[clip]={entries=clip.entries,frames=clip.frames,target=clip.target,vehicles=clip.vehicles,name=clip.name,saved=clip.saved,bound=clip.bound,restored=clip.restored}
    end
    for _,p in ipairs(plan.clips) do
        local clip=p.clip;capture(clip)
        clip.entries=p.mapped.entries;clip.frames=p.mapped.frames;clip.vehicles=p.vehicles or listReplace(p.donor and p.donor.vehicles or clip.vehicles,old,new)
        if p.target then clip.target=p.target
        elseif clip.target==old or (p.donor and p.donor.target==old) then clip.target=new;clip.name=new:getName() end
        clip.saved=nil;clip.restored=false;clip.bound=true
        local saved=JLRSPersist.describe(clip)
        if undo.clips[clip].saved then
            saved.groups=JLRSChange.copy(undo.clips[clip].saved.groups)
            saved.sceneCount=undo.clips[clip].saved.sceneCount
            saved.sceneDuration=undo.clips[clip].saved.sceneDuration
        end
        JLRSPersist.sceneClock(clip)
    end
    for _,p in ipairs(plan.groups) do
        local clip=p.clip;capture(clip)
        if p.savedOnly then
            local saved=JLRSChange.copy(clip.saved);saved.groups=JLRSChange.copy(clip.saved.groups)
            local g=JLRSChange.describeGroup(p.vehicle or new,p.group)
            saved.groups[p.index]=g;clip.saved=saved
        else
            local scene=p.scene
            if not undo.scenes[scene] then undo.scenes[scene]={groups=scene.groups,entries=scene.entries};scene.groups=JLRSChange.copy(scene.groups) end
            scene.groups[p.index]=p.group;sceneRebuild(scene)
            local previous=clip.saved or JLRSPersist.describe(clip)
            local saved=JLRSChange.copy(previous);saved.groups=JLRSChange.copy(previous.groups)
            local g=JLRSChange.describeGroup(p.vehicle or new,p.group)
            saved.groups[p.savedIndex or p.index]=g;clip.saved=saved
        end
    end
    return undo
end
function JLRSChange.rollback(c,undo)
    for clip,s in pairs(undo.clips) do
        clip.entries=s.entries;clip.frames=s.frames;clip.target=s.target;clip.vehicles=s.vehicles;clip.name=s.name
        clip.saved=s.saved;clip.bound=s.bound;clip.restored=s.restored
    end
    for scene,s in pairs(undo.scenes) do scene.groups=s.groups;scene.entries=s.entries end
end
function JLRSChange.clean(c,t)
    for node in pairs(t.helpers or {}) do if entityExists(node) then delete(node) end end
    t.helpers={}
    for _,f in ipairs(t.streams or {}) do
        local used=false
        for _,clip in ipairs(c.history or {}) do
            if clip.frames==f then used=true;break end
            for _,g in ipairs(clip.saved and clip.saved.groups or {}) do for _,e in ipairs(g.entries) do if e.samples==f then used=true end end end
        end
        if not used and f._jlrs and not f._jlrs.released then f._jlrs.persistent=false;JLRSFrames.release(f) end
    end
end
function JLRSChange.cancel(c,message)
    local t=c.changePending
    if t then
        if t.newVehicle and JLRSRecorder.valid(t.newVehicle) then
            local new=t.newVehicle
            if t.newReturnPose then
                pcall(function()
                    if new.isAddedToPhysics then new:removeFromPhysics() end
                    JLRSRecorder.apply(t.newEntries,t.newReturnPose,true);new:addToPhysics()
                end)
            elseif t.detached then pcall(new.addToPhysics,new) end
            if t.identityChanged then new.jlrsPersistentId=t.newOriginalId;new.jlrsIdentitySaved=t.newOriginalSaved end
        end
        if t.leftOld and JLRSRecorder.valid(t.old) and c.mission.controlledVehicle==nil then pcall(c.mission.requestToEnterVehicle,c.mission,t.old) end
        JLRSChange.clean(c,t)
    end
    c.changePending=nil
    if c.changeOpen and c.mission then JLRSChange.items(c) end
    if message then c:notify(message) end
end
-- Retire the selected vehicle through the mission, checking its actual bodies.
-- Some callbacks only unregister/queue removal; do not mistake that for deletion.
function JLRSChange.retire(c,old)
    local bodies={}
    if old.rootNode then bodies[old.rootNode]=true end
    for _,component in pairs(old.components or {}) do
        if component.node then bodies[component.node]=true end
    end
    local function alive()
        for node in pairs(bodies) do if entityExists(node) then return true end end
        return false
    end
    local function registered()
        for _,vehicle in pairs(c.mission.vehicles or {}) do if vehicle==old then return true end end
        return false
    end
    local ok,err=pcall(c.mission.removeVehicle,c.mission,old,true)
    -- Allow a queued native deletion to finish on subsequent game updates.
    for i=1,8 do
        if not alive() and not registered() then break end
        coroutine.yield()
    end
    if alive() and not old.isDeleted and not old.isDeleting then
        -- Use the base FS22 lifecycle, including specialization onDelete events,
        -- if an instance-specific delete callback left the original bodies alive.
        local nativeDelete=Vehicle and Vehicle.delete or old.delete
        if type(nativeDelete)=='function' then
            ok,err=pcall(nativeDelete,old)
        end
    end
    for i=1,8 do
        if not alive() and not registered() then break end
        coroutine.yield()
    end
    if alive() then return false,tostring(err or 'badan mobil lama masih aktif') end
    if registered() then
        -- No raw scene-node deletion or manual registry edits: leave cleanup to FS22.
        return false,'badan mobil terhapus tetapi daftar native belum diperbarui',true
    end
    return true
end
function JLRSChange.finish(c,t,plan)
    if not JLRSRecorder.valid(t.old) or not JLRSRecorder.valid(t.newVehicle) then error('Mobil berubah saat proses Change.') end
    local new,old=t.newVehicle,t.old;t.sync=true
    local oldEntries=JLRSRecorder.topology(old);local pose=JLRSRecorder.capture(oldEntries)
    if not pose then error('Posisi mobil lama tidak tersedia.') end
    local aligned=JLRSChange.adapt(oldEntries,{{t=0,pose=pose}},old,new,false,c)
    if not JLRSRecorder.apply(aligned.entries,JLRSFrames.get(aligned.frames,1).pose) then error('Posisi mobil pengganti gagal diterapkan.') end
    new:addToPhysics();t.detached=false
    local controlled=c.mission.controlledVehicle==old
    if controlled then
        -- Enterable.doLeaveVehicle uses this native mission exit callback.
        -- requestToEnterVehicle(nil) is not an exit request in FS22.
        c.mission:onLeaveVehicle()
        t.leftOld=true
        for i=1,120 do
            if c.mission.controlledVehicle~=old then break end
            coroutine.yield()
        end
        if c.mission.controlledVehicle==old then error('Keluar native dari mobil lama belum selesai; kedua mobil dipertahankan.') end
    end
    local undo=JLRSChange.applyPlan(c,plan)
    if not JLRSPersist.safeSave(c) then JLRSChange.rollback(c,undo);error('History pengganti belum tersimpan. Mobil lama dan pembelian baru dipertahankan.') end
    local ok,err,retired=JLRSChange.retire(c,old)
    if not ok and not retired then
        JLRSChange.rollback(c,undo);JLRSPersist.safeSave(c);error('Mobil lama tidak dapat dihapus: '..tostring(err))
    end
    if retired then print('[J_L Cinema Studio] CHANGE REMOVE | '..tostring(err)) end
    for _,p in ipairs(plan.clips) do
        if c.frames==undo.clips[p.clip].frames then
            c.frames=p.clip.frames;c.entries=p.clip.entries;c.recordVehicles=p.clip.vehicles;c.target=p.clip.target;c.frameIndex=1
        end
    end
    if c.target==old then c.target=new end
    if c.cameraTarget==old then c.cameraTarget=new end
    if c.angleMemory and c.angleMemory[old] then c.angleMemory[new]=c.angleMemory[old];c.angleMemory[old]=nil end
    if c.objectTarget and c.objectTarget.rootNode==old.rootNode then c.objectTarget.rootNode=new.rootNode end
    if c.objectReturn and c.objectReturn.cameraTarget==old then c.objectReturn.cameraTarget=new end
    c.changeTarget=new;c.worldRecord=nil
    if controlled then pcall(c.mission.requestToEnterVehicle,c.mission,new) end
    JLRSChange.clean(c,t);c.changePending=nil
    local used={}
    for _,clip in ipairs(c.history) do
        used[clip.frames]=true
        for _,g in ipairs(clip.saved and clip.saved.groups or {}) do for _,e in ipairs(g.entries) do used[e.samples]=true end end
    end
    for _,f in pairs(JLRSFrames.stores) do if not used[f] then f._jlrs.persistent=false end end
    JLRSUnlimited.prune(c);JLRSChange.items(c)
    c.changeOpen=false;c.changeHits={};JLRSChange.iconsClear(c);JLRSMouse.refresh(c)
    if retired then
        c:notify('Replay sudah dipindahkan; pembersihan daftar kendaraan native belum selesai. Lihat CHANGE REMOVE di log.')
    else
        c:notify('CHANGE BERHASIL | mobil lama terhapus | '..new:getName()..' | Replay & History tetap tersedia. Save Game sebelum keluar.')
    end
end
local function ownedCar(v)
    if JLRSWorld.isTrain(v) then return false end
    return JLRSRecorder.valid(v) and v.spec_enterable~=nil and v.spec_motorized~=nil
        and (not Vehicle or v.propertyState~=Vehicle.PROPERTY_STATE_SHOP_CONFIG)
end
function JLRSChange.items(c)
    local list={};for _,v in pairs(c.mission.vehicles or {}) do if ownedCar(v) then list[#list+1]=v end end
    table.sort(list,function(a,b)
        local an,bn=a:getName():lower(),b:getName():lower()
        if an~=bn then return an<bn end;return JLRSPersist.identity(a)<JLRSPersist.identity(b)
    end)
    c.changeItems=list;c.changePage=math.max(1,math.min(c.changePage or 1,math.max(1,math.ceil(#list/JLRSChange.ROWS))))
end
function JLRSChange.open(c)
    if c.changePending then c.changeOpen=true;return end
    c:stop();JLRSPersist.load(c);c.menu=false;c.historyOpen=false;c.objectPicking=false
    JLRSChange.iconsClear(c)
    c.changeOpen=true;c.changeTarget=nil;c.changePage=1;c.changeHits={};c.changeIcons={};JLRSChange.items(c);JLRSMouse.refresh(c)
end
function JLRSChange.close(c)
    if c.changePending then JLRSChange.cancel(c,'Change dibatalkan. Mobil lama dan mobil yang sudah dibeli tetap tersedia.') end
    c.changeOpen=false;c.changeHits={};JLRSChange.iconsClear(c);JLRSMouse.refresh(c)
end
function JLRSChange.begin(c)
    if c.changePending then return end
    local old=c.changeTarget
    if not ownedCar(old) then c:notify('Pilih mobil di daftar map dahulu.');return end
    if not coroutine or not coroutine.create or not coroutine.resume or not coroutine.yield then c:notify('API proses bertahap FS22 tidak tersedia. Change belum dimulai.');return end
    if not g_server or not g_messageCenter or not BuyVehicleEvent then c:notify('Change Cars memerlukan Store dan single player FS22.');return end
    if type(c.mission.removeVehicle)~='function' or type(Vehicle and Vehicle.delete or old.delete)~='function' then c:notify('API penghapusan kendaraan native tidak tersedia.');return end
    if (old.getAttachedImplements and #old:getAttachedImplements()>0) or (old.getAttacherVehicle and old:getAttacherVehicle()) then c:notify('Lepaskan trailer/implement dari mobil sebelum Change.');return end
    if old.getIsAIActive and old:getIsAIActive() then c:notify('Hentikan AI sebelum Change.');return end
    if c.mission.controlledVehicle==old and (type(c.mission.onLeaveVehicle)~='function' or type(c.mission.requestToEnterVehicle)~='function') then c:notify('Keluar dari mobil dahulu sebelum Change.');return end
    c:stop();JLRSPersist.load(c)
    if not JLRSPersist.safeSave(c) then return end
    local snapshot={};for _,v in pairs(c.mission.vehicles or {}) do snapshot[v]=true end
    c.changePending={old=old,snapshot=snapshot,streams={},helpers={},done=0,wasControlled=c.mission.controlledVehicle==old,farm=old.getOwnerFarmId and old:getOwnerFarmId() or nil}
    local ok,err=pcall(function()
        if not g_gui or not g_gui.showGui then error('GUI Store tidak tersedia.') end
        if g_gui.guis and g_gui.guis.ShopMenu then g_gui:showGui('ShopMenu')
        elseif g_gui.guis and g_gui.guis.InGameMenu and InGameMenu and g_gui.guis.InGameMenu.target then
            g_gui.guis.InGameMenu.target:setMode(InGameMenu.MODE_SHOP);g_gui:showGui('InGameMenu')
        else error('Menu Store native tidak ditemukan.') end
    end)
    if not ok then JLRSChange.cancel(c,'Store gagal dibuka: '..tostring(err));return end
    c:notify('CHANGE CARS | beli satu mobil pengganti di Store, lalu tutup Store. Harga & konfigurasi mengikuti FS22.')
end
function JLRSChange.purchase(c,errorCode,leaseVehicle)
    local t=c.changePending;if not t or t.confirmed then return end
    local success=BuyVehicleEvent and BuyVehicleEvent.BUY_SUCCESS or 0
    if errorCode~=success then t.buyFailed=true;return end
    if leaseVehicle then JLRSChange.cancel(c,'Lease tidak mengganti mobil. Gunakan pembelian Buy di Store.');return end
    t.confirmed=true;t.waitClock=g_time or 0
end
function JLRSChange.tick(c)
    local t=c.changePending
    if not t then
        if c.changeOpen and (g_time or 0)>=(c.changeRefresh or 0) then
            JLRSChange.items(c);c.changeRefresh=(g_time or 0)+1000
            if c.changeTarget and not JLRSRecorder.valid(c.changeTarget) then c.changeTarget=nil end
        end
        return
    end
    local gui=g_gui and g_gui:getIsGuiVisible()
    if gui then t.sawGui=true end
    if t.confirmed and not t.newVehicle then
        local candidates={}
        for _,v in pairs(c.mission.vehicles or {}) do
            if not (t.buySnapshot or t.snapshot)[v] and ownedCar(v)
                and (not t.filename or v.configFileName==t.filename)
                and (not t.farm or not v.getOwnerFarmId or v:getOwnerFarmId()==t.farm) then candidates[#candidates+1]=v end
        end
        if #candidates>1 then JLRSChange.cancel(c,'Lebih dari satu mobil baru ditemukan. Change dibatalkan; semua mobil tetap ada.');return end
        if #candidates==1 then t.newVehicle=candidates[1] end
    end
    if gui then return end
    if t.sawGui and not t.confirmed then JLRSChange.cancel(c,'Store ditutup tanpa pembelian. Mobil lama tetap tersedia.');return end
    if not t.confirmed then return end
    if not t.newVehicle then
        if (g_time or 0)-(t.waitClock or 0)>30000 then JLRSChange.cancel(c,'Mobil yang dibeli belum ditemukan. Mobil lama tetap tersedia.');return end
        return
    end
    if not t.worker then
        t.worker=coroutine.create(function()
            local new=t.newVehicle
            if type(new.removeFromPhysics)~='function' or type(new.addToPhysics)~='function' then error('Physics mobil pengganti tidak tersedia.') end
            t.newEntries=JLRSRecorder.topology(new);t.newReturnPose=JLRSRecorder.capture(t.newEntries)
            new:removeFromPhysics();t.detached=true
            t.newOriginalId=JLRSPersist.identity(new);t.newOriginalSaved=new.jlrsIdentitySaved;t.identityChanged=true
            -- The logical identity follows the replacement; its model/topology are updated in History.
            local plan=JLRSChange.plan(c,t.old,new)
            new.jlrsPersistentId=JLRSPersist.identity(t.old);new.jlrsIdentitySaved=false
            JLRSChange.finish(c,t,plan)
        end)
    end
    local ok,err=coroutine.resume(t.worker)
    if not ok then JLRSChange.cancel(c,'Change gagal; mobil lama dan pembelian baru dipertahankan. '..tostring(err)) end
end
function JLRSChange.cursor(c)
    return c.changeOpen and not c.menu and not (g_gui and g_gui:getIsGuiVisible())
end
function JLRSChange.iconsClear(c)
    for _,id in pairs(c.changeIcons or {}) do if id and id~=0 then delete(id) end end
    c.changeIcons={}
end
function JLRSChange.draw(c)
    c.changeHits={}
    if not JLRSChange.cursor(c) or not c.overlay then return end
    local original=c.hitboxes;c.hitboxes={}
    JLRSMenu.rect(c,0.22,0.18,0.56,0.65,0.015,0.023,0.037,0.98)
    JLRSMenu.rect(c,0.22,0.76,0.56,0.07,0.025,0.16,0.23)
    JLRSMenu.text(0.24,0.789,0.023,'CHANGE CARS',0.12,0.85,0.9)
    JLRSMenu.button(c,0.724,0.783,0.037,0.033,'X',function() JLRSChange.close(c) end)
    JLRSMenu.text(0.24,0.733,0.011,'MOBIL DI MAP | pilih mobil lama, lalu Change untuk membuka Store')
    local list=c.changeItems or {};local pages=math.max(1,math.ceil(#list/JLRSChange.ROWS))
    c.changePage=math.max(1,math.min(c.changePage or 1,pages))
    local visible={}
    for row=1,JLRSChange.ROWS do
        local index=(c.changePage-1)*JLRSChange.ROWS+row;local v=list[index]
        if v then
            local y=0.65-(row-1)*0.061
            local selected=c.changeTarget==v
            JLRSMenu.button(c,0.24,y,0.52,0.054,'',function() if not c.changePending then c.changeTarget=v end end,selected)
            local item=g_storeManager and g_storeManager:getItemByXMLFilename(v.configFileName or '')
            local image=item and item.imageFilename
            if image and image~='' then
                visible[image]=true
                local id=c.changeIcons[image]
                if not id then id=createImageOverlay(image);if id and id~=0 then c.changeIcons[image]=id end end
                if id and id~=0 then setOverlayColor(id,1,1,1,1);renderOverlay(id,0.25,y+0.003,0.048/(g_screenWidth and g_screenHeight and g_screenWidth/g_screenHeight or 16/9),0.048) end
            else JLRSMenu.text(0.253,y+0.02,0.009,'MOBIL',0.65,0.74,0.83) end
            JLRSMenu.text(0.33,y+0.027,0.013,string.format('%02d  %s',index,v:getName()):sub(1,43))
            local count=0
            for _,clip in ipairs(c.history) do if clip.target==v or JLRSChange.contains(clip.entries,v) then count=count+1 end end
            JLRSMenu.text(0.33,y+0.008,0.010,tostring(count)..' rekaman | '..(selected and 'DIPILIH' or 'Klik untuk memilih'),0.65,0.74,0.83)
        end
    end
    for image,id in pairs(c.changeIcons or {}) do if not visible[image] then delete(id);c.changeIcons[image]=nil end end
    if #list==0 then JLRSMenu.text(0.24,0.62,0.014,'Belum ada mobil yang dapat dikendarai di map.') end
    JLRSMenu.button(c,0.24,0.309,0.07,0.03,'<',function() c.changePage=math.max(1,c.changePage-1) end)
    JLRSMenu.text(0.325,0.319,0.011,string.format('%d / %d | %d mobil | Scroll daftar',c.changePage,pages,#list))
    JLRSMenu.button(c,0.69,0.309,0.07,0.03,'>',function() c.changePage=math.min(pages,c.changePage+1) end)
    if c.changeTarget then
        JLRSMenu.button(c,0.24,0.259,0.52,0.038,c.changePending and ('MENYIAPKAN REPLAY | '..c.changePending.done..' sampel') or 'CHANGE — BUKA STORE FS22',function() JLRSChange.begin(c) end,true)
    end
    JLRSMenu.text(0.24,0.234,0.010,'Beli satu mobil, lalu tutup Store. Pembatalan mempertahankan mobil lama.')
    JLRSMenu.text(0.24,0.212,0.010,(c.notice or ''):sub(1,78),1,0.75,0.35)
    JLRSMenu.text(0.24,0.189,0.009,'©Copyright 2023 | Jupryan Lowlight',0.65,0.74,0.83)
    c.changeHits=c.hitboxes;c.hitboxes=original
end
-- Capture the native Buy confirmation, excluding vehicles created before that purchase.
if ShopConfigScreen and ShopConfigScreen.onYesNoBuy then
    local buy=ShopConfigScreen.onYesNoBuy
    ShopConfigScreen.onYesNoBuy=function(screen,yes,...)
        local c=JLReplayStudio;local t=c and c.changePending
        if t and yes and not t.confirmed then
            t.buySnapshot={};for _,v in pairs(c.mission.vehicles or {}) do t.buySnapshot[v]=true end
            local item=screen.storeItem or screen.currentStoreItem
            t.filename=item and item.xmlFilename or nil
        end
        return buy(screen,yes,...)
    end
end
local refresh=JLRSMouse.refresh
JLRSMouse.refresh=function(c,...)
    local result=refresh(c,...)
    if JLRSChange.cursor(c) and g_inputBinding then g_inputBinding:setShowMouseCursor(true) end
    return result
end
local axis=JLRSCamera.mouseAxis
JLRSCamera.mouseAxis=function(c,...)
    if JLRSChange.cursor(c) then return end
    return axis(c,...)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    if c.mission then JLRSChange.tick(c) end
    local result=draw(c,...)
    if c.mission then JLRSChange.draw(c) end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);if not c.mission then return result end
    c.changeOpen=false;c.changePending=nil;c.changeTarget=nil;c.changeHits={};c.changeIcons={}
    if g_messageCenter and BuyVehicleEvent then
        c.changePurchase=function(_,errorCode,leaseVehicle,...) JLRSChange.purchase(c,errorCode,leaseVehicle) end
        g_messageCenter:subscribe(BuyVehicleEvent,c.changePurchase,c)
    end
    c.changeOldMouse=c.mission.mouseEvent
    c.changeMouse=function(m,x,y,isDown,isUp,button,...)
        if c.changeConsumeRelease and isUp and button==Input.MOUSE_BUTTON_LEFT then c.changeConsumeRelease=false;return end
        if JLRSChange.cursor(c) then
            if isDown and (button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN) and x>=0.24 and x<=0.76 and y>=0.34 and y<=0.71 then
                local pages=math.max(1,math.ceil(#(c.changeItems or {})/JLRSChange.ROWS))
                c.changePage=math.max(1,math.min(pages,(c.changePage or 1)+(button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1)));return
            end
            if isDown and button==Input.MOUSE_BUTTON_LEFT then
                c.changeConsumeRelease=true
                -- Keep the stable Mini HUD click priority.
                for _,hits in ipairs({c.miniHudEnabled and c.miniHudHits or {},c.changeHits or {}}) do
                    for _,h in ipairs(hits) do if x>=h.x and x<=h.x+h.w and y>=h.y and y<=h.y+h.h then h.callback(x,y);return end end
                end
                return
            end
            if button==Input.MOUSE_BUTTON_LEFT then return end
        end
        return c.changeOldMouse(m,x,y,isDown,isUp,button,...)
    end
    c.mission.mouseEvent=c.changeMouse;return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.changePending then JLRSChange.cancel(c) end
    c.changeOpen=false;JLRSChange.iconsClear(c)
    if g_messageCenter and BuyVehicleEvent and c.changePurchase then g_messageCenter:unsubscribe(BuyVehicleEvent,c) end
    if c.mission and c.mission.mouseEvent==c.changeMouse then c.mission.mouseEvent=c.changeOldMouse end
    local result=deleteMap(c,...);c.changeMouse=nil;c.changeOldMouse=nil;c.changePurchase=nil;return result
end
local record=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c==JLReplayStudio and c.changePending then c:notify('Tunggu Change Cars selesai sebelum Record.');return end
    if c==JLReplayStudio and c.changeOpen then JLRSChange.close(c) end
    return record(c,...)
end
local replay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c==JLReplayStudio and c.changePending then c:notify('Tunggu Change Cars selesai sebelum Replay.');return end
    if c==JLReplayStudio and c.changeOpen then JLRSChange.close(c) end
    return replay(c,...)
end
local historyPlay=JLRSHistory.replay
JLRSHistory.replay=function(c,...)
    if c.changePending then c:notify('Tunggu Change Cars selesai sebelum Replay.');return end
    if c.changeOpen then JLRSChange.close(c) end
    return historyPlay(c,...)
end
local all=JLRSGroup.all
JLRSGroup.all=function(c,...)
    if c.changePending then c:notify('Tunggu Change Cars selesai sebelum Replay All.');return end
    if c.changeOpen then JLRSChange.close(c) end
    return all(c,...)
end
local remove=JLRSHistory.delete
JLRSHistory.delete=function(c,...)
    if c.changePending then c:notify('Tunggu Change Cars selesai sebelum menghapus History.');return end
    return remove(c,...)
end
-- Compatibility for takes already remapped by older Change Cars versions.
-- Reuse the sampled pose; no history conversion or full vehicle update per frame.
local wheelReplayTick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,dt)
    local result=wheelReplayTick(track,dt)
    if not track.replaying or track.paused or (track.frames and track.frames.jlrsRecordAll) then return result end
    local time=track.replayTime
    if not time or not track.frames then return result end
    local state=track.changeWheelReplay
    if not state or state.entries~=track.entries then
        local initial=JLRSFrames.get(track.frames,1)
        state={entries=track.entries,wheels={},pose=initial.pose,time=initial.t};track.changeWheelReplay=state
        local roles,roots={},{}
        for i,e in ipairs(track.entries) do if e.world and e.vehicle and e.node==e.vehicle.rootNode then roots[e.vehicle]=(i-1)*6 end end
        for _,vehicle in ipairs(track.recordVehicles or {track.target}) do
            for node,role in pairs(JLRSChange.wheelRoles(vehicle)) do roles[node]={role=role,vehicle=vehicle} end
        end
        for i,e in ipairs(track.entries) do
            if e.world and e.node==track.target.rootNode then state.root=(i-1)*6 end
            local found=roles[e.node]
            if found and found.role.kind=='drive' and not e.world and roots[found.vehicle] then
                state.wheels[#state.wheels+1]={node=e.node,offset=(i-1)*6,root=roots[found.vehicle],vehicle=found.vehicle,radius=math.max(0.001,found.role.radius)}
            end
        end
    end
    if not state.root or #state.wheels==0 then return result end
    local pose=track.replayAudioTime==time and track.replayAudioPose or JLRSRecorder.sample(track,time)
    local previous=state.pose
    if previous and state.time and time>state.time then
        for _,wheel in ipairs(state.wheels) do
            -- Cargo wheels use their own motion relative to the carrier.
            local n=wheel.root;local dx=pose[n+1]-previous[n+1];local dz=pose[n+3]-previous[n+3]
            local yaw=pose[n+5]
            local travel=math.sqrt(dx*dx+dz*dz)*((dx*math.sin(yaw)+dz*math.cos(yaw))<0 and -1 or 1)
            if JLRSTrailerReplay then travel=JLRSTrailerReplay.travel(track,wheel.vehicle,pose,previous,travel)end
            local o=wheel.offset
            -- Steering/camber changes on Y/Z must not suppress missing roll on X.
            local delta=math.abs(JLRSRecorder.angle(previous[o+4],pose[o+4],1)-previous[o+4])
            if delta<0.000001 and math.abs(travel)>0.000001 and entityExists(wheel.node) then
                wheel.spin=(wheel.spin or previous[o+4])+travel/wheel.radius
                setRotation(wheel.node,wheel.spin,pose[o+5],pose[o+6])
            else wheel.spin=pose[o+4] end
        end
    elseif state.time==time then
        -- Zero-delta ticks (Pause/seek/multiple render passes) must not erase
        -- displacement spin after the underlying replay reapplies donor poses.
        for _,wheel in ipairs(state.wheels) do
            local o=wheel.offset
            if wheel.spin and entityExists(wheel.node) then setRotation(wheel.node,wheel.spin,pose[o+5],pose[o+6]) end
        end
    else
        for _,wheel in ipairs(state.wheels) do wheel.spin=pose[wheel.offset+4] end
    end
    state.pose=pose;state.time=time
    return result
end
