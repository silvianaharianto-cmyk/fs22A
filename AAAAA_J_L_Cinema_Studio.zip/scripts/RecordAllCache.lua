-- Lossless in-memory chunk compaction during Record All only. The XML format,
-- samples, timestamps, stream IDs and native precision remain unchanged.
JLRSRecordAllCache={MIN_VALUES=128}
local C=JLRSRecordAllCache
local Q=JLRSWriteBudget
local compactMeta={__index=function(frame,key)
    if key~='pose' then return nil end
    local base=frame._base;local pose={}
    for i=1,#base do pose[i]=base[i] end
    for i,index in ipairs(frame._indices) do pose[index]=frame._values[i] end
    return pose
end}
function C.compact(item)
    local first=item.data[1];local base=first and first.pose
    if not base or #base<C.MIN_VALUES then return false end
    local changed=false
    for i=2,#item.data do
        local frame=item.data[i]
        -- Frames packed at capture already own exact sparse values. Do not
        -- expand them again merely to seal/account the chunk.
        local pose=not getmetatable(frame) and frame.pose
        if pose and pose~=base and #pose==#base then
            local indices,values={},{};local limit=math.floor(#base/4)
            for j=1,#base do if pose[j]~=base[j] then
                indices[#indices+1]=j;values[#values+1]=pose[j]
                if #indices>limit then break end
            end end
            if #indices<=limit then
                item.data[i]=setmetatable({t=frame.t,_base=base,_indices=indices,_values=values},compactMeta)
                changed=true
            end
        end
    end
    -- Account the retained numeric tables, not a future full XML copy for
    -- every queued frame. XML text is charged when the staged writer builds it.
    local bytes=256;local seen={}
    local function charge(p)
        if not seen[p] then seen[p]=true;bytes=bytes+#p*24+128 end
    end
    for i,frame in ipairs(item.data) do
        if getmetatable(frame)==compactMeta then
            charge(frame._base);charge(frame._indices);charge(frame._values);bytes=bytes+256
        else charge(frame.pose);bytes=bytes+128 end
        if item.encoded[i] then bytes=bytes+#item.encoded[i] end
    end
    item.compactCache=true;item.encodedCharged=#item.encoded
    Q.bytes=Q.bytes-item.bytes+bytes;item.bytes=bytes
    return changed
end
-- Pack when a frame enters the RAM buffer, rather than waiting for a full
-- chunk. A moving activity stream otherwise retains thousands of redundant
-- zero/unchanged slots during long Record All sessions. No values are rounded
-- or discarded; the base plus overrides reconstructs the exact original pose.
local push=JLRSFrames.push
JLRSFrames.push=function(frames,frame)
    local c=JLReplayStudio;local s=frames._jlrs
    if not s or not c.recording or not c.recordAllActive or not frame.pose
        or #frame.pose<C.MIN_VALUES then return push(frames,frame) end
    if #frames>=s.chunkSize then JLRSFrames.flush(frames) end
    local base=frames[1] and frames[1].pose
    local pose=frame.pose
    if base and #base==#pose and not getmetatable(frame) then
        local indices,values={},{};local limit=math.floor(#base/4)
        for j=1,#base do
            if pose[j]~=base[j] then
                indices[#indices+1]=j;values[#values+1]=pose[j]
                if #indices>limit then break end
            end
        end
        if #indices<=limit then
            frame=setmetatable({t=frame.t,_base=base,_indices=indices,_values=values},compactMeta)
        end
    end
    return push(frames,frame)
end
local flush=JLRSFrames.flush
JLRSFrames.flush=function(frames,...)
    local c=JLReplayStudio
    if not c.recording or not c.recordAllActive or not frames._jlrs or #frames==0 then return flush(frames,...) end
    local oldPeak=Q.peakBytes
    local result=flush(frames,...)
    local item=Q.queue[#Q.queue]
    if item and item.frames==frames and item.chunk==frames._jlrs.sealed then C.compact(item) end
    Q.peakBytes=math.max(oldPeak,Q.bytes)
    return result
end
local process=Q.process
Q.process=function(limit,...)
    local item=Q.queue[1]
    local result=process(limit,...)
    if item and item.compactCache and item.frames._jlrs.pending
        and item.frames._jlrs.pending[item.chunk]==item.data then
        local extra=0
        if item.encoder and not item.encoderCharged then
            extra=#(item.encoder.lastNumbers or {})*48+256;item.encoderCharged=true
        end
        local count=#item.encoded
        for i=(item.encodedCharged or 0)+1,count do extra=extra+#item.encoded[i] end
        item.encodedCharged=count
        Q.bytes=Q.bytes+extra;item.bytes=item.bytes+extra;Q.peakBytes=math.max(Q.peakBytes,Q.bytes)
    end
    return result
end
-- Finished chunks remain in the existing bounded replay cache. Expand a frame
-- once on first access there, so replay does not repeatedly rebuild its pose.
local get=JLRSFrames.get
JLRSFrames.get=function(frames,index,...)
    local frame=get(frames,index,...)
    if frame and getmetatable(frame)==compactMeta then
        local s=frames._jlrs;local chunk=math.floor((index-1)/s.chunkSize)+1
        if not (s.pending and s.pending[chunk]) then
            local pose=frame.pose
            frame._base=nil;frame._indices=nil;frame._values=nil
            rawset(frame,'pose',pose);setmetatable(frame,nil)
        end
    end
    return frame
end
