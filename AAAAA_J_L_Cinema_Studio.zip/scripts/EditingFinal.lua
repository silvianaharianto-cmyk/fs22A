-- Timeline decision lists reference immutable History IDs. Existing capture paths stay untouched.
JLRSFinalEditing={ROWS=6,SOURCES=6}
local E=JLRSFinalEditing
local function copyPlan(plan)
    local out={rows={}}
    for _,r in ipairs((plan or {}).rows or {}) do
        local n={ids={},start=r.start,sourceIn=r.sourceIn,length=r.length,enabled=r.enabled~=false,name=r.name}
        for _,id in ipairs(r.ids or {}) do n.ids[#n.ids+1]=id end
        if r.vehicleIds then n.vehicleIds={};for _,id in ipairs(r.vehicleIds)do n.vehicleIds[#n.vehicleIds+1]=id end end
        out.rows[#out.rows+1]=n
    end
    return out
end
E.copyPlan=copyPlan
local function finite(n)return type(n)=='number' and n==n and math.abs(n)<math.huge end
function E.parseTime(text)
    if type(text)~='string' then return end
    text=text:match('^%s*(.-)%s*$'):gsub(',','.')
    local minute,second=text:match('^(%d+):(%d+%.?%d*)$')
    local n
    if minute then if tonumber(second)>=60 then return end;n=tonumber(minute)*60+tonumber(second)
    else n=tonumber(text) end
    if finite(n) and n>=0 then return n end
end
function E.time(n)return string.format('%02d:%05.2f',math.floor(math.max(0,n)/60),math.max(0,n)%60)end
function E.duration(plan)
    local last=0
    for _,r in ipairs((plan or {}).rows or {})do if r.enabled~=false then last=math.max(last,r.start+r.length)end end
    return last
end
local function clipById(c,id)
    for _,clip in ipairs(c.history or {})do if clip.id==id then return clip end end
end
function E.writePlan(x,k,plan)
    x:setInt(k..'#version',1);x:setInt(k..'#count',#plan.rows)
    for i,r in ipairs(plan.rows) do
        local p=k..'.row('..(i-1)..')'
        x:setString(p..'#name',r.name or 'History');x:setString(p..'#start',string.format('%.17g',r.start))
        x:setString(p..'#in',string.format('%.17g',r.sourceIn));x:setString(p..'#length',string.format('%.17g',r.length))
        x:setInt(p..'#enabled',r.enabled~=false and 1 or 0);x:setInt(p..'#clips',#r.ids)
        for j,id in ipairs(r.ids)do x:setInt(p..'.clip('..(j-1)..')#id',id)end
        x:setInt(p..'#vehicles',#(r.vehicleIds or {}))
        for j,id in ipairs(r.vehicleIds or {})do x:setString(p..'.vehicle('..(j-1)..')#id',id)end
    end
end
function E.readPlan(x,k)
    if x:getInt(k..'#version',0)==0 then return end
    if x:getInt(k..'#version')~=1 then error('Versi timeline tidak didukung.') end
    local n=x:getInt(k..'#count',-1);if not n or n<0 or n>10000 then error('Jumlah clip timeline rusak.')end
    local plan={rows={}}
    for i=1,n do
        local p=k..'.row('..(i-1)..')'
        local r={ids={},name=x:getString(p..'#name','History'),start=tonumber(x:getString(p..'#start')),sourceIn=tonumber(x:getString(p..'#in')),length=tonumber(x:getString(p..'#length')),enabled=x:getInt(p..'#enabled',1)==1}
        if not finite(r.start) or r.start<0 or not finite(r.sourceIn) or r.sourceIn<0 or not finite(r.length) or r.length<=0 then error('Durasi timeline rusak.')end
        local count=x:getInt(p..'#clips',0);if count<1 or count>10000 then error('Sumber timeline rusak.')end
        for j=1,count do local id=x:getInt(p..'.clip('..(j-1)..')#id');if not id or id<1 then error('ID History timeline rusak.')end;r.ids[#r.ids+1]=id end
        local vehicles=x:getInt(p..'#vehicles',0)
        if vehicles<0 or vehicles>10000 then error('Filter kendaraan timeline rusak.')end
        if vehicles>0 then r.vehicleIds={};for j=1,vehicles do local id=x:getString(p..'.vehicle('..(j-1)..')#id');if not id or id=='' then error('ID kendaraan timeline hilang.')end;r.vehicleIds[j]=id end end
        plan.rows[#plan.rows+1]=r
    end
    return plan
end
function E.writeTake(x,k,t)if t.editingPlan then E.writePlan(x,k..'.editing',t.editingPlan)end end
function E.readTake(x,k,t)t.editingPlan=E.readPlan(x,k..'.editing')end
function E.load(c)
    if c.editingLoaded then return end
    local ready=JLRSFrames.prepare();if not ready then return end
    local catalogs={}
    for _,name in ipairs({(c.editingFinalOnly and 'finalEditing_'or 'editing_')..'A.xml',(c.editingFinalOnly and 'finalEditing_'or 'editing_')..'B.xml'}) do
        local path=JLRSFrames.directory..name
        if fileExists(path) then
            local x=XMLFile.load('jlrsEditingLoad',path)
            if x then catalogs[#catalogs+1]={x=x,revision=x:getInt('editing#revision',0)}else c.editingReadFailed=true end
        end
    end
    table.sort(catalogs,function(a,b)return a.revision>b.revision end)
    local restored=false
    for _,item in ipairs(catalogs) do
        if not restored then
            local ok,plan=pcall(E.readPlan,item.x,'editing.plan')
            if ok and plan then c.editingPlan=plan;c.editingRevision=item.revision;c.editingReadFailed=false;restored=true end
        end
        item.x:delete()
    end
    if #catalogs>0 and not restored then c.editingReadFailed=true end
    c.editingLoaded=true;c.editingPlan=c.editingPlan or {rows={}}
end
function E.save(c)
    E.load(c)
    if not c.editingLoaded or c.editingReadFailed then c:notify('Timeline lama belum dapat dibaca; file dipertahankan.');return false end
    local ok,err=pcall(function()
        local rev=(c.editingRevision or 0)+1;local path=JLRSFrames.directory..(c.editingFinalOnly and 'finalEditing_'or 'editing_')..(rev%2==0 and 'A.xml' or 'B.xml')
        local x=XMLFile.create('jlrsEditingSave',path,'editing');if not x then error('Tidak dapat menulis timeline.')end
        local wrote,why=pcall(function()x:setInt('editing#revision',rev);E.writePlan(x,'editing.plan',c.editingPlan);if x:save()==false then error('Disk penuh / timeline belum tersimpan.')end end)
        x:delete();if not wrote then error(why)end
        local check=XMLFile.load('jlrsEditingCheck',path);if not check then error('Timeline tidak dapat dibaca setelah Save.')end
        local verified,plan=pcall(E.readPlan,check,'editing.plan');local revision=check:getInt('editing#revision');check:delete()
        if not verified or not plan or revision~=rev or #plan.rows~=#c.editingPlan.rows then error('Verifikasi timeline gagal.')end
        c.editingRevision=rev;return true
    end)
    if not ok then c:notify('Timeline belum tersimpan: '..tostring(err));return false end
    return true
end
function E.validate(c,plan)
    local sources={};local enabled=0
    for i,r in ipairs(plan.rows or {}) do
        if not finite(r.start) or r.start<0 or not finite(r.sourceIn) or r.sourceIn<0 or not finite(r.length) or r.length<=0 then return nil,'Waktu clip #'..i..' tidak valid.'end
        if r.enabled~=false then
            enabled=enabled+1;local longest=0
            for _,id in ipairs(r.ids or {}) do
                local clip=clipById(c,id)
                if not clip or not JLRSHistory.valid(clip) then return nil,'History #'..tostring(id)..' tidak tersedia. Ganti / bind kendaraan dahulu.'end
                sources[id]=clip;longest=math.max(longest,clip.duration)
            end
            for _,wanted in ipairs(r.vehicleIds or {})do
                local found=false
                for _,id in ipairs(r.ids or {})do for _,v in ipairs(sources[id].vehicles or {sources[id].target})do if JLRSPersist.identity(v)==wanted then found=true end end end
                if not found then return nil,'Kendaraan jalur #'..i..' tidak tersedia; periksa History / Change Cars.'end
            end
            if longest<=r.sourceIn or r.sourceIn+r.length>longest+.00001 then return nil,'Durasi clip #'..i..' melebihi sumber History.'end
        end
    end
    if enabled==0 then return nil,'Centang minimal satu clip di Editing Final.'end
    return sources
end
-- Projected stream views keep all original timestamps, activity channels and precision.
-- At most eight recently requested poses per view; no resampling or file duplication.
local baseCount=JLRSFrames.count
JLRSFrames.count=function(f)if f and f.editingView then return baseCount(f.editingView.source)end;return baseCount(f)end
local baseGet=JLRSFrames.get
JLRSFrames.get=function(f,index)
    if not f or not f.editingView then return baseGet(f,index)end
    local v=f.editingView;local cached=v.cache[index];if cached then return cached end
    local original=baseGet(v.source,index);if not original then return end
    local pose={};for i,j in ipairs(v.indices)do pose[i]=original.pose[j]end
    cached={t=original.t,pose=pose};v.cache[index]=cached;v.order[#v.order+1]=index
    if #v.order>8 then v.cache[table.remove(v.order,1)]=nil end
    return cached
end
local function view(source,indices)return {editingView={source=source,indices=indices,cache={},order={}}}end
-- Legacy capture and restored History leave wheel/local nodes without .vehicle.
-- Recover ownership once per source topology; never alter stored entries or poses.
function E.entryOwners(clip)
    local cached=clip.editingOwners
    if cached and cached.entries==clip.entries and cached.vehicles==clip.vehicles then return cached end
    local owners,components={},{}
    for _,v in ipairs(clip.vehicles or {clip.target})do
        owners[v.rootNode]=v
        for i,comp in ipairs(v.components or {})do owners[comp.node]=v;components[comp.node]=i end
        local function wheel(w)
            if w.repr then owners[w.repr]=v end;if w.driveNode then owners[w.driveNode]=v end
            for _,extra in ipairs(w.additionalWheels or {})do wheel(extra)end
        end
        for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do wheel(w)end
    end
    local entries={}
    for i,e in ipairs(clip.entries)do
        local owner=e.vehicle or owners[e.node]
        if not owner and clip.saved and clip.saved.entries[i]then owner=(clip.vehicles or {})[clip.saved.entries[i].vehicle]end
        local node=e.node;local seen={}
        while not owner and node and node~=0 and not seen[node] and entityExists(node)do
            seen[node]=true;node=getParent(node);owner=owners[node]
        end
        if owner then
            local entry={};for k,v in pairs(e)do entry[k]=v end
            entry.vehicle=owner;entry.componentIndex=e.componentIndex or components[e.node];entries[i]=entry
        end
    end
    cached={entries=clip.entries,vehicles=clip.vehicles,resolved=entries};clip.editingOwners=cached;return cached
end
function E.project(clip,allowed)
    local entries,vehicles,indices={},{},{}
    for _,v in ipairs(clip.vehicles or {clip.target})do if allowed[v] then vehicles[#vehicles+1]=v end end
    local resolved=E.entryOwners(clip).resolved
    for i,e in ipairs(clip.entries)do local owned=resolved[i];if owned and allowed[owned.vehicle] then
        entries[#entries+1]=owned;for j=1,6 do indices[#indices+1]=(i-1)*6+j end
    end end
    if #entries==0 or #vehicles==0 then return end
    local target=allowed[clip.target] and clip.target or vehicles[1]
    local original=JLRSFrames.get(clip.frames,1)
    if target==clip.target and #original.pose>=#clip.entries*6+3 then for j=1,3 do indices[#indices+1]=#clip.entries*6+j end end
    local frames=view(clip.frames,indices);frames.jlrsRecordAll=clip.frames.jlrsRecordAll
    local data=clip.frames.jlrsActivities;local skipAudio=false
    if data and data.frames then
        local schema,channels={},{}
        for i,ch in ipairs(data.schema)do
            local owner=JLRSActivities.resolve(ch,clip.vehicles or {clip.target})
            if allowed[owner] then
                schema[#schema+1]=ch;for j=1,6 do channels[#channels+1]=(i-1)*6+j end
                if target~=clip.target and owner==target and ch.kind=='allMotor' then skipAudio=true end
            end
        end
        if #schema>0 then frames.jlrsActivities={schema=schema,frames=view(data.frames,channels)}end
    end
    return {entries=entries,vehicles=vehicles,target=target,frames=frames,source=clip,skipAudio=skipAudio}
end
local function newer(a,b)
    return not b or a.row.start>b.row.start or (a.row.start==b.row.start and (a.index>b.index or a.index==b.index and a.clip.id>b.clip.id))
end
function E.owners(session,time)
    local owners={}
    for i,r in ipairs(session.plan.rows)do if r.enabled~=false and time>=r.start then
        for _,id in ipairs(r.ids) do
            local clip=session.sources[id];local candidate={row=r,index=i,clip=clip,key=i..':'..id}
            for _,v in ipairs(clip.vehicles or {clip.target})do
                local selected=not r.vehicleIds
                for _,id in ipairs(r.vehicleIds or {})do if JLRSPersist.identity(v)==id then selected=true;break end end
                if selected and newer(candidate,owners[v])then owners[v]=candidate end
            end
        end
    end end
    local desired={}
    for v,o in pairs(owners)do
        local d=desired[o.key]
        if not d then d={row=o.row,index=o.index,clip=o.clip,allowed={}};desired[o.key]=d end
        d.allowed[v]=true
    end
    return desired
end
local function sameOwners(a,b)
    for v in pairs(a)do if not b[v]then return false end end
    for v in pairs(b)do if not a[v]then return false end end
    return true
end
local function sceneWithoutProps(scene)
    if not scene then return end
    local out={groups={},sampleCount=scene.sampleCount,duration=scene.duration}
    for _,g in ipairs(scene.groups or {})do if not g.prop then out.groups[#out.groups+1]=g end end
    return out
end
function E.reconcile(c,s)
    if not s.forceScene and s.rangeStart and s.time>=s.rangeStart and s.time<s.rangeEnd and #c.liveTracks==s.trackCount then return end
    s.rangeStart=0;s.rangeEnd=math.huge
    for _,row in ipairs(s.plan.rows)do if row.enabled~=false then
        if row.start<=s.time then s.rangeStart=math.max(s.rangeStart,row.start)else s.rangeEnd=math.min(s.rangeEnd,row.start)end
    end end
    local wanted=E.owners(s,s.time);local changed=false
    local incoming=false
    for key,d in pairs(wanted)do
        local found=false
        for _,track in ipairs(c.liveTracks)do if track.editingKey==key and sameOwners(track.editingAllowed,d.allowed)then found=true;break end end
        if not found then incoming=true;break end
    end
    -- Release background/cargo ownership before a future primary track claims it.
    -- In particular, a pickup carried by an earlier truck can become a later clip.
    if incoming or s.forceScene then
        JLRSWorld.stop(c)
        for _,t in ipairs(c.liveTracks)do JLRSWorld.releaseReplay(t.cargoReplay);t.cargoReplay=nil end
    end
    for i=#c.liveTracks,1,-1 do
        local track=c.liveTracks[i];local nextOwner=wanted[track.editingKey]
        if not nextOwner or not sameOwners(track.editingAllowed,nextOwner.allowed)then
            JLRSRecorder.stopReplay(track);table.remove(c.liveTracks,i);changed=true
        else wanted[track.editingKey]=nil end
    end
    local keys={};for k in pairs(wanted)do keys[#keys+1]=k end;table.sort(keys)
    c.worldBatch=true
    local ok,err=pcall(function()
        for _,key in ipairs(keys)do
            local d=wanted[key];local p=E.project(d.clip,d.allowed)
            if p then
                local track={target=p.target,entries=p.entries,frames=p.frames,recordVehicles=p.vehicles,duration=d.clip.duration,
                    replayTime=0,frameIndex=1,replaySpeed=1,loop=false,paused=false,replaying=false,active=false,
                    notify=function(_,message)c:notify(message)end,editingKey=key,editingAllowed=d.allowed,editingRow=d.row,editingSource=d.clip}
                track.editingSkipAudio=p.skipAudio
                track.returnPose=JLRSRecorder.capture(track.entries)
                if not track.returnPose or not JLRSLive.detachPhysics(track) then error('Physics clip #'..d.clip.id..' tidak tersedia.')end
                track.replaying=true;c.liveTracks[#c.liveTracks+1]=track
                local time=math.min(track.duration,d.row.sourceIn+math.min(d.row.length,math.max(0,s.time-d.row.start)))
                JLRSRecorder.apply(track.entries,JLRSRecorder.sample(track,time));track.replayTime=time
                if track.collisionReplay then JLRSCollision.place(track,JLRSRecorder.sample(track,time))end
                changed=true
            end
        end
    end)
    c.worldBatch=nil;if not ok then error(err)end
    if changed or s.forceScene then
        s.forceScene=nil
        JLRSWorld.stop(c)
        for _,t in ipairs(c.liveTracks)do JLRSWorld.releaseReplay(t.cargoReplay);t.cargoReplay=nil end
        local owner
        for _,t in ipairs(c.liveTracks)do
            if t.editingSource.worldScene and (not owner or t.editingRow.start>owner.editingRow.start or t.editingRow.start==owner.editingRow.start and t.editingKey>owner.editingKey)then owner=t end
        end
        for _,t in ipairs(c.liveTracks)do
            local scene=sceneWithoutProps(t.editingSource.worldScene)
            if scene then JLRSWorld.start(c,scene,t,true)end
        end
        if owner then JLRSWorld.start(c,owner.editingSource.worldScene,owner)end
        if not c.groupCamera and #c.liveTracks>0 then JLRSGroup.camera(c)end
        if not JLRSRecorder.valid(c.cameraTarget)then c.cameraTarget=c.liveTracks[1] and c.liveTracks[1].target end
    end
    s.trackCount=#c.liveTracks
end
function E.start(c,plan,time)
    if c.recording or c.finalRecording then c:notify('Stop Record dahulu sebelum memulai timeline.');return false end
    local sources,why=E.validate(c,plan);if not sources then c:notify(why);return false end
    c:stop()
    local entries,seen={},{}
    for _,clip in pairs(sources)do for _,entry in ipairs(clip.entries)do if not seen[entry.node]then entries[#entries+1]=entry;seen[entry.node]=true end end end
    local s={plan=copyPlan(plan),sources=sources,time=math.max(0,math.min(E.duration(plan),time or 0)),duration=E.duration(plan),clock=g_time or 0,
        tracks={},master={replaying=true,replayTime=0,duration=E.duration(plan),paused=false},settings={live=c.liveDrive,speed=c.replaySpeed,loop=c.loop,keys=c.nativeShortcuts,entries=c.entries},returnEntries=entries}
    s.returnPose=JLRSRecorder.capture(entries);if not s.returnPose then c:notify('Kendaraan timeline berubah; periksa History.');return false end
    c.editingSession=s;c.liveDrive=true;c.liveTracks={};c.livePaused=false;c.replaySpeed=1;c.loop=false;c.entries={};c.nativeShortcuts=false
    c.liveClock=g_time or 0;c.lastClock=g_time or 0;c.groupClock=g_time or 0
    s.master.replayTime=s.time
    local ok,err=pcall(E.reconcile,c,s)
    if not ok then c:stop();c:notify('Editing Final gagal: '..tostring(err));return false end
    if #c.liveTracks==0 then
        for _,row in ipairs(s.plan.rows)do if row.enabled~=false then c.cameraTarget=s.sources[row.ids[1]].target;break end end
        c.groupCamera=true;JLRSCamera.activate(c);JLRSCamera.choose(c,c.mode)
    end
    c.menu=false;c.editingOpen=false;c.finalListOpen=false;c.historyOpen=false;JLRSMouse.refresh(c)
    return true
end
function E.seek(c,time)
    local s=c.editingSession;if not s then return end
    if c.finalRecording or c.finalPlaying then c:notify('Stop Final dahulu sebelum menggeser playhead.');return end
    s.time=math.max(0,math.min(s.duration,time));s.master.replayTime=s.time;s.clock=g_time or 0
    E.reconcile(c,s)
    for _,track in ipairs(c.liveTracks)do
        track.changeWheelReplay=nil;track.allWheelReplay=nil;track.collisionVelocity=nil;track.collisionCorrection=nil
        JLRSWheelVisual.clear(track)
        local row=track.editingRow;local t=math.min(track.duration,row.sourceIn+math.min(row.length,math.max(0,s.time-row.start)))
        local pose=JLRSRecorder.sample(track,t)
        if track.collisionReplay then JLRSCollision.place(track,pose)else JLRSRecorder.apply(track.entries,pose)end
        track.replayTime=t;JLRSRecorder.replayTick(track,0)
        if track.cargoReplay then JLRSWorld.tick(c,t,track.cargoReplay)end
    end
    if c.worldReplay then JLRSWorld.tick(c,c.worldReplay.owner.replayTime)end
end
local replayTick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,dt,...)
    local s=JLReplayStudio.editingSession
    if not s or not track.editingKey then return replayTick(track,dt,...)end
    local row=track.editingRow
    local time=math.min(track.duration,row.sourceIn+math.min(row.length,math.max(0,s.time-row.start)))
    local ended=s.time>=row.start+row.length or time>=track.duration
    local frozen=JLReplayStudio.livePaused or (JLReplayStudio.menu and not JLReplayStudio.editingPreviewRunning) or JLReplayStudio.mission.isPaused or (g_gui and g_gui:getIsGuiVisible()) or s.time>=s.duration
    local step=(ended or frozen) and 0 or math.min(math.max(0,dt or 0),time)
    track.replayTime=math.max(0,time-step);track.paused=frozen;track.loop=false;track.replaySpeed=1
    local result=replayTick(track,step,...)
    track.replayTime=time;track.paused=frozen or ended
    if track.collisionReplay and track.paused then
        for _,entry in ipairs(track.entries)do if entry.world then setLinearVelocity(entry.node,0,0,0);setAngularVelocity(entry.node,0,0,0)end end
    end
    return result
end
function E.record(c)
    JLRSFinal.load(c)
    if c.finalRecording then JLRSFinal.finish(c);return end
    if c.finalPlaying or c.recording or c.finalReadFailed or c.finalLoadPending then c:notify('Stop Replay Final / Record dahulu; periksa daftar Final.');return end
    local s=c.editingSession;if not s or s.time>=s.duration then c:notify('Mulai Preview Editing Final dari awal dahulu.');return end
    -- Commit History before a camera take can reference it across restarts.
    if not JLRSPersist.safeSave(c)then return end
    local ids={};local seen={}
    for _,row in ipairs(s.plan.rows)do if row.enabled~=false then for _,id in ipairs(row.ids)do if not seen[id]then seen[id]=true;ids[#ids+1]=id end end end end
    local t={id=c.finalNextId or 1,name=string.format('Editing Final #%03d',c.finalNextId or 1),clips=ids,starts={},masterId=ids[1],frames=JLRSFrames.new(12),duration=0,sourceStart=s.time,speed=1,loop=false,shot=1,
        master=s.master,lastSource=s.time,wasPaused=c.livePaused or false,editingPlan=copyPlan(s.plan)}
    for _,id in ipairs(ids)do t.starts[id]=0 end
    c.finalRecording=t
    local ok,err=pcall(JLRSFinal.append,c,t)
    if not ok then c.finalRecording=nil;JLRSFrames.release(t.frames);c:notify('Record Final gagal: '..tostring(err));return end
    c:notify('RECORD FINAL EDITING | Space Pause / Cut | Stop Final untuk simpan')
end
function E.playTake(c,t)
    local sources,why=E.validate(c,t.editingPlan);if not sources then c:notify(why);return end
    local settings={physics=c.physicsReplay,speed=c.replaySpeed,loop=c.loop,mode=c.mode,lock=c.lock,angle=c.angleEnabled,live=c.liveDrive,keys=c.nativeShortcuts,x=c.x,y=c.y,z=c.z,yaw=c.yaw,pitch=c.pitch,fov=c.fov}
    c:stop();c.physicsReplay=not c.preciseReplay
    if not E.start(c,t.editingPlan,t.sourceStart)then c.physicsReplay=settings.physics;return end
    c.angleEnabled=false
    local ok,err=pcall(function()
        local camera=createCamera('JLRSEditingFinalCamera',math.rad(c.fov or 60),.1,6000);link(getRootNode(),camera)
        c.finalPlaying={take=t,time=0,master=c.editingSession.master,lastSource=c.editingSession.time,camera=camera,previousCamera=getCamera(),settings=settings}
        E.camera(c,c.finalPlaying)
    end)
    if not ok then c:stop();c:notify('Replay Final Editing gagal: '..tostring(err));return end
    c:notify('REPLAY FINAL READY | timeline gabungan + kamera + cut')
end
function E.camera(c,p)
    local pose=JLRSFinal.sample(p.take,p.time)
    setTranslation(p.camera,pose[1],pose[2],pose[3]);setRotation(p.camera,pose[4],pose[5],pose[6]);setFovY(p.camera,pose[7]);if getCamera()~=p.camera then setCamera(p.camera) end
end
function E.finalTick(c)
    local s=c.editingSession;if not s then if c.finalRecording then JLRSFinal.finish(c)elseif c.finalPlaying then c:stop()end;return end
    local t=c.finalRecording
    if t then
        local delta=math.max(0,s.time-t.lastSource);t.lastSource=s.time
        local isPaused=c.livePaused or c.mission.isPaused or (g_gui and g_gui:getIsGuiVisible()) or false
        if not t.wasPaused and delta>0 then
            t.duration=t.duration+delta
            if t.pendingCut then t.shot=t.shot+1;t.pendingCut=nil end
            JLRSFinal.append(c,t)
        end
        if t.wasPaused and not isPaused then t.shot=t.shot+1;JLRSFinal.append(c,t)end
        t.wasPaused=isPaused
        if s.time>=s.duration then JLRSFinal.finish(c);c.livePaused=true end
    end
    local p=c.finalPlaying
    if p then
        local delta=math.max(0,s.time-p.lastSource);p.lastSource=s.time;p.time=math.min(p.take.duration,p.time+delta)
        E.camera(c,p)
        if p.time>=p.take.duration or s.time>=s.duration then
            c.livePaused=true;s.master.paused=true
            for _,track in ipairs(c.liveTracks)do track.paused=true end
            if not p.ended then p.ended=true;c:notify('Replay Final selesai | semua clip Editing Final selesai')end
        end
    end
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    local s=c.editingSession
    local result=stop(c,...)
    if s then
        c.editingSession=nil;s.master.replaying=false
        if s.returnPose then JLRSRecorder.apply(s.returnEntries,s.returnPose,true)end
        c.liveDrive=s.settings.live;c.replaySpeed=s.settings.speed;c.loop=s.settings.loop;c.nativeShortcuts=s.settings.keys;c.entries=s.settings.entries
    end
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.editingPlan={rows={}};c.editingLoaded=false;c.editingRevision=0;c.editingReadFailed=false;c.editingOpen=false;c.editingSession=nil;c.editingOffset=0;c.editingSourceOffset=0;c.editingSourceMarked={};c.editingSpan=60;c.editingViewStart=0
    return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.editingLoaded and not c.editingReadFailed then E.save(c)end
    c.editingOpen=false;c.editingDrag=nil
    return deleteMap(c,...)
end
local historyDelete=JLRSHistory.delete
JLRSHistory.delete=function(c,clip,...)
    for _,t in ipairs(c.finalTakes or {})do if t.editingPlan then
        for _,r in ipairs(t.editingPlan.rows)do for _,id in ipairs(r.ids)do if id==clip.id then c:notify('History dipakai Final Editing #'..t.id..'; hapus Final itu dahulu.');return end end end
    end end
    if c.editingSession then c:notify('Stop Editing Final dahulu sebelum Delete History.');return end
    return historyDelete(c,clip,...)
end
local manualSave=JLRSManualSave.save
JLRSManualSave.save=function(c,...)
    local result=manualSave(c,...)
    if result and c.editingLoaded then return E.save(c)end
    return result
end
local audioTick=JLRSAudio.tick
JLRSAudio.tick=function(track,...)
    if track.editingSkipAudio then return end
    return audioTick(track,...)
end
for _,name in ipairs({'start','startReplay'})do
    local previous=JLRSRecorder[name]
    JLRSRecorder[name]=function(c,...)
        if c==JLReplayStudio and c.editingSession and not c.finalRecording and not c.finalPlaying then c:stop()end
        return previous(c,...)
    end
end
local historyReplay=JLRSHistory.replay
JLRSHistory.replay=function(c,...)
    if c.editingSession and not c.finalRecording and not c.finalPlaying then c:stop()end
    return historyReplay(c,...)
end
local groupAll=JLRSGroup.all
JLRSGroup.all=function(c,...)
    if c.editingSession and not c.finalRecording and not c.finalPlaying then c:stop()end
    return groupAll(c,...)
end
local liveToggle=JLRSLive.toggle
JLRSLive.toggle=function(c,...)
    if c.editingSession and not c.finalRecording and not c.finalPlaying then
        c:stop();if c.liveDrive then return liveToggle(c,...)end;return
    end
    return liveToggle(c,...)
end
