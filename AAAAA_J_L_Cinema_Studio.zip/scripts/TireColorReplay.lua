-- J_L Tire Effects uses baked material swatches, not wheel shader parameters.
-- Persist the source clock only: runtime material/node handles never enter cache.
JLRSTireColorReplay={owners=setmetatable({},{__mode='k'}),classes=setmetatable({},{__mode='k'})}
local E=JLRSTireColorReplay
local function valid(n)return n and n~=0 and entityExists(n)end
local function clock(v)return v and v.spec_jlTireEffects end
local function classFor(v)
    local cls=E.classes[v]
    if cls then return cls end
    for _,list in ipairs({v.specializations or {},v.eventListeners and v.eventListeners.onUpdate or {}})do
        for _,candidate in pairs(list)do
            if type(candidate)=='table' and candidate.specName=='jlTireEffects' and candidate.materialCache then
                E.classes[v]=candidate;return candidate
            end
        end
    end
end
local function render(v,elapsed)
    local s=clock(v)
    if not s or not s.isLoaded then return end
    local cls=classFor(v)
    if not cls then return end
    local frame
    if s.rainbow then
        local duration=cls.PHASE_DURATION_MS or 2000
        local steps=cls.STEPS_PER_PHASE or 24
        local cycle=math.max(0,elapsed)%(7*duration)
        frame=math.floor(cycle/duration)*steps+math.min(steps-1,math.floor((cycle%duration)/(cls.COLOR_UPDATE_MS or duration/steps)))
    end
    local material=frame and cls.materialCache[frame]
    for _,entry in ipairs(s.wheels or {})do
        if valid(entry.node) and valid(entry.overlay)then
            -- Copy only the cosmetic sibling. Wheel physics/steering/roll stays owned
            -- by the existing proven replay path, including carried vehicles.
            local x,y,z=getTranslation(entry.node);setTranslation(entry.overlay,x,y,z)
            local rx,ry,rz=getRotation(entry.node);setRotation(entry.overlay,rx,ry,rz)
            local sx,sy,sz=getScale(entry.node);setScale(entry.overlay,sx,sy,sz)
            if material and material~=0 and (entry.appliedFrame~=frame or entry.jlrsColorMaterial~=material)then
                setMaterial(entry.overlay,material,0)
                entry.appliedFrame=frame;entry.jlrsColorMaterial=material
            end
        end
    end
end
local function readInto(v,ch,out)
    local s=clock(v)
    out[1]=s and s.elapsed or 0
    for i=2,6 do out[i]=0 end
    return out
end
JLRSActivities.registerAdapter('jlrsTireColor',{
    cinemaNumericReadInto=true,readInto=readInto,
    read=function(v,ch)return readInto(v,ch,{})end,
    discover=function(v)
        local s=clock(v)
        if s then return {{name='tireColorClock',mode='linear',index=1}}end
        return {}
    end,
    write=function(v,ch,p,paused,restoring)
        if not clock(v)then return end
        if restoring then E.owners[v]=nil;render(v,p[1]);return end
        local track=JLRSSecondaryEffects and JLRSSecondaryEffects.track
        local owner=E.owners[v]
        if not owner then owner={};E.owners[v]=owner end
        owner.track=track;owner.elapsed=p[1]
        render(v,p[1])
    end
})
local function vehicles(track)
    local cache=track.jlrsTireColorVehicles
    if cache and cache.source==track.recordVehicles and cache.activity==track.activityReplay and cache.target==track.target then return cache end
    cache={source=track.recordVehicles,activity=track.activityReplay,target=track.target};local seen={}
    local function add(v)
        if v and not seen[v]then
            seen[v]=true
            if clock(v)then cache[#cache+1]={vehicle=v,origin=clock(v).elapsed or 0}end
        end
    end
    add(track.target)
    for _,v in ipairs(track.recordVehicles or {})do add(v)end
    for _,state in ipairs(track.activityReplay and track.activityReplay.channels or {})do add(state.vehicle)end
    track.jlrsTireColorVehicles=cache;return cache
end
local refresh=JLRSWheelVisual.refresh
JLRSWheelVisual.refresh=function(track,...)
    local result=refresh(track,...)
    if track.replaying then
        for _,entry in ipairs(vehicles(track))do
            local v=entry.vehicle
            local native=JLRSLiveDriverOwnership and JLRSLiveDriverOwnership.native
            if not (native and native(JLReplayStudio,v))then
                local owner=E.owners[v]
                if owner and owner.track and owner.track.replaying then render(v,owner.elapsed)
                else
                    -- Legacy takes lack a phase channel. Keep their animation alive
                    -- from a stable local origin; seeks/pause use source replay time.
                    local effects=JLRSSecondaryEffects and JLRSSecondaryEffects.owners[v]
                    if not effects or effects.track==track or not effects.track.replaying then
                        render(v,entry.origin+(track.replayTime or 0)*1000)
                    end
                end
            end
        end
    end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    local result=stop(track,...)
    for v,owner in pairs(E.owners)do if owner.track==track then E.owners[v]=nil end end
    track.jlrsTireColorVehicles=nil;return result
end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=delete(c,...)
    E.owners=setmetatable({},{__mode='k'});E.classes=setmetatable({},{__mode='k'})
    return result
end
