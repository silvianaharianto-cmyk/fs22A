-- Final-only non-destructive speed ranges. Raw camera/motion cache stays immutable.
JLRSFinalSlowMotion={}
local S=JLRSFinalSlowMotion
local F,H,T=JLRSFinal,JLRSFinalCuts,JLRSUnifiedTimecode
local length,source,output=H.length,H.source,H.output
local function clamp(x,a,b)return math.max(a,math.min(b,x))end
local function enabled(t)return t and t.slowRanges and #t.slowRanges>0 end
local function copy(ranges)local out={};for i,r in ipairs(ranges or {})do out[i]={a=r.a,b=r.b,rate=r.rate}end;return out end
function S.plan(t,raw)
 raw=raw or t.cutSourceDuration or t.duration or 0
 local p=t.slowPlan
 if p and p.cuts==t.finalCuts and p.ranges==t.slowRanges then
  if p.raw==raw then return p end
  if raw>p.raw and (p.maxEdge or 0)<=p.raw then
   local last=p.segments[#p.segments];local delta=raw-p.raw
   if last and last.b==p.raw and last.rate==1 then last.b=raw;last.finish=last.finish+delta
   else p.segments[#p.segments+1]={a=p.raw,b=raw,start=p.duration,finish=p.duration+delta,rate=1}end
   p.raw=raw;p.duration=p.duration+delta;return p
  end
 end
 p={raw=raw,cuts=t.finalCuts,ranges=t.slowRanges,segments={},duration=0,maxEdge=0};t.slowPlan=p
 local edges={0,raw}
 for _,list in ipairs({t.finalCuts or {},t.slowRanges or {}})do for _,r in ipairs(list)do p.maxEdge=math.max(p.maxEdge,r.b);edges[#edges+1]=clamp(r.a,0,raw);edges[#edges+1]=clamp(r.b,0,raw)end end
 table.sort(edges)
 local ci,si=1,1;local cuts,rates=t.finalCuts or {},t.slowRanges or {}
 for i=1,#edges-1 do
  local a,b=edges[i],edges[i+1]
  if b>a then
   while cuts[ci] and cuts[ci].b<=a do ci=ci+1 end
   while rates[si] and rates[si].b<=a do si=si+1 end
   if not(cuts[ci] and cuts[ci].a<=a and cuts[ci].b>=b)then
    local rate=rates[si] and rates[si].a<=a and rates[si].b>=b and rates[si].rate or 1
    local finish=p.duration+(b-a)/rate
    p.segments[#p.segments+1]={a=a,b=b,start=p.duration,finish=finish,rate=rate}
    p.duration=finish
   end
  end
 end
 return p
end
function S.source(t,raw,time)
 local p=S.plan(t,raw);time=clamp(time,0,p.duration)
 local lo,hi=1,#p.segments
 while lo<=hi do local mid=math.floor((lo+hi)/2);local r=p.segments[mid]
  if time<r.start then hi=mid-1 elseif time>=r.finish then lo=mid+1 else return r.a+(time-r.start)*r.rate,mid end
 end
 return p.segments[#p.segments] and p.segments[#p.segments].b or 0,#p.segments+1
end
function S.output(t,raw,time)
 local p=S.plan(t,raw);time=clamp(time,0,p.raw)
 for _,r in ipairs(p.segments)do
  if time<r.a then return r.start end
  if time<=r.b then return r.start+(time-r.a)/r.rate end
 end
 return p.duration
end
H.length=function(t)if enabled(t)then return S.plan(t).duration end;return length(t)end
H.source=function(t,time)if enabled(t)then return S.source(t,nil,time)end;return source(t,time)end
H.output=function(t,time)if enabled(t)then return S.output(t,nil,time)end;return output(t,time)end
function S.replace(ranges,a,b,rate)
 local out={}
 for _,r in ipairs(ranges or {})do
  if r.b<=a or r.a>=b then out[#out+1]={a=r.a,b=r.b,rate=r.rate}
  else
   if r.a<a then out[#out+1]={a=r.a,b=a,rate=r.rate}end
   if r.b>b then out[#out+1]={a=b,b=r.b,rate=r.rate}end
  end
 end
 if rate<1 then out[#out+1]={a=a,b=b,rate=rate}end
 table.sort(out,function(x,y)return x.a<y.a end)
 local merged={}
 for _,r in ipairs(out)do local last=merged[#merged]
  if last and last.b==r.a and last.rate==r.rate then last.b=r.b else merged[#merged+1]=r end
 end
 return #merged>0 and merged or nil
end
function S.apply(c,rate)
 local t=not c.finalRecording and c.finalPlaying and c.finalPlaying.take;local mark=c.finalCutMark
 if not t then c:notify('Slowmo hanya dapat diatur saat Replay Final.');return end
 if not mark or mark.take~=t or mark.b==nil then c:notify('Tandai awal dan akhir di Timecode dengan X, lalu pilih Slowmo.');return end
 if rate~=rate or rate<.1 or rate>1 then return end
 local raw=t.cutSourceDuration or t.duration
 local a,b
 if enabled(t)then a=S.source(t,raw,math.min(mark.a,mark.b));b=S.source(t,raw,math.max(mark.a,mark.b))
 else local m={duration=raw,cutSourceDuration=raw,finalCuts=t.finalCuts};a=source(m,math.min(mark.a,mark.b));b=source(m,math.max(mark.a,mark.b))end
 if b-a<.001 then c:notify('Pilih rentang Slowmo yang lebih panjang.');return end
 T.pause(c)
 local before=copy(t.slowRanges)
 local oldRanges,oldDuration,oldRaw=t.slowRanges,t.duration,t.cutSourceDuration
 t.slowRanges=S.replace(t.slowRanges,a,b,rate);t.slowPlan=nil
 t.cutSourceDuration=(enabled(t)or t.finalCuts and #t.finalCuts>0)and raw or nil
 t.duration=enabled(t)and S.plan(t,raw).duration or length({duration=raw,finalCuts=t.finalCuts})
 if not F.save(c)then
  t.slowRanges=oldRanges;t.duration=oldDuration;t.cutSourceDuration=oldRaw;t.slowPlan=nil
  c:notify('Slowmo belum diterapkan: hasil Final tidak dapat disimpan.');return
 end
 local h=H.undoHistory[t]or {undo={},redo={}};H.undoHistory[t]=h
 h.undo[#h.undo+1]={kind='slow',before=before,after=copy(t.slowRanges),raw=a};h.redo={}
 c.finalCutMark=nil;c.slowPopup=nil
 local cursor=enabled(t)and S.output(t,raw,a)or output({duration=raw,finalCuts=t.finalCuts},a)
 c.finalCutCursor=cursor;T.seek(c,T.context(c),cursor)
 c:notify(string.format('Slowmo %.2fx diterapkan | durasi hasil %.2f detik',rate,H.length(t)))
end
local undo=H.undo
H.undo=function(c,redo,...)
 local t=c.finalRecording or(c.finalPlaying and c.finalPlaying.take)or(c.finalTakes or {})[c.finalSelected or 0]
 local h=t and H.undoHistory[t];local from=h and(redo and h.redo or h.undo);local edit=from and from[#from]
 if not edit or edit.kind~='slow' then return undo(c,redo,...)end
 local raw=c.finalRecording==t and t.duration or t.cutSourceDuration or t.duration
 local old,oldDuration,oldRaw=t.slowRanges,t.duration,t.cutSourceDuration
 local desired=copy(redo and edit.after or edit.before);t.slowRanges=#desired>0 and desired or nil;t.slowPlan=nil
 t.cutSourceDuration=(enabled(t)or t.finalCuts and #t.finalCuts>0)and raw or nil
 if c.finalRecording~=t then
  t.duration=enabled(t)and S.plan(t,raw).duration or length({duration=raw,finalCuts=t.finalCuts})
  if not F.save(c)then t.slowRanges=old;t.duration=oldDuration;t.cutSourceDuration=oldRaw;t.slowPlan=nil;return end
 end
 table.remove(from);local to=redo and h.undo or h.redo;to[#to+1]=edit
 c.finalCutMark=nil;c.finalCutCursor=H.output(t,edit.raw)
end
local context=T.context
T.context=function(c,...)
 local ctx=context(c,...)
 if ctx.final and enabled(ctx.take)then
  ctx.duration=S.plan(ctx.take,ctx.raw).duration
  ctx.time=c.finalPlaying and c.finalPlaying.time or ctx.duration
 end
 return ctx
end
local finish=F.finish
F.finish=function(c,...)
 local t=c.finalRecording
 if enabled(t)then t.cutSourceDuration=t.duration;t.duration=S.plan(t,t.duration).duration end
 c.slowPopup=nil
 return finish(c,...)
end
local write=H.write
H.write=function(x,k,t,...)
 write(x,k,t,...)
 if not enabled(t)then return end
 x:setInt(k..'.slow#count',#t.slowRanges);x:setString(k..'.slow#raw',string.format('%.17g',t.cutSourceDuration))
 for i,r in ipairs(t.slowRanges)do local p=k..'.slow.range('..(i-1)..')';x:setString(p..'#a',string.format('%.17g',r.a));x:setString(p..'#b',string.format('%.17g',r.b));x:setString(p..'#rate',string.format('%.17g',r.rate))end
end
local read=H.read
H.read=function(x,k,t,...)
 local n=x:getInt(k..'.slow#count',0)
 if n<0 or n>10000 then error('Metadata Slowmo rusak.')end
 if n>0 then
  local raw=tonumber(x:getString(k..'.slow#raw'));if not raw or raw~=raw or raw<=0 or raw>=math.huge then error('Durasi Slowmo rusak.')end
  t.cutSourceDuration=raw;t.slowRanges={};local last=0
  for i=1,n do
   local p=k..'.slow.range('..(i-1)..')';local a,b,rate=tonumber(x:getString(p..'#a')),tonumber(x:getString(p..'#b')),tonumber(x:getString(p..'#rate'))
   if not a or not b or not rate or a~=a or b~=b or rate~=rate or a<last or b<=a or b>raw or rate<.1 or rate>=1 then error('Rentang Slowmo rusak.')end
   t.slowRanges[i]={a=a,b=b,rate=rate};last=b
  end
 end
 local result=read(x,k,t,...)
 if enabled(t)and math.abs(H.length(t)-t.duration)>.001 then error('Durasi hasil Slowmo tidak cocok.')end
 return result
end
-- Cache one camera sample per output frame and feed its recorded source clock
-- into the existing motion/activity writers. No seek, physics reset or extra scan.
local cameraSample=F.sample
F.sample=function(t,time,...)
 local p=JLReplayStudio.finalPlaying
 if p and p.take==t and p.slowPose and p.slowPending==time then
  p.jlrsRenderedCameraPose=p.slowPose;return p.slowPose
 end
 return cameraSample(t,time,...)
end
local replay=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,dt,...)
 local c=JLReplayStudio;local p=c.finalPlaying
 if not p or not enabled(p.take)or not track.replaying then return replay(track,dt,...)end
 if c.livePaused or track.paused or c.mission.isPaused or(g_gui and g_gui:getIsGuiVisible())then return replay(track,0,...)end
 if not p.slowOffsets then
  p.slowOffsets={};local t=p.take;local start=t.starts[t.masterId]or t.sourceStart
  local live={};if c.replaying then live[#live+1]=c end;for _,v in ipairs(c.liveTracks or {})do if v.replaying then live[#live+1]=v end end
  for _,v in ipairs(live)do for _,clip in ipairs(c.history or {})do if clip.frames==v.frames then p.slowOffsets[v]=(t.starts[clip.id]or t.sourceStart)-start;break end end end
 end
 local offset=p.slowOffsets[track]
 if offset==nil then return replay(track,dt,...)end
 if not p.slowPending and dt and dt>0 then p.slowPending=math.min(p.take.duration,p.time+dt);p.slowPose=F.sample(p.take,p.slowPending)end
 if not p.slowPending then return replay(track,0,...)end
 local desired=p.slowPose[8]+offset
 if p.take.loop and track.duration>0 then desired=desired%track.duration else desired=clamp(desired,0,track.duration)end
 local delta=desired-track.replayTime
 if delta<-.000001 or delta>(dt or 0)*(p.take.speed or 1)+.001 then
  track.replayTime=desired
  if track.collisionReplay then JLRSCollision.place(track,JLRSRecorder.sample(track,desired))end
  return replay(track,0,...)
 end
 local speed=track.replaySpeed
 track.replaySpeed=dt and dt>0 and math.max(0,delta/dt)or 0
 local ok,result=pcall(replay,track,dt or 0,...);track.replaySpeed=speed
 if not ok then error(result,0)end
 return result
end
local tick=F.tick
F.tick=function(c,...)
 local recording=c.finalRecording
 if enabled(recording)then recording.cutSourceDuration=recording.duration end
 local p=c.finalPlaying
 if not p or not enabled(p.take)or c.jlrsRenderBoundary then
  local result=tick(c,...)
  if enabled(c.finalRecording)then c.finalRecording.cutSourceDuration=c.finalRecording.duration end
  return result
 end
 if not p.master.replaying then c:stop();return end
 if p.slowPending then p.time=p.slowPending end
 -- The output clock is authoritative for retimed takes. Let the existing
 -- Final pipeline draw camera, stop, preview and advance playlists normally,
 -- with zero additional source-driven elapsed time in that pipeline.
 p.lastSource=p.master.replayTime
 local _,segment=S.source(p.take,nil,p.time);p.cutSegment=segment
 local result=tick(c,...)
 p.slowPending=nil;p.slowPose=nil
 return result
end
local seek=T.seekFinal
T.seekFinal=function(c,ctx,time,...)
 local p=c.finalPlaying;if p then p.slowPending=nil;p.slowPose=nil end
 return seek(c,ctx,time,...)
end
-- A compact control belongs to the existing Timecode; no second timeline.
local function inside(b,x,y)return b and x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h end
local draw=T.drawBox
T.drawBox=function(c,bar,...)
 local result=draw(c,bar,...);c.slowHits={};c.slowPanel=nil;bar.slow=nil
 if not c.finalPlaying or c.finalRecording then c.slowPopup=nil;return result end
 bar.slow={x=bar.x+bar.w*.82,y=bar.y+bar.h*.59,w=bar.w*.18,h=bar.h*.41}
 JLRSMenu.rect(c,bar.slow.x,bar.slow.y,bar.slow.w,bar.slow.h,.08,.22,.30,1)
 JLRSMenu.text(bar.slow.x+.003,bar.slow.y+bar.slow.h*.25,.008,'Slowmo')
 if c.slowPopup then
  local w,h=.175,.106;local x=bar.x+bar.w-w;local y=bar.y+bar.h+.008
  c.slowPanel={x=x,y=y,w=w,h=h}
  JLRSMenu.rect(c,x,y,w,h,.015,.025,.04,.98)
  JLRSMenu.text(x+.006,y+.083,.009,'X awal - X akhir | pilih kecepatan')
  local rates={.25,.5,.75,1}
  for i,rate in ipairs(rates)do
   local hit={x=x+.005+(i-1)*.042,y=y+.047,w=.039,h=.026,callback=function()S.apply(c,rate)end}
   c.slowHits[#c.slowHits+1]=hit;JLRSMenu.rect(c,hit.x,hit.y,hit.w,hit.h,.06,.15,.22,1)
   JLRSMenu.text(hit.x+.002,hit.y+.008,.009,string.format('%.2fx',rate))
  end
  local hit={x=x+.005,y=y+.009,w=w-.01,h=.026,callback=function()c.slowPopup=nil end};c.slowHits[#c.slowHits+1]=hit
  JLRSMenu.text(hit.x+.005,hit.y+.008,.009,'Close | Space = lanjut Replay Final')
 end
 return result
end
local mouse=T.mouse
T.mouse=function(c,x,y,down,up,button,...)
 if JLRSMiniHud.interacting(c)then
  for _,hit in ipairs(c.slowPopup and c.slowHits or {})do if inside(hit,x,y)then if down and button==Input.MOUSE_BUTTON_LEFT then hit.callback()end;return true end end
  if c.slowPopup and inside(c.slowPanel,x,y)then return true end
  local bar=c.timecodeStandard
  if c.finalPlaying and not c.finalRecording and bar and inside(bar.slow,x,y)then
   if down and button==Input.MOUSE_BUTTON_LEFT then T.pause(c);c.timecodeFocus=c.finalPlaying.take;c.slowPopup=not c.slowPopup end
   return true
  end
 end
 return mouse(c,x,y,down,up,button,...)
end
