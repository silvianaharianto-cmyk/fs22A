-- Recorded Washable dirt amounts; bypass Mud System's incrementing setter.
JLRSVehicleDirt={shaders={},targets={},nodeTargets=setmetatable({},{__mode='v'})}
local D=JLRSVehicleDirt
-- Observe native Lua RDT writes (Washable, Wearable and supplied mud mods).
-- Keep all four components, so replay dirt never overwrites wear/color values.
function D.install()
    if D.shaderHook or type(setShaderParameter)~='function' then return end
    local native=setShaderParameter
    setShaderParameter=function(node,name,x,y,z,w,...)
        local result=native(node,name,x,y,z,w,...)
        local state=name=='RDT' and D.shaders[node]
        if state then state[1],state[2],state[3],state[4]=x,y,z,w end
        local target=name=='RDT' and D.nodeTargets[node]
        if target and y~=target.shown then target.dirty=true end
        return result
    end
    D.shaderHook=true
end
function D.shader(node,fresh)
    D.install()
    local state=D.shaders[node]
    if not state or fresh then
        local x,y,z,w=getShaderParameter(node,'RDT')
        state=state or {};state[1],state[2],state[3],state[4]=x,y,z,w;D.shaders[node]=state
    end
    return state
end
local function nodeData(v,index)
    return v.spec_washable and v.spec_washable.washableNodes and v.spec_washable.washableNodes[index]
end
function D.discover(v)
    local out={}
    for i in ipairs(v.spec_washable and v.spec_washable.washableNodes or {}) do
        out[#out+1]={name='body',index=i,mode='linear'}
    end
    for i,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {}) do
        if type(w.dirtAmount)=='number' then out[#out+1]={name='wheel',index=i,mode='linear'} end
    end
    return out
end
local function fill(out,a,b,c,d,e,f)
    out[1]=a or 0;out[2]=b or 0;out[3]=c or 0;out[4]=d or 0;out[5]=e or 0;out[6]=f or 0;return out
end
function D.readInto(v,ch,out)
    if ch.name=='wheel' then
        local w=v.spec_wheels and v.spec_wheels.wheels[ch.index]
        return fill(out,w and w.dirtAmount or 0,0,0,0,0,0)
    end
    local data=nodeData(v,ch.index);if not data then return fill(out,0,0,0,0,0,0) end
    local amount=data.dirtAmount or 0;local sent=data.dirtAmountSent or amount
    local shown=sent;local n=data.nodes and data.nodes[1]
    if n and entityExists(n) and getShaderParameter then
        -- Other mod environments can retain their own native setter. The
        -- observer cannot see those writes. Refresh when Washable changes,
        -- without polling every clean material during recording.
        local changed=data.jlrsCapturedDirtAmount~=amount or data.jlrsCapturedDirtSent~=sent
        local ok,state=pcall(D.shader,n,changed)
        if ok and type(state[2])=='number' then shown=state[2] end
    end
    data.jlrsCapturedDirtAmount=amount;data.jlrsCapturedDirtSent=sent
    return fill(out,amount,sent,shown,0,0,0)
end
function D.read(v,ch)
    -- Fresh boundary snapshot also handles foreign mods that retained an older
    -- native setter reference before our hook was installed.
    local data=ch.name~='wheel' and nodeData(v,ch.index)
    for _,node in ipairs(data and data.nodes or {}) do D.shaders[node]=nil end
    return D.readInto(v,ch,{})
end

local function shownAmount(values)
    local shown=values[3]
    -- Older takes can contain a stale zero shader snapshot although native
    -- Washable already sent a nonzero amount. Recover that visible state.
    if shown==0 and values[2]>0 then return values[2]end
    return shown
end
local function applyShader(n,amount,cached)
    if not entityExists(n)then return end
    -- Preserve current wear/color values even if a foreign mod bypassed our
    -- observer. Never call the mud mod's incrementing dirt setter here.
    local state=D.shader(n,not cached)
    if state[2]~=amount then setShaderParameter(n,'RDT',state[1],amount,state[3],state[4],false)end
end
function D.write(v,ch,values,paused,restoring)
    if restoring then
        for data,target in pairs(D.targets[v]or {})do
            for _,n in ipairs(data.nodes or {})do if D.nodeTargets[n]==target then D.nodeTargets[n]=nil end end
        end
        D.targets[v]=nil
    end
    if ch.name=='wheel' then
        local w=v.spec_wheels and v.spec_wheels.wheels[ch.index]
        if w then w.dirtAmount=values[1] end
        return
    end
    local data=nodeData(v,ch.index);if not data then return end
    data.dirtAmount=values[1];data.dirtAmountSent=values[2]
    -- Calling vehicle:setNodeDirtAmount here adds more mud on every replay tick.
    -- Use the recorded visible amount and retain wear/color shader parameters.
    if getShaderParameter and setShaderParameter then
        D.install()
        local shown=restoring and values[3]or shownAmount(values)
        if not restoring and JLReplayStudio.preciseReplay then
            local targets=D.targets[v]or {};D.targets[v]=targets
            local target=targets[data]
            if not target then
                D.nextTarget=(D.nextTarget or 0)+1
                target={slot=D.nextTarget,dirty=true};targets[data]=target
                for _,n in ipairs(data.nodes or {})do D.nodeTargets[n]=target end
            end
            target.amount=values[1];target.sent=values[2];target.shown=shown
        else for _,n in ipairs(data.nodes or {})do applyShader(n,shown)end end
    end
end
function D.flush(c)
    if not c.preciseReplay or not getShaderParameter or not setShaderParameter then return end
    -- Called after all Final/vehicle passes. Only registered replay Washable
    -- materials are checked, not the map or every vehicle update listener.
    D.flushSerial=(D.flushSerial or 0)+1
    for v,targets in pairs(D.targets)do
        if not v.rootNode or not entityExists(v.rootNode)then D.targets[v]=nil else
            for data,target in pairs(targets)do
                data.dirtAmount=target.amount;data.dirtAmountSent=target.sent
                local verify=(D.flushSerial+(target.slot or 0))%32==0
                if target.dirty or target.lastShown~=target.shown or verify then
                    for _,n in ipairs(data.nodes or {})do applyShader(n,target.shown,not verify)end
                    target.lastShown=target.shown;target.dirty=false
                end
            end
        end
    end
end
JLRSActivities.registerAdapter('jlrsVehicleDirt',{discover=D.discover,read=D.read,readInto=D.readInto,write=D.write})

local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)D.shaders={};D.targets={};D.nodeTargets=setmetatable({},{__mode='v'});D.nextTarget=0;D.flushSerial=0;D.install();return load(c,...)end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)local result=deleteMap(c,...);D.shaders={};D.targets={};D.nodeTargets=setmetatable({},{__mode='v'});D.nextTarget=0;D.flushSerial=0;return result end
