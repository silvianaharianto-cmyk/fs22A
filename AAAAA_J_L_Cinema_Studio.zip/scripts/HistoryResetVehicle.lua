-- History-only selection. No added recording/replay tick or cache writes.
JLRSHistoryReset={ROWS=8}
local S=JLRSHistoryReset
local function valid(v)return JLRSRecorder.valid(v) and v.components and not JLRSWorld.isTrain(v)end
local function name(v)return tostring(type(v.getName)=='function' and v:getName() or 'Trailer / Vehicle')end
function S.collect(c)
 local list,seen,targets={},{},{}
 local function visit(v)
  if not valid(v) or seen[v] then return end
  seen[v]=true;list[#list+1]=v
  if type(v.getAttachedImplements)=='function' then for _,imp in ipairs(v:getAttachedImplements() or {})do visit(imp.object)end end
 end
 for _,v in pairs(c.mission.vehicles or {})do visit(v)end
 local function add(v,entry,pose,offset,source)
  if not seen[v] or not entry.world or not entityExists(entry.node) or getParent(entry.node)~=entry.parent then return end
  local item=targets[v];if not item then item={vehicle=v,entries={},pose={},nodes={}};targets[v]=item end
  local index=item.nodes[entry.node]
  if not index then index=#item.entries+1;item.nodes[entry.node]=index;item.entries[index]=entry end
  local copy={};for k,value in pairs(entry)do copy[k]=value end;copy.vehicle=v;item.entries[index]=copy
  for j=1,6 do item.pose[(index-1)*6+j]=pose[offset+j] end
  item.source=source
 end
 for _,item in ipairs(c.vehicleResetSnapshot or {})do for i,e in ipairs(item.entries)do add(item.vehicle,e,item.pose,(i-1)*6,'Map awal')end end
 -- Later takes override earlier starts for the same vehicle, as normal Reset does.
 for _,clip in ipairs(c.history or {})do
  for _,e in ipairs(clip.worldScene and clip.worldScene.entries or {})do
   local first=e.samples and JLRSFrames.count(e.samples)>0 and JLRSFrames.get(e.samples,1)
   if first then add(e.vehicle,e,first.pose,0,'Record awal')end
  end
  if clip.frames and JLRSFrames.count(clip.frames)>0 then
   local first=JLRSFrames.get(clip.frames,1)
   local owners=JLRSFinalEditing.entryOwners(clip).resolved
   for i,e in ipairs(clip.entries or {})do add(owners[i] and owners[i].vehicle or e.vehicle,e,first.pose,(i-1)*6,'Record awal')end
  end
 end
 -- The latest successful Record boundary wins over starts from unrelated takes.
 for _,item in ipairs(c.beforeRecordResetSnapshot or {})do
  targets[item.vehicle]=nil
  for i,e in ipairs(item.entries)do add(item.vehicle,e,item.pose,(i-1)*6,'Sebelum Record')end
 end
 table.sort(list,function(a,b)if name(a)==name(b)then return a.rootNode<b.rootNode end;return name(a)<name(b)end)
 c.historyResetItems=list;c.historyResetTargets=targets
 c.historyResetOffset=math.min(c.historyResetOffset or 0,math.max(0,#list-S.ROWS))
end
function S.open(c)
 c.historyResetOpen=true;c.historyResetMarked={};c.historyResetOffset=0;S.collect(c)
 c.historyDrag=nil;c.historyScrollDrag=nil;c.hitboxes={};JLRSMouse.refresh(c)
end
function S.close(c)c.historyResetOpen=false;c.hitboxes={};JLRSMouse.refresh(c)end
function S.apply(c)
 if c.recording then c:notify('Stop / ESC dahulu sebelum Reset Vehicle.');return end
 if c.changePending then c:notify('Tunggu Change Cars selesai.');return end
 S.collect(c);local selected,targets={},{}
 for _,v in ipairs(c.historyResetItems)do if c.historyResetMarked[v] and c.historyResetTargets[v]then selected[v]=true;targets[#targets+1]=c.historyResetTargets[v]end end
 if #targets==0 then c:notify('Pilih kendaraan yang memiliki posisi awal.');return end
 local original=c.trailerResetSnapshot
 c.trailerResetSnapshot=c.beforeRecordTrailerSnapshot or original
 local ok,err=pcall(JLRSResetVehicle.reset,c,selected,targets)
 c.trailerResetSnapshot=original
 if not ok then c.historyResetActive=nil;c:notify('Reset Vehicle gagal: '..tostring(err))end
end
function S.draw(c)
 if not c.overlay then return end
 local M=JLRSMenu;c.hitboxes={};c.historyRowAreas={};c.historyScrollbar=nil
 M.rect(c,.18,.15,.64,.70,.015,.023,.037,.98)
 M.text(.20,.805,.022,'History | Reset Vehicle')
 M.text(.20,.767,.012,'Pilih kendaraan / trailer. Replay berhenti; posisi kendaraan lain tetap.')
 for i=1,S.ROWS do
  local v=c.historyResetItems[(c.historyResetOffset or 0)+i];local y=.70-(i-1)*.055
  if v then
   local target=c.historyResetTargets[v];local marked=c.historyResetMarked[v]
   M.rect(c,.20,y-.008,.60,.05,.04,.065,.09)
   M.button(c,.21,y,.035,.032,marked and 'X' or '',function()if target then c.historyResetMarked[v]=not c.historyResetMarked[v]end end,marked)
   M.text(.26,y+.015,.014,JLRSHistoryGroups.fitName(name(v),.014,.39))
   M.text(.26,y,.010,target and target.source or 'Posisi awal belum tersedia',.65,.75,.82)
  end
 end
 local total=#c.historyResetItems;local max=math.max(0,total-S.ROWS);local knob=.44*math.min(1,S.ROWS/math.max(S.ROWS,total))
 M.rect(c,.805,.31,.008,.44,.08,.12,.16)
 M.rect(c,.805,.75-knob-(max>0 and c.historyResetOffset/max*(.44-knob)or 0),.008,knob,.2,.7,.8)
 c.historyResetBar={x=.80,y=.31,w=.02,h=.44,knob=knob,max=max}
 M.button(c,.20,.235,.18,.036,'SELECT ALL',function()for _,v in ipairs(c.historyResetItems)do c.historyResetMarked[v]=c.historyResetTargets[v]~=nil end end)
 M.button(c,.39,.235,.22,.036,'RESET SELECTED',function()S.apply(c)end)
 M.button(c,.62,.235,.18,.036,'BACK',function()S.close(c)end)
 M.text(.20,.195,.011,JLRSHistoryGroups.fitName(c.notice or 'Scroll mouse untuk daftar kendaraan.',.011,.59),1,.75,.35)
end
local draw=JLRSHistory.draw
JLRSHistory.draw=function(c,...)if c.historyResetOpen then return S.draw(c)end;return draw(c,...)end
local close=JLRSHistory.close
JLRSHistory.close=function(c,...)c.historyResetOpen=false;c.historyResetDrag=nil;return close(c,...)end
local begin=JLRSTrailers.resetBegin
JLRSTrailers.resetBegin=function(c,vehicles,frames)
 if not c.historyResetActive then return begin(c,vehicles,frames)end
 local selected=c.historyResetActive
 if c.beforeRecordResetSnapshot then frames=nil end
 local desired=begin(c,vehicles,frames)
 for child,item in pairs(desired)do if not selected[child] or not selected[item.parent]then desired[child]=nil end end
 -- A selected trailer must separate from an unselected truck, and vice versa.
 for _,v in pairs(c.mission.vehicles or {})do
  local children={}
  if type(v.getAttachedImplements)=='function'then for _,imp in ipairs(v:getAttachedImplements()or {})do children[#children+1]=imp.object end end
  for _,child in ipairs(children)do if selected[v] or selected[child]then JLRSTrailers.detach(v,child)end end
 end
 local visual={};for child,item in pairs(JLRSTrailers.visual or {})do if selected[child] or selected[item.parent]then visual[#visual+1]={child=child,parent=item.parent}end end
 for _,item in ipairs(visual)do JLRSTrailers.detach(item.parent,item.child)end
 return desired
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
 local result=load(c,...);c.historyResetOpen=false
 if not c.mission then return result end
 local previous=c.mission.mouseEvent
 c.mission.mouseEvent=function(m,x,y,down,up,button,...)
  if c.historyOpen and c.menu and c.historyResetOpen and not(g_gui and g_gui:getIsGuiVisible())then
   c.mouseX=x;c.mouseY=y
   local max=math.max(0,#c.historyResetItems-S.ROWS)
   if down and (button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN)then
    c.historyResetOffset=math.max(0,math.min(max,c.historyResetOffset+(button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1)));return
   end
   local b=c.historyResetBar
   if c.historyResetDrag then
    if b and b.max>0 then c.historyResetOffset=math.floor(math.max(0,math.min(1,(b.y+b.h-b.knob/2-y)/math.max(.001,b.h-b.knob)))*b.max+.5)end
    if up then c.historyResetDrag=nil end;return
   end
   if down and button==Input.MOUSE_BUTTON_LEFT and b and x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h then c.historyResetDrag=true;return end
   JLRSMenu.click(c,x,y,down,button);return
  end
  return previous(m,x,y,down,up,button,...)
 end
 return result
end

-- One boundary snapshot only. Never scan/capture the map every replay frame.
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
 if c.recording then return start(c,...)end
 local map,trailer=c.vehicleResetSnapshot,c.trailerResetSnapshot
 JLRSResetVehicle.snapshot(c)
 local before,attachments=c.vehicleResetSnapshot,c.trailerResetSnapshot
 c.vehicleResetSnapshot=map;c.trailerResetSnapshot=trailer
 local result=start(c,...)
 if c.recording then c.beforeRecordResetSnapshot=before;c.beforeRecordTrailerSnapshot=attachments end
 return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
 c.beforeRecordResetSnapshot=nil;c.beforeRecordTrailerSnapshot=nil
 return unload(c,...)
end
