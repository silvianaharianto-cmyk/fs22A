-- Cosmetic camera filtering and final wheel pin after all replay activity writes.
-- No resampling, vehicle path edits, or blending across requested angle cuts.
JLRSRenderStable={}
local focus=JLRSCamera.focus
JLRSCamera.focus=function(c,...)
    -- Do not delay focus independently from the vehicle/camera pose. Tracking
    -- already uses this current-frame focus and is the stable reference.
    c.renderFocus=nil
    return focus(c,...)
end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)c.renderFocus=nil;return choose(c,...)end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,dt,...)
    -- Final playback owns a separate camera; no hidden preset camera pass.
    if c.finalPlaying then return end
    local time=g_time or 0
    -- Normal render advances camera phase/input once. Explicit zero-dt cuts remain instant.
    if dt and dt>0 and c.active and not c.editingOpen then
        if c.renderCameraTime==time and not c.angleCutPending then return end
        c.renderCameraTime=time
    end
    return tick(c,dt,...)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result
    if c.finalPlaying then
        local previous=c.jlrsLateWheelPass
        -- Reserve only tracks which this exact outer pass will refresh. No
        -- global wheel hook is bypassed; native late wheel pins remain active.
        local late={};if c.replaying then late[c]=true end
        for _,track in ipairs(c.liveTracks or {})do if track.replaying then late[track]=true end end
        c.jlrsLateWheelPass=late
        local ok,value=pcall(draw,c,...)
        c.jlrsLateWheelPass=previous
        if not ok then error(value,0)end
        result=value
    else result=draw(c,...) end
    if c.replaying then JLRSWheelVisual.refresh(c)end
    for _,track in ipairs(c.liveTracks or {})do if track.replaying then JLRSWheelVisual.refresh(track)end end
    -- A native graphics wheel pass may run after draw. Its existing guarded hook
    -- now sees the final authoritative local pose, including fallback tyre roll.
    return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)local result=load(c,...);c.renderFocus=nil;c.renderCameraTime=nil;return result end
