-- Live Record can promote precise tracks to contact physics. A camera-only
-- Final must hand those tracks back to the chosen replay mode, without rewinding.
JLRSFinalContactHandoff={}
local H=JLRSFinalContactHandoff
function H.prepare(c)
    if not c.preciseReplay or c.recording then return true end
    local tracks={}
    if c.replaying then tracks[#tracks+1]=c end
    for _,t in ipairs(c.liveTracks or {})do if t.replaying then tracks[#tracks+1]=t end end
    for _,t in ipairs(tracks)do
        if t.frames and t.collisionReplay then
            -- Use the actual displayed pose, including curve/replacement offsets.
            -- Handoff changes ownership without rewinding or sampling another path.
            local pose=JLRSRecorder.capture(t.entries)
            if not pose then c:notify('Isolasi replay gagal: node kendaraan berubah.');return false end
            local batch,physics=c.worldBatch,c.physicsReplay
            c.worldBatch=true;c.physicsReplay=false
            local ok,result=pcall(function()
                -- Do not call stopReplay: that restores end poses, trailer joints,
                -- engine state and sound. Only change this track's body controller.
                JLRSLive.restorePhysics(t)
                t.collisionReplay=false
                if not JLRSLive.detachPhysics(t)then error('Isolasi replay tidak tersedia.')end
                if JLRSRecorder.apply(t.entries,pose,false,true)==false then error('Pose kendaraan berubah.')end
            end)
            c.worldBatch=batch;c.physicsReplay=physics
            if not ok then
                JLRSLive.restorePhysics(t);t.collisionReplay=true
                c:notify('Isolasi replay gagal: '..tostring(result));return false
            end
            t.livePrecisionContact=nil;t.collisionVelocity=nil;t.collisionCorrection=nil
            t.replayAudioPose=pose;t.replayAudioTime=t.replayTime
        end
    end
    -- World can be absent while the live tracks still own cargo scenes.
    local ok,err=pcall(function()
        if c.worldReplay then H.isolateScene(c.worldReplay)end
        for _,t in ipairs(c.liveTracks or {})do if t.cargoReplay then H.isolateScene(t.cargoReplay)end end
    end)
    if not ok then c:notify('Isolasi obstacle gagal: '..tostring(err));return false end
    return true
end
function H.isolateScene(scene)
    if not scene or not JLRSProps or not JLRSProps.isolatePlayback then return end
    for _,state in ipairs(scene.states or {})do
        if state.propBodies then JLRSProps.isolatePlayback(state)end
    end
end
-- Contact physics belongs to active Live Record. Once Stop has saved the take,
-- all remaining replay tracks return to pure transform playback, of either type.
local stopRecord=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    local was=c.recording
    local result=stopRecord(c,...)
    if was and c==JLReplayStudio and not c.recording then
        if not H.prepare(c)then c:stop()end
    end
    return result
end
local record=JLRSFinal.record
JLRSFinal.record=function(c,...)
    if not c.finalRecording and not c.finalPlaying and not c.recording then
        if not H.prepare(c)then return end
    end
    return record(c,...)
end
