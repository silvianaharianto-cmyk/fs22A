-- Optional side stream: never changes the V1.14.13 motion/audio frame layout.
JLRSActivities={adapters={}}
local A=JLRSActivities
local function finite(v) return type(v)=='number' and v==v and math.abs(v)<math.huge end
local function scalar(v) if type(v)=='boolean' then return v and 1 or 0 end;return finite(v) and v or 0 end
local function copy(t) local out={};for i,v in ipairs(t) do out[i]=v end;return out end
local function invoke(v,name,...)
    if type(v[name])~='function' then return false end
    return pcall(v[name],v,...)
end
function A.registerAdapter(name,adapter)
    -- A custom specialization supplies discover/read/write; it owns its API.
    assert(type(name)=='string' and adapter.discover and adapter.read and adapter.write)
    A.adapters[name]=adapter
end
function A.discover(vehicles)
    local schema={};local seen={}
    for _,v in ipairs(vehicles or {}) do
        if not seen[v] then
            seen[v]=true
            local function add(kind,name,index,mode,getter,setter)
                schema[#schema+1]={owner=JLRSPersist.identity(v),config=v.configFileName or v.xmlFilename or '',kind=kind,
                    name=name or '',index=index or 0,mode=mode or 'step',getter=getter or '',setter=setter or '',object=v}
            end
            if v.spec_lights then
                for _,name in ipairs({'lightsTypesMask','beaconLightsActive','turnLightState','brakeLightsVisibility','reverseLightsVisibility'}) do add('light',name) end
                for i,beacon in ipairs(v.spec_lights.beaconLights or {}) do
                    if beacon.rotatorNode and entityExists(beacon.rotatorNode) then add('rotator','',i,'angle') end
                end
            end
            if v.spec_honk and v.playHonk then add('horn') end
            for _,pair in ipairs({{'getIsSirenActive','setIsSirenActive'},{'getSirenState','setSirenState'}}) do
                if type(v[pair[1]])=='function' and type(v[pair[2]])=='function' then
                    add('siren','',0,'step',pair[1],pair[2]);break
                end
            end
            local animations=v.spec_animatedVehicle and v.spec_animatedVehicle.animations or {}
            local names={};for name in pairs(animations) do if type(name)=='string' then names[#names+1]=name end end
            table.sort(names)
            if v.getAnimationTime and v.setAnimationTime then
                for _,name in ipairs(names) do add('animation',name,0,animations[name].looping and 'loop' or 'linear') end
            end
            local componentNodes={};for _,component in ipairs(v.components or {}) do componentNodes[component.node]=true end
            for _,kind in ipairs({'tool','part'}) do
                local list=v.spec_cylindered and v.spec_cylindered[kind=='tool' and 'movingTools' or 'movingParts'] or {}
                for i,tool in ipairs(list) do
                    if tool.node and tool.node~=v.rootNode and not componentNodes[tool.node] and entityExists(tool.node) then add(kind,'',i,'transform') end
                end
            end
            local adapterNames={};for name in pairs(A.adapters) do adapterNames[#adapterNames+1]=name end;table.sort(adapterNames)
            for _,name in ipairs(adapterNames) do
                local adapter=A.adapters[name]
                local ok,channels=pcall(adapter.discover,v)
                if ok then for _,ch in ipairs(channels or {}) do add('custom',ch.name,ch.index,ch.mode or 'step',name) end end
            end
        end
    end
    return schema
end
function A.resolve(channel,vehicles)
    for _,v in ipairs(vehicles or {}) do if v.jlrsPersistentId==channel.owner then return v end end
end
function A.values(channel,v,buffer)
    local out=buffer or {}
    -- Proven numeric adapters fill the existing buffer completely; preserve the
    -- generic adapter path for unknown external specializations.
    if v and channel.kind=='custom' then
        local adapter=A.adapters[channel.getter]
        if adapter and adapter.cinemaNumericReadInto and adapter.readInto then
            local ok,values=pcall(adapter.readInto,v,channel,out)
            if ok and values==out then return out end
            for i=1,6 do out[i]=ok and values and scalar(values[i])or 0 end
            return out
        end
    end
    for i=1,6 do out[i]=0 end
    if not v then return out end
    if channel.kind=='light' then out[1]=scalar((v.spec_lights or {})[channel.name])
    elseif channel.kind=='horn' then out[1]=scalar((v.spec_honk or {}).isPlaying)
    elseif channel.kind=='siren' then local ok,value=invoke(v,channel.getter);if ok then out[1]=scalar(value) end
    elseif channel.kind=='animation' then
        local ok,value=invoke(v,'getAnimationTime',channel.name);if ok then out[1]=scalar(value) end
    elseif channel.kind=='rotator' then
        local beacon=v.spec_lights and v.spec_lights.beaconLights and v.spec_lights.beaconLights[channel.index]
        if beacon and beacon.rotatorNode and entityExists(beacon.rotatorNode) then out[1],out[2],out[3]=getRotation(beacon.rotatorNode) end
    elseif channel.kind=='tool' or channel.kind=='part' then
        local tool=v.spec_cylindered and (v.spec_cylindered[channel.kind=='tool' and 'movingTools' or 'movingParts'] or {})[channel.index]
        if tool and tool.node and entityExists(tool.node) then
            out[1],out[2],out[3]=getTranslation(tool.node);out[4],out[5],out[6]=getRotation(tool.node)
        end
    elseif channel.kind=='custom' then
        local adapter=A.adapters[channel.getter]
        if adapter then local ok,values
            if buffer and adapter.readInto then ok,values=pcall(adapter.readInto,v,channel,out)
            else ok,values=pcall(adapter.read,v,channel) end
            if ok and values then for i=1,6 do out[i]=scalar(values[i]) end end end
    end
    return out
end
function A.capture(schema,vehicles)
    -- Record topology is fixed. Resolve UUIDs once instead of scanning every car per channel/frame.
    if not schema._recordOwners or schema._recordVehicles~=vehicles then
        local owners={};for _,v in ipairs(vehicles or {}) do owners[JLRSPersist.identity(v)]=v end
        schema._recordOwners=owners;schema._recordVehicles=vehicles
    end
    local pose={};local offset=0
    for _,channel in ipairs(schema) do
        local scratch=channel._recordScratch or {};channel._recordScratch=scratch
        local values=A.values(channel,schema._recordOwners[channel.owner] or channel.object,scratch)
        for i=1,6 do pose[offset+i]=values[i] end
        offset=offset+6
    end
    return pose
end
function A.equal(a,b)
    if not a or #a~=#b then return false end
    for i=1,#a do if a[i]~=b[i] and math.abs(a[i]-b[i])>0.0000001 then return false end end
    return true
end
-- Two private activity keys avoid allocating a full large pose at every key.
-- Each replay interpolator owns these buffers; source frames stay immutable.
local function activityTime(frames,index,buffered)
    if buffered then return JLRSFrames.time(frames,index) end
    return JLRSFrames.get(frames,index).t
end
local function activityKey(context,frames,index,reserved)
    local keys=context.finalActivityKeys
    if not keys or keys.frames~=frames then
        keys={frames=frames,{buffer={pose={}}},{buffer={pose={}}}};context.finalActivityKeys=keys
    end
    for _,key in ipairs(keys) do if key.index==index then return key.frame,key end end
    local key=keys[1]~=reserved and keys[1] or keys[2]
    key.index=nil -- A failed read must never leave a valid-looking partial key.
    key.frame=JLRSFrames.readInto(frames,index,key.buffer,true);key.index=index
    return key.frame,key
end
function A.at(data,time,state)
    local context=state or {};context.frames=data.frames
    local buffered=context.reuse and context.bufferedFinal
        and #data.schema>=128 and JLRSFrames.time and JLRSFrames.readInto
    -- Nearby search avoids disk-wide seeks and avoids allocating a discarded blended pose.
    local first,nextFrame
    local interval=context.activityInterval
    if interval and interval.frames==data.frames and time>=interval.first.t and time<=interval.nextFrame.t then
        first,nextFrame=interval.first,interval.nextFrame;context.frameIndex=interval.index
    else
        local count=JLRSFrames.count(data.frames)
        local i=math.max(1,math.min(context.frameIndex or 1,count));local steps=0
        while i>1 and steps<8 and activityTime(data.frames,i,buffered)>time do i=i-1;steps=steps+1 end
        steps=0
        while i<count and steps<8 and activityTime(data.frames,i+1,buffered)<time do i=i+1;steps=steps+1 end
        if not (activityTime(data.frames,i,buffered)<=time and (i==count or activityTime(data.frames,i+1,buffered)>=time)) then
            local low,high=1,count
            while low<=high do
                local mid=math.floor((low+high)/2)
                if activityTime(data.frames,mid,buffered)<=time then i=mid;low=mid+1 else high=mid-1 end
            end
        end
        context.frameIndex=i
        if buffered then
            -- Discard the old interval before reusing either private key.
            context.activityInterval=nil
            local reserved;first,reserved=activityKey(context,data.frames,i)
            nextFrame=activityKey(context,data.frames,math.min(i+1,count),reserved)
        else
            first=JLRSFrames.get(data.frames,i);nextFrame=JLRSFrames.get(data.frames,math.min(i+1,count))
        end
        context.activityInterval={frames=data.frames,first=first,nextFrame=nextFrame,index=i}
    end
    local firstPose,nextPose=first.pose,nextFrame.pose
    local alpha=nextFrame.t>first.t and math.max(0,math.min(1,(time-first.t)/(nextFrame.t-first.t))) or 0
    if context.reuse then
        local program=context.activityProgram
        if not program or program.schema~=data.schema then
            program={schema=data.schema,ops={},step={},linear={},angle={},loop={}};context.activityProgram=program
            local pose={};context.poseBuffer=pose
            for ci,ch in ipairs(data.schema) do
                local width=6
                if ch.kind=='light' or ch.kind=='horn' or ch.kind=='siren' or ch.kind=='animation' then width=1
                elseif ch.kind=='rotator' or ch.kind=='allMotor' then width=3
                elseif ch.kind=='custom' then
                    if ch.getter=='jlrsVehicleDirt' then width=ch.name=='wheel' and 1 or 3
                    elseif ch.getter=='jlrsVehicleParticles' then width=ch.name:match('/color$') and 3 or 5
                    elseif ch.getter=='jlrsTensionBelt' or ch.getter=='jlrsWheelSteering' then width=1
                    elseif ch.getter=='jlrsSuspension' and (ch.name=='movingParts' or ch.name=='movingTools') then width=3 end
                end
                for j=1,6 do pose[(ci-1)*6+j]=0 end
                for j=1,width do
                    local kind='step'
                    if ch.mode=='linear' or (ch.mode=='transform' and j<=3) then kind='linear'
                    elseif ch.mode=='loop' and j==1 then kind='loop'
                    elseif (ch.mode=='angle' and j<=3) or (ch.mode=='transform' and j>3) then kind='angle' end
                    local list=program[kind];list[#list+1]=(ci-1)*6+j
                end
            end
        end
        local pose=context.poseBuffer
        -- Compile only the channels which vary in this immutable key interval.
        -- Constant values are copied once; all setters still run every replay tick.
        if program.interval~=context.activityInterval then
            program.interval=context.activityInterval
            program.first,program.nextFrame=first,nextFrame
            -- Reuse interval work arrays; stale indices must be removed on shorter intervals.
            program.activeStep=program.activeStep or {};program.activeLinear=program.activeLinear or {};program.activeAngle=program.activeAngle or {}
            for _,kind in ipairs({'step','linear','angle'})do
                local active=program[kind=='step' and 'activeStep' or kind=='linear' and 'activeLinear' or 'activeAngle']
                local used=0
                for _,n in ipairs(program[kind])do
                    local a,b=firstPose[n],nextPose[n]
                    pose[n]=a
                    if a~=b then used=used+1;active[used]=n end
                end
                for j=#active,used+1,-1 do active[j]=nil end
            end
        end
        local step=program.activeStep
        for j=1,#step do local n=step[j];pose[n]=alpha>=1 and nextPose[n] or firstPose[n] end
        local linear=program.activeLinear
        for j=1,#linear do local n=linear[j];local a=firstPose[n];pose[n]=a+(nextPose[n]-a)*alpha end
        local angle=program.activeAngle;local pi=math.pi;local tau=pi*2
        for j=1,#angle do local n=angle[j];local a=firstPose[n];pose[n]=a+((nextPose[n]-a+pi)%tau-pi)*alpha end
        local loop=program.loop
        for j=1,#loop do
            local n=loop[j];local a,b=firstPose[n],nextPose[n]
            pose[n]=(a+((b-a+.5)%1-.5)*alpha)%1
        end
        return pose
    end
    local pose=context.reuse and (context.poseBuffer or {}) or {}
    if context.reuse then context.poseBuffer=pose end
    local writeIndex=0
    for ci,ch in ipairs(data.schema) do
        local offset=(ci-1)*6
        for j=1,6 do
            local a,b=firstPose[offset+j],nextPose[offset+j];local value=a
            if a==b and ch.mode~='loop' then value=a
            elseif ch.mode=='linear' then value=a+(b-a)*alpha
            elseif ch.mode=='loop' and j==1 then value=(a+((b-a+0.5)%1-0.5)*alpha)%1
            elseif ch.mode=='angle' and j<=3 then value=JLRSRecorder.angle(a,b,alpha)
            elseif ch.mode=='transform' then value=j<=3 and (a+(b-a)*alpha) or JLRSRecorder.angle(a,b,alpha)
            elseif alpha>=1 then value=b end
            writeIndex=writeIndex+1;pose[writeIndex]=value
        end
    end
    for j=#pose,writeIndex+1,-1 do pose[j]=nil end
    return pose
end
function A.animationName(channel,v)
    local anims=v.spec_animatedVehicle and v.spec_animatedVehicle.animations or {}
    if anims[channel.name] then return channel.name end
    -- Different vehicle models only transfer animations when a compatible name exists.
end
local setters={lightsTypesMask='setLightsTypesMask',beaconLightsActive='setBeaconLightsVisibility',turnLightState='setTurnLightState',
    brakeLightsVisibility='setBrakeLightsVisibility',reverseLightsVisibility='setReverseLightsVisibility'}
local booleans={beaconLightsActive=true,brakeLightsVisibility=true,reverseLightsVisibility=true}
-- Exact local geometry guards reduce scene-graph dirtiness for large schemas.
-- Read actual node values each time, so native animation or another mod can
-- never defeat replay authority by overwriting a cached pose.
function A.localPose(node,p,rotationOnly)
    local perf=JLRSFinalReplayPerf
    if perf and perf.active and perf.active() and perf.localTranslation and perf.localRotation then
        if not rotationOnly then perf.localTranslation(node,p[1],p[2],p[3]) end
        local offset=rotationOnly and 0 or 3
        perf.localRotation(node,p[offset+1],p[offset+2],p[offset+3])
        return
    end
    if not rotationOnly then
        local x,y,z=getTranslation(node)
        if x~=p[1] or y~=p[2] or z~=p[3] then setTranslation(node,p[1],p[2],p[3]) end
    end
    local offset=rotationOnly and 0 or 3
    local x,y,z=getRotation(node)
    if x~=p[offset+1] or y~=p[offset+2] or z~=p[offset+3] then setRotation(node,p[offset+1],p[offset+2],p[offset+3]) end
end
function A.apply(channel,v,values,state,paused,restoring)
    if not v or not JLRSRecorder.valid(v) then return end
    if channel.kind=='light' then
        if not v.spec_lights then return end
        local value=booleans[channel.name] and values[1]>=0.5 or values[1]
        if booleans[channel.name] then value=values[1]>=0.5 end
        if state.applied==nil or v.spec_lights[channel.name]~=value then
            invoke(v,setters[channel.name],value,state.applied==nil,true)
        end
        state.applied=value
    elseif channel.kind=='horn' then
        local on=values[1]>=0.5 and not paused
        if not v.spec_honk then return end
        if state.applied~=on or v.spec_honk.isPlaying~=on then invoke(v,'playHonk',on,true) end
        -- Native Honk can refuse audio for an unselected vehicle; ensure Replay All audio works.
        local sample=v.spec_honk.sample
        if sample and g_soundManager then
            if on and g_soundManager.getIsSamplePlaying and not g_soundManager:getIsSamplePlaying(sample) and g_soundManager.playSample then g_soundManager:playSample(sample)
            elseif not on and state.applied~=false and g_soundManager.stopSample then g_soundManager:stopSample(sample) end
        end
        state.applied=on
    elseif channel.kind=='siren' then
        local value=values[1]
        if channel.getter=='getIsSirenActive' then value=values[1]>=0.5 and not paused
        elseif paused then value=0 end
        local ok,current=invoke(v,channel.getter)
        if state.applied==nil or not ok or current~=value then invoke(v,channel.setter,value,true) end
        state.applied=value
    elseif channel.kind=='animation' then
        local name=A.animationName(channel,v);if not name then return end
        if not state.started then invoke(v,'stopAnimation',name,true);state.started=true end
        local ok,current=invoke(v,'getAnimationTime',name)
        if state.applied==nil or not ok or math.abs(current-values[1])>0.0000001 then
            invoke(v,'setAnimationTime',name,values[1],true,false)
        end
        state.applied=values[1]
    elseif channel.kind=='rotator' then
        local beacon=v.spec_lights and v.spec_lights.beaconLights and v.spec_lights.beaconLights[channel.index]
        if beacon and beacon.rotatorNode and entityExists(beacon.rotatorNode) then A.localPose(beacon.rotatorNode,values,true) end
    elseif channel.kind=='tool' or channel.kind=='part' then
        -- Local geometry belongs to its model; never transfer raw hydraulic transforms across models.
        if (v.configFileName or v.xmlFilename or '')~=channel.config then return end
        local tool=v.spec_cylindered and (v.spec_cylindered[channel.kind=='tool' and 'movingTools' or 'movingParts'] or {})[channel.index]
        if tool and tool.node and tool.node~=v.rootNode and entityExists(tool.node) then
            A.localPose(tool.node,values,false)
            if tool.curTrans then for i=1,3 do tool.curTrans[i]=values[i] end end
            if tool.curRot then for i=1,3 do tool.curRot[i]=values[i+3] end end
        end
    elseif channel.kind=='custom' then
        local adapter=A.adapters[channel.getter];if adapter then adapter.write(v,channel,values,paused,restoring) end
    end
end
function A.tick(track)
    local data=track.frames and track.frames.jlrsActivities
    if not data or not data.frames or JLRSFrames.count(data.frames)==0 then return end
    local state=track.activityReplay
    if not state or state.data~=data then
        A.restore(track)
        state={data=data,channels={},renderVehicles={},sample={reuse=true,bufferedFinal=true}};track.activityReplay=state
        for i,ch in ipairs(data.schema) do
            local vehicle=A.resolve(ch,track.recordVehicles or {track.target})
            local s={vehicle=vehicle,original=A.values(ch,vehicle)};state.channels[i]=s
            if vehicle then state.renderVehicles[vehicle]=true end
            if vehicle and ch.kind=='animation' then
                local animation=vehicle.spec_animatedVehicle and vehicle.spec_animatedVehicle.animations[ch.name]
                if animation then local ok,playing=invoke(vehicle,'getIsAnimationPlaying',ch.name);s.wasPlaying=ok and playing or false;s.speed=animation.currentSpeed end
            end
        end
    end
    local ok,pose=pcall(A.at,data,track.replayTime or 0,state.sample)
    if not ok then
        if not state.reported then track:notify('Aktivitas replay tidak terbaca: '..tostring(pose));state.reported=true end
        return
    end
    -- Compile a dispatch list once per immutable key interval. Constant local
    -- geometry and inactive effect snapshots need no per-render wrapper chain.
    -- Active effects, motor/audio, coupling and changing channels always run.
    state.dispatchTick=(state.dispatchTick or 0)+1
    local interval=state.sample.activityInterval
    local intervalChanged=state.dispatchInterval~=interval
    local full=not state.dispatchPrimed or state.dispatchPaused~=track.paused
        or state.dispatchTick%16==0 or not JLReplayStudio.preciseReplay or JLReplayStudio.recording
    if interval and state.dispatchInterval~=interval then
        local list=state.dispatch or {};state.dispatch=list
        local pending=state.dispatchPending or {};state.dispatchPending=pending
        local pendingCount=0
        local used=0;local first,last=interval.first.pose,interval.nextFrame.pose
        for i,ch in ipairs(data.schema)do
            local n=(i-1)*6
            local candidate=ch.kind=='animation' or ch.kind=='tool' or ch.kind=='part' or ch.kind=='rotator'
            if ch.kind=='custom'then
                candidate=ch.getter=='jlrsVehicleDirt' or (ch.getter=='jlrsVehicleParticles'
                    and ((ch.name or ''):match('/color$')or (first[n+1]<.5 and last[n+1]<.5)))
                    or (ch.getter=='jlrsTrailerAttachment' and first[n+1]<.5 and last[n+1]<.5)
            end
            local constant=candidate
            if constant then for j=1,6 do if first[n+j]~=last[n+j]then constant=false;break end end end
            if not constant then used=used+1;list[used]=i
            else
                local previous=state.channels[i].values
                local dirty=not previous
                if previous then for j=1,6 do if previous[j]~=first[n+j]then dirty=true;break end end end
                if dirty then pendingCount=pendingCount+1;pending[pendingCount]=i end
            end
        end
        for i=#list,used+1,-1 do list[i]=nil end
        for i=#pending,pendingCount+1,-1 do pending[i]=nil end
        state.dispatchInterval=interval
    end
    state.dispatchPaused=track.paused
    local list=not full and interval and state.dispatch
    local pending=list and intervalChanged and state.dispatchPending
    local activeSize=list and #list or #data.schema
    local size=activeSize+(pending and #pending or 0)
    state.dispatchPrimed=true
    for di=1,size do
        local i=di<=activeSize and (list and list[di]or di)or pending[di-activeSize]
        local ch=data.schema[i]
        local s=state.channels[i]
        if not s.failed then
            local adapter=ch.kind=='custom' and A.adapters[ch.getter]
            local values=(not adapter or adapter.readInto or adapter.reuseReplayValues) and (s.values or {}) or {}
            s.values=values
            local n=(i-1)*6
            values[1],values[2],values[3]=pose[n+1],pose[n+2],pose[n+3]
            values[4],values[5],values[6]=pose[n+4],pose[n+5],pose[n+6]
            local success,err=pcall(A.apply,ch,s.vehicle,values,s,track.paused,false)
            if not success then s.failed=true;print('[J_L Cinema Studio] ACTIVITY '..ch.kind..': '..tostring(err)) end
        end
    end
    if Lights and Lights.onUpdate then
        -- Only the light rendering listener; no Vehicle:update or physics update.
        -- Zero dt prevents extra rotation over the recorded rotator pose.
        for v in pairs(state.renderVehicles) do
            if v.spec_lights then pcall(Lights.onUpdate,v,0,false,false,false) end
        end
    end
end
function A.restore(track)
    local state=track.activityReplay;if not state then return end
    track.activityReplay=nil
    for i,ch in ipairs(state.data.schema) do
        local s=state.channels[i]
        if s and s.vehicle then
            pcall(A.apply,ch,s.vehicle,s.original,{},false,true)
            if ch.kind=='animation' and s.wasPlaying then invoke(s.vehicle,'playAnimation',ch.name,s.speed or 1,s.original[1],true) end
        end
    end
end
function A.record(c,force)
    local state=c.activityRecording;if not state then return end
    local time=c.recordTime or 0;local pose=A.capture(state.data.schema,c.recordVehicles)
    local count=JLRSFrames.count(state.data.frames)
    if count==0 or force or not A.equal(pose,state.last) then
        -- Keep an exact old-state boundary before a switch across a stationary interval.
        if count>0 and state.lastTime and time>state.lastTime and state.lastSampleTime<state.lastTime then
            JLRSFrames.push(state.data.frames,{t=state.lastTime,pose=state.last});state.lastSampleTime=state.lastTime
        end
        if count==0 or time>state.lastSampleTime then
            JLRSFrames.push(state.data.frames,{t=time,pose=pose});state.lastSampleTime=time
        end
    end
    state.last=pose;state.lastTime=time
end
function A.write(x,key,frames)
    local data=frames.jlrsActivities;if not data then return end
    local k=key..'.activities';x:setInt(k..'#version',1);x:setInt(k..'#channels',#data.schema)
    if data.frames then JLRSPersist.writeStream(x,k..'.frames',data.frames)
    else for name,value in pairs(data.reference or {}) do x:setInt(k..'.frames#'..name,value) end end
    for i,ch in ipairs(data.schema) do
        local ck=k..'.channel('..(i-1)..')'
        for _,name in ipairs({'owner','config','kind','name','mode','getter','setter'}) do x:setString(ck..'#'..name,ch[name]) end
        x:setInt(ck..'#index',ch.index)
    end
end
function A.read(x,key,frames)
    local k=key..'.activities';if x:getInt(k..'#version',0)==0 then return end
    local schema={}
    for i=1,x:getInt(k..'#channels',0) do
        local ck=k..'.channel('..(i-1)..')';local ch={}
        for _,name in ipairs({'owner','config','kind','name','mode','getter','setter'}) do ch[name]=x:getString(ck..'#'..name,'') end
        ch.index=x:getInt(ck..'#index',0);schema[i]=ch
    end
    if #schema==0 then return end
    local ok,stream=pcall(JLRSPersist.readStream,x,k..'.frames')
    if ok then frames.jlrsActivities={schema=schema,frames=stream}
    else
        local reference={}
        for _,name in ipairs({'id','count','sealed','chunkSize'}) do reference[name]=x:getInt(k..'.frames#'..name,0) end
        frames.jlrsActivities={schema=schema,reference=reference}
        print('[J_L Cinema Studio] ACTIVITY HISTORY tidak tersedia; metadata asli dipertahankan: '..tostring(stream))
    end
end
function A.commit(frames)
    local data=frames.jlrsActivities;if data and data.frames then data.frames._jlrs.persistent=true end
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    local result=start(c,...)
    if c.recording then
        local schema=A.discover(c.recordVehicles)
        if #schema>0 then
            local data={schema=schema,frames=JLRSFrames.new(#schema*6)};c.frames.jlrsActivities=data
            -- Large activity schemas previously sealed every 2-6 frames: native
            -- XML save/verify work accumulated faster than the staged writer.
            -- Existing manifests persist chunkSize; timestamps/channels stay exact.
            if #schema>=128 and data.frames._jlrs then
                data.frames._jlrs.chunkSize=math.max(4,math.min(60,math.floor(180000/(#schema*6))))
            end
            c.activityRecording={data=data,lastSampleTime=-1};A.record(c,true)
            c:notify('ACTIVITY RECORD | '..#schema..' kanal | lampu + horn/sirine + animasi')
        end
    end
    return result
end
local recordTick=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,...)
    local result=recordTick(c,...)
    if c.recording and c.activityRecording then
        local ok,err=pcall(A.record,c,false)
        if not ok then JLRSRecorder.stopRecord(c);c:notify('Penyimpanan aktivitas gagal: '..tostring(err)) end
    end
    return result
end
local stopRecord=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    if c.recording and c.activityRecording then
        local ok,err=pcall(A.record,c,true)
        if not ok then c:notify('Frame akhir aktivitas gagal: '..tostring(err)) end
    end
    c.activityRecording=nil;return stopRecord(c,...)
end
local replayTick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    local result=replayTick(track,...)
    if track.replaying then A.tick(track) else A.restore(track) end
    return result
end
local stopReplay=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    local result=stopReplay(track,...);A.restore(track);return result
end
local adapt=JLRSChange.adapt
JLRSChange.adapt=function(entries,frames,...)
    local result=adapt(entries,frames,...)
    if result and frames.jlrsActivities then result.frames.jlrsActivities=frames.jlrsActivities end
    return result
end
-- Activity streams can be shared by remapped History; only free unreferenced data.
local remove=JLRSHistory.delete
JLRSHistory.delete=function(c,clip,...)
    local data=clip.frames.jlrsActivities;local result=remove(c,clip,...)
    if data then
        local referenced=false
        for _,item in ipairs(c.history or {}) do if item.frames.jlrsActivities==data then referenced=true;break end end
        if not referenced and data.frames then data.frames._jlrs.persistent=false;JLRSFrames.release(data.frames) end
    end
    return result
end

local resetClock=JLRSLive.resetClock
JLRSLive.resetClock=function(c,...)
    local result=resetClock(c,...)
    for _,track in ipairs(c.liveTracks or {}) do A.tick(track) end
    return result
end
local startReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    local result=startReplay(c,...)
    if c.replaying then A.tick(c) end
    return result
end
local pause=JLReplayStudio.togglePause
JLReplayStudio.togglePause=function(c,...)
    local result=pause(c,...)
    if c.replaying then A.tick(c) end
    for _,track in ipairs(c.liveTracks or {}) do
        track.paused=c.livePaused or (track.replayTime>=track.duration and not track.loop)
        A.tick(track)
    end
    return result
end
