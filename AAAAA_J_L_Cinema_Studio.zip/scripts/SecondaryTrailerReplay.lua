-- V88 base: coupling and native ramp geometry for secondary vehicles. Their body
-- and wheel motion remains in the existing sparse world stream. No full-map
-- activity discovery or per-render vehicle discovery is installed.
local NAME='jlrsTrailerAttachment'
local discover=JLRSActivities.discover
JLRSActivities.discover=function(vehicles)
    local schema=discover(vehicles);local c=JLReplayStudio
    if not c.standardCargoBuilding or c.recordAllActive then return schema end
    local adapter=JLRSActivities.adapters[NAME];if not adapter then return schema end
    local seen={}
    for _,v in ipairs(vehicles or {})do seen[v]=true end
    for _,track in ipairs(c.liveTracks or {})do if track.replaying then
        for _,v in ipairs(track.recordVehicles or {track.target})do seen[v]=true end
        for _,e in ipairs(track.entries or {})do if e.vehicle then seen[e.vehicle]=true end end
    end end
    for _,v in pairs(c.mission and c.mission.vehicles or {})do
        if not seen[v] and JLRSRecorder.valid(v) and not JLRSWorld.isTrain(v) then
            seen[v]=true
            local owner=JLRSPersist.identity(v)
            local config=v.configFileName or v.xmlFilename or ''
            -- Only the existing three motor scalars; no extra motion stream or
            -- broad activity adapter discovery is needed for secondary audio.
            local motor=v.spec_motorized and v.spec_motorized.motor
            if motor and type(motor.getLastModulatedMotorRpm)=='function'then
                schema[#schema+1]={owner=owner,config=config,kind='allMotor',name='',index=0,
                    mode='linear',getter='',setter='',object=v}
            end
            for _,effectName in ipairs({'jlrsWheelSteering','jlrsTensionBelt','jlrsVehicleDirt','jlrsVehicleParticles','jlrsInstantEffects_instantFire','jlrsInstantEffects_instantWash','jlrsInstantEffects_instantWashRed'})do
                local effect=JLRSActivities.adapters[effectName]
                if effect then for _,ch in ipairs(effect.discover(v)or {})do
                    schema[#schema+1]={owner=owner,config=config,kind='custom',name=ch.name or '',index=ch.index or 0,
                        mode=ch.mode or 'step',getter=effectName,setter='',object=v}
                end end
            end
            -- Every vehicle keeps its own suspension/parent pose in the shared
            -- take, including vehicles driven after TAB without pressing Stop.
            -- Do not duplicate the large hydraulic-scale channel set.
            for _,effectName in ipairs({'jlrsSuspension','jlrsTireColor','jlrsStrobe'})do
                local effect=JLRSActivities.adapters[effectName]
                if effect then for _,ch in ipairs(effect.discover(v)or {})do
                    if effectName=='jlrsTireColor' or effectName=='jlrsStrobe' or ch.name=='wheel' or ch.name=='node'
                        or (ch.name or ''):match('^wheelParent%d+$')then
                        schema[#schema+1]={owner=owner,config=config,kind='custom',name=ch.name or '',index=ch.index or 0,
                            mode=ch.mode or 'step',getter=effectName,setter='',object=v}
                    end
                end end
            end
            -- Beacon-only lighting channels. Do not expand the full light/effect
            -- schema for secondary vehicles; existing interpolation owns rotation.
            if v.spec_lights and #(v.spec_lights.beaconLights or {})>0 then
                schema[#schema+1]={owner=owner,config=config,kind='light',name='beaconLightsActive',index=0,
                    mode='step',getter='',setter='',object=v}
                for i,beacon in ipairs(v.spec_lights.beaconLights)do
                    if beacon.rotatorNode and entityExists(beacon.rotatorNode)then
                        schema[#schema+1]={owner=owner,config=config,kind='rotator',name='',index=i,
                            mode='angle',getter='',setter='',object=v}
                    end
                end
            end
            local animations=v.spec_animatedVehicle and v.spec_animatedVehicle.animations or {}
            local names={}
            if type(v.getAnimationTime)=='function' and type(v.setAnimationTime)=='function'then
                for name in pairs(animations)do if type(name)=='string'then names[#names+1]=name end end
                table.sort(names)
                for _,name in ipairs(names)do
                    schema[#schema+1]={owner=owner,config=config,kind='animation',name=name,index=0,
                        mode=animations[name].looping and 'loop' or 'linear',getter='',setter='',object=v}
                end
            end
            -- Some ramps use cylindered transforms instead of named animations.
            local components={};for _,part in ipairs(v.components or {})do components[part.node]=true end
            for _,kind in ipairs({'tool','part'})do
                local list=v.spec_cylindered and v.spec_cylindered[kind=='tool' and 'movingTools' or 'movingParts']or {}
                for i,part in ipairs(list)do
                    if part.node and part.node~=v.rootNode and not components[part.node] and entityExists(part.node)then
                        schema[#schema+1]={owner=owner,config=config,kind=kind,name='',index=i,
                            mode='transform',getter='',setter='',object=v}
                    end
                end
            end
            for _,ch in ipairs(adapter.discover(v)or {})do
                schema[#schema+1]={owner=JLRSPersist.identity(v),config=v.configFileName or v.xmlFilename or '',
                    kind='custom',name=ch.name or '',index=ch.index or 0,mode=ch.mode or 'step',getter=NAME,setter='',object=v}
            end
        end
    end
    return schema
end
-- Coupling preparation resolves these once and uses its existing detach/restore
-- lifecycle, so native joints cannot fight the secondary trailer's saved pose.
local resolve=JLRSActivities.resolve
JLRSActivities.resolve=function(ch,vehicles)
    local v=resolve(ch,vehicles)
    local effect=ch.kind=='custom' and (ch.getter=='jlrsStrobe' or ch.getter=='jlrsSuspension' or ch.getter=='jlrsTireColor' or ch.getter=='jlrsWheelSteering' or ch.getter=='jlrsTensionBelt' or ch.getter=='jlrsVehicleDirt' or ch.getter=='jlrsVehicleParticles' or (ch.getter or ''):match('^jlrsInstantEffects_'))
    if v or (not effect and ch.getter~=NAME and ch.kind~='animation' and ch.kind~='tool' and ch.kind~='part' and ch.kind~='rotator' and ch.kind~='allMotor' and not (ch.kind=='light' and ch.name=='beaconLightsActive')) then return v end
    local found
    for _,candidate in pairs(JLReplayStudio.mission and JLReplayStudio.mission.vehicles or {})do
        if candidate.jlrsPersistentId==ch.owner and JLRSRecorder.valid(candidate)then
            if found and found~=candidate then return nil end
            found=candidate
        end
    end
    return found
end
