JLRSMenu={}
function JLRSMenu.toggle(c)
    c.menu=not c.menu
    if g_inputBinding then g_inputBinding:setShowMouseCursor(c.menu) end
    JLRSMouse.refresh(c)
end
function JLRSMenu.text(x,y,size,value,r,g,b)
    setTextAlignment(RenderText.ALIGN_LEFT);setTextColor(r or 0.9,g or 0.94,b or 1,1)
    renderText(x,y,size,tostring(value))
end
function JLRSMenu.rect(c,x,y,w,h,r,g,b,a)
    setOverlayColor(c.overlay,r,g,b,a or 1);renderOverlay(c.overlay,x,y,w,h)
end
function JLRSMenu.button(c,x,y,w,h,label,callback,selected,color)
    local hover=c.mouseX and c.mouseX>=x and c.mouseX<=x+w and c.mouseY>=y and c.mouseY<=y+h
    local r,g,b=0.065,0.095,0.14
    if selected then r,g,b=0.035,0.42,0.5 elseif hover then r,g,b=0.14,0.22,0.30 end
    if color then r,g,b=color[1],color[2],color[3] end
    JLRSMenu.rect(c,x,y,w,h,r,g,b)
    JLRSMenu.text(x+0.008,y+h*0.33,0.013,label)
    c.hitboxes[#c.hitboxes+1]={x=x,y=y,w=w,h=h,callback=callback}
end
function JLRSMenu.adjust(c,y,label,key,step,min,max,format)
    JLRSMenu.text(0.545,y+0.009,0.012,label,0.65,0.74,0.83)
    local function change(d) c[key]=math.max(min,math.min(max,c[key]+d*step)) end
    JLRSMenu.button(c,0.685,y,0.025,0.03,'-',function() change(-1) end)
    JLRSMenu.text(0.72,y+0.009,0.013,string.format(format or '%.1f',c[key]))
    JLRSMenu.button(c,0.805,y,0.025,0.03,'+',function() change(1) end)
end
local shotFields={
    {'Replay Speed','replaySpeed',0.25,0.25,2,'x%.2f'},
    {'Camera Speed','cameraSpeed',0.1,0.1,3,'%.1f'},
    {'Distance','distance',1,2,100,'%.0fm'},
    {'Height','height',0.5,0.5,60,'%.1fm'},
    {'Amplitude','amplitude',0.5,0.5,20,'%.1fm'},
    {'Tracking Side','side',1,-50,50,'%.0fm'},
    {'FOV / Zoom','fov',5,15,100,'%.0f'},
    {'Mouse Sensitivity','sensitivity',0.1,0.1,2,'%.1f'},
    {'T Auto Interval','fixedAngleInterval',1,1,120,'%.0fs'}
}
function JLRSMenu.beginShot(c)
    c.shotDraft={}
    for _,f in ipairs(shotFields) do c.shotDraft[f[2]]=c[f[2]] end
end
function JLRSMenu.applyShot(c)
    if not c.shotDraft then return end
    local oldDistance,oldHeight=c.distance,c.height
    for _,f in ipairs(shotFields) do c[f[2]]=c.shotDraft[f[2]] end
    local saved=c.angleEnabled and JLRSAngle.saved(c)
    if saved then
        local scale=c.distance/math.max(oldDistance,0.01)
        saved.x=saved.x*scale;saved.z=saved.z*scale;saved.y=saved.y+c.height-oldHeight
        saved.distance=c.distance;saved.height=c.height;saved.fov=c.fov
    end
    if c.active then JLRSCamera.choose(c,c.mode) end
    c.notice='Shoot setting diterapkan.'
end
function JLRSMenu.common(c)
    JLRSMenu.text(0.365,0.365,0.012,'CAMERA CONTROLS',0.12,0.85,0.9)
    JLRSMenu.button(c,0.365,0.310,0.142,0.036,'Reset Angle',function() JLRSReset.angle(c) end)
    JLRSMenu.button(c,0.516,0.310,0.142,0.036,'Reset Movement',function() JLRSReset.movement(c) end)
    JLRSMenu.button(c,0.667,0.310,0.163,0.036,'Reset Shoot',function() JLRSCamera.choose(c,c.mode) end)
    JLRSMenu.button(c,0.365,0.259,0.223,0.037,'Lock Kendaraan: '..(c.lock and 'ON' or 'OFF'),function() JLRSCamera.toggleLock(c) end,c.lock)
    JLRSMenu.button(c,0.598,0.259,0.232,0.037,'Camera Angle: '..(c.angleEnabled and 'ON' or 'OFF'),function() JLRSAngle.toggle(c) end,c.angleEnabled)
    JLRSMenu.text(0.365,0.236,0.010,'R: ganti angle | WASDQE + mouse: gerakkan kamera',0.65,0.74,0.83)
end
-- One layout owns all Other entries; extensions no longer draw over each other.
function JLRSMenu.otherActive(c)
    return c.menu and c.uiTab=='Other' and not(c.changeOpen or c.colorCarsOpen or c.curvaOpen
        or c.carsOpen or c.historyOpen or c.finalListOpen or c.editingOpen)
end
function JLRSMenu.otherRows(c)
    return {
        {'Object Movement',function() JLRSObject.open(c) end,c.objectEnabled,'Klik objek di map | F9 mulai | 9 tampil / sembunyikan'},
        {'Change Cars',function() JLRSChange.open(c) end,c.changeOpen,'Ganti kendaraan melalui Store asli'},
        {'Change Color Cars',function() JLRSColorCars.open(c) end,false,'Pilih kendaraan dan ubah warna'},
        {'Physics Placeable: '..(c.physicsPlaceable and 'ON' or 'OFF'),function() JLRSPhysicsPlaceable.toggle(c) end,c.physicsPlaceable,'Rekam aktivitas placeable bergerak'},
        {'Anti Lag: '..(c.antiLag~=false and 'ON' or 'OFF'),function() JLRSAntiLag.toggle(c) end,c.antiLag~=false,'Pengaturan optimasi Cinema Studio'},
        {'Curva',function() JLRSCurva.open(c) end,false,'Edit jalur kendaraan'}
    }
end
function JLRSMenu.drawOther(c)
    local rows=JLRSMenu.otherRows(c);local visible=5
    local maxScroll=math.max(0,#rows-visible)
    c.otherScroll=math.max(0,math.min(maxScroll,c.otherScroll or 0))
    c.otherMaxScroll=maxScroll
    JLRSMenu.rect(c,.355,.245,.485,.505,.026,.043,.065)
    for slot=1,visible do
        local row=rows[c.otherScroll+slot]
        if row then
            local y=.681-(slot-1)*.096
            JLRSMenu.button(c,.369,y,.438,.047,row[1],row[2],row[3])
            JLRSMenu.text(.377,y-.020,.010,row[4],.65,.74,.83)
        end
    end
    JLRSMenu.rect(c,.822,.265,.006,.463,.08,.13,.18)
    local h=.463*math.min(1,visible/#rows)
    local y=.265+(.463-h)*(1-(maxScroll>0 and c.otherScroll/maxScroll or 0))
    JLRSMenu.rect(c,.822,y,.006,h,.12,.65,.72)
    JLRSMenu.text(.369,.222,.010,'Scroll mouse untuk melihat menu lainnya',.65,.74,.83)
end
function JLRSMenu.draw(c)
    if not c.overlay then return end
    if not c.menu then
        if c.recording or c.replaying then
            JLRSMenu.rect(c,0.018,0.018,0.49,0.055,0.015,0.025,0.04,0.9)
            local state=c.recording and 'RECORD' or (c.paused and 'PAUSED' or 'REPLAY')
            JLRSMenu.text(0.028,0.048,0.014,string.format('J_L Cinema Studio | %s | %.2fs',state,c.recording and c.recordTime or c.replayTime),0.1,0.9,0.95)
            JLRSMenu.text(0.028,0.027,0.011,'F6 Menu | Space Pause | Backspace Stop | Mouse / Scroll')
        end
        return
    end
    c.hitboxes={};c.uiTab=c.uiTab or 'Record'
    JLRSMenu.rect(c,0.15,0.09,0.70,0.82,0.015,0.023,0.037,0.97)
    JLRSMenu.rect(c,0.15,0.83,0.70,0.08,0.025,0.16,0.23)
    JLRSMenu.rect(c,0.15,0.827,0.70,0.003,0,0.83,0.88)
    JLRSMenu.text(0.173,0.865,0.028,'J_L Cinema Studio',0.95,1,1)
    JLRSMenu.text(0.174,0.841,0.011,'CINEMATIC VEHICLE RECORDER  /  V1.18.86.136')
    JLRSMenu.button(c,0.795,0.852,0.035,0.036,'X',function() JLRSMenu.toggle(c) end)
    JLRSMenu.rect(c,0.165,0.215,0.174,0.595,0.026,0.043,0.065)
    for i,label in ipairs({'Record','Camera Preset','Shot Settings','Other','Director'}) do
        JLRSMenu.button(c,0.173,0.746-(i-1)*0.061,0.157,0.049,label,function()
            c.uiTab=label;if label=='Shot Settings' then JLRSMenu.beginShot(c) end
        end,c.uiTab==label)
    end
    JLRSMenu.button(c,0.173,0.350,0.157,0.039,'History Record',function() JLRSHistory.open(c) end)
    JLRSMenu.button(c,0.173,0.301,0.157,0.039,'Replay Camera',function() JLRSGroup.camera(c) end,c.groupCamera)
    JLRSMenu.button(c,0.173,0.252,0.157,0.039,'Next Car / Tab',function() JLRSGroup.next(c) end)
    JLRSMenu.text(0.365,0.773,0.020,c.uiTab,0.12,0.85,0.9)
    if c.uiTab=='Record' then
        local state=c.recordAllActive and c.recording and 'RECORDING ALL' or c.recording and 'RECORDING' or ((c.replaying or #(c.liveTracks or {})>0) and ((c.paused or c.livePaused) and 'PAUSED' or 'REPLAYING') or 'READY')
        JLRSMenu.text(0.365,0.735,0.012,string.format('%s | %d frames | %.2fs',state,JLRSFrames.count(c.frames),c.duration or 0))
        local labels={c.recordAllActive and c.recording and 'ALL ACTIVE' or c.recording and 'Stop Record' or 'Record','Replay',(c.paused or c.livePaused) and 'Play' or 'Pause','Stop'}
        local actions={function() c:toggleRecord() end,function() JLRSRecorder.startReplay(c) end,function() c:togglePause() end,function() JLRSStopLoading.request(c,true) end}
        for i,label in ipairs(labels) do
            JLRSMenu.button(c,0.365+((i-1)%2)*0.239,0.661-math.floor((i-1)/2)*0.058,0.226,0.046,label,actions[i],false,i==1 and {0.55,0.08,0.14} or nil)
        end
        JLRSMenu.button(c,0.365,0.542,0.226,0.039,'Loop: '..(c.loop and 'ON' or 'OFF'),function() c.loop=not c.loop end,c.loop)
        JLRSMenu.button(c,0.604,0.542,0.226,0.039,'Mini Hud: '..(c.miniHudEnabled and 'ON' or 'OFF'),function() JLRSMiniHud.toggle(c) end,c.miniHudEnabled)
        local ratio=c.duration>0 and math.max(0,math.min(1,c.replayTime/c.duration)) or 0
        JLRSMenu.rect(c,0.365,0.505,0.465,0.012,0.08,0.13,0.18)
        JLRSMenu.rect(c,0.365,0.505,0.465*ratio,0.012,0,0.75,0.8)
        c.hitboxes[#c.hitboxes+1]={x=0.365,y=0.495,w=0.465,h=0.03,callback=function(x) JLRSRecorder.seek(c,(x-0.365)/0.465*c.duration) end}
        JLRSMenu.text(0.365,0.480,0.010,string.format('%.2f / %.2fs | Klik timeline untuk seek',c.replayTime,c.duration))
        JLRSMenu.button(c,0.365,0.405,0.465,0.032,c.preciseReplay and 'Replay Mode: PRESISI' or ('Physics: '..(c.physicsReplay and 'ON' or 'OFF')),function() JLRSCollision.toggle(c) end,c.physicsReplay)
        JLRSMenu.common(c)
    elseif c.uiTab=='Camera Preset' then
        local presets={{1,'Free Camera'},{3,'Tilt Camera'},{5,'Zoom Camera'},{7,'Vertigo'},{9,'Fly-By'},{11,'Pedestal'},{2,'Orbit'},{4,'Panning'},{6,'Dolly'},{8,'Tracking'},{10,'Crane'}}
        for i,p in ipairs(presets) do
            JLRSMenu.button(c,0.365+((i-1)%2)*0.239,0.704-math.floor((i-1)/2)*0.052,0.226,0.040,p[2],function() JLRSCamera.choose(c,p[1]) end,c.mode==p[1])
        end
        JLRSMenu.common(c)
    elseif c.uiTab=='Shot Settings' then
        JLRSMenu.button(c,0.365,0.705,0.226,0.039,'Live Drive: '..(c.liveDrive and 'ON' or 'OFF'),function() JLRSLive.toggle(c) end,c.liveDrive)
        JLRSMenu.button(c,0.604,0.705,0.226,0.039,'FS22 Keys: '..((c.liveDrive and c.nativeShortcuts) and 'ON' or 'OFF'),function() JLRSLive.toggleKeys(c) end,c.liveDrive and c.nativeShortcuts)
        JLRSMenu.text(0.365,0.663,0.013,'Shoot Setting',0.12,0.85,0.9)
        if not c.shotDraft then JLRSMenu.beginShot(c) end
        if c.shotDraft.fixedAngleInterval==nil then c.shotDraft.fixedAngleInterval=c.fixedAngleInterval or 5 end
        for i,f in ipairs(shotFields) do
            local y=0.611-(i-1)*0.036
            JLRSMenu.text(0.365,y+0.009,0.012,f[1],0.65,0.74,0.83)
            local function change(d) c.shotDraft[f[2]]=math.max(f[4],math.min(f[5],c.shotDraft[f[2]]+d*f[3])) end
            JLRSMenu.button(c,0.653,y,0.032,0.030,'-',function() change(-1) end)
            JLRSMenu.text(0.703,y+0.009,0.013,string.format(f[6],c.shotDraft[f[2]]))
            JLRSMenu.button(c,0.798,y,0.032,0.030,'+',function() change(1) end)
        end
        JLRSMenu.button(c,0.365,0.258,0.465,0.044,'Apply Shoot Setting',function() JLRSMenu.applyShot(c) end,true)
        JLRSMenu.text(0.365,0.235,0.010,'Klik Apply untuk menerapkan nilai yang diubah.',0.65,0.74,0.83)
    elseif c.uiTab=='Director' then
        JLRSAIDirector.drawPanel(c)
    else
        JLRSMenu.drawOther(c)
    end
    JLRSMenu.rect(c,0.165,0.157,0.67,0.039,0.035,0.06,0.09)
    JLRSMenu.text(0.173,0.170,0.011,c.notice or 'Siap merekam kendaraan.',1,0.75,0.35)
    JLRSMenu.text(0.173,0.132,0.010,'F6 Menu | 2 Replay | Space Pause / Play | 0 Hud | Backspace Stop',0.65,0.74,0.83)
    JLRSMenu.text(0.173,0.106,0.011,'©Copyright 2023 | Jupryan Lowlight',0.65,0.74,0.83)
    setTextColor(1,1,1,1);setTextAlignment(RenderText.ALIGN_LEFT)
end
function JLRSMenu.click(c,x,y,isDown,button)
    c.mouseX=x;c.mouseY=y
    if JLRSMenu.otherActive(c) and x>=.355 and x<=.840 and y>=.245 and y<=.750
        and (button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN)then
        if isDown then
            local delta=button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1
            c.otherScroll=math.max(0,math.min(c.otherMaxScroll or 1,(c.otherScroll or 0)+delta))
            -- Discard stale row callbacks until the next draw rebuilds them.
            c.hitboxes={}
        end
        return
    end
    if not isDown or button~=Input.MOUSE_BUTTON_LEFT then return end
    for _,hit in ipairs(c.hitboxes or {}) do
        if x>=hit.x and x<=hit.x+hit.w and y>=hit.y and y<=hit.y+hit.h then hit.callback(x,y);return end
    end
end
