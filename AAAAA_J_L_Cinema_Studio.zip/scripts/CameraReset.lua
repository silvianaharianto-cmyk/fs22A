JLRSReset={}
function JLRSReset.angle(c)
    c.angleMemory={};c.angleStable=nil;c.angleMoveGoal=nil
    c.distance=12;c.height=3;c.fov=55;c.motionFov=55
    c.angleIndex=c.angleIndex or 1
    if c.active then JLRSCamera.choose(c,c.mode)
    else c.phase=0;c.offsetYaw=0;c.offsetPitch=0;c.manualX=0;c.manualY=0;c.manualZ=0 end
    c:notify('RESET ANGLE | memori semua angle dihapus | posisi default')
end
function JLRSReset.movement(c)
    -- Preserve the current angle pose before restarting the shot.
    if c.angleEnabled and c.active then JLRSAngle.save(c) end
    c.cameraSpeed=0.5;c.amplitude=5;c.side=6;c.manualSpeed=6;c.sensitivity=0.5
    c.phase=0;c.offsetYaw=0;c.offsetPitch=0;c.manualX=0;c.manualY=0;c.manualZ=0
    c.angleStable=nil;c.angleMoveGoal=nil
    if c.active then JLRSCamera.choose(c,c.mode) end
    c:notify('RESET MOVEMENT | movement tetap | speed/amplitude/kontrol default | fase awal')
end
