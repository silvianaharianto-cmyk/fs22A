-- Record the native steering signal independently of wheel-node hierarchy.
-- Keep the native wheel geometry and recorded roll; transfer only steering.
local S={cinemaNumericReadInto=true}
function S.discover(v)
    local out={}
    for i,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do
        if type(w.steeringAngle)=='number' then
            out[#out+1]={name='angle',index=i,mode='linear'}
        end
    end
    return out
end
function S.readInto(v,ch,out)
    local w=v.spec_wheels and v.spec_wheels.wheels[ch.index]
    out[1]=w and w.steeringAngle or 0
    for i=2,6 do out[i]=0 end
    return out
end
function S.read(v,ch)return S.readInto(v,ch,{})end
function S.write(v,ch,p,paused,restoring)
    local w=v.spec_wheels and v.spec_wheels.wheels[ch.index]
    if not w then return end
    if restoring then
        if w.jlrsChangeSteering then w.steeringAngle=w.jlrsChangeSteering.original end
        w.jlrsChangeSteering=nil
        for _,node in ipairs({w.repr,w.driveNode})do
            local state=JLRSWheelVisual.nodes[node]
            if state then state.changeSteering=nil end
        end
        return
    end
    local state=w.jlrsChangeSteering
    if not state then state={original=w.steeringAngle,replacement=(v.configFileName or v.xmlFilename or '')~=(ch.config or '')};w.jlrsChangeSteering=state end
    w.steeringAngle=p[1]
    local visual=JLRSWheelVisual.nodes[w.repr]
    if (state.angle~=p[1] or (visual and not visual.changeSteering)) and WheelsUtil and WheelsUtil.updateVisualWheel then
        state.angle=p[1]
        local n=w.netInfo or {}
        WheelsUtil.updateVisualWheel(v,w,n.x or 0,n.y or 0,n.z or 0,n.xDrive or w.lastXDrive or 0,n.suspensionLength or 0)
    end
end
JLRSActivities.registerAdapter('jlrsWheelSteering',S)

-- Replacement models have their own reference-driven axle/steering links.
-- Native vehicle updates are isolated during replay; repair only these simple
-- visual links after the authoritative wheel poses, never wheel shapes/joints.
local function links(track)
    local state=track.replacementLinks
    if state and state.entries==track.entries then return state end
    state={entries=track.entries,parts={}};track.replacementLinks=state
    local seen={}
    for _,v in ipairs(track.recordVehicles or {track.target})do
        local wheels,excluded={},{}
        excluded[v.rootNode]=true
        for _,body in ipairs(v.components or {})do excluded[body.node]=true end
        for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do
            if w.jlrsChangeSteering and w.jlrsChangeSteering.replacement and w.repr then wheels[w.repr]=true end
            if w.repr then excluded[w.repr]=true end
            if w.driveNode then excluded[w.driveNode]=true end
        end
        for _,part in ipairs(v.spec_cylindered and v.spec_cylindered.movingParts or {})do
            local node=part.node
            -- Advanced mechanisms retain their existing/native implementation.
            if node and not seen[node]and not excluded[node]and entityExists(node)
                and part.referencePoint and entityExists(part.referencePoint)
                and part.referenceFrame and entityExists(part.referenceFrame)
                and part.referenceDistance==0 and part.doDirectionAlignment
                and not part.useLocalOffset and not part.moveToReferenceFrame
                and not part.doInversedLineAlignment and not part.doLineAlignment
                and not part.doRotationAlignment and not part.smoothedDirectionScale then
                local parent=getParent(node);local cursor=parent;local related=false
                while cursor and cursor~=0 and entityExists(cursor)do
                    if wheels[cursor]then related=true;break end
                    if excluded[cursor]then break end
                    cursor=getParent(cursor)
                end
                if related then
                    local x,y,z=getTranslation(node);local rx,ry,rz=getRotation(node)
                    local sx,sy,sz
                    if getScale then sx,sy,sz=getScale(node)end
                    state.parts[#state.parts+1]={part=part,node=node,parent=parent,pose={x,y,z,rx,ry,rz},scale=sx and {sx,sy,sz}}
                    seen[node]=true
                end
            end
        end
    end
    return state
end
local refresh=JLRSWheelVisual.refresh
JLRSWheelVisual.refresh=function(track,...)
    local result=refresh(track,...)
    if not track.replaying or not I3DUtil or type(I3DUtil.setWorldDirection)~='function'then return result end
    -- Build after activity dispatch has established replacement steering owners.
    local active=false
    for _,v in ipairs(track.recordVehicles or {track.target})do
        for _,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {})do
            if w.jlrsChangeSteering and w.jlrsChangeSteering.replacement then active=true;break end
        end
        if active then break end
    end
    if not active then return result end
    local state=links(track)
    for _,item in ipairs(state.parts)do
        local p=item.part
        if entityExists(item.node)and getParent(item.node)==item.parent
            and entityExists(p.referencePoint)and entityExists(p.referenceFrame)then
            local x,y,z=getWorldTranslation(item.node)
            local tx,ty,tz=getWorldTranslation(p.referencePoint)
            local dx,dy,dz=tx-x,ty-y,tz-z
            local length=math.sqrt(dx*dx+dy*dy+dz*dz)
            if length>.000001 then
                if p.invertZ then dx,dy,dz=-dx,-dy,-dz end
                local ux,uy,uz=localDirectionToWorld(p.referenceFrame,0,1,0)
                local lx,ly,lz=worldDirectionToLocal(item.parent,dx,dy,dz)
                local ax,ay,az=worldDirectionToLocal(item.parent,ux,uy,uz)
                local rx,ry,rz=getRotation(item.node)
                local prev=item.last
                if not prev or math.abs(lx-prev[1])+math.abs(ly-prev[2])+math.abs(lz-prev[3])
                    +math.abs(ax-prev[4])+math.abs(ay-prev[5])+math.abs(az-prev[6])>.0000001
                    or rx~=item.rx or ry~=item.ry or rz~=item.rz then
                    I3DUtil.setWorldDirection(item.node,dx,dy,dz,ux,uy,uz,p.limitedAxis,p.minRot,p.maxRot)
                    item.last=prev or {};local a=item.last
                    a[1],a[2],a[3],a[4],a[5],a[6]=lx,ly,lz,ax,ay,az
                    item.rx,item.ry,item.rz=getRotation(item.node)
                    if p.scaleZ and p.localReferenceDistance and p.localReferenceDistance>0 and setScale then
                        setScale(item.node,1,1,length/p.localReferenceDistance)
                    end
                end
            end
        end
    end
    return result
end
local clear=JLRSWheelVisual.clear
JLRSWheelVisual.clear=function(track,...)
    local state=track.replacementLinks;track.replacementLinks=nil
    for _,item in ipairs(state and state.parts or {})do
        if entityExists(item.node)and getParent(item.node)==item.parent then
            local p=item.pose
            setTranslation(item.node,p[1],p[2],p[3]);setRotation(item.node,p[4],p[5],p[6])
            if item.scale and setScale then setScale(item.node,item.scale[1],item.scale[2],item.scale[3])end
        end
    end
    return clear(track,...)
end
