JLRSCamera={names={'Free Camera','Orbit Camera','Tilt Camera','Panning','Zoom Camera','Dolly Camera','Vertigo Camera','Tracking','Fly-By','Crane','Pedestal'}}
function JLRSCamera.gameplay()
    local m=g_currentMission;local v=m.controlledVehicle
    local s=v and v.spec_enterable
    local cam=s and (s.activeCamera or (s.cameras and s.cameras[s.camIndex]))
    local node=cam and cam.cameraNode or (m.player and m.player.cameraNode)
    if node and entityExists(node) then return node end
    return getCamera()
end
function JLRSCamera.clearInput(c)
    c.cameraInput=nil
end
function JLRSCamera.scroll(c,direction)
    if not c.active or c.menu or c.finalPlaying or (g_gui and g_gui:getIsGuiVisible()) then return end
    local input=c.cameraInput or {x=0,y=0,zoom=0};c.cameraInput=input
    local goal=math.max(15,math.min(100,c.fov+input.zoom+direction*3))
    input.zoom=goal-c.fov
end
function JLRSCamera.applyInput(c,dt)
    local input=c.cameraInput
    if not input or dt<=0 or c.menu or (g_gui and g_gui:getIsGuiVisible()) then return end
    -- Integrate event deltas once per rendered camera tick, independent of FPS.
    local blend=1-math.exp(-dt/0.025)
    local function consume(name)
        local remaining=input[name];local value=remaining*blend
        if c.mode~=8 then
            -- Continuous angular velocity across successive mouse events.
            -- Solve a critically damped response exactly for the render dt;
            -- focus/vehicle pose stays immediate and angle cuts clear input.
            local velocity=input[name..'Velocity'] or 0
            local omega=80;local decay=math.exp(-omega*dt)
            local term=velocity-omega*remaining
            local nextError=(-remaining+term*dt)*decay
            input[name..'Velocity']=(velocity-omega*term*dt)*decay
            value=remaining+nextError
            if math.abs(remaining-value)<.000001 and math.abs(input[name..'Velocity'])<.000001 then
                value=remaining;input[name..'Velocity']=0
            end
        elseif math.abs(remaining-value)<0.00001 then value=remaining end
        input[name]=remaining-value;return value
    end
    local dx,dy=consume('x'),consume('y')
    if c.lock or c.mode==3 or c.mode==4 then
        c.offsetYaw=c.offsetYaw-dx;c.offsetPitch=math.max(-1.2,math.min(1.2,c.offsetPitch-dy))
    else
        c.yaw=c.yaw-dx;c.pitch=math.max(-1.5,math.min(1.5,c.pitch-dy))
    end
    -- Critically damped zoom: continuous velocity as wheel events arrive.
    -- Exact time solution avoids acceleration spikes and FPS-dependent overshoot.
    local goal=c.fov+input.zoom
    local error=c.fov-goal;local velocity=input.zoomVelocity or 0
    local omega=18;local decay=math.exp(-omega*dt)
    local term=velocity+omega*error
    local nextError=(error+term*dt)*decay
    input.zoomVelocity=(velocity-omega*term*dt)*decay
    c.fov=math.max(15,math.min(100,goal+nextError));input.zoom=goal-c.fov
    if math.abs(input.zoom)<0.00001 and math.abs(input.zoomVelocity)<0.00001 then
        c.fov=goal;input.zoom=0;input.zoomVelocity=0
    end
end
function JLRSCamera.activate(c)
    if c.active then return end
    JLRSCamera.clearInput(c)
    c.previousCamera=JLRSCamera.gameplay()
    c.x,c.y,c.z=getWorldTranslation(c.previousCamera)
    -- A parented gameplay camera can have an equivalent Euler decomposition
    -- with Z=pi. Copying that roll and later clamping pitch flips the image.
    -- Reconstruct yaw/pitch from its world viewing direction, with world up.
    local fx,fy,fz=localDirectionToWorld(c.previousCamera,0,0,-1)
    local length=math.sqrt(fx*fx+fy*fy+fz*fz)
    if length>0.000001 then
        c.yaw=math.atan2(-fx,-fz)
        c.pitch=math.asin(math.max(-1,math.min(1,fy/length)))
    else c.pitch=0;c.yaw=0 end
    c.pitch=math.max(-1.5,math.min(1.5,c.pitch))
    c.roll=0
    c.camera=createCamera('JL_ReplayStudio_Camera',math.rad(c.fov),0.1,6000)
    link(getRootNode(),c.camera)
    setTranslation(c.camera,c.x,c.y,c.z);setRotation(c.camera,c.pitch,c.yaw,c.roll)
    c.active=true
    local p=g_currentMission.player
    if p then c.player=p;c.oldPlayerLock=p.lockedInput;c.oldWalkingLock=p.walkingIsLocked;p:lockInput(true) end
    JLRSMouse.refresh(c);setCamera(c.camera)
end
function JLRSCamera.deactivate(c)
    if not c.active then return end
    JLRSCamera.clearInput(c)
    JLRSMouse.disable(c);c.active=false
    local normal=JLRSCamera.gameplay()
    if normal==c.camera or normal==nil or not entityExists(normal) then normal=c.previousCamera end
    if normal and entityExists(normal) then setCamera(normal) end
    if c.camera then delete(c.camera);c.camera=nil end
    if c.player then
        c.player:lockInput(c.oldPlayerLock or false)
        if c.oldWalkingLock~=nil and c.player.setWalkingLock then c.player:setWalkingLock(c.oldWalkingLock) end
        if c.player.removeActionEvents then c.player:removeActionEvents() end
        if c.player.registerActionEvents then c.player:registerActionEvents() end
        if c.player.updateActionEvents then c.player:updateActionEvents() end
        c.player=nil
    end
    c.keys={};c.previousCamera=nil
    if g_inputBinding then g_inputBinding:setShowMouseCursor(c.menu) end
end
function JLRSCamera.focus(c)
    if not JLRSRecorder.valid(c.target) then return nil end
    local x,y,z=getWorldTranslation(c.target.rootNode)
    return x,y+c.focusHeight,z
end
function JLRSCamera.choose(c,index)
    JLRSCamera.clearInput(c)
    c.roll=0
    c.trackingHeading=nil;c.renderAim=nil;c.levelHeading=nil
    c.mode=index;c.phase=0;c.offsetYaw=0;c.offsetPitch=0;c.manualX=0;c.manualY=0;c.manualZ=0
    c.baseFov=c.fov;c.motionFov=c.fov
    local x,y,z=JLRSCamera.focus(c)
    if not x then return end
    c.anchorX,c.anchorY,c.anchorZ=x,y,z
    local _,ry,_=getWorldRotation(c.target.rootNode);c.anchorYaw=ry
    local dx,dy,dz=JLRSCamera.levelOffset(c,c.distance*0.65,c.height,-c.distance)
    if index~=1 then
        c.x=x+dx;c.y=y+dy;c.z=z+dz
        c.yaw=math.atan2(dx,dz)
        c.pitch=math.atan2(-dy,math.sqrt(dx*dx+dz*dz))
    end
    c.fixedX,c.fixedY,c.fixedZ=c.x,c.y,c.z
    c.anchorPitch=c.pitch;c.panYaw=c.yaw
    c:notify('Camera: '..JLRSCamera.names[index])
end
-- Tracking uses a level heading frame; suspension roll/pitch must not swing
-- the camera arm. Translation stays on the current vehicle frame, never delayed.
-- A level yaw frame prevents suspension pitch/roll from swinging camera arms.
function JLRSCamera.levelOffset(c,x,y,z)
    local target=c.groupCamera and c.cameraTarget or c.target
    local fx,_,fz=localDirectionToWorld(target.rootNode,0,0,1)
    local yaw=math.atan2(fx,fz)
    local state=c.levelHeading
    if state and state.target==target then yaw=state.yaw end
    return math.cos(yaw)*x+math.sin(yaw)*z,y,-math.sin(yaw)*x+math.cos(yaw)*z
end
function JLRSCamera.trackingOffset(c,dt)
    local target=c.target
    local fx,_,fz=localDirectionToWorld(target.rootNode,0,0,1)
    local heading=math.atan2(fx,fz)
    local state=c.trackingHeading
    if not state or state.target~=target or c.angleCutPending then
        state={target=target,yaw=heading};c.trackingHeading=state
    else
        state.yaw=JLRSRecorder.angle(state.yaw,heading,1-math.exp(-math.max(0,dt)/0.035))
    end
    local x,y,z=c.side,c.height,-c.distance
    if c.angleEnabled then
        local dx,dy,dz=JLRSAngle.vector(c,c.distance,c.height)
        x,y,z=worldDirectionToLocal(target.rootNode,dx,dy,dz)
    end
    local a=state.yaw
    return math.cos(a)*x+math.sin(a)*z,y,-math.sin(a)*x+math.cos(a)*z
end
function JLRSCamera.tick(c,dt)
    if not c.active or not c.camera then return end
    local tx,ty,tz=JLRSCamera.focus(c)
    if not tx then return end
    if c.mode==2 or c.mode==6 or c.mode==7 or c.mode==10 then
        local target=c.groupCamera and c.cameraTarget or c.target
        local fx,_,fz=localDirectionToWorld(target.rootNode,0,0,1)
        local heading=math.atan2(fx,fz);local state=c.levelHeading
        if not state or state.target~=target or c.angleCutPending then
            state={target=target,yaw=heading};c.levelHeading=state
        else state.yaw=JLRSRecorder.angle(state.yaw,heading,1-math.exp(-math.max(0,dt)/0.035)) end
    else c.levelHeading=nil end
    JLRSCamera.applyInput(c,dt)
    local gui=g_gui and g_gui:getIsGuiVisible()
    if not c.paused and not c.livePaused and not gui then c.phase=c.phase+dt*c.cameraSpeed end
    local phase=c.phase;local mode=c.mode;local x,y,z=c.x,c.y,c.z
    local u=math.sin(phase);local v=math.cos(phase)
    local fov=c.fov
    if mode==2 then
        if c.angleEnabled then
            local dx,dy,dz=JLRSAngle.vector(c,c.distance,c.height,phase);x=tx+dx;y=ty+dy;z=tz+dz
        else x=tx+math.sin(phase+c.anchorYaw)*c.distance;y=ty+c.height;z=tz+math.cos(phase+c.anchorYaw)*c.distance end
    elseif mode==3 or mode==4 or mode==5 or mode==9 then
        x,y,z=c.fixedX,c.fixedY,c.fixedZ
        if mode==5 then fov=math.max(12,math.min(110,c.fov+u*22)) end
    elseif mode==6 or mode==7 then
        local distance=math.max(1,c.distance+u*c.amplitude)
        local dx,dy,dz=(c.angleEnabled and JLRSAngle.vector or function(_,d,h) return JLRSCamera.levelOffset(c,0,h,-d) end)(c,distance,c.height)
        x,y,z=tx+dx,ty+dy,tz+dz
        if mode==7 then
            local base=math.sqrt(c.distance*c.distance+c.height*c.height)
            local current=math.sqrt(distance*distance+c.height*c.height)
            fov=math.deg(2*math.atan(math.tan(math.rad(c.fov)/2)*base/current))
        end
    elseif mode==8 then
        local dx,dy,dz=JLRSCamera.trackingOffset(c,dt)
        x,y,z=tx+dx,ty+dy,tz+dz
    elseif mode==10 then
        local height=c.height+(1+u)*c.amplitude*0.5
        local dx,dy,dz=(c.angleEnabled and JLRSAngle.vector or function(_,d,h) return JLRSCamera.levelOffset(c,c.side,h,-d) end)(c,c.distance,height)
        x,y,z=tx+dx,ty+dy,tz+dz
    elseif mode==11 then
        x=c.fixedX;y=c.fixedY+u*c.amplitude;z=c.fixedZ
    end
    if not c.menu and not gui then
        local function pressed(name)
            local key=Input[name]
            return key and Input.isKeyPressed(key) and 1 or 0
        end
        local forward=pressed('KEY_w')-pressed('KEY_s')
        local side=pressed('KEY_d')-pressed('KEY_a')
        local up=pressed('KEY_q')-pressed('KEY_e')
        local length=math.sqrt(forward*forward+side*side+up*up)
        if length>0 then
            local fast=pressed('KEY_lshift')+pressed('KEY_rshift')>0
            local speed=c.manualSpeed*(fast and 4 or 1)*dt/length
            local dx=(-math.sin(c.yaw)*math.cos(c.pitch)*forward+math.cos(c.yaw)*side)*speed
            local dy=(math.sin(c.pitch)*forward+up)*speed
            local dz=(-math.cos(c.yaw)*math.cos(c.pitch)*forward-math.sin(c.yaw)*side)*speed
            if mode==1 then x=x+dx;y=y+dy;z=z+dz
            else c.manualX=c.manualX+dx;c.manualY=c.manualY+dy;c.manualZ=c.manualZ+dz end
        end
    end
    if mode~=1 then x=x+c.manualX;y=y+c.manualY;z=z+c.manualZ end
    c.x,c.y,c.z=x,y,z
    if c.lock then
        local dx,dy,dz=tx-x,ty-y,tz-z
        c.yaw=math.atan2(-dx,-dz)+c.offsetYaw
        c.pitch=math.atan2(dy,math.sqrt(dx*dx+dz*dz))+c.offsetPitch
        if mode==3 then c.pitch=c.pitch+u*0.18 end
        if mode==4 then c.yaw=c.yaw+u*0.45 end
    elseif mode==3 then c.pitch=c.anchorPitch+u*0.3+c.offsetPitch;c.yaw=c.panYaw+c.offsetYaw
    elseif mode==4 then c.yaw=c.panYaw+u*0.55+c.offsetYaw;c.pitch=c.anchorPitch+c.offsetPitch end
    c.pitch=math.max(-1.5,math.min(1.5,c.pitch))
    c.motionFov=fov
    c.roll=0
    local pitch,yaw=c.pitch,c.yaw
    -- Use the same current-frame aim as Tracking. An independent aim delay
    -- makes the target drift relative to a moving camera arm / recorded car.
    -- Mouse/scroll easing remains in applyInput; angle cuts stay instantaneous.
    c.renderAim=nil
    setTranslation(c.camera,x,y,z);setRotation(c.camera,pitch,yaw,0)
    setFovY(c.camera,math.rad(math.max(10,math.min(110,fov))))
    if getCamera()~=c.camera then setCamera(c.camera) end
end
function JLRSCamera.mouseAxis(c,axis,value)
    if not c.active or c.menu or (g_gui and g_gui:getIsGuiVisible()) then return end
    local delta=value*0.001*16.666*c.sensitivity*2
    local input=c.cameraInput or {x=0,y=0,zoom=0};c.cameraInput=input
    if axis=='X' then input.x=input.x+delta else input.y=input.y+delta end
end
function JLRSCamera.toggleLock(c)
    JLRSCamera.clearInput(c)
    c.lock=not c.lock;c.offsetYaw=0;c.offsetPitch=0
    c.anchorPitch=c.pitch;c.panYaw=c.yaw
end
