-- Reference-style Mini HUD. All buttons delegate to unchanged V1.16.2 functions.
JLRSMiniHud={}
local H=JLRSMiniHud
local directory=g_currentModDirectory
function H.cursor(c)
    if not c.mission or not c.miniHudEnabled or c.menu or c.shortcutHudHidden then return false end
    if g_gui and g_gui:getIsGuiVisible() then return false end
    return (Input.KEY_lalt and Input.isKeyPressed(Input.KEY_lalt))
        or (Input.KEY_ralt and Input.isKeyPressed(Input.KEY_ralt)) or false
end
function H.interacting(c)
    if H.cursor(c) then return true end
    return c.mission and c.miniHudEnabled and not c.menu and not c.shortcutHudHidden
        and not (g_gui and g_gui:getIsGuiVisible()) and JLRSObject and JLRSObject.cursor(c) or false
end
-- Route the visible Final toolbar before the standard toolbar can consume an
-- Alt click. Both entry points are needed when mouse wrappers install/rebuild
-- in a different order. Hidden menus and native dialogs keep their ownership.
function H.finalMouse(c,x,y,isDown,isUp,button)
    if not H.interacting(c) then return false end
    for _,hit in ipairs(c.finalHudHits or {}) do
        if x>=hit.x and x<=hit.x+hit.w and y>=hit.y and y<=hit.y+hit.h then
            if isDown and button==Input.MOUSE_BUTTON_LEFT then hit.callback() end
            return true
        end
    end
    return false
end
function H.install(c)
    if not c.mission or c.miniOuterWrapper then return end
    -- Install after the existing Object Movement/Change Cars mouse wrappers are ready.
    -- Own only the timeline gesture, so their other click behaviour remains unchanged.
    c.miniOuterPrevious=c.mission.mouseEvent
    c.miniOuterWrapper=function(m,x,y,isDown,isUp,button,...)
        if H.finalMouse(c,x,y,isDown,isUp,button) then return end
        local bar=c.miniTimeline
        if c.miniScrub or (H.interacting(c) and bar and x>=bar.x and x<=bar.x+bar.w and y>=bar.y and y<=bar.y+bar.h) then
            return H.mouse(c,x,y,isDown,isUp,button)
        end
        return c.miniOuterPrevious(m,x,y,isDown,isUp,button,...)
    end
    c.mission.mouseEvent=c.miniOuterWrapper
    local deleteMap=c.deleteMap
    c.miniOuterDelete=deleteMap
    c.deleteMap=function(self,...)
        if self.mission and self.mission.mouseEvent==self.miniOuterWrapper then self.mission.mouseEvent=self.miniOuterPrevious end
        self.miniOuterWrapper=nil;self.miniOuterPrevious=nil
        self.deleteMap=deleteMap;self.miniOuterDelete=nil
        return deleteMap(self,...)
    end
end
function H.formatTime(seconds)
    local total=math.floor(math.max(0,tonumber(seconds) or 0))
    return string.format('%02d:%02d',math.floor(total/60),total%60)
end
function H.clock(c)
    local duration,time=0,0
    if c.replaying then duration=c.duration or 0;time=c.replayTime or 0 end
    for _,track in ipairs(c.liveTracks or {}) do
        if track.replaying and (track.duration or 0)>=duration then duration=track.duration or 0;time=track.replayTime or 0 end
    end
    if c.recording then duration=c.recordTime or 0;time=duration end
    if duration==0 then duration=c.duration or 0 end
    return duration,time
end
function H.seekTracks(c,time,commit)
    local scrub=c.miniScrub;if not scrub then return end
    for _,saved in ipairs(scrub.tracks) do
        local track=saved.track
        if track.replaying and track.frames==saved.frames then
            local t=math.max(0,math.min(track.duration,time))
            if track.loop and track.duration>0 and time>track.duration then t=time%track.duration end
            if not track.collisionReplay then
                JLRSRecorder.seek(track,t)
            elseif commit then
                -- Physics bodies are repositioned once on release, never remove/add per mouse event.
                track.replayTime=t;track.frameIndex=1
                local pose=JLRSRecorder.sample(track,t)
                JLRSCollision.place(track,pose)
                track.changeWheelReplay=nil;track.allWheelReplay=nil
                JLRSRecorder.replayTick(track,0)
            end
        end
    end
    for _,track in ipairs(c.liveTracks or {}) do
        if track.cargoReplay then JLRSWorld.tick(c,track.replayTime,track.cargoReplay) end
    end
    if c.worldReplay and c.worldReplay.owner.replaying then JLRSWorld.tick(c,c.worldReplay.owner.replayTime) end
end
function H.finish(c)
    local scrub=c.miniScrub;if not scrub then return end
    local ok,err=pcall(H.seekTracks,c,scrub.time,true)
    c.miniScrub=nil
    if c.mission and ok then
        local anyLive=false
        for _,saved in ipairs(scrub.tracks) do
            local track=saved.track
            if track.replaying and track.frames==saved.frames then
                local paused=scrub.livePaused;if saved.main then paused=scrub.mainPaused end
                track.paused=paused or (not track.loop and track.replayTime>=track.duration)
                if not saved.main then anyLive=true end
                -- Restore sound/activity Pause state without advancing the clock.
                JLRSRecorder.replayTick(track,0)
            end
        end
        if anyLive then c.livePaused=scrub.livePaused end
    elseif not ok then c:stop();c:notify('Timeline dihentikan: '..tostring(err)) end
end
function H.begin(c,x)
    if c.recording or c.miniScrub then return end
    local duration=H.clock(c);if duration<=0 then return end
    local scrub={duration=duration,tracks={},mainPaused=c.paused==true,livePaused=c.livePaused==true}
    if c.replaying then scrub.tracks[#scrub.tracks+1]={track=c,frames=c.frames,main=true} end
    for _,track in ipairs(c.liveTracks or {}) do
        if track.replaying then scrub.tracks[#scrub.tracks+1]={track=track,frames=track.frames} end
    end
    if #scrub.tracks==0 then c:notify('Mulai Replay dahulu untuk menggeser timeline.');return end
    c.miniScrub=scrub
    for _,saved in ipairs(scrub.tracks) do saved.track.paused=true end
    if #(c.liveTracks or {})>0 then c.livePaused=true end
    H.drag(c,x)
end
function H.drag(c,x)
    local scrub=c.miniScrub;local bar=c.miniTimeline
    if not scrub or not bar then return end
    scrub.time=math.max(0,math.min(1,(x-bar.x)/bar.w))*scrub.duration
    -- Coalesce mouse events in the same rendered frame.
    local clock=g_time or 0
    if scrub.drawClock~=clock then
        scrub.drawClock=clock
        local ok,err=pcall(H.seekTracks,c,scrub.time,false)
        if not ok then c.miniScrub=nil;c:stop();c:notify('Timeline dihentikan: '..tostring(err)) end
    end
end
function H.toggle(c)
    H.finish(c);c.miniHudEnabled=not c.miniHudEnabled;c.miniHudHits={};c.miniTimeline=nil
    c:notify('Mini HUD : '..(c.miniHudEnabled and 'ON | tahan Alt untuk klik / geser timeline' or 'OFF'))
end
local function text(x,y,size,value,r,g,b)
    setTextAlignment(RenderText.ALIGN_CENTER or RenderText.ALIGN_LEFT)
    setTextColor(r or 1,g or 1,b or 1,1);renderText(x,y,size,value)
    setTextAlignment(RenderText.ALIGN_LEFT)
end
function H.draw(c)
    H.install(c)
    c.miniHudHits={};c.miniTimeline=nil
    if not c.miniHudEnabled or c.menu or not c.overlay then return end
    local aspect=(g_screenWidth and g_screenHeight and g_screenWidth/g_screenHeight) or 16/9
    local w=0.38;local scale=w/0.54;local x=(1-w)/2;local y=0.012;local sx=w/1010;local sy=sx*aspect
    local function box(px,py,pw,ph) return x+px*sx,y+(356-py-ph)*sy,pw*sx,ph*sy end
    local function rect(px,py,pw,ph,r,g,b,a) local bx,by,bw,bh=box(px,py,pw,ph);JLRSMenu.rect(c,bx,by,bw,bh,r,g,b,a) end
    local function icon(name,px,py,pw,ph,r,g,b,a)
        local overlay=c.miniIcons and c.miniIcons[name]
        if overlay then local bx,by,bw,bh=box(px,py,pw,ph);setOverlayColor(overlay,r or 1,g or 1,b or 1,a or 1);renderOverlay(overlay,bx,by,bw,bh) end
    end
    local function label(px,py,pw,ph,value)
        local bx,by,bw,bh=box(px,py,pw,ph)
        local font=#value>20 and 0.013 or 0.014
        text(bx+bw/2,by+bh*0.32,font*scale*aspect/(16/9),value)
    end
    local hits={}
    local function button(index,px,py,pw,ph,value,callback,selected)
        local bx,by,bw,bh=box(px,py,pw,ph)
        hits[index]={x=bx,y=by,w=bw,h=bh,callback=callback,label=value}
        rect(px,py,pw,ph,0.015,0.025,0.04,0.90)
        rect(px+1,py+1,pw-2,ph-2,0,0,0,0.80)
        if selected then rect(px,py+ph-2,pw,2,0.18,0.35,0.83,1) end
        label(px,py,pw,ph,value)
    end
    button(6,40,61,208,35,'LIVE DRIVE : '..(c.liveDrive and 'ON' or 'OFF'),function()JLRSLive.toggle(c)end,c.liveDrive)
    button(7,40,112,208,35,'FS22 KEYS : '..((c.liveDrive and c.nativeShortcuts) and 'ON' or 'OFF'),function()JLRSLive.toggleKeys(c)end,c.liveDrive and c.nativeShortcuts)
    button(10,407,61,208,35,'CAMERA ANGLE : '..(c.angleEnabled and 'ON' or 'OFF'),function()JLRSAngle.toggle(c)end,c.angleEnabled)
    button(11,407,112,208,35,'LOCK KENDARAAN : '..(c.lock and 'ON' or 'OFF'),function()JLRSCamera.toggleLock(c)end,c.lock)
    button(9,774,61,208,35,'RESET VEHICLE',function()JLRSResetVehicle.reset(c)end)
    button(8,774,112,208,35,c.preciseReplay and 'REPLAY : PRESISI' or ('PHYSICS : '..(c.physicsReplay and 'ON' or 'OFF')),function()JLRSCollision.toggle(c)end,c.physicsReplay)
    button(13,407,160,208,32,'PHYSICS PLACEABLE: '..(c.physicsPlaceable and 'ON' or 'OFF'),function()JLRSPhysicsPlaceable.toggle(c)end,c.physicsPlaceable)
    icon('circle',657,65,74,74,0,0,0,0.80)
    label(657,65,74,74,'Cars')
    local cx,cy,cw,ch=box(657,65,74,74)
    hits[12]={x=cx,y=cy,w=cw,h=ch,label='Cars',callback=function()JLRSCars.open(c)end}
    -- The numeric Timecode is the only seek/cut surface; no rail/timeline.
    rect(40,203,942,61,0.006,0.012,0.024,0.95)
    local bx,by,bw,bh=box(64,208,900,46)
    c.miniTimeline=nil;c.timecodeStandard={x=bx,y=by,w=bw,h=bh}
    if JLRSUnifiedTimecode then JLRSUnifiedTimecode.drawBox(c,c.timecodeStandard)end
    rect(40,276,942,64,0.18,0.35,0.81,0.98)
    -- Semantic indices are retained; visual order matches Stop / Replay / Record / Pause / History.
    local actions={
        {4,40,'STOP',function()JLRSStopLoading.request(c,true)end},
        {2,228,'REPLAY',function()JLRSRecorder.startReplay(c)end},
        {1,416,c.recording and 'STOP RECORD' or 'RECORD',function()c:toggleRecord()end},
        {3,604,(c.paused or c.livePaused) and 'PLAY' or 'PAUSE',function()c:togglePause()end},
        {5,792,'HISTORY',function()JLRSHistory.open(c)end}
    }
    local hovered
    for _,action in ipairs(actions) do
        local ax,ay,aw,ah=box(action[2],276,187,64)
        hits[action[1]]={x=ax,y=ay,w=aw,h=ah,label=action[3],callback=action[4]}
        if H.cursor(c) and c.miniMouseX and c.miniMouseX>=ax and c.miniMouseX<=ax+aw and c.miniMouseY>=ay and c.miniMouseY<=ay+ah then
            rect(action[2],276,187,64,0.26,0.44,0.94,1);hovered=action[3]
        end
    end
    icon('stop',145,282,52,53);icon('replay',298,288,41,44)
    rect(443,286,6,47,0,0,0,1);rect(443,286,17,5,0,0,0,1);rect(443,328,17,5,0,0,0,1)
    rect(554,286,6,47,0,0,0,1);rect(543,286,17,5,0,0,0,1);rect(543,328,17,5,0,0,0,1)
    local visible=not c.recording or math.floor((c.miniRecordBlinkMs or 0)/450)%2==0
    if visible then icon('circle',483,288,40,40,1,0,0) end
    if c.paused or c.livePaused then icon('play',667,288,41,41)
    else icon('pause',664,286,46,44) end
    icon('history',812,284,55,53)
    c.miniHudHits=hits
    if hovered then text(x+w/2,y+0.001,0.010*scale,'ALT + klik : '..hovered) end
    setTextColor(1,1,1,1);setTextAlignment(RenderText.ALIGN_LEFT)
end
function H.mouse(c,x,y,isDown,isUp,button)
    c.miniMouseX=x;c.miniMouseY=y
    if c.miniScrub then
        H.drag(c,x)
        if isUp and button==Input.MOUSE_BUTTON_LEFT then H.finish(c) end
        return
    end
    if isDown and button==Input.MOUSE_BUTTON_LEFT then
        local bar=c.miniTimeline
        if bar and x>=bar.x and x<=bar.x+bar.w and y>=bar.y and y<=bar.y+bar.h then H.begin(c,x);return end
        for _,hit in ipairs(c.miniHudHits or {}) do
            if x>=hit.x and x<=hit.x+hit.w and y>=hit.y and y<=hit.y+hit.h then hit.callback();return end
        end
    end
end
local oldLoad=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    oldLoad(c,...)
    if not c.mission then return end
    c.miniHudEnabled=false;c.miniHudHits={};c.miniCursorShown=false;c.miniScrub=nil
    c.miniIcons={}
    for _,name in ipairs({'stop','replay','pause','history','circle','play'}) do c.miniIcons[name]=createImageOverlay(directory..'ui/'..name..'.dds') end
    c.miniPreviousMouse=c.mission.mouseEvent
    c.miniMouseWrapper=function(mission,x,y,isDown,isUp,button,...)
        if H.finalMouse(c,x,y,isDown,isUp,button) then return end
        if c.miniScrub or H.cursor(c) then return H.mouse(c,x,y,isDown,isUp,button) end
        return c.miniPreviousMouse(mission,x,y,isDown,isUp,button,...)
    end
    c.mission.mouseEvent=c.miniMouseWrapper
end
local oldDraw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    if c.miniScrub and not H.interacting(c) then H.finish(c) end
    oldDraw(c,...)
    if not c.mission then return end
    if c.miniScrub and not H.interacting(c) then H.finish(c) end
    local cursor=H.cursor(c)
    if g_inputBinding and (cursor or c.miniCursorShown) then
        JLRSMouse.syncCursor(c)
    end
    c.miniCursorShown=cursor
    if not (g_gui and g_gui:getIsGuiVisible()) then H.draw(c) end
end
local oldAxis=JLRSCamera.mouseAxis
JLRSCamera.mouseAxis=function(c,...)
    if H.cursor(c) or c.miniScrub then return end
    return oldAxis(c,...)
end
local oldDelete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    c.miniScrub=nil
    if c.mission and c.mission.mouseEvent==c.miniMouseWrapper then c.mission.mouseEvent=c.miniPreviousMouse end
    c.miniHudEnabled=false;c.miniHudHits={};c.miniCursorShown=false;c.miniTimeline=nil
    oldDelete(c,...)
    for _,overlay in pairs(c.miniIcons or {}) do if overlay and overlay~=0 then delete(overlay) end end
    c.miniIcons=nil;c.miniPreviousMouse=nil;c.miniMouseWrapper=nil
end

-- UI clock follows actual update delta rather than a possibly absent global clock.
local previousUpdate=JLReplayStudio.update
JLReplayStudio.update=function(c,dt,...)
    if c.recording then c.miniRecordBlinkMs=((c.miniRecordBlinkMs or 0)+math.max(0,tonumber(dt) or 0))%900
    else c.miniRecordBlinkMs=0 end
    return previousUpdate(c,dt,...)
end
