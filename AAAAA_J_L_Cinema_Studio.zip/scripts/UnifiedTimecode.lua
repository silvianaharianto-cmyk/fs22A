-- Numeric timecode editing. Exclusion metadata only: immutable source cache,
-- 80ms recording cadence and per-frame replay writers are unchanged.
JLRSUnifiedTimecode={history=setmetatable({},{__mode='k'})}
local T=JLRSUnifiedTimecode;local F=JLRSFinalCuts
local function clamp(x,a,b)return math.max(a,math.min(b,x))end
local function copy(cuts)local out={};for i,r in ipairs(cuts or {})do out[i]={a=r.a,b=r.b}end;return out end
local function model(cuts,duration)return {finalCuts=cuts,duration=duration,cutSourceDuration=duration}end
function T.length(cuts,duration)return F.length(model(cuts,duration))end
function T.output(cuts,duration,time)return F.output(model(cuts,duration),time)end
function T.source(cuts,duration,time)return F.source(model(cuts,duration),time)end
local function tracks(c)
 local out={};if c.replaying then out[#out+1]=c end
 for _,t in ipairs(c.liveTracks or {})do if t.replaying then out[#out+1]=t end end
 return out
end
function T.context(c)
 local take=c.finalRecording or(c.finalPlaying and c.finalPlaying.take)
 if take then
  local raw=c.finalRecording and take.duration or take.cutSourceDuration or take.duration
  local time=c.finalPlaying and c.finalPlaying.time or T.output(take.finalCuts,raw,raw)
  return {key=take,final=true,take=take,raw=raw,duration=T.length(take.finalCuts,raw),time=time}
 end
 local owner=c.recording and c or nil
 if not owner then for _,t in ipairs(tracks(c))do if not owner or T.length(t.frames.timecodeCuts,t.duration)>T.length(owner.frames.timecodeCuts,owner.duration)then owner=t end end end
 owner=owner or c
 local raw=c.recording and c.recordTime or owner.duration or 0
 local cuts=owner.frames and owner.frames.timecodeCuts
 return {key=owner.frames,owner=owner,raw=raw,cuts=cuts,duration=T.length(cuts,raw),time=T.output(cuts,raw,c.recording and raw or owner.replayTime or 0)}
end
function T.cursor(c,ctx)
 if c.timecodePauseOwned and c.timecodeCursor and c.timecodeCursor.key==ctx.key then return clamp(c.timecodeCursor.time,0,ctx.duration)end
 return ctx.time
end
local function poseCamera()
 local n=getCamera();if not n or not entityExists(n)then return end
 local x,y,z=getWorldTranslation(n);local a,b,c=getWorldRotation(n)
 return {node=n,p={x,y,z,a,b,c,type(getFovY)=='function'and getFovY(n)or math.rad(55)}}
end
local function setCameraPose(p)
 if not p or not entityExists(p.node)then return end
 local a=p.p;setWorldTranslation(p.node,a[1],a[2],a[3]);setWorldRotation(p.node,a[4],a[5],a[6]);setFovY(p.node,a[7])
end
function T.pause(c)
 if c.timecodePauseOwned then return end
 c.timecodePauseOwned=true;c.timecodeBeforePause={main=c.paused,live=c.livePaused}
 if c.recording then
  c.timecodeRecordPose=JLRSRecorder.capture(c.entries);c.timecodeRecordHold=true
 elseif c.finalRecording then
  local saved={camera=poseCamera(),tracks={}};c.timecodeFinalPreview=saved
  for _,t in ipairs(tracks(c))do saved.tracks[#saved.tracks+1]={track=t,time=t.replayTime,frames=t.frames}end
 end
 c.paused=true;c.livePaused=true
 for _,t in ipairs(tracks(c))do t.paused=true end
 if c.finalRecording then c.finalRecording.wasPaused=true;c.finalRecording.lastSource=c.finalRecording.master.replayTime end
end
function T.restoreRecord(c)
 local p=c.timecodeRecordPose
 if p and c.entries then JLRSRecorder.apply(c.entries,p,true)end
 c.timecodeRecordPose=nil;c.timecodeRecordHold=nil
 local saved=c.timecodeFinalPreview;c.timecodeFinalPreview=nil
 if saved then
  for _,s in ipairs(saved.tracks)do if s.track.replaying and s.track.frames==s.frames then
   JLRSRecorder.seek(s.track,s.time)
   if s.track.collisionReplay then JLRSCollision.place(s.track,JLRSRecorder.sample(s.track,s.time))end
   if s.track.cargoReplay then JLRSWorld.tick(c,s.time,s.track.cargoReplay)end
  end end
  if c.worldReplay and c.worldReplay.owner then JLRSWorld.tick(c,c.worldReplay.owner.replayTime)end
  setCameraPose(saved.camera)
  if c.finalRecording then c.finalRecording.lastSource=c.finalRecording.master.replayTime;c.finalRecording.wasPaused=true end
 end
end
function T.resume(c)
 T.restoreRecord(c);c.timecodePauseOwned=nil;c.timecodeBeforePause=nil;c.timecodeCursor=nil
 c.paused=false;c.livePaused=false
 if c.finalRecording then c.finalRecording.wasPaused=false;c.finalRecording.pendingCut=true;c.finalRecording.lastSource=c.finalRecording.master.replayTime end
 for _,t in ipairs(tracks(c))do
  t.paused=not t.loop and t.replayTime>=t.duration
  JLRSRecorder.replayTick(t,0)
 end
end
function T.seekFinal(c,ctx,time)
 local take=ctx.take;local source,segment
 if JLRSFinalSlowMotion and take.slowRanges and #take.slowRanges>0 then source,segment=JLRSFinalSlowMotion.source(take,ctx.raw,time)
 else source,segment=F.source(model(take.finalCuts,ctx.raw),time)end
 local pose=F.place(c,take,source)
 local playing=c.finalPlaying
 if playing then
  playing.time=time;playing.lastSource=playing.master.replayTime;playing.cutSegment=segment
  playing.ended=time>=ctx.duration;playing.jlrsRenderedCameraPose=pose
 end
 if c.finalRecording then c.finalRecording.lastSource=c.finalRecording.master.replayTime;c.finalRecording.wasPaused=true end
 local node=playing and playing.camera or getCamera()
 setCameraPose({node=node,p=pose})
 c.finalCutCursor=time;c.finalCutPreviewPose=nil;c.finalCutPreviewRestore=nil;c.finalCutPreviewCamera=nil
end
function T.seek(c,ctx,time)
 time=clamp(time,0,ctx.duration);c.timecodeCursor={key=ctx.key,time=time};c.timecodeFocus=ctx.key
 if ctx.final then T.seekFinal(c,ctx,time)
 elseif c.recording then
  local source=T.source(ctx.cuts,ctx.raw,time)
  if JLRSFrames.count(c.frames)>0 then
   local index=c.frameIndex;c.frameIndex=1
   local pose=JLRSRecorder.sample(c,source);c.frameIndex=index
   JLRSRecorder.apply(c.entries,pose,true)
  end
 else
  for _,t in ipairs(tracks(c))do
   local d=T.length(t.frames.timecodeCuts,t.duration)
   local raw=T.source(t.frames.timecodeCuts,t.duration,math.min(time,d))
   JLRSRecorder.seek(t,raw)
   if t.collisionReplay then JLRSCollision.place(t,JLRSRecorder.sample(t,raw))end
   if t.cargoReplay then JLRSWorld.tick(c,raw,t.cargoReplay)end
  end
  if c.worldReplay and c.worldReplay.owner then JLRSWorld.tick(c,c.worldReplay.owner.replayTime)end
  if c.active and c.camera then JLRSCamera.tick(c,0)end
 end
end
function T.mark(c)
 local ctx=T.context(c);if not ctx.key or ctx.duration<=0 then return end
 local time=T.cursor(c,ctx)
 if ctx.final then c.finalCutCursor=time;F.mark(c);return end
 local m=c.timecodeMark
 if not m or m.key~=ctx.key or m.b then c.timecodeMark={key=ctx.key,a=time}
 else m.b=time end
end
local function history(key)local h=T.history[key];if not h then h={undo={},redo={}};T.history[key]=h end;return h end
function T.remove(c)
 local ctx=T.context(c)
 if ctx.final then
  local mark=c.finalCutMark;if not mark or mark.take~=ctx.key or mark.b==nil then return end
  T.pause(c);c.finalCutCursor=T.cursor(c,ctx);F.remove(c)
  local nextCtx=T.context(c);T.seek(c,nextCtx,clamp(c.finalCutCursor or 0,0,nextCtx.duration));return
 end
 local m=c.timecodeMark;if not m or m.key~=ctx.key or m.b==nil then return end
 local a,b=math.min(m.a,m.b),math.max(m.a,m.b)
 if b-a<.001 or ctx.duration-(b-a)<.01 then c:notify('Pilih rentang dan sisakan sebagian rekaman.');return end
 T.pause(c)
 local targets={{frames=ctx.key,raw=ctx.raw}};local seen={[ctx.key]=true}
 if not c.recording then for _,track in ipairs(tracks(c))do if not seen[track.frames]then
  targets[#targets+1]={frames=track.frames,raw=track.duration};seen[track.frames]=true
 end end end
 local changes={}
 for _,target in ipairs(targets)do
  local frames=target.frames;local old=frames.timecodeCuts;local duration=T.length(old,target.raw)
  local first,last=math.min(a,duration),math.min(b,duration)
  if last>first then
   local cuts=F.merge(old,T.source(old,target.raw,first),T.source(old,target.raw,last))
   changes[#changes+1]={frames=frames,before=copy(old),after=copy(cuts),original=old};frames.timecodeCuts=cuts
  end
 end
 if not c.recording and JLRSPersist.safeSave(c)==false then for _,edit in ipairs(changes)do edit.frames.timecodeCuts=edit.original end;return end
 local h=history(ctx.key);h.undo[#h.undo+1]={changes=changes,time=a};h.redo={}
 c.timecodeMark=nil;T.seek(c,T.context(c),a);c:notify('CUT tersimpan | rentang dilewati saat Replay')
end
function T.undo(c,redo)
 local ctx=T.context(c)
 if ctx.final then
  local h=F.undoHistory[ctx.key];local stack=h and(redo and h.redo or h.undo)
  if not stack or #stack==0 then return end
  T.pause(c);F.undo(c,redo);T.seek(c,T.context(c),c.finalCutCursor or 0);return
 end
 if not ctx.key then return end
 local h=history(ctx.key);local from=redo and h.redo or h.undo;local to=redo and h.undo or h.redo
 local edit=from[#from];if not edit then return end
 T.pause(c)
 local originals={}
 for i,item in ipairs(edit.changes)do originals[i]=item.frames.timecodeCuts;item.frames.timecodeCuts=copy(redo and item.after or item.before)end
 if not c.recording and JLRSPersist.safeSave(c)==false then for i,item in ipairs(edit.changes)do item.frames.timecodeCuts=originals[i]end;return end
 table.remove(from);to[#to+1]=edit;c.timecodeMark=nil;T.seek(c,T.context(c),edit.time)
end
local function time(value)
 value=math.max(0,value or 0);local total=math.floor(value*100+.00001)
 return string.format('%02d:%02d.%02d',math.floor(total/6000),math.floor(total/100)%60,total%100)
end
function T.drawBox(c,bar)
 local ctx=T.context(c);local cursor=T.cursor(c,ctx)
 JLRSMenu.rect(c,bar.x,bar.y,bar.w,bar.h,.025,.04,.06,.98)
 JLRSMenu.text(bar.x+.006,bar.y+bar.h*.66,math.min(.010,bar.h*.31),'TIMECODE  '..time(cursor)..' / '..time(ctx.duration))
 local mark=ctx.final and c.finalCutMark or c.timecodeMark
 local valid=mark and(ctx.final and mark.take==ctx.key or not ctx.final and mark.key==ctx.key)
 local message='Alt + drag | X / X / Delete'
 if valid then message='CUT  '..time(math.min(mark.a,mark.b or cursor))..' - '..time(math.max(mark.a,mark.b or cursor));JLRSMenu.rect(c,bar.x,bar.y,bar.w*.7,bar.h*.32,0,0,0,1)end
 -- Visible guide INSIDE the same numeric Timecode, not a separate panel.
 local rail={x=bar.x+.006,y=bar.y+bar.h*.43,w=math.max(.001,bar.w-.012),h=bar.h*.19};bar.rail=rail
 local y=rail.y+rail.h*.5;local thickness=math.max(.0012,bar.h*.065)
 local ratio=ctx.duration>0 and clamp(cursor/ctx.duration,0,1)or 0
 JLRSMenu.rect(c,rail.x,y-thickness*.5,rail.w,thickness,.68,.76,.83,1)
 JLRSMenu.rect(c,rail.x,y-thickness*.5,rail.w*ratio,thickness,.15,.78,1,1)
 for _,edge in ipairs({0,1})do JLRSMenu.rect(c,rail.x+(rail.w-.001)*edge,y-bar.h*.09,.001,bar.h*.18,.9,.94,1,1)end
 if valid and ctx.duration>0 then
  local a=clamp(math.min(mark.a,mark.b or cursor)/ctx.duration,0,1)
  local b=clamp(math.max(mark.a,mark.b or cursor)/ctx.duration,0,1)
  JLRSMenu.rect(c,rail.x+rail.w*a,y-bar.h*.095,rail.w*(b-a),bar.h*.19,0,0,0,1)
  for _,point in ipairs({mark.a,mark.b})do
   local x=rail.x+rail.w*clamp(point/ctx.duration,0,1)
   JLRSMenu.rect(c,clamp(x-.001,rail.x,rail.x+rail.w-.002),y-bar.h*.16,.002,bar.h*.32,1,.65,.10,1)
  end
 end
 local head=clamp(rail.x+rail.w*ratio-.0008,rail.x,rail.x+rail.w-.0016)
 JLRSMenu.rect(c,head,y-bar.h*.14,.0016,bar.h*.28,1,1,1,1)
 JLRSMenu.text(bar.x+.006,bar.y+bar.h*.09,.008,message)
 bar.undo={x=bar.x+bar.w*.73,y=bar.y,w=bar.w*.12,h=bar.h*.46}
 bar.redo={x=bar.x+bar.w*.86,y=bar.y,w=bar.w*.14,h=bar.h*.46}
 JLRSMenu.text(bar.undo.x,bar.undo.y+bar.h*.13,.008,'Undo')
 JLRSMenu.text(bar.redo.x,bar.redo.y+bar.h*.13,.008,'Redo')
end
local function inside(b,x,y)return b and x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h end
function T.mouse(c,x,y,down,up,button)
 local drag=c.timecodeDrag
 if drag then
  local ctx=T.context(c)
  if ctx.key~=drag.key then c.timecodeDrag=nil;return true end
  local value=drag.start+(x-drag.x)/drag.width*drag.duration
  if c.timecodeMouseFrame~=(g_time or 0)or up then c.timecodeMouseFrame=g_time or 0;T.seek(c,ctx,value)end
  if up and button==Input.MOUSE_BUTTON_LEFT then c.timecodeDrag=nil end
  return true
 end
 if not JLRSMiniHud.interacting(c)then return false end
 for _,bar in ipairs({c.timecodeStandard or false,c.timecodeFinal or false})do if bar and inside(bar,x,y)then
  if down and button==Input.MOUSE_BUTTON_LEFT then
   local ctx=T.context(c);c.timecodeFocus=ctx.key
   if inside(bar.undo,x,y)then T.pause(c);T.undo(c,false)
   elseif inside(bar.redo,x,y)then T.pause(c);T.undo(c,true)
   elseif ctx.duration>0 then
    T.pause(c)
    local onRail=inside(bar.rail,x,y)
    local width=onRail and bar.rail.w or bar.w
    local start=onRail and clamp((x-bar.rail.x)/bar.rail.w,0,1)*ctx.duration or T.cursor(c,ctx)
    c.timecodeDrag={key=ctx.key,x=x,start=start,width=width,duration=ctx.duration}
    T.seek(c,ctx,start)
   end
  end
  return true
 end end
 return false
end
local finalMouse=JLRSMiniHud.finalMouse
JLRSMiniHud.finalMouse=function(c,...)if T.mouse(c,...)then return true end;return finalMouse(c,...)end
local cursor=JLRSMiniHud.cursor
JLRSMiniHud.cursor=function(c,...)if c.timecodeDrag then return true end;return cursor(c,...)end
local axis=JLRSCamera.mouseAxis
JLRSCamera.mouseAxis=function(c,...)if c.timecodeDrag then return end;return axis(c,...)end
local drawFinal=JLRSFinal.draw
JLRSFinal.draw=function(c,...)
 local result=drawFinal(c,...);c.timecodeFinal=nil;c.finalCutBar=nil

 return result
end
local pause=JLReplayStudio.togglePause
JLReplayStudio.togglePause=function(c,...)if c.timecodePauseOwned then T.resume(c);return end;return pause(c,...)end
local record=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,...)if c.timecodeRecordHold then return end;return record(c,...)end
local stopRecord=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
 local saved=c.timecodeBeforePause
 T.restoreRecord(c);c.timecodePauseOwned=nil;c.timecodeBeforePause=nil
 if saved then c.paused=saved.main;c.livePaused=saved.live end
 return stopRecord(c,...)
end
local finishFinal=JLRSFinal.finish
JLRSFinal.finish=function(c,...)
 if c.timecodeFinalPreview then T.restoreRecord(c)end
 return finishFinal(c,...)
end
-- Skip source ranges only at a cut boundary. Ordinary replay remains exactly
-- the 1.18.86.72 path; no additional capture or pose write on normal frames.
local replay=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,dt,...)
 local cuts=track.frames and track.frames.timecodeCuts
 local c=JLReplayStudio;local playing=c.finalPlaying
 if playing then
  if not playing.timecodeFrames then
   local map={};playing.timecodeFrames=map
   for _,clip in ipairs(c.history or {})do
    local ranges=playing.take.standardTimecode and playing.take.standardTimecode[clip.id]
    if ranges then map[clip.frames]=ranges end
   end
  end
  cuts=playing.timecodeFrames[track.frames]
 end
 if cuts and #cuts>0 and track.replaying and not track.paused and not c.timecodeStartingFinal then
  local raw=track.duration;local duration=T.length(cuts,raw)
  local output=T.output(cuts,raw,track.replayTime)+(dt or 0)*(track.replaySpeed or 1)
  if track.loop and duration>0 then output=output%duration end
  local desired=T.source(cuts,raw,math.min(output,duration))
  local expected=track.replayTime+(dt or 0)*(track.replaySpeed or 1)
  local jump=desired-expected
  if math.abs(jump)>.000001 then
   track.replayTime=desired-(dt or 0)*(track.replaySpeed or 1)
   if track.collisionReplay then JLRSCollision.place(track,JLRSRecorder.sample(track,desired))end
   local t=c.finalRecording;if t and t.master==track then t.lastSource=t.lastSource+jump;t.pendingCut=true end
   if playing and playing.master==track then playing.lastSource=playing.lastSource+jump end
  end
 end
 return replay(track,dt,...)
end
local write=JLRSActivities.write
JLRSActivities.write=function(x,key,frames,...)
 local result=write(x,key,frames,...);local cuts=frames.timecodeCuts
 if cuts and #cuts>0 then
  x:setInt(key..'.timecode#count',#cuts)
  for i,r in ipairs(cuts)do local k=key..'.timecode.range('..(i-1)..')';x:setString(k..'#a',string.format('%.17g',r.a));x:setString(k..'#b',string.format('%.17g',r.b))end
 end
 return result
end
local read=JLRSActivities.read
JLRSActivities.read=function(x,key,frames,...)
 local result=read(x,key,frames,...);local count=x:getInt(key..'.timecode#count',0)
 if count<0 or count>10000 then error('Metadata Timecode rusak')end
 local cuts={};local last=0
 for i=1,count do
  local k=key..'.timecode.range('..(i-1)..')';local a=tonumber(x:getString(k..'#a'));local b=tonumber(x:getString(k..'#b'))
  if not a or not b or a~=a or b~=b or b>=math.huge or a<last or b<=a then error('Rentang Timecode rusak')end
  cuts[i]={a=a,b=b};last=b
 end
 frames.timecodeCuts=#cuts>0 and cuts or nil;return result
end
if JLRSChange then
 local adapt=JLRSChange.adapt
 JLRSChange.adapt=function(entries,frames,...)
  local result=adapt(entries,frames,...)
  if result and result.frames and frames.timecodeCuts then result.frames.timecodeCuts=copy(frames.timecodeCuts)end
  return result
 end
end
local poll=JLReplayStudio.poll
JLReplayStudio.poll=function(c,...)
 local result=poll(c,...);local ctx=T.context(c)
 if c.timecodeDrag and(not c.miniHudEnabled or c.shortcutHudHidden or c.menu or(g_gui and g_gui:getIsGuiVisible()))then c.timecodeDrag=nil end
 local enabled=c.mission and not c.menu and c.miniHudEnabled and not c.shortcutHudHidden
  and not c.finalListOpen and not c.curvaOpen and not(g_gui and g_gui:getIsGuiVisible())and c.timecodeFocus~=nil and c.timecodeFocus==ctx.key
 local keys=c.timecodeKeys or {};c.timecodeKeys=keys
 for _,a in ipairs({{'x',Input.KEY_x,T.mark},{'delete',Input.KEY_delete,T.remove}})do
  local on=a[2]and Input.isKeyPressed(a[2])or false
  if enabled and on and not keys[a[1]]then a[3](c)end;keys[a[1]]=on
 end
 local on=Input.KEY_space and Input.isKeyPressed(Input.KEY_space)or false
 if c.recording and c.timecodePauseOwned and not c.menu and not(g_gui and g_gui:getIsGuiVisible())and on and not keys.space then T.resume(c)end
 keys.space=on;return result
end
local reserved=JLRSShortcuts.reserved
JLRSShortcuts.reserved=function(c)
 local ctx=c and T.context(c)
 if c and c.timecodePauseOwned and not c.menu and not(g_gui and g_gui:getIsGuiVisible())and Input.KEY_space and Input.isKeyPressed(Input.KEY_space)then return true end
 if c and c.timecodeFocus~=nil and c.timecodeFocus==ctx.key and c.miniHudEnabled and not c.shortcutHudHidden and not c.menu and not(g_gui and g_gui:getIsGuiVisible())then
  for _,key in ipairs({Input.KEY_x,Input.KEY_delete})do if key and Input.isKeyPressed(key)then return true end end
 end
 return reserved(c)
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
 local saved=c.timecodeBeforePause
 T.restoreRecord(c);c.timecodeBeforePause=nil;c.timecodeDrag=nil;c.timecodePauseOwned=nil;c.timecodeFocus=nil;c.timecodeCursor=nil;c.timecodeMark=nil
 if saved then c.paused=saved.main;c.livePaused=saved.live end
 return stop(c,...)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
 local result=load(c,...);c.timecodeStandard=nil;c.timecodeFinal=nil;c.timecodeKeys={};return result
end

-- Snapshot standard cuts with a new camera take. Later edits to History must
-- not silently change the timing of an already-saved Final from another day.
local finalRecord=JLRSFinal.record
JLRSFinal.record=function(c,...)
 local result=finalRecord(c,...);local t=c.finalRecording
 if t and not t.standardTimecode then
  t.standardTimecode={}
  for _,clip in ipairs(c.history or {})do for _,id in ipairs(t.clips or {})do
   if clip.id==id and clip.frames.timecodeCuts then t.standardTimecode[id]=copy(clip.frames.timecodeCuts)end
  end end
 end
 return result
end
local playFinal=JLRSFinal.play
JLRSFinal.play=function(c,...)
 c.timecodeStartingFinal=true
 local ok,result=pcall(playFinal,c,...);c.timecodeStartingFinal=nil
 if not ok then error(result,0)end
 return result
end
local writeFinal=F.write
F.write=function(x,k,t)
 writeFinal(x,k,t)
 if not t.standardTimecode then return end
 x:setInt(k..'.timecodeSources#version',1)
 for _,id in ipairs(t.clips or {})do
  local ranges=t.standardTimecode[id]or {};local key=k..'.timecodeSources.clip'..id
  x:setInt(key..'#count',#ranges)
  for i,r in ipairs(ranges)do local p=key..'.range('..(i-1)..')';x:setString(p..'#a',string.format('%.17g',r.a));x:setString(p..'#b',string.format('%.17g',r.b))end
 end
end
local readFinal=F.read
F.read=function(x,k,t)
 readFinal(x,k,t)
 if x:getInt(k..'.timecodeSources#version',0)==0 then return end
 t.standardTimecode={}
 for _,id in ipairs(t.clips or {})do
  local key=k..'.timecodeSources.clip'..id;local count=x:getInt(key..'#count',0);local ranges={};local last=0
  if count<0 or count>10000 then error('Metadata sumber Timecode Final rusak')end
  for i=1,count do
   local p=key..'.range('..(i-1)..')';local a=tonumber(x:getString(p..'#a'));local b=tonumber(x:getString(p..'#b'))
   if not a or not b or a~=a or b~=b or b>=math.huge or a<last or b<=a then error('Rentang sumber Timecode Final rusak')end
   ranges[i]={a=a,b=b};last=b
  end
  t.standardTimecode[id]=ranges
 end
end
