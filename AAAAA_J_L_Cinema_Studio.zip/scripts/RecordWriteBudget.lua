-- Stage XML chunk construction, save and verification across record ticks. Recorded samples and
-- the fixed-size on-disk format stay unchanged. Pending chunks remain readable.
-- Keep ordinary takes in RAM, avoiding synchronous native disk calls in Record.
-- Long takes start staged spooling at the high watermark and stop at the low one.
JLRSWriteBudget={queue={},bytes=0,RAM_HIGH=128*1024*1024,RAM_LOW=64*1024*1024,MAX_BYTES=192*1024*1024,spooling=false,peakBytes=0}
local Q=JLRSWriteBudget
function Q.captureActive()
    local c=JLReplayStudio
    return c.recording or c.finalRecording~=nil
end
function Q.service()
    -- Record All can accumulate wide activity frames quickly. Begin writing
    -- well before the old 128 MiB cliff instead of retaining minutes of data.
    local all=JLReplayStudio.recording and JLReplayStudio.recordAllActive
    local high=all and 24*1024*1024 or Q.RAM_HIGH
    local low=all and 12*1024*1024 or Q.RAM_LOW
    if Q.bytes>=high then Q.spooling=true end
    if Q.bytes<=low then Q.spooling=false end
    if Q.spooling then Q.process(1) end
end
local flush=JLRSFrames.flush
local get=JLRSFrames.get
local manifest=JLRSFrames.manifest
-- XML building, disk save and read-back verification occupy separate ticks.
-- The limits bound native setString calls and values per build step; a single
-- frame is always written whole so the chunk format is exactly the same.
Q.BUILD_ROWS=60;Q.BUILD_VALUES=3000
local function closeItem(item)
    if item.file then item.file:delete();item.file=nil end
end
local function step(item)
    local s=item.frames._jlrs
    if not item.phase then
        item.file=XMLFile.create('jlrsFrameChunk',JLRSFrames.path(s,item.chunk),'record')
        if not item.file then error('Tidak dapat membuat chunk record.') end
        item.file:setInt('record#count',#item.data)
        item.nextRow=1;item.phase='build'
    end
    if item.phase=='build' then
        local rows,values=0,0
        local all=JLReplayStudio.recording and JLReplayStudio.recordAllActive
        local maxValues=all and 18000 or Q.BUILD_VALUES
        local start=Q.captureActive() and type(getTimeSec)=='function' and getTimeSec() or nil
        while item.nextRow<=#item.data and rows<Q.BUILD_ROWS and values<maxValues do
            -- At least one row makes progress. Extra rows share a 1 ms build
            -- budget, allowing fast PCs to keep up without a full-queue drain.
            if start and rows>0 and getTimeSec()-start>=.001 then break end
            local i=item.nextRow
            -- Conversion is deferred from the collision sampling path to this budgeted step.
            local text=item.encoded[i]
            if not text then
                item.encoder=item.encoder or {}
                text=JLRSFrames.encode(item.data[i],item.encoder)
                item.encoded[i]=text
            end
            item.file:setString('record.frame('..(i-1)..')#data',text)
            values=values+(item.data[i]._base and #item.data[i]._base or #item.data[i].pose);rows=rows+1;item.nextRow=i+1
        end
        if item.nextRow>#item.data then item.phase='save' end
        return false
    elseif item.phase=='save' then
        local saved=item.file:save();closeItem(item)
        if saved==false then error('Disk penuh / cache tidak dapat ditulis.') end
        item.phase='verify';return false
    else
        local check=XMLFile.load('jlrsFrameChunkCheck',JLRSFrames.path(s,item.chunk))
        if not check then error('Chunk tidak dapat dibaca setelah disimpan.') end
        local ok,valid=pcall(check.getInt,check,'record#count');check:delete()
        if not ok then error(valid) end
        if valid~=#item.data then error('Chunk cache tidak lengkap; buffer dipertahankan.') end
        JLRSFrames.indexDirty=true
        return true
    end
end
function Q.process(limit)
    local steps=0
    while #Q.queue>0 and (not limit or steps<limit) do
        local item=Q.queue[1];local s=item.frames._jlrs;local finished=s.released
        if finished then closeItem(item) else
            local ok,result=pcall(step,item)
            if not ok then
                closeItem(item);item.phase=nil;item.nextRow=nil
                error(result)
            end
            finished=result
            if finished then
                s.pending[item.chunk]=nil
                s.cache[item.chunk]=item.data;s.order[#s.order+1]=item.chunk
                while #s.order>JLRSFrames.CACHE_CHUNKS do s.cache[table.remove(s.order,1)]=nil end
            end
        end
        if finished then table.remove(Q.queue,1);Q.bytes=Q.bytes-item.bytes end
        steps=steps+1
    end
end
JLRSFrames.manifest=function(...)
    if Q.writing then JLRSFrames.indexDirty=true;return end
    if not Q.captureActive() then Q.process() end
    return manifest(...)
end
JLRSFrames.flush=function(frames)
    local s=frames._jlrs
    if not s or #frames==0 then return end
    if not Q.captureActive() then Q.process();return flush(frames) end
    -- Keep a strict memory bound if the disk cannot keep up with many streams.
    -- Emergency backpressure reclaims only enough space, never drains the
    -- entire queue during capture. Disk stalls can still occur beyond the cap.
    while Q.bytes>=Q.MAX_BYTES and #Q.queue>0 do Q.process(1) end
    local data,encoded,bytes={},{},0
    for i,frame in ipairs(frames) do
        data[i]=frame;encoded[i]=s.encoded and s.encoded[i]
        -- Conservative budget including future text, table slots and raw pose data.
        local width=frame._base and #frame._base or #frame.pose
        bytes=bytes+(encoded[i] and #encoded[i] or width*32+32)+width*16+256
    end
    local chunk=s.sealed+1
    s.pending=s.pending or {};s.pending[chunk]=data
    s.sealed=chunk;s.bounds[chunk]={first=data[1].t,last=data[#data].t,count=#data}
    Q.queue[#Q.queue+1]={frames=frames,chunk=chunk,data=data,encoded=encoded,bytes=bytes}
    Q.bytes=Q.bytes+bytes;Q.peakBytes=math.max(Q.peakBytes,Q.bytes);s.encoded={}
    for i=#frames,1,-1 do frames[i]=nil end
end
-- Keep incoming numeric samples unchanged in RAM. The staged writer performs
-- exact %.17g conversion later; Stop/History keep the original immediate path.
local push=JLRSFrames.push
JLRSFrames.push=function(frames,frame)
    local state=frames._jlrs
    if not state or not Q.captureActive() then return push(frames,frame) end
    if #frames>=state.chunkSize then JLRSFrames.flush(frames) end
    frames[#frames+1]=frame;state.count=state.count+1
end
JLRSFrames.get=function(frames,index)
    local s=frames and frames._jlrs
    if s and not s.released and index>=1 and index<=s.count then
        local chunk=math.floor((index-1)/s.chunkSize)+1
        local data=s.pending and s.pending[chunk]
        if data then return data[(index-1)%s.chunkSize+1] end
    end
    return get(frames,index)
end
-- History must never refer to chunks that have not reached disk.
local save=JLRSPersist.save
JLRSPersist.save=function(...) Q.process();return save(...) end
local stop=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    if c==JLReplayStudio then Q.process() end
    local result=stop(c,...)
    if c==JLReplayStudio then Q.process() end
    return result
end
local tick=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,...)
    if c==JLReplayStudio and c.recording and not c.cacheFault then
        local ok,err=true,nil
        ok,err=pcall(Q.service)
        if not ok then
            c.cacheFault=tostring(err);c.recording=false
            c:notify('Record dihentikan: cache tidak dapat ditulis. Data buffer tetap disimpan; periksa ruang disk. '..tostring(err))
            return
        end
    end
    return tick(c,...)
end
local release=JLRSFrames.release
JLRSFrames.release=function(frames,...)
    local result=release(frames,...)
    if frames and frames._jlrs then
        frames._jlrs.pending=nil
        for _,item in ipairs(Q.queue) do if item.frames==frames then closeItem(item) end end
    end
    return result
end
local cleanup=JLRSFrames.cleanup
JLRSFrames.cleanup=function(...)
    local result=cleanup(...);Q.queue={};Q.bytes=0;Q.spooling=false;Q.peakBytes=0;return result
end
