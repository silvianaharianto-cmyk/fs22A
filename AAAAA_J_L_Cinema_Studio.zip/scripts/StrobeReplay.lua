-- LightExtension and renamed forks (including AddNewStoreCategory) keep their
-- sequenced strobes outside spec_lights.beaconLights. No foreign onUpdate runs.
JLRSStrobeReplay={cache=setmetatable({},{__mode='k'}),owners=setmetatable({},{__mode='k'}),visual=setmetatable({},{__mode='k'})}
local E=JLRSStrobeReplay
local function groups(v)
    local list=E.cache[v]
    if list then return list end
    list={};E.cache[v]=list
    for name,spec in pairs(v)do
        if type(name)=='string' and name:match('^spec_')and type(spec)=='table'
            and type(spec.strobeLights)=='table' and type(spec.strobeLights.strobes)=='table'then
            list[#list+1]={name=name,group=spec.strobeLights}
        end
    end
    table.sort(list,function(a,b)return a.name<b.name end)
    return list
end
local function groupFor(v,name)
    local list=groups(v)
    for _,entry in ipairs(list)do if entry.name==name then return entry.group end end
    -- Change Cars may replace one renamed fork with another compatible fork.
    if #list==1 then return list[1].group end
end
local function paint(group,st,on,force)
    local previous=E.visual[st]
    if not force and previous and previous.on==on and previous.real==group.realBeaconLights then return end
    local function valid(n)return n and entityExists(n)end
    if valid(st.realLightNode) and group.realBeaconLights then setVisibility(st.realLightNode,on)end
    if valid(st.lightNode)then setVisibility(st.lightNode,on)end
    if valid(st.lightShaderNode) and setShaderParameter then
        local p=st.shaderParameter or {0,0,0}
        setShaderParameter(st.lightShaderNode,'lightControl',on and (st.intensity or 100)or 0,p[1],p[2],p[3],false)
    end
    previous=previous or {};previous.on=on;previous.real=group.realBeaconLights;E.visual[st]=previous
end
local function phase(st,p,extra)
    local on=p[1]>=.5;local timer=math.max(0,p[2]+extra);local nextTime=math.max(0,p[3]);local index=math.max(1,math.floor(p[4]))
    if extra<=0 then return on end -- Preserve exact captured keys, including a native pending toggle.
    local sq=st.sq
    if st.rnd or not sq or #sq==0 then return on end -- New random takes retain the sampled state/duration.
    local turns=0
    while timer>nextTime and turns<256 do
        timer=timer-nextTime;on=not on;index=index%#sq+1
        nextTime=math.max(1,tonumber(sq[index])or 1);turns=turns+1
    end
    return on
end
local function readInto(v,ch,out)
    local g=groupFor(v,ch.name);local st=g and g.strobes[ch.index]
    out[1]=st and st.ls and 1 or 0;out[2]=st and st.t or 0;out[3]=st and st.ns or 0
    out[4]=st and st.ss or 1;out[5]=g and g.active and 1 or 0
    out[6]=JLReplayStudio.recording and (JLReplayStudio.recordTime or 0)or 0
    return out
end
JLRSActivities.registerAdapter('jlrsStrobe',{
    cinemaNumericReadInto=true,readInto=readInto,read=function(v,ch)return readInto(v,ch,{})end,
    discover=function(v)
        local out={}
        for _,entry in ipairs(groups(v))do for i,st in ipairs(entry.group.strobes)do
            if type(st)=='table' and (st.lightShaderNode or st.lightNode or st.realLightNode)then
                out[#out+1]={name=entry.name,index=i,mode='step'}
            end
        end end
        return out
    end,
    write=function(v,ch,p,paused,restoring)
        local g=groupFor(v,ch.name);local st=g and g.strobes[ch.index];if not st then return end
        local track=JLRSSecondaryEffects and JLRSSecondaryEffects.track
        if restoring then
            E.owners[st]=nil;g.active=p[5]>=.5
            paint(g,st,g.active and p[1]>=.5,true);return
        end
        local owner=E.owners[st]or {};E.owners[st]=owner;owner.track=track
        local extra=track and math.max(0,(track.replayTime or 0)-p[6])*1000 or 0
        g.active=p[5]>=.5
        paint(g,st,g.active and phase(st,p,math.min(extra,1000)),false)
    end
})
-- Existing History has beacon ON/OFF but no custom phase channels. Use the
-- vehicle's own sequence/invert and source clock; never a generic blink rate.
local tick=JLRSActivities.tick
JLRSActivities.tick=function(track,...)
    local result=tick(track,...);local state=track.activityReplay
    if not state then return result end
    if not state.legacyStrobes then
        local list={};state.legacyStrobes=list
        for v in pairs(state.renderVehicles)do
            for _,entry in ipairs(groups(v))do for _,st in ipairs(entry.group.strobes)do
                list[#list+1]={vehicle=v,group=entry.group,st=st,p={st.inv and 1 or 0,1,0,1,1,0}}
            end end
        end
    end
    for _,item in ipairs(state.legacyStrobes)do
        local owner=E.owners[item.st]
        local effect=JLRSSecondaryEffects and JLRSSecondaryEffects.owners[item.vehicle]
        if not(owner and owner.track and owner.track.replaying)
            and (not effect or effect.track==track or not effect.track.replaying)then
            local active=item.group.active
            if item.vehicle.spec_lights and item.vehicle.spec_lights.beaconLightsActive~=nil then active=item.vehicle.spec_lights.beaconLightsActive end
            local time=math.max(0,track.replayTime or 0)*1000
            -- Full cycles of even-length patterns return to the same state.
            local sq=item.st.sq
            if sq and #sq>0 then
                if not item.cycle then local cycle=0;for _,ms in ipairs(sq)do cycle=cycle+math.max(1,ms)end;item.cycle=cycle*(#sq%2==1 and 2 or 1)end
                time=time%item.cycle
            end
            paint(item.group,item.st,active and phase(item.st,item.p,time),false)
        end
    end
    return result
end
local restore=JLRSActivities.restore
JLRSActivities.restore=function(track,...)
    local state=track.activityReplay
    local result=restore(track,...)
    for _,item in ipairs(state and state.legacyStrobes or {})do
        local owner=E.owners[item.st]
        if not owner or owner.track==track or not(owner.track and owner.track.replaying)then
            paint(item.group,item.st,item.group.active and item.st.ls,true);E.owners[item.st]=nil;E.visual[item.st]=nil
        end
    end
    return result
end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=delete(c,...)
    E.cache=setmetatable({},{__mode='k'});E.owners=setmetatable({},{__mode='k'});E.visual=setmetatable({},{__mode='k'})
    return result
end
