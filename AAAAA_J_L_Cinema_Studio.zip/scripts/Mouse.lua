JLRSMouse={}
function JLRSMouse.syncCursor(c)
    local binding=g_inputBinding;if not binding then return end
    -- All Cinema HUD/camera refreshes use the same ownership policy. Do not
    -- hide a cursor here and show it again later in the same render frame.
    local visible=c.menu or (g_gui and g_gui:getIsGuiVisible())
        or (JLRSMiniHud and JLRSMiniHud.cursor(c))
        or (JLRSObject and JLRSObject.cursor(c))
        or (JLRSChange and JLRSChange.cursor(c)) or false
    visible=visible==true
    local current
    if c.cursorBinding==binding then current=c.cursorVisible end
    if type(binding.getShowMouseCursor)=='function' then
        local ok,value=pcall(binding.getShowMouseCursor,binding)
        if ok then current=value==true end
    elseif type(binding.cursorVisible)=='boolean' then
        current=binding.cursorVisible
    end
    if current~=visible then binding:setShowMouseCursor(visible) end
    if visible and not c.cursorVisible then
        -- Mouse deltas captured just before a HUD opens must not rotate the
        -- camera later when the user releases Alt or closes the HUD.
        c.compatMouse=nil
        if c.cameraInput then c.cameraInput.x=0;c.cameraInput.y=0 end
    end
    c.cursorBinding=binding;c.cursorVisible=visible
end
function JLRSMouse.onAxis(self,action,value,state,isAnalog,isMouse)
    if isMouse and value~=0 then JLRSCamera.mouseAxis(self.controller,state,value) end
end
function JLRSMouse.refresh(c)
    if not g_inputBinding then return end
    if c.active then
        local vehicle=g_currentMission.controlledVehicle
        if c.mouseInput and c.mouseInput.vehicle~=vehicle then JLRSMouse.disable(c) end
        -- Recover our own action events when another mod rebuilds vehicle inputs.
        if c.mouseInput and type(g_inputBinding.events)=='table' then
            for _,id in ipairs(c.mouseInput.events) do
                if g_inputBinding.events[id]==nil then JLRSMouse.disable(c);break end
            end
        end
        if not c.mouseInput then
            local target={controller=c,vehicle=vehicle,events={},axes={}}
            c.mouseInput=target
            do
                for _,item in ipairs({{'JLRS_MOUSE_X','X'},{'JLRS_MOUSE_Y','Y'}}) do
                    local action=InputAction[item[1]]
                    if action then
                        local ok,id=g_inputBinding:registerActionEvent(action,target,JLRSMouse.onAxis,false,false,true,true,item[2],true)
                        if ok and id then target.events[#target.events+1]=id;target.axes[item[2]]=true;g_inputBinding:setActionEventTextVisibility(id,false) end
                    end
                end
            end
        end
        local enabled=not c.menu and not (g_gui and g_gui:getIsGuiVisible())
        for _,id in ipairs(c.mouseInput.events) do g_inputBinding:setActionEventActive(id,enabled) end
    end
    if c.active or c.menu then JLRSMouse.syncCursor(c) end
end
function JLRSMouse.disable(c)
    if c.mouseInput and g_inputBinding then g_inputBinding:removeActionEventsByTarget(c.mouseInput) end
    c.mouseInput=nil
end
-- Native vehicle axes keep working while the simulation update is paused.
if VehicleCamera then
    for _,item in ipairs({{'actionEventLookLeftRight','X'},{'actionEventLookUpDown','Y'}}) do
        local name,axis=item[1],item[2];local original=VehicleCamera[name]
        if type(original)=='function' then
            VehicleCamera[name]=function(camera,action,value,state,isAnalog,isMouse)
                local c=JLReplayStudio;local controlled=g_currentMission and g_currentMission.controlledVehicle
                if c and c.active and controlled and camera.vehicle==controlled then
                    if isMouse and not (c.mouseInput and c.mouseInput.axes[axis]) then JLRSCamera.mouseAxis(c,axis,value) end
                    return
                end
                return original(camera,action,value,state,isAnalog,isMouse)
            end
        end
    end
    JLRSMouse.vehicleBridge=type(VehicleCamera.actionEventLookLeftRight)=='function' and type(VehicleCamera.actionEventLookUpDown)=='function'
end
