-- Editor input only. No new replay/body writer or changes to recorded data.
JLRSCurvaInput={}
local C=JLRSCurva
local mouse=C.mouse
local function panel(c,x,y)
 return x>=.735 or (c.curvaViews and x>=.50 and y>=.19 and y<=.40)
  or(c.curvaTools and x>=.49 and y>=.43 and y<=.76)
  or(x>=.50 and x<=.715 and y>=.35 and y<=.422)
end
C.mouse=function(c,x,y,down,up,button,...)
 c.mouseX=x;c.mouseY=y
 if c.curvaOpen and c.curvaPage=='vehicles' and down and button==Input.MOUSE_BUTTON_LEFT
  and x>=.75 and x<=.97 and y>=.125 and y<=.161 then
  if c.recording or c.finalRecording then c:notify('Stop Record dahulu sebelum Edit Curva.');return end
  if c.changePending then c:notify('Tunggu Change Cars selesai.');return end
  C.catalog(c)
  local found=false
  for _,item in ipairs(c.curvaItems or {})do if (c.curvaMarked or {})[item.vehicle]then found=true;break end end
  if not found then
   c:notify('Edit Curva: pilih minimal satu kendaraan dengan rekaman di History. Mobil tanpa rekaman dapat menjadi pengikut Follow One.')
   return
  end
  -- Finished/paused replay tracks are still marked replaying and previously
  -- blocked the button. Release replay explicitly when entering this editor.
  if c.replaying or c.finalPlaying or #(c.liveTracks or {})>0 then c:stop()end
  c.curvaPage='edit';c.curvaSelection=1;c.curvaPoint=1;c.curvaEdit=true
  c.curvaDrag=nil;c.curvaRotateDrag=nil;c.hitboxes={};C.view(c,'ATAS')
  return
 end
 -- Vehicle selection must not depend on whether a curve has already been generated.
 -- Editing still uses the original recorded-route validation; no fake take is created.
 if c.curvaOpen and c.curvaPage=='vehicles' and down and button==Input.MOUSE_BUTTON_LEFT
  and x>=.751 and x<=.928 then
  local list=C.vehicles(c)
  for row=1,7 do local bottom=.721-(row-1)*.073
   if y>=bottom+.006 and y<=bottom+.058 then
    local v=list[(c.curvaVehicleOffset or 0)+row]
    if v then c.curvaMarked=c.curvaMarked or {};c.curvaMarked[v]=not c.curvaMarked[v];c.curvaLabelVehicle=v end
    return
   end
  end
 end
 local right=Input.MOUSE_BUTTON_RIGHT or 3
 if c.curvaRotateDrag then
  if up and button==right then c.curvaRotateDrag=nil;return end
  local p=c.curvaViewCamera;local drag=c.curvaRotateDrag
  if p and c.curvaOpen and c.curvaPage=='edit' then
   local dx,dy=x-drag.x,y-drag.y;drag.x=x;drag.y=y
   p.rotation[2]=p.rotation[2]-dx*3.5
   p.rotation[1]=math.max(-math.pi/2+.001,math.min(math.pi/2-.001,p.rotation[1]+dy*3.5))
   p.rotation[3]=0
   setRotation(p.node,unpack(p.rotation))
   return
  end
  c.curvaRotateDrag=nil
 end
 if c.curvaOpen and c.curvaPage=='edit' and down and button==right
  and not c.curvaDrag and not panel(c,x,y) and not(g_gui and g_gui:getIsGuiVisible())then
  C.cameraTick(c,0)
  if c.curvaViewCamera then c.curvaRotateDrag={x=x,y=y}end
  return
 end
 return mouse(c,x,y,down,up,button,...)
end
local open=C.open
C.open=function(c,...)
 c.curvaRotateDrag=nil
 if JLRSFollowOne then JLRSFollowOne.close(c)end
 return open(c,...)
end
local release=C.releaseCamera
C.releaseCamera=function(c,...)c.curvaRotateDrag=nil;return release(c,...)end
local view=C.view
C.view=function(c,...)c.curvaRotateDrag=nil;return view(c,...)end
