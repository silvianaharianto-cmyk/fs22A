-- Editor-only vehicle lanes, bounded Store thumbnails and one native render overlay.
local E=JLRSFinalEditing
E.ROWS=5
local function clip(c,id)for _,v in ipairs(c.history or {})do if v.id==id then return v end end end
local function name(v)
    if v and type(v.getName)=='function' then local ok,n=pcall(v.getName,v);if ok and n then return tostring(n)end end
    return 'Kendaraan'
end
function E.expandVehicles(c)
    if c.editingPlan.kind=='final' then return end
    local rows={}
    for _,r in ipairs(c.editingPlan.rows)do
        if r.vehicleIds then rows[#rows+1]=r
        else
            local added=false
            for _,id in ipairs(r.ids)do
                local source=clip(c,id)
                if not source then local missing=E.copyPlan({rows={r}}).rows[1];missing.ids={id};rows[#rows+1]=missing;added=true end
                for _,v in ipairs(source and (source.vehicles or {source.target})or {})do
                    if JLRSRecorder.valid(v)then
                        local row=E.copyPlan({rows={r}}).rows[1];row.ids={id};row.vehicleIds={JLRSPersist.identity(v)};row.name=name(v)
                        row.sourceIn=math.min(row.sourceIn,math.max(0,source.duration-.001));row.length=math.min(row.length,math.max(.001,source.duration-row.sourceIn))
                        rows[#rows+1]=row;added=true
                    end
                end
            end
            if not added then rows[#rows+1]=r end
        end
    end
    c.editingPlan.rows=rows
    c.editingOffset=math.max(0,math.min(c.editingOffset or 0,math.max(0,#rows-E.ROWS)))
end
function E.vehicle(c,row)
    if not row then return end
    for _,id in ipairs(row.ids)do local s=clip(c,id)
        if s then for _,v in ipairs(s.vehicles or {s.target})do
            if not row.vehicleIds then return v,s end
            for _,uid in ipairs(row.vehicleIds)do if JLRSPersist.identity(v)==uid then return v,s end end
        end end
    end
end
function E.icon(c,v)
    if not v or not g_storeManager or not g_storeManager.getItemByXMLFilename then return end
    local ok,item=pcall(g_storeManager.getItemByXMLFilename,g_storeManager,v.configFileName or v.xmlFilename or '')
    local file=ok and item and item.imageFilename
    if not file or file=='' then return end
    c.editingIcons=c.editingIcons or {};c.editingIconOrder=c.editingIconOrder or {}
    if c.editingIcons[file]~=nil then return c.editingIcons[file] or nil end
    local success,id=pcall(createImageOverlay,file)
    id=success and id and id~=0 and id or false
    c.editingIcons[file]=id;c.editingIconOrder[#c.editingIconOrder+1]=file
    if #c.editingIconOrder>32 then local oldest=table.remove(c.editingIconOrder,1);local old=c.editingIcons[oldest];if old then delete(old)end;c.editingIcons[oldest]=nil end
    return id or nil
end
local function thumbnail(c,v,x,y,w,h)
    local id=E.icon(c,v)
    if id then setOverlayColor(id,1,1,1,1);renderOverlay(id,x,y,w,h)
    else
        JLRSMenu.rect(c,x+w*.12,y+h*.18,w*.76,h*.40,.18,.3,.4)
        JLRSMenu.rect(c,x+w*.29,y+h*.58,w*.42,h*.22,.18,.3,.4)
        for _,rx in ipairs({.21,.65})do JLRSMenu.rect(c,x+w*rx,y+h*.1,w*.15,h*.17,.025,.035,.05)end
    end
end
function E.hold(c)
    local p=c.editingCameraLock
    if c.editingOpen and p and entityExists(p.node)then setTranslation(p.node,unpack(p.position));setRotation(p.node,unpack(p.rotation));setCamera(p.node)end
end
function E.lockEditor(c)
    if c.editingCameraLock then return end
    local node=getCamera();if not node or not entityExists(node)then return end
    local x,y,z=getWorldTranslation(node);local rx,ry,rz=getWorldRotation(node)
    local camera=createCamera('JLRS_Editor_Fixed',math.rad(c.fov or 55),.1,6000);link(getRootNode(),camera)
    c.editingCameraLock={node=camera,previous=node,position={x,y,z},rotation={rx,ry,rz}}
    JLRSCamera.clearInput(c);E.hold(c)
end
function E.releaseVisual(c)
    local p=c.editingCameraLock;c.editingCameraLock=nil
    if p then
        local normal=(c.active and c.camera) or p.previous
        if not normal or not entityExists(normal)then normal=JLRSCamera.gameplay()end
        if normal and entityExists(normal)then setCamera(normal)end
    end
    if c.editingRenderOverlay then delete(c.editingRenderOverlay)end;c.editingRenderOverlay=nil
    if c.editingPreviewCamera then delete(c.editingPreviewCamera)end;c.editingPreviewCamera=nil
    if p and entityExists(p.node)then delete(p.node)end
    for _,id in pairs(c.editingIcons or {})do if id then delete(id)end end
    c.editingIcons={};c.editingIconOrder={};c.editingPreviewFailed=nil;c.editingPreviewRunning=false
    JLRSCamera.clearInput(c)
end
function E.previewCamera(c)
    if c.editingPreviewCamera then return c.editingPreviewCamera end
    local p=c.editingCameraLock;if not p then return end
    local node=createCamera('JLRS_Editor_Preview',math.rad(50),.1,6000);link(getRootNode(),node)
    setTranslation(node,unpack(p.position));setRotation(node,unpack(p.rotation));c.editingPreviewCamera=node
    if type(createRenderOverlay)=='function' and type(updateRenderOverlay)=='function' then
        local aspect=(type(getScreenAspectRatio)=='function' and getScreenAspectRatio()or 16/9)*(.34/.30)
        local ok,id=pcall(createRenderOverlay,node,aspect,576,math.floor(576/aspect+.5),false,255,16711680)
        if ok and id and id~=0 then c.editingRenderOverlay=id else c.editingPreviewFailed=true end
    else c.editingPreviewFailed=true end
    return node
end
function E.frameSelected(c)
    local row=c.editingPlan.rows[c.editingSelected or 0];local v=E.vehicle(c,row);local camera=E.previewCamera(c)
    if not v or not camera or not JLRSRecorder.valid(v)then return end
    local x,y,z=getWorldTranslation(v.rootNode)
    local size=math.max(8,tonumber(v.sizeLength)or 0,tonumber(v.sizeWidth)or 0)
    local distance=size*1.6
    local px,py,pz=x+distance,y+distance*.6,z+distance
    if g_currentMission.terrainRootNode and type(getTerrainHeightAtWorldPos)=='function' then py=math.max(py,getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode,px,0,pz)+.5)end
    setTranslation(camera,px,py,pz)
    local dx,dy,dz=x-px,y+1.2-py,z-pz
    setRotation(camera,math.atan2(dy,math.sqrt(dx*dx+dz*dz)),math.atan2(-dx,-dz),0)
end
function E.select(c,index,frame)
    c.editingSelected=index
    if frame then E.frameSelected(c)end
end
local function inspectTime(c)return c.editingSession and c.editingSession.time or c.editingSeekTime or 0 end
function E.editorPreview(c,time,playing)
    if not c.editingSession then
        local ok=E.start(c,c.editingPlan,time or inspectTime(c));if not ok then return false end
    else E.seek(c,time or inspectTime(c))end
    c.editingOpen=true;c.menu=true;c.editingPreviewRunning=playing==true;c.livePaused=not c.editingPreviewRunning
    E.hold(c);JLRSMouse.refresh(c);JLRSMouse.syncCursor(c)
    return true
end
local open=E.open
E.open=function(c,...)
    if c.editingOpen then return end
    if c.editingSession and not c.finalRecording and not c.finalPlaying then c.editingSeekTime=c.editingSession.time;c:stop()end
    local result=open(c,...)
    if c.editingOpen then E.expandVehicles(c);E.lockEditor(c);E.previewCamera(c);c.editingPreviewRunning=false end
    return result
end
local close=E.close
E.close=function(c,...)
    E.releaseVisual(c)
    if c.editingSession then c.livePaused=true end
    return close(c,...)
end
local start=E.start
E.start=function(c,...)
    local editor=c.editingOpen;local result=start(c,...)
    if editor and result then c.editingOpen=true;c.menu=true;E.hold(c);JLRSMouse.refresh(c)end
    return result
end
local add=E.addChecked
E.addChecked=function(c,...)
    local result=add(c,...);if c.editingOpen then E.expandVehicles(c)end;return result
end
local function button(c,x,y,w,label,fn,on)
    JLRSMenu.rect(c,x,y,w,.028,on and .045 or .06,on and .37 or .1,on and .47 or .16,.98)
    JLRSMenu.text(x+.004,y+.009,.009,label)
    c.hitboxes[#c.hitboxes+1]={x=x,y=y,w=w,h=.028,callback=fn}
end
local function border(c,x,y,w,h,r,g,b)
    for _,v in ipairs({{x,y,w,.002},{x,y+h-.002,w,.002},{x,y,.0015,h},{x+w-.0015,y,.0015,h}})do JLRSMenu.rect(c,v[1],v[2],v[3],v[4],r,g,b,1)end
end
function E.draw(c)
    E.hold(c);c.hitboxes={};c.editingBarHits={}
    JLRSMenu.rect(c,.04,.055,.92,.90,.012,.018,.028,.98)
    JLRSMenu.rect(c,.04,.88,.92,.075,.023,.12,.18)
    JLRSMenu.text(.057,.918,.023,'J_L Cinema Studio | Editing Final')
    JLRSMenu.text(.058,.89,.010,'Final clips | click to select | drag clip / trim handles | scrub to preview | fixed camera')
    button(c,.91,.908,.03,'X',function()E.close(c)end)
    JLRSMenu.text(.057,.853,.012,'RECORD FINAL SOURCES',.3,.87,.95)
    button(c,.057,.816,.052,'ALL',function()for _,s in ipairs(E.editorSources and E.editorSources(c)or c.history)do c.editingSourceMarked[s.id]=true end end)
    button(c,.115,.816,.052,'CLEAR',function()c.editingSourceMarked={}end)
    button(c,.173,.816,.128,'ADD CHECKED',function()E.addChecked(c)end,true)
    for i=1,6 do
        local s=(E.editorSources and E.editorSources(c)or c.history)[(c.editingSourceOffset or 0)+i]
        if s then
            local y=.770-(i-1)*.038
            JLRSMenu.rect(c,.054,y-.005,.247,.033,.035,.05,.075)
            button(c,.058,y,.022,c.editingSourceMarked[s.id]and 'X'or '',function()c.editingSourceMarked[s.id]=not c.editingSourceMarked[s.id]end,c.editingSourceMarked[s.id])
            JLRSMenu.text(.086,y+.016,.010,('#'..s.id..' '..(s.name or 'History')):sub(1,30))
            JLRSMenu.text(.086,y+.003,.008,'RECORD FINAL | '..E.time(s.duration),.65,.77,.86)
        end
    end
    button(c,.057,.538,.115,'SOURCE UP',function()c.editingSourceOffset=math.max(0,(c.editingSourceOffset or 0)-6)end)
    button(c,.179,.538,.122,'SOURCE DOWN',function()c.editingSourceOffset=math.min(math.max(0,#(E.editorSources and E.editorSources(c)or c.history)-6),(c.editingSourceOffset or 0)+6)end)
    local camera=E.previewCamera(c)
    JLRSMenu.rect(c,.32,.55,.34,.30,.018,.027,.043)
    if c.editingRenderOverlay then
        local ok=pcall(updateRenderOverlay,c.editingRenderOverlay)
        if ok then setOverlayColor(c.editingRenderOverlay,1,1,1,1);renderOverlay(c.editingRenderOverlay,.32,.55,.34,.30)end
    else
        local row=c.editingPlan.rows[c.editingSelected or 0];thumbnail(c,E.vehicle(c,row),.4,.63,.18,.13)
        JLRSMenu.text(.34,.59,.011,'Preview render tidak tersedia pada sesi ini.',1,.72,.36)
    end
    border(c,.32,.55,.34,.30,.12,.46,.58)
    JLRSMenu.rect(c,.32,.825,.34,.025,.016,.025,.04,.9)
    JLRSMenu.text(.328,.833,.010,'SCENE PREVIEW | '..E.time(inspectTime(c)),.4,.94,.85)
    local selected=c.editingPlan.rows[c.editingSelected or 0];local vehicle,source=E.vehicle(c,selected)
    JLRSMenu.text(.680,.835,.014,'SELECTED CLIP',.3,.9,.98)
    thumbnail(c,vehicle,.69,.715,.105,.09)
    JLRSMenu.text(.80,.776,.011,(selected and selected.name or name(vehicle)):sub(1,22))
    JLRSMenu.text(.80,.755,.009,source and ('Record Final #'..source.id)or 'Klik sebuah clip')
    if selected then
        button(c,.681,.680,.255,'START  '..E.time(selected.start),function()E.fieldDialog(c,selected,'start','Start')end)
        button(c,.681,.646,.255,'SOURCE IN  '..E.time(selected.sourceIn),function()E.fieldDialog(c,selected,'sourceIn','Source In')end)
        button(c,.681,.612,.255,'DURATION  '..E.time(selected.length),function()E.fieldDialog(c,selected,'length','Duration')end)
    end
    button(c,.681,.573,.124,'VIEW CLIP',function()E.frameSelected(c)end)
    button(c,.811,.573,.125,c.editingPreviewRunning and 'PAUSE PREVIEW'or 'PLAY PREVIEW',function()E.editorPreview(c,inspectTime(c),not c.editingPreviewRunning)end,c.editingPreviewRunning)
    local left,right=.265,.940;local span=c.editingSpan or 60;local origin=c.editingViewStart or 0
    c.editingTimeline={x=left,y=.175,w=right-left,h=.335,span=span,origin=origin}
    JLRSMenu.text(.057,.515,.011,'FINAL TIMELINE | '..#c.editingPlan.rows..' tracks')
    button(c,.57,.515,.055,'<',function()c.editingViewStart=math.max(0,origin-span*.25)end)
    button(c,.63,.515,.055,'>',function()c.editingViewStart=origin+span*.25 end)
    button(c,.69,.515,.075,'ZOOM+',function()c.editingSpan=math.max(1,span*.75)end)
    button(c,.77,.515,.075,'ZOOM-',function()c.editingSpan=span/.75 end)
    button(c,.85,.515,.090,'FIT',function()c.editingSpan=math.max(1,E.duration(c.editingPlan));c.editingViewStart=0 end)
    JLRSMenu.rect(c,left,.482,right-left,.025,.05,.09,.135)
    c.editingBarHits[#c.editingBarHits+1]={x=left,y=.482,w=right-left,h=.025,kind='playhead'}
    for i=0,8 do
        local x=left+(right-left)*i/8
        JLRSMenu.rect(c,x,.178,.0007,.300,.12,.18,.25)
        JLRSMenu.text(math.min(x,right-.047),.490,.008,E.time(origin+span*i/8),.68,.8,.9)
    end
    for slot=1,E.ROWS do
        local index=(c.editingOffset or 0)+slot;local r=c.editingPlan.rows[index]
        if r then
            local y=.417-(slot-1)*.058;local v,s=E.vehicle(c,r);local on=c.editingSelected==index
            JLRSMenu.rect(c,.055,y-.004,.890,.051,on and .04 or .027,on and .13 or .041,on and .18 or .06)
            button(c,.06,y+.008,.023,r.enabled~=false and 'X'or '',function()
                if c.editingSession then c.editingPreviewRunning=false;c:stop()end;r.enabled=not r.enabled
            end,r.enabled~=false)
            thumbnail(c,v,.088,y+.004,.040,.038)
            JLRSMenu.text(.132,y+.026,.010,(r.name or name(v)):sub(1,20),on and .3 or .88,on and .94 or .91,1)
            JLRSMenu.text(.132,y+.009,.008,(s and ('#'..s.id..' FINAL')or 'MISSING')..' | '..index,.62,.76,.88)
            c.hitboxes[#c.hitboxes+1]={x=.086,y=y,w=.17,h=.046,callback=function()E.select(c,index,true)end}
            c.editingBarHits[#c.editingBarHits+1]={x=left,y=y-.002,w=right-left,h=.045,kind='select',row=r,index=index}
            local begin=left+(r.start-origin)/span*(right-left);local finish=left+(r.start+r.length-origin)/span*(right-left)
            local x,endX=math.max(left,begin),math.min(right,finish)
            if endX>x then
                local width=endX-x;JLRSMenu.rect(c,x,y,width,.041,r.enabled~=false and .065 or .07,on and .35 or .19,on and .46 or .29)
                local cells=math.max(1,math.min(12,math.floor(width/.045)))
                for cell=1,cells do
                    local cx=x+(cell-1)*width/cells;local cw=width/cells
                    JLRSMenu.rect(c,cx+.001,y+.002,math.max(.001,cw-.002),.037,.028,.068,.10)
                    thumbnail(c,v,cx+cw*.20,y+.009,cw*.6,.027)
                    for _,ey in ipairs({y+.002,y+.037})do for k=0,2 do JLRSMenu.rect(c,cx+.003+k*.004,ey,.002,.002,.43,.63,.7)end end
                end
                if width>.095 then JLRSMenu.text(x+.005,y+.002,.007,E.time(r.sourceIn)..' > '..E.time(r.sourceIn+r.length))end
                c.editingBarHits[#c.editingBarHits+1]={x=x,y=y,w=width,h=.041,kind='move',row=r,index=index}
                if begin>=left and begin<=right then JLRSMenu.rect(c,begin,y,.004,.041,.32,.81,.9);c.editingBarHits[#c.editingBarHits+1]={x=begin,y=y,w=.006,h=.041,kind='trimLeft',row=r,index=index}end
                if finish>=left and finish<=right then JLRSMenu.rect(c,finish-.004,y,.004,.041,.32,.81,.9);c.editingBarHits[#c.editingBarHits+1]={x=finish-.006,y=y,w=.006,h=.041,kind='trimRight',row=r,index=index}end
                if on then border(c,x,y,width,.041,.95,.68,.20)end
            end
        end
    end
    local px=left+(inspectTime(c)-origin)/span*(right-left)
    if px>=left and px<=right then JLRSMenu.rect(c,px,.178,.0015,.329,1,.4,.12)end
    button(c,.057,.135,.095,'TRACKS UP',function()c.editingOffset=math.max(0,(c.editingOffset or 0)-E.ROWS)end)
    button(c,.158,.135,.095,'TRACKS DOWN',function()c.editingOffset=math.min(math.max(0,#c.editingPlan.rows-E.ROWS),(c.editingOffset or 0)+E.ROWS)end)
    button(c,.265,.135,.105,'SAVE / APPLY',function()
        if c.editingSession then c.editingPreviewRunning=false;c:stop()end;E.apply(c)
    end,true)
    button(c,.377,.135,.105,'STOP PREVIEW',function()c.editingPreviewRunning=false;c:stop()end)
    button(c,.489,.135,.112,'EXPORT FINAL',function()E.exportFinal(c)end,true)
    button(c,.608,.135,.052,'CUT',function()E.split(c)end)
    button(c,.665,.135,.051,'DELETE',function()if selected then E.removeRow(c,c.editingSelected)end end)
    button(c,.723,.135,.106,'FINAL LIST',function()E.close(c);JLRSFinalList.open(c)end)
    button(c,.836,.135,.104,'CLOSE',function()E.close(c)end)
    JLRSMenu.text(.057,.105,.010,'Pilih Final | CUT = belah pada playhead | DELETE = hapus clip | drag clip / ujung = geser / trim')
    JLRSMenu.text(.057,.083,.009,(c.notice or ''):sub(1,125),1,.75,.35)
    JLRSMenu.text(.057,.063,.009,'©Copyright 2023 | Jupryan Lowlight',.65,.74,.83)
end
local drag=E.drag
E.drag=function(c,x)
    local d=c.editingDrag;if not d then return end
    if d.row then
        for i,row in ipairs(c.editingPlan.rows)do if row==d.row then E.select(c,i,not d.selectedOnce);d.selectedOnce=true;break end end
        if d.kind=='select'then return end
    end
    if d.kind=='playhead'then
        local t=c.editingTimeline;local time=math.max(0,math.min(E.duration(c.editingPlan),t.origin+(x-t.x)/t.w*t.span))
        c.editingSeekTime=time;c.editingPreviewRunning=false
        E.editorPreview(c,time,false);return
    end
    return drag(c,x)
end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,...)if c.editingOpen then return end;return tick(c,...)end
for _,method in ipairs({'mouseAxis','scroll'})do
    local previous=JLRSCamera[method]
    JLRSCamera[method]=function(c,...)if c.editingOpen then return end;return previous(c,...)end
end
local locked=JLRSInputGuard.isLocked
JLRSInputGuard.isLocked=function()if JLReplayStudio.editingOpen then return true end;return locked()end
local own=JLRSInputGuard.isOwn
JLRSInputGuard.isOwn=function(target,action)
    if JLReplayStudio.editingOpen then return target==JLReplayStudio or type(target)=='table' and target.controller==JLReplayStudio or type(action)=='string' and action:sub(1,5)=='JLRS_'end
    return own(target,action)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...);if c.editingOpen then E.hold(c)end;return result
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.editingPreviewRunning=false;c.editingCameraLock=nil;c.editingPreviewCamera=nil;c.editingRenderOverlay=nil;c.editingIcons={};c.editingIconOrder={};return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    E.releaseVisual(c);return deleteMap(c,...)
end
