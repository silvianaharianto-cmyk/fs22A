-- Optional ensemble playback. The stable single-vehicle cinematic path is
-- unchanged while LIVE DRIVE is OFF. Live tracks preserve native dynamic bodies
-- because FS22 continues updating wheel shapes while the world runs.
JLRSLive={}
-- Replay vehicles are temporarily detached from native physics. Keep body
-- types intact, and suspend only their updates to avoid stale wheel queries.
function JLRSLive.restorePhysics(track)
    for _,state in ipairs(track.livePhysics or {}) do
        for name,hook in pairs(state.hooks) do
            if state.vehicle[name]==hook.wrapper then state.vehicle[name]=hook.raw end
        end
    end
    for _,state in ipairs(track.livePhysics or {}) do
        if state.added and JLRSRecorder.valid(state.vehicle) then
            local ok,err=pcall(state.vehicle.addToPhysics,state.vehicle)
            if not ok then print('[J_L Cinema Studio] LIVE PHYSICS RESTORE: '..tostring(err)) end
        end
    end
    track.livePhysics=nil
end
function JLRSLive.detachPhysics(track)
    local vehicles=track.recordVehicles or {track.target}
    for _,v in ipairs(vehicles) do
        if type(v.removeFromPhysics)~='function' or type(v.addToPhysics)~='function' then
            track:notify('Live replay batal: fungsi physics native kendaraan tidak tersedia.');return false
        end
    end
    track.livePhysics={}
    local ok,err=pcall(function()
        for _,v in ipairs(vehicles) do
            local state={vehicle=v,added=v.isAddedToPhysics==true,hooks={}}
            track.livePhysics[#track.livePhysics+1]=state
            if state.added then v:removeFromPhysics() end
            for _,name in ipairs({'update','updateTick','updateInterpolation','updateEnd','addToPhysics'}) do
                if type(v[name])=='function' then
                    local hook={raw=rawget(v,name),wrapper=function() end}
                    state.hooks[name]=hook;v[name]=hook.wrapper
                end
            end
        end
    end)
    if not ok then
        JLRSLive.restorePhysics(track);track:notify('Live replay batal: '..tostring(err));return false
    end
    return true
end
-- Use the same native physics isolation for cinematic replay. Converting
-- bodies immediately after wheel recreation can race queued engine work.
local oldLockBodies=JLRSRecorder.lockBodies
JLRSRecorder.lockBodies=function(c)
    if c==JLReplayStudio then
        if c.livePhysics then return true end
        if not JLRSLive.detachPhysics(c) then return false end
        return true
    end
    return oldLockBodies(c)
end
local oldStopReplay=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    local result=oldStopReplay(track,...)
    if track.livePhysics then JLRSLive.restorePhysics(track) end
    return result
end
function JLRSLive.pinDriver(c,v)
    if not JLRSRecorder.valid(v) then return end
    local spec=v and v.spec_enterable
    if not spec then return end
    local pin=c.driverPins[v]
    if not pin then pin={spec=spec,disable=spec.disableCharacterOnLeave};c.driverPins[v]=pin end
    spec.disableCharacterOnLeave=false
    local character=spec.vehicleCharacter
    if character and type(character.setCharacterVisibility)=='function' then
        if pin.character~=character then
            if pin.character and pin.wrapper and pin.character.setCharacterVisibility==pin.wrapper then pin.character.setCharacterVisibility=pin.oldVisibility end
            pin.character=character;pin.oldVisibility=character.setCharacterVisibility
            pin.wrapper=function(self,visible,...)
                if c.liveDrive and c.driverPins[v] and g_currentMission.controlledVehicle~=v then visible=true end
                return pin.oldVisibility(self,visible,...)
            end
            character.setCharacterVisibility=pin.wrapper
        end
        if g_currentMission.controlledVehicle~=v then character:setCharacterVisibility(true) end
    end
end
function JLRSLive.releaseDrivers(c)
    for v,pin in pairs(c.driverPins or {}) do
        pin.spec.disableCharacterOnLeave=pin.disable
        if pin.character and pin.character.setCharacterVisibility==pin.wrapper then
            pin.character.setCharacterVisibility=pin.oldVisibility
            if JLRSRecorder.valid(v) and g_currentMission.controlledVehicle~=v then
                pin.character:setCharacterVisibility(false)
            end
        end
    end
    c.driverPins={}
end
function JLRSLive.hasVehicle(track,v)
    for _,vehicle in ipairs(track.recordVehicles or {}) do if vehicle==v then return true end end
    return track.target==v
end
function JLRSLive.stopTracks(c)
    for _,track in ipairs(c.liveTracks or {}) do JLRSRecorder.stopReplay(track) end
    c.liveTracks={};c.livePaused=false
end
function JLRSLive.resetClock(c)
    for _,track in ipairs(c.liveTracks) do
        track.changeWheelReplay=nil;track.allWheelReplay=nil
        track.replayTime=0;track.frameIndex=1;track.paused=false;track.lastBodyLog=-1
        JLRSRecorder.apply(track.entries,JLRSFrames.get(track.frames,1).pose)
    end
    c.livePaused=false
end
function JLRSLive.add(c)
    if c.recording then JLRSRecorder.stopRecord(c) end
    if JLRSFrames.count(c.frames)<2 or not JLRSRecorder.valid(c.target) or JLRSRecorder.capture(c.entries)==nil then
        c:notify('Replay live tidak tersedia: record/kendaraan tidak valid.');return
    end
    -- One track per physical vehicle/implement. Never let two recordings
    -- write competing poses to the same body.
    for i=#c.liveTracks,1,-1 do
        local track=c.liveTracks[i];local overlap=false
        for _,v in ipairs(c.recordVehicles or {}) do if JLRSLive.hasVehicle(track,v) then overlap=true end end
        if overlap then JLRSRecorder.stopReplay(track);table.remove(c.liveTracks,i) end
    end
    local track={target=c.target,entries=c.entries,frames=c.frames,recordVehicles=c.recordVehicles,
        duration=c.duration,replayTime=0,frameIndex=1,replaySpeed=c.replaySpeed,
        loop=c.loop,paused=false,replaying=false,active=false,lastBodyLog=-1,
        notify=function(_,message) c:notify(message) end}
    track.returnPose=JLRSRecorder.capture(track.entries)
    -- Native detach invalidates joints/wheels safely before pose playback.
    if not JLRSLive.detachPhysics(track) then return end
    track.bodyStates=nil
    track.replaying=true;c.liveTracks[#c.liveTracks+1]=track
    for _,v in ipairs(track.recordVehicles or {}) do JLRSLive.pinDriver(c,v) end
    JLRSLive.pinDriver(c,track.target)
    if not c.worldBatch then JLRSLive.resetClock(c) end
    c:notify(string.format('LIVE REPLAY | %d kendaraan replay | pindah ke kendaraan lain untuk mengemudi',#c.liveTracks))
end
function JLRSLive.toggle(c)
    if c.liveDrive then
        if c.recording then JLRSRecorder.stopRecord(c) end
        JLRSLive.stopTracks(c);JLRSLive.releaseDrivers(c)
        c.liveDrive=false;c.nativeShortcuts=true;c:notify('LIVE DRIVE OFF | mode cinematic normal')
    else
        c.liveDrive=true;c.nativeShortcuts=true
        if c.replaying then
            -- Restore the cinematic body handoff before allowing world updates.
            -- Then create a live track without any rigid-body type conversion.
            local time=c.replayTime;local paused=c.paused
            JLRSRecorder.stopReplay(c)
            JLRSLive.add(c)
            local track=c.liveTracks[#c.liveTracks]
            if track then
                track.replayTime=time;track.paused=paused;c.livePaused=paused
                JLRSRecorder.replayTick(track,0)
            end
        end
        if c.recording then JLRSLive.pinDriver(c,c.target) end
        c:notify('LIVE DRIVE ON | kamera & kontrol normal kendaraan kedua | shortcut asli ON')
    end
end
function JLRSLive.toggleKeys(c)
    if not c.liveDrive then c:notify('Aktifkan LIVE DRIVE untuk mengatur shortcut asli saat mengemudi.');return end
    c.nativeShortcuts=not c.nativeShortcuts
    c:notify('Shortcut asli FS22 : '..(c.nativeShortcuts and 'ON' or 'OFF | gas/rem/steer tetap aktif saat Live Drive'))
end
local oldLoad=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    oldLoad(c,...)
    if not c.mission then return end
    c.liveDrive=false;c.nativeShortcuts=true;c.liveTracks={};c.driverPins={};c.livePaused=false;c.liveClock=nil
    local hud=c.mission.hud
    if hud and type(hud.draw)=='function' then
        c.liveHud=hud;c.liveOldHudDraw=hud.draw
        c.liveHudWrapper=function(self,...)
            if c.liveDrive and #c.liveTracks>0 and c.shortcutHudHidden then return end
            return c.liveOldHudDraw(self,...)
        end
        hud.draw=c.liveHudWrapper
    end
end
local oldReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c==JLReplayStudio and c.liveDrive then return JLRSLive.add(c) end
    return oldReplay(c,...)
end
local oldStart=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c==JLReplayStudio and c.liveDrive then
        local live=g_currentMission.controlledVehicle
        for _,track in ipairs(c.liveTracks) do
            if JLRSLive.hasVehicle(track,live) then c:notify('Pilih kendaraan lain: kendaraan ini sedang direplay.');return end
        end
        -- Rewind existing tracks so the new take starts on the same timeline.
        JLRSLive.resetClock(c)
    end
    local result=oldStart(c,...)
    if c.liveDrive and c.recording then JLRSLive.pinDriver(c,c.target) end
    return result
end
local oldDraw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local now=g_time or 0;local dt=c.liveClock and math.max(0,(now-c.liveClock)/1000) or 0
    c.liveClock=now
    oldDraw(c,...)
    if not c.mission or not c.liveDrive then return end
    if g_gui and g_gui:getIsGuiVisible() then return end
    if c.mission.isPaused then return end
    for i=#c.liveTracks,1,-1 do
        local track=c.liveTracks[i]
        track.replaySpeed=c.replaySpeed;track.loop=c.loop
        local ended=track.replayTime>=track.duration and not track.loop
        track.paused=c.livePaused or ended
        JLRSRecorder.replayTick(track,dt)
        if not track.replaying then table.remove(c.liveTracks,i)
        else
            for _,v in ipairs(track.recordVehicles or {}) do JLRSLive.pinDriver(c,v) end
        end
    end
end
local oldPause=JLReplayStudio.togglePause
JLReplayStudio.togglePause=function(c,...)
    if c.liveDrive and #c.liveTracks>0 then
        c.livePaused=not c.livePaused;c:notify(c.livePaused and 'Semua live replay PAUSED' or 'Semua live replay PLAY');return
    end
    return oldPause(c,...)
end
local oldStop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    if c.liveDrive then JLRSLive.stopTracks(c);JLRSLive.releaseDrivers(c) end
    return oldStop(c,...)
end
local oldDelete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    JLRSLive.stopTracks(c);JLRSLive.releaseDrivers(c)
    if c.liveHud and c.liveHud.draw==c.liveHudWrapper then c.liveHud.draw=c.liveOldHudDraw end
    c.liveHud=nil;c.liveOldHudDraw=nil;c.liveHudWrapper=nil
    return oldDelete(c,...)
end
local oldGuard=JLRSInputGuard.isLocked
JLRSInputGuard.isLocked=function()
    local c=JLReplayStudio
    if c and c.mission and c.liveDrive then
        return (#c.liveTracks>0 and not c.nativeShortcuts) or JLRSShortcuts.reserved(c)
    end
    return oldGuard()
end
local oldOwn=JLRSInputGuard.isOwn
JLRSInputGuard.isOwn=function(target,action)
    local c=JLReplayStudio
    if c and c.liveDrive then
        -- Keep physical driving and on-foot movement available even with
        -- nonessential native shortcuts OFF. Mouse is already exempt.
        for _,name in ipairs({'AXIS_ACCELERATE_VEHICLE','AXIS_BRAKE_VEHICLE','AXIS_MOVE_SIDE_VEHICLE',
            'AXIS_MOVE_FORWARD_PLAYER','AXIS_MOVE_SIDE_PLAYER'}) do
            if action==name or (InputAction and action==InputAction[name]) then return true end
        end
    end
    return oldOwn(target,action)
end
local oldContext=JLRSShortcuts.context
JLRSShortcuts.context=function(c)
    if c.mission and c.liveDrive and #c.liveTracks>0 and not (g_gui and g_gui:getIsGuiVisible()) then return true end
    return oldContext(c)
end
local oldReserved=JLRSShortcuts.reserved
JLRSShortcuts.reserved=function(c)
    if c and c.mission and c.liveDrive and #c.liveTracks>0 then
        if Input.isKeyPressed(Input.KEY_space) or (c.shortcutKeys and c.shortcutKeys.pause) then return true end
    end
    return oldReserved(c)
end
local oldHistoryPlay=JLRSHistory.replay
JLRSHistory.replay=function(c,clip)
    oldHistoryPlay(c,clip)
    if c.liveDrive and #c.liveTracks>0 then JLRSHistory.close(c);c.menu=false;JLRSMouse.refresh(c) end
end
local oldHistoryDelete=JLRSHistory.delete
JLRSHistory.delete=function(c,clip)
    for i=#(c.liveTracks or {}),1,-1 do
        local track=c.liveTracks[i]
        if track.frames==clip.frames then JLRSRecorder.stopReplay(track);table.remove(c.liveTracks,i) end
    end
    return oldHistoryDelete(c,clip)
end
