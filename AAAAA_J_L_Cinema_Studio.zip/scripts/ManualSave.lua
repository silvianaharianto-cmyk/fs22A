-- Explicit combined checkpoint. No change to sampling, physics or replacement mapping.
JLRSManualSave={}
function JLRSManualSave.save(c,fromFinal)
    if c.recording or c.finalRecording or c.finalPlaying or c.replaying or #(c.liveTracks or {})>0 then
        c:notify('Stop Record / Replay dahulu sebelum Save.');return false
    end
    if c.changePending or c.changeTransaction or c.changeWorker or c.carsWorker then
        c:notify('Tunggu proses kendaraan selesai sebelum Save.');return false
    end
    JLRSPersist.load(c);JLRSFinal.load(c)
    if c.jlrsLoadPending or c.jlrsHistoryReadFailed or c.finalReadFailed or c.finalLoadPending then
        c:notify('Save gagal: data lama belum dapat dibaca; file asli tetap dipertahankan.');return false
    end
    -- Save History first: Final references those stable clip IDs and adapted streams.
    if not JLRSPersist.safeSave(c) then return false end
    local before=c.finalApplied
    if fromFinal and c.finalListOpen then
        local draft={};for k,v in pairs(c.finalDraft or {})do if v then draft[k]=true end end
        c.finalApplied=draft
    end
    if not JLRSFinal.save(c) then c.finalApplied=before;return false end
    if fromFinal then c.finalListReady=#JLRSFinalList.ids(c)>0 end
    c:notify('SAVE berhasil: History + Final | Save Game FS22 sebelum keluar agar kendaraan pengganti ikut tersimpan.')
    return true
end
