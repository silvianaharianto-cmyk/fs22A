JLReplayStudio={}
local modDirectory=g_currentModDirectory
function JLReplayStudio:notify(message)
    self.notice=message
    -- Keep HUD feedback; write only diagnostics to log.txt, not routine actions.
    local text=tostring(message);local lower=text:lower();local diagnostic=false
    for _,word in ipairs({'gagal','error','failed','unable','corrupt','denied','cannot','rusak','tidak dapat','belum tersimpan','diblokir','pemulihan','belum dimuat','pembersihan','tidak tersedia','dihentikan','access','disk penuh','folder'}) do
        if lower:find(word,1,true) then diagnostic=true;break end
    end
    if diagnostic then
        local now=g_time or 0
        if self.lastDiagnostic~=text or not self.lastDiagnosticTime or now<self.lastDiagnosticTime or now-self.lastDiagnosticTime>=5000 then
            print('[J_L Cinema Studio] '..text);self.lastDiagnostic=text;self.lastDiagnosticTime=now
        end
    end
end
function JLReplayStudio:loadMap()
    if g_dedicatedServer~=nil or (g_currentMission.missionDynamicInfo and g_currentMission.missionDynamicInfo.isMultiplayer) then return end
    self.mission=g_currentMission;self.frames={};self.entries={};self.recordVehicles={}
    self.recording=false;self.replaying=false;self.paused=false;self.menu=false;self.active=false
    self.duration=0;self.recordTime=0;self.replayTime=0;self.replaySpeed=1;self.loop=false
    self.mode=1;self.lock=false;self.distance=12;self.height=3;self.focusHeight=1.5
    self.amplitude=5;self.side=6;self.cameraSpeed=0.5;self.manualSpeed=6;self.sensitivity=0.5
    self.fov=55;self.motionFov=55;self.phase=0;self.keys={};self.keyState={};self.pendingRecordDt=0
    self.overlay=createImageOverlay(modDirectory..'white.dds');self.lastClock=nil
    local m=self.mission
    self.oldUpdate=m.update
    self.updateWrapper=function(mission,dt,...)
        local pauseWorld=self.timecodeRecordHold or (self.replaying and self.paused) or (self.liveDrive and self.livePaused and #(self.liveTracks or {})>0) or (self.editingSession and self.livePaused)
        if not pauseWorld then return self.oldUpdate(mission,dt,...) end
        -- Use the confirmed cinematic-freeze pause branch only inside update.
        -- Input continues outside it, and draw drives the replay clock.
        local previous=mission.isPaused;mission.isPaused=true
        local results={pcall(self.oldUpdate,mission,dt,...)}
        mission.isPaused=previous
        if not results[1] then error(results[2]) end
        return unpack(results,2)
    end
    m.update=self.updateWrapper
    self.oldMouse=m.mouseEvent
    self.mouseWrapper=function(mission,x,y,isDown,isUp,button,...)
        if g_gui and g_gui:getIsGuiVisible() then return self.oldMouse(mission,x,y,isDown,isUp,button,...) end
        if self.menu then JLRSMenu.click(self,x,y,isDown,button);return end
        -- Cinema wheel zoom must not also move the native gameplay camera.
        if JLRSScrollAudio and JLRSScrollAudio.wheel(self,button) then
            if isDown and not self.finalPlaying then JLRSCamera.scroll(self,button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1) end
            return
        end
        local result=self.oldMouse(mission,x,y,isDown,isUp,button,...)
        if self.active and isDown then
            if button==Input.MOUSE_BUTTON_WHEEL_UP then JLRSCamera.scroll(self,-1)
            elseif button==Input.MOUSE_BUTTON_WHEEL_DOWN then JLRSCamera.scroll(self,1) end
        end
        return result
    end
    m.mouseEvent=self.mouseWrapper
    self:notify('V1.6 siap | F6 menu | Record via HUD | 2 Replay')
end
function JLReplayStudio:toggleRecord()
    if self.recording then JLRSRecorder.stopRecord(self) else JLRSRecorder.start(self) end
end
function JLReplayStudio:togglePause()
    if self.replaying then self.paused=not self.paused;self:notify(self.paused and 'Replay PAUSED' or 'Replay RESUMED') end
end
function JLReplayStudio:stop()
    if self.recording then JLRSRecorder.stopRecord(self) end
    JLRSRecorder.stopReplay(self)
end
function JLReplayStudio:poll()
    local gui=g_gui and g_gui:getIsGuiVisible()
    local function edge(name)
        local key=Input[name];local down=key and Input.isKeyPressed(key) or false
        local old=self.keyState[name];self.keyState[name]=down
        return down and not old and not gui
    end
    local menu= edge('KEY_f6');local record=edge('KEY_KP_7');local replay=edge('KEY_KP_8')
    local pause=edge('KEY_KP_0');local stop=edge('KEY_BACKSPACE');local nextCamera=edge('KEY_f9')
    local lock=edge('KEY_l');local escape=edge('KEY_escape')
    if menu then JLRSMenu.toggle(self) end
    -- Record is started only from the main/mini HUD.
    if replay then JLRSRecorder.startReplay(self) end
    if pause then self:togglePause() end
    if stop then self:stop() end
    if nextCamera and self.replaying then JLRSCamera.choose(self,self.mode%#JLRSCamera.names+1) end
    if lock and self.replaying then JLRSCamera.toggleLock(self) end
    if escape and self.menu then JLRSMenu.toggle(self) end
end
function JLReplayStudio:update(dt)
    if self.recording then self.pendingRecordDt=self.pendingRecordDt+dt/1000 end
end
function JLReplayStudio:draw()
    if not self.mission then return end
    local now=g_time or 0
    local dt=self.lastClock and math.max(0,(now-self.lastClock)/1000) or 0
    self.lastClock=now
    self:poll();JLRSMouse.refresh(self)
    if g_gui and g_gui:getIsGuiVisible() then self.pendingRecordDt=0;return end
    if self.recording and not self.mission.isPaused then JLRSRecorder.recordTick(self,self.pendingRecordDt) end
    self.pendingRecordDt=0
    if self.replaying and not self.mission.isPaused then
        JLRSRecorder.replayTick(self,dt)
        -- EnsembleCamera draws after LiveDrive has updated every vehicle.
        -- Do not consume the once-per-frame camera tick on an old group target.
        if not self.groupCamera then JLRSCamera.tick(self,math.min(dt,0.1)) end
    end
    JLRSMenu.draw(self)
end
function JLReplayStudio:keyEvent(unicode,sym,modifier,isDown) end
function JLReplayStudio:mouseEvent(x,y,isDown,isUp,button) end
function JLReplayStudio:deleteMap()
    if not self.mission then return end
    self:stop();JLRSCamera.deactivate(self)
    if g_inputBinding then g_inputBinding:setShowMouseCursor(false) end
    if self.mission.update==self.updateWrapper then self.mission.update=self.oldUpdate end
    if self.mission.mouseEvent==self.mouseWrapper then self.mission.mouseEvent=self.oldMouse end
    if self.overlay then delete(self.overlay);self.overlay=nil end
    self.mission=nil;self.frames={}
end
-- Only block user driving actions while UI or replay owns the controls.
if Drivable then
    for _,name in ipairs({'actionEventAccelerate','actionEventBrake','actionEventSteer','actionEventCruiseControlState','actionEventCruiseControlValue'}) do
        local original=Drivable[name]
        if original then
            Drivable[name]=function(vehicle,...)
                if JLReplayStudio.menu or JLReplayStudio.replaying then return end
                return original(vehicle,...)
            end
        end
    end
end
addModEventListener(JLReplayStudio)
