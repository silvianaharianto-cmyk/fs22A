-- Interpolate tilted body orientations as a whole, including side/back flips.
-- Native quaternion conversions keep GIANTS' Euler convention. Endpoints,
-- wheel/audio/activity channels, translation and recorded data are untouched.
JLRSRotationContinuity={}
local R=JLRSRotationContinuity
-- FS22 does not require the newer mathQuaternionToEuler binding. Let the
-- native transform decode its own Euler convention, using one nonphysical node.
local function canDecode()
    return type(mathQuaternionToEuler)=='function' or
        (type(createTransformGroup)=='function' and type(setQuaternion)=='function'
        and type(getRotation)=='function' and type(delete)=='function')
end
function R.decode(q)
    if type(mathQuaternionToEuler)=='function' then
        return mathQuaternionToEuler(q[1],q[2],q[3],q[4])
    end
    if not R.decoder then R.decoder=createTransformGroup('jlrsReplayRotationDecoder')end
    setQuaternion(R.decoder,q[1],q[2],q[3],q[4])
    return getRotation(R.decoder)
end
function R.releaseDecoder()
    if R.decoder then delete(R.decoder);R.decoder=nil end
end
function R.interpolate(a,b,t)
    local dot=0;for i=1,4 do dot=dot+a[i]*b[i]end
    local sign=dot<0 and -1 or 1;dot=math.min(1,math.abs(dot))
    local x,y=1-t,t
    if dot<.9995 then local angle=math.acos(dot);local divisor=math.sin(angle);x=math.sin((1-t)*angle)/divisor;y=math.sin(t*angle)/divisor end
    local q={};local norm=0
    for i=1,4 do q[i]=a[i]*x+b[i]*y*sign;norm=norm+q[i]*q[i]end
    norm=math.sqrt(norm);for i=1,4 do q[i]=q[i]/norm end
    return q
end
-- Time-aware quaternion tangents make angular velocity continuous at keys.
-- All neighbour conversion/tangent work is cached with the current interval.
local function align(q,reference)
    local dot=0;for j=1,4 do dot=dot+q[j]*reference[j]end
    if dot<0 then for j=1,4 do q[j]=-q[j]end end
    return q
end
local function tangent(prev,q,next,hp,hn)
    local d1,d2={},{};local n1,n2,dot=0,0,0
    for j=1,4 do
        d1[j]=hp>0 and (q[j]-prev[j])/hp or (next[j]-q[j])/hn
        d2[j]=hn>0 and (next[j]-q[j])/hn or d1[j]
        n1=n1+d1[j]^2;n2=n2+d2[j]^2;dot=dot+d1[j]*d2[j]
    end
    local m={0,0,0,0};if dot<=0 then return m end
    local radial=0
    for j=1,4 do m[j]=hp>0 and hn>0 and (d1[j]*hn+d2[j]*hp)/(hp+hn)or (hp>0 and d1[j]or d2[j]);radial=radial+m[j]*q[j]end
    local norm=0;for j=1,4 do m[j]=m[j]-radial*q[j];norm=norm+m[j]^2 end
    local limit=2*math.sqrt(math.min(n1,n2));local scale=norm>0 and math.min(1,limit/math.sqrt(norm))or 1
    for j=1,4 do m[j]=m[j]*scale end
    return m
end
function R.cubic(ch,t)
    if not ch.ma then return R.interpolate(ch.a,ch.b,t)end
    local u=t*t;local v=u*t;local h1=2*v-3*u+1;local h2=-2*v+3*u;local h3=v-2*u+t;local h4=v-u
    local q={};local norm=0
    for j=1,4 do q[j]=h1*ch.a[j]+h2*ch.b[j]+ch.span*(h3*ch.ma[j]+h4*ch.mb[j]);norm=norm+q[j]^2 end
    if norm<1e-12 then return R.interpolate(ch.a,ch.b,t)end
    norm=math.sqrt(norm);for j=1,4 do q[j]=q[j]/norm end
    return q
end
local sample=JLRSRecorder.sample
JLRSRecorder.sample=function(track,time,...)
    local pose=sample(track,time,...)
    if not track.replaying or type(mathEulerToQuaternion)~='function' or not canDecode()then return pose end
    -- Audio/physics look-ahead can leave frameIndex on a different interval.
    -- SmoothRuntime can then return a cached pose without restoring frameIndex.
    -- Resolve rotation from its own time/frames, never from that mutable cursor.
    local count=JLRSFrames.count(track.frames)
    if count<2 then return pose end
    local interval=track.jlrsRotationInterval
    local i,a,b
    if interval and interval.frames==track.frames and interval.count==count
        and time>=interval.a.t and time<=interval.b.t then
        i,a,b=interval.index,interval.a,interval.b
    else
        i=math.max(1,math.min(count-1,track.frameIndex or 1))
        a=JLRSFrames.get(track.frames,i);b=JLRSFrames.get(track.frames,i+1)
        if time<a.t or time>b.t then
            local lo,hi=1,count-1
            while lo<=hi do
                local mid=math.floor((lo+hi)/2)
                local key=JLRSFrames.get(track.frames,mid)
                if key.t<=time then i=mid;lo=mid+1 else hi=mid-1 end
            end
            a=JLRSFrames.get(track.frames,i);b=JLRSFrames.get(track.frames,i+1)
        end
        track.jlrsRotationInterval={frames=track.frames,count=count,index=i,a=a,b=b}
    end
    if not a or not b or b.t<=a.t or time<=a.t or time>=b.t then return pose end
    local plan=track.jlrsRotationPlan
    if not plan or plan.a~=a or plan.b~=b or plan.entries~=track.entries then
        plan={a=a,b=b,entries=track.entries,channels={}};track.jlrsRotationPlan=plan
        for n,e in ipairs(track.entries or {})do if e.world then
            local o=(n-1)*6;local flip=false
            for j=4,6 do if math.abs(JLRSRecorder.angle(a.pose[o+j],b.pose[o+j],1)-a.pose[o+j])>1 then flip=true end end
            local tilted=math.abs(a.pose[o+4])>.05 or math.abs(a.pose[o+6])>.05
                or math.abs(b.pose[o+4])>.05 or math.abs(b.pose[o+6])>.05
            local changed=false
            for j=4,6 do if a.pose[o+j]~=b.pose[o+j]then changed=true;break end end
            if changed and (flip or tilted) then
                local qa={mathEulerToQuaternion(a.pose[o+4],a.pose[o+5],a.pose[o+6])};local qb={mathEulerToQuaternion(b.pose[o+4],b.pose[o+5],b.pose[o+6])}
                align(qb,qa)
                local ch={offset=o,a=qa,b=qb,span=b.t-a.t}
                local previous=JLRSFrames.get(track.frames,math.max(1,i-1))
                local following=JLRSFrames.get(track.frames,math.min(i+2,JLRSFrames.count(track.frames)))
                if previous.t<a.t or following.t>b.t then
                    local qp=previous.t<a.t and align({mathEulerToQuaternion(previous.pose[o+4],previous.pose[o+5],previous.pose[o+6])},qa)or qa
                    local qn=following.t>b.t and align({mathEulerToQuaternion(following.pose[o+4],following.pose[o+5],following.pose[o+6])},qb)or qb
                    ch.ma=tangent(qp,qa,qb,a.t-previous.t,ch.span)
                    ch.mb=tangent(qa,qb,qn,ch.span,following.t-b.t)
                end
                plan.channels[#plan.channels+1]=ch
            end
        end end
    end
    if #plan.channels==0 then return pose end
    local out={};for n,v in ipairs(pose)do out[n]=v end
    local alpha=(time-a.t)/(b.t-a.t)
    for _,ch in ipairs(plan.channels)do
        local q=R.cubic(ch,alpha)
        out[ch.offset+4],out[ch.offset+5],out[ch.offset+6]=R.decode(q)
    end
    return out
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(t,...)t.jlrsRotationPlan=nil;t.jlrsRotationInterval=nil;return stop(t,...)end

if JLReplayStudio and JLReplayStudio.deleteMap then
    local unload=JLReplayStudio.deleteMap
    JLReplayStudio.deleteMap=function(c,...)
        R.releaseDecoder()
        return unload(c,...)
    end
end
