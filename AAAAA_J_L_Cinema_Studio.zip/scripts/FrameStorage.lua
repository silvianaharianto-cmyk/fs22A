-- Bounded frame buffers backed by native FS22 XML chunks (no io dependency).
local jlrsModName=g_currentModName or (g_currentModDirectory or ""):gsub("[/\\]+$", ""):match("([^/\\]+)$")
if jlrsModName then jlrsModName=jlrsModName:gsub("%.zip$", "") end
JLRSFrames={CHUNK_VALUES=18000,MAX_CHUNK_FRAMES=120,CACHE_CHUNKS=4,stores={},nextId=0}
local decodeMemo=setmetatable({},{__mode="k"})
function JLRSFrames.count(frames) return frames and (frames._jlrs and frames._jlrs.count or #frames) or 0 end
function JLRSFrames.path(s,chunk) return JLRSFrames.directory..'take_'..s.id..'_'..chunk..'.xml' end
function JLRSFrames.manifest()
    local file=XMLFile.create('jlrsCacheIndex',JLRSFrames.directory..'index.xml','cache')
    if not file then error('Tidak dapat membuat index cache.') end
    local i=0
    for _,frames in pairs(JLRSFrames.stores) do
        local s=frames._jlrs
        if s and not s.released then
            local key='cache.stream('..i..')';file:setInt(key..'#id',s.id);file:setInt(key..'#chunks',s.sealed);i=i+1
        end
    end
    local result=file:save();file:delete()
    if result==false then error('Tidak dapat menulis index cache.') end
end
function JLRSFrames.prepare()
    if JLRSFrames.ready then return true end
    if not XMLFile or not XMLFile.create or not XMLFile.load or not getUserProfileAppPath or not createFolder then
        return false,'API cache XML FS22 tidak tersedia.'
    end
    local profile=getUserProfileAppPath()
    if not jlrsModName or not jlrsModName:match('^[%w_]+$') then return false,'Nama mod untuk izin folder tidak tersedia.' end
    local info=g_currentMission and g_currentMission.missionInfo or {}
    local slot=tonumber(info.savegameIndex or info.savegameId) or tonumber((info.savegameDirectory or ''):match('savegame(%d+)'))
    local base=profile..'modSettings/'..jlrsModName..'/'
    createFolder(base);createFolder(base..'recordCache/')
    JLRSFrames.directory=base..'recordCache/'..(slot and ('savegame'..slot) or 'unsaved')..'/'
    createFolder(JLRSFrames.directory)
    local ok,err=pcall(function()
        local probe=XMLFile.create('jlrsCacheProbe',JLRSFrames.directory..'probe.xml','cache')
        if not probe then error('Folder cache tidak dapat ditulis.') end
        probe:setString('cache#check','JLRS');local result=probe:save();probe:delete()
        if result==false then error('Penyimpanan cache gagal.') end
        local read=XMLFile.load('jlrsCacheProbeRead',JLRSFrames.directory..'probe.xml')
        if not read then error('Cache tidak dapat dibaca.') end
        local valid=read:getString('cache#check')=='JLRS';read:delete()
        if not valid then error('Verifikasi cache gagal.') end
        if deleteFile then deleteFile(JLRSFrames.directory..'probe.xml') end
        -- Permanent History owns old chunks. Never delete them at startup.

    end)
    if not ok then return false,tostring(err) end
    JLRSFrames.ready=true;return true
end
function JLRSFrames.new(values)
    local ok,err=JLRSFrames.prepare();if not ok then error(err) end
    JLRSFrames.nextId=JLRSFrames.nextId+1
    local frames={_jlrs={id=JLRSFrames.nextId,count=0,sealed=0,chunkSize=math.max(2,math.min(JLRSFrames.MAX_CHUNK_FRAMES,math.floor(JLRSFrames.CHUNK_VALUES/math.max(1,values)))),cache={},order={},bounds={}}}
    JLRSFrames.stores[frames._jlrs.id]=frames;return frames
end
-- Format each incoming frame once instead of formatting a full take chunk on one draw.
function JLRSFrames.encode(frame,state)
    local numbers=state and state.numberText or {}
    local previous=state and state.lastNumbers or {}
    if state then state.numberText=numbers;state.lastNumbers=previous end
    numbers[1]=string.format('%.17g',frame.t)
    local pose=frame.pose
    for j,v in ipairs(pose) do
        if previous[j]~=v then numbers[j+1]=string.format('%.17g',v);previous[j]=v end
    end
    for j=#numbers,#pose+2,-1 do numbers[j]=nil;previous[j-1]=nil end
    return table.concat(numbers,' ')
end
local function remember(s,chunk,data)
    s.cache[chunk]=data;s.order[#s.order+1]=chunk
    while #s.order>JLRSFrames.CACHE_CHUNKS do s.cache[table.remove(s.order,1)]=nil end
end
function JLRSFrames.flush(frames)
    local s=frames._jlrs;if not s or #frames==0 then return end
    local chunk=s.sealed+1;local path=JLRSFrames.path(s,chunk)
    local file=XMLFile.create('jlrsFrameChunk',path,'record')
    if not file then error('Tidak dapat membuat chunk record: '..path) end
    local ok,err=pcall(function()
        file:setInt('record#count',#frames)
        for i,frame in ipairs(frames) do
            file:setString('record.frame('..(i-1)..')#data',s.encoded and s.encoded[i] or JLRSFrames.encode(frame))
        end
        local result=file:save();if result==false then error('Disk penuh / cache tidak dapat ditulis.') end
    end)
    file:delete();if not ok then error(err) end
    local check=XMLFile.load('jlrsFrameChunkCheck',path)
    if not check then error('Chunk tidak dapat dibaca setelah disimpan.') end
    local valid=check:getInt('record#count')==#frames;check:delete()
    if not valid then error('Chunk cache tidak lengkap; buffer dipertahankan.') end
    s.sealed=chunk;s.bounds[chunk]={first=frames[1].t,last=frames[#frames].t,count=#frames}
    local okIndex,errIndex=pcall(JLRSFrames.manifest)
    if not okIndex then s.sealed=chunk-1;s.bounds[chunk]=nil;if deleteFile then deleteFile(path) end;error(errIndex) end
    -- Recently recorded frames are already decoded: retain them in the bounded replay cache.
    local data={};for i,frame in ipairs(frames) do data[i]=frame end
    remember(s,chunk,data);s.encoded={}
    for i=#frames,1,-1 do frames[i]=nil end
end
function JLRSFrames.push(frames,frame)
    local s=frames._jlrs
    if not s then frames[#frames+1]=frame;return end
    if #frames>=s.chunkSize then JLRSFrames.flush(frames) end
    s.encoded=s.encoded or {};s.encoded[#frames+1]=JLRSFrames.encode(frame,s)
    frames[#frames+1]=frame;s.count=s.count+1
end
-- Exact decoder: unchanged token memo hits no longer rewrite two large tables.
-- Decode the timestamp separately instead of branching for it for every value.
function JLRSFrames.decode(text,s,target)
    local words=text:gmatch('%S+')
    local time=tonumber(words());if not time then error('Waktu cache tidak valid.')end
    local memo=decodeMemo[s]
    if not memo then memo={tokens={},values={},ready=false};decodeMemo[s]=memo end
    local tokens,values=memo.tokens,memo.values
    local numbers=target and target.pose or {};local previousWidth=#numbers;local offset,hits=0,0
    for word in words do
        offset=offset+1
        if tokens and tokens[offset]==word then
            numbers[offset]=values[offset];hits=hits+1
        else
            local n=tonumber(word);if not n then error('Nilai cache tidak valid.')end
            numbers[offset]=n
            if tokens then tokens[offset]=word;values[offset]=n end
        end
    end
    if tokens and memo.ready and hits<(offset+1)/8 then memo.tokens=nil;memo.values=nil end
    memo.ready=true
    for i=previousWidth,offset+1,-1 do numbers[i]=nil end
    if target then target.t=time;target.pose=numbers;return target end
    return {t=time,pose=numbers}
end
local function loadChunk(s,chunk)
    local data=s.cache[chunk]
    if data then return data end
    local file=XMLFile.load('jlrsFrameChunkRead',JLRSFrames.path(s,chunk))
    if not file then error('Chunk record hilang / tidak dapat dibaca.') end
    data={encoded={}}
    local ok,err=pcall(function()
        local count=file:getInt('record#count',0)
        if count~=s.chunkSize then error('Jumlah frame cache tidak cocok.') end
        for i=1,count do
            local value=file:getString('record.frame('..(i-1)..')#data')
            if not value then error('Data frame cache tidak lengkap.') end
            data.encoded[i]=value
        end
    end)
    file:delete();if not ok then error(err) end
    remember(s,chunk,data);return data
end
-- Header-only search: do not decode thousands of activity values merely to
-- compare timestamps during a seek. Generic get() keeps its immutable contract.
function JLRSFrames.time(frames,index)
    local s=frames and frames._jlrs
    if not s or index>s.sealed*s.chunkSize then
        local frame=JLRSFrames.get(frames,index);return frame and frame.t
    end
    if s.released then error('Cache record sudah dilepas.') end
    if index<1 or index>s.count then return nil end
    local chunk=math.floor((index-1)/s.chunkSize)+1;local i=(index-1)%s.chunkSize+1
    if s.pending and s.pending[chunk] then
        local frame=JLRSFrames.get(frames,index);return frame and frame.t
    end
    local data=loadChunk(s,chunk)
    if data[i] then return data[i].t end
    data.times=data.times or {}
    local t=data.times[i]
    if t==nil then
        t=tonumber(data.encoded[i]:match('^%s*(%S+)'))
        if not t then error('Waktu cache tidak valid.') end
        data.times[i]=t
    end
    return t
end
-- Caller-owned scratch frame only. It is NEVER inserted into shared caches or
-- recording tables; readers holding ordinary get() frames cannot see mutations.
function JLRSFrames.readInto(frames,index,target,share)
    local s=frames and frames._jlrs
    if s and s.released then error('Cache record sudah dilepas.') end
    if index<1 or index>JLRSFrames.count(frames) then return nil end
    local frame
    if s and index<=s.sealed*s.chunkSize then
        local chunk=math.floor((index-1)/s.chunkSize)+1;local i=(index-1)%s.chunkSize+1
        if s.pending and s.pending[chunk] then frame=JLRSFrames.get(frames,index)
        else
            local data=loadChunk(s,chunk)
            if not data[i] then return JLRSFrames.decode(data.encoded[i],s,target) end
            frame=data[i]
        end
    else frame=JLRSFrames.get(frames,index) end
    -- An existing immutable shared frame needs neither a copy nor a second decode.
    if share then
        if getmetatable(frame) then return JLRSFrames.get(frames,index) end
        return frame
    end
    local pose=frame.pose;local out=target.pose or {};local width=#out
    for i=1,#pose do out[i]=pose[i] end
    for i=width,#pose+1,-1 do out[i]=nil end
    target.t=frame.t;target.pose=out;return target
end
function JLRSFrames.get(frames,index)
    local s=frames and frames._jlrs
    if not s then return frames and frames[index] end
    if s.released then error('Cache record sudah dilepas.') end
    if index<1 or index>s.count then return nil end
    local sealedCount=s.sealed*s.chunkSize
    if index>sealedCount then return frames[index-sealedCount] end
    local chunk=math.floor((index-1)/s.chunkSize)+1;local localIndex=(index-1)%s.chunkSize+1
    local data=loadChunk(s,chunk)
    if not data[localIndex] then
        local decoded=JLRSFrames.decode(data.encoded[localIndex],s)
        data[localIndex]=decoded
        if JLReplayStudio and not JLReplayStudio.recording and (JLReplayStudio.finalPlaying or JLReplayStudio.replaying
            or #(JLReplayStudio.liveTracks or {})>0)and #decoded.pose>=4096 then
            -- Avoid releasing an entire 18-frame, 9480-value numeric chunk in
            -- one render. Retain at most eight decoded large keys per stream.
            -- Keep their immutable XML text in the existing bounded chunk cache
            -- for exact backward seeks. Never mutate an evicted frame/pose.
            local ring=s.finalDecoded or {slot=0};s.finalDecoded=ring
            local slot=ring.slot%8+1;ring.slot=slot
            local old=ring[slot]
            if old then
                local cached=s.cache[old.chunk]
                if cached and cached[old.index]==old.frame then cached[old.index]=nil end
            end
            ring[slot]={chunk=chunk,index=localIndex,frame=decoded}
        else data.encoded[localIndex]=nil end
    end
    return data[localIndex]
end
function JLRSFrames.release(frames)
    local s=frames and frames._jlrs;if not s or s.released then return end
    if not s.persistent and deleteFile then
        for i=1,s.sealed do deleteFile(JLRSFrames.path(s,i)) end
        deleteFile(JLRSFrames.directory.."take_"..s.id.."_tail.xml")
    end
    decodeMemo[s]=nil;s.finalDecoded=nil
    s.released=true;s.cache={};s.order={};s.encoded=nil;s.lastNumbers=nil;s.numberText=nil;JLRSFrames.stores[s.id]=nil
    for i=#frames,1,-1 do frames[i]=nil end
end
function JLRSFrames.cleanup()
    local list={};for _,frames in pairs(JLRSFrames.stores) do list[#list+1]=frames end
    for _,frames in ipairs(list) do JLRSFrames.release(frames) end
    if JLRSFrames.directory and deleteFile then deleteFile(JLRSFrames.directory..'index.xml') end
    JLRSFrames.ready=false;JLRSFrames.nextId=0;JLRSFrames.indexDirty=nil
end
