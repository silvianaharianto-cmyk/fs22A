JLRSAngle={shots={
    {'Kanan Mobil',-1,0,0},{'Depan Mobil',0,0,1},{'Kiri Mobil',1,0,0},
    {'Depan Samping Kanan',-0.7071,0,0.7071},{'Depan Samping Kiri',0.7071,0,0.7071},
    {'Belakang Samping Kanan',-0.7071,0,-0.7071},{'Belakang Samping Kiri',0.7071,0,-0.7071},
    {'Atas Mobil',0,1,0.05}}}
function JLRSAngle.ensureCamera(c)
    if not c.active and c.liveDrive and #(c.liveTracks or {})>0 then
        local mode=c.mode
        JLRSGroup.camera(c)
        -- Group camera defaults to Free; preserve the selected movement.
        if c.active then JLRSCamera.choose(c,mode) end
    end
    return c.active
end
function JLRSAngle.target(c) return c.groupCamera and c.cameraTarget or c.target end
function JLRSAngle.saved(c)
    local target=JLRSAngle.target(c)
    return c.angleMemory and c.angleMemory[target] and c.angleMemory[target][c.angleIndex or 1]
end
function JLRSAngle.save(c)
    local target=JLRSAngle.target(c)
    if not c.angleEnabled or not c.active or not JLRSRecorder.valid(target) then return end
    local tx,ty,tz=JLRSCamera.focus(c)
    local x,y,z=worldDirectionToLocal(target.rootNode,c.x-tx,c.y-ty,c.z-tz)
    local _,yaw=getWorldRotation(target.rootNode)
    if c.mode~=8 then
        local fx,_,fz=localDirectionToWorld(target.rootNode,0,0,1);yaw=math.atan2(fx,fz)
        local dx,dz=c.x-tx,c.z-tz
        x=math.cos(yaw)*dx-math.sin(yaw)*dz;y=c.y-ty;z=math.sin(yaw)*dx+math.cos(yaw)*dz
    end
    c.angleMemory=c.angleMemory or {};c.angleMemory[target]=c.angleMemory[target] or {}
    c.angleMemory[target][c.angleIndex or 1]={x=x,y=y,z=z,yaw=c.yaw-yaw,pitch=c.pitch,
        distance=c.distance,height=c.height,fov=c.motionFov or c.fov}
end
function JLRSAngle.vector(c,distance,height,phase)
    local shot=JLRSAngle.shots[c.angleIndex or 1]
    local x,y,z=shot[2]*distance,shot[3]*distance+height,shot[4]*distance
    local saved=JLRSAngle.saved(c)
    if saved then
        local scale=distance/math.max(0.001,saved.distance)
        x=saved.x*scale;y=saved.y+height-saved.height;z=saved.z*scale
    end
    if phase then
        local a,b=x,z;x=a*math.cos(phase)+b*math.sin(phase);z=b*math.cos(phase)-a*math.sin(phase)
    end
    if c.mode==8 then return localDirectionToWorld(JLRSAngle.target(c).rootNode,x,y,z) end
    return JLRSCamera.levelOffset(c,x,y,z)
end
function JLRSAngle.place(c)
    if not c.angleEnabled or not JLRSRecorder.valid(JLRSAngle.target(c)) then return end
    local memory=JLRSAngle.saved(c)
    if memory then c.distance=memory.distance;c.height=memory.height end
    local x,y,z=JLRSCamera.focus(c)
    local dx,dy,dz=JLRSAngle.vector(c,c.distance,c.height)
    c.phase=0;c.manualX=0;c.manualY=0;c.manualZ=0;c.offsetYaw=0;c.offsetPitch=0
    c.x=x+dx;c.y=y+dy;c.z=z+dz
    c.yaw=math.atan2(dx,dz);c.pitch=math.max(-1.5,math.min(1.5,math.atan2(-dy,math.sqrt(dx*dx+dz*dz))))
    local saved=JLRSAngle.saved(c)
    if saved then
        local _,yaw=getWorldRotation(JLRSAngle.target(c).rootNode)
        c.yaw=yaw+saved.yaw;c.pitch=saved.pitch;c.fov=saved.fov;c.motionFov=c.fov
    end
    c.fixedX=c.x;c.fixedY=c.y;c.fixedZ=c.z;c.panYaw=c.yaw;c.anchorPitch=c.pitch;c.roll=0
    if c.active and c.camera then
        setTranslation(c.camera,c.x,c.y,c.z);setRotation(c.camera,c.pitch,c.yaw,0);setCamera(c.camera)
    end
end
function JLRSAngle.random(c)
    if not c.angleEnabled or not JLRSAngle.ensureCamera(c) then return end
    JLRSAngle.save(c)
    local previous=c.angleIndex;local index=math.random(1,#JLRSAngle.shots-1)
    if previous and index>=previous then index=index+1 elseif not previous then index=math.random(1,#JLRSAngle.shots) end
    c.angleIndex=index;JLRSCamera.choose(c,c.mode)
    c:notify('Angle: '..JLRSAngle.shots[index][1]..' | '..JLRSCamera.names[c.mode])
end
function JLRSAngle.toggle(c)
    if c.angleEnabled then JLRSAngle.save(c) end
    c.angleStable=nil;c.angleMoveGoal=nil
    c.angleEnabled=not c.angleEnabled
    if c.angleEnabled then c.angleIndex=c.angleIndex or 1;JLRSAngle.ensureCamera(c);JLRSAngle.place(c) end
    c:notify('CAMERA ANGLE '..(c.angleEnabled and 'ON | R = random cut' or 'OFF | E = turun'))
end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,index,...)
    -- Capture the rendered pose before changing movement; never save the
    -- outgoing angle under the incoming index (random already saves it).
    if c.angleEnabled and c.active and index~=c.mode then JLRSAngle.save(c) end
    if c.angleEnabled then JLRSAngle.ensureCamera(c) end
    local result=choose(c,index,...);JLRSAngle.place(c)
    if c.active and c.camera then
        setTranslation(c.camera,c.x,c.y,c.z);setRotation(c.camera,c.pitch,c.yaw,0)
        setFovY(c.camera,math.rad(c.fov));setCamera(c.camera)
    end
    c.angleCutPending=true
    return result
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local held=Input.KEY_r and Input.isKeyPressed(Input.KEY_r) or false
    local edge=held and not c.angleR;c.angleR=held
    if edge and c.angleEnabled and not c.menu and not (g_gui and g_gui:getIsGuiVisible()) then JLRSAngle.random(c) end
    return draw(c,...)
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    load(c,...);c.angleEnabled=false;c.angleIndex=nil;c.angleR=false;c.angleMemory={}
end

local replay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    local result=replay(c,...)
    if c==JLReplayStudio and c.angleEnabled then JLRSAngle.ensureCamera(c) end
    return result
end

-- Stabilize the rendered camera between angle cuts. Never interpolate a cut.
local stableChoose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)
    c.angleStable=nil;c.angleMoveGoal=nil
    local result=stableChoose(c,...)
    if c.active and c.angleEnabled then
        c.angleStable={x=c.x,y=c.y,z=c.z,pitch=c.pitch,yaw=c.yaw,target=JLRSAngle.target(c)}
    end
    return result
end
local stableTick=JLRSCamera.tick
JLRSCamera.tick=function(c,dt)
    -- Render every preset against the current target frame, like Tracking.
    -- Lagged world-space position blending makes the subject drift relative to
    -- the camera and feeds a delayed pose back into mouse/manual state.
    stableTick(c,dt)
    c.angleMoveGoal=nil;c.angleCutPending=nil
    if c.active and c.angleEnabled then
        c.angleStable={x=c.x,y=c.y,z=c.z,pitch=c.pitch,yaw=c.yaw,target=JLRSAngle.target(c)}
    else c.angleStable=nil end
end
local stableDeactivate=JLRSCamera.deactivate
JLRSCamera.deactivate=function(c,...)
    c.angleStable=nil;c.angleMoveGoal=nil;return stableDeactivate(c,...)
end
