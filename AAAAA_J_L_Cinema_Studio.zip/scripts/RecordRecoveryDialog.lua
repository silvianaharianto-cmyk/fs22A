-- Opt-in catalog reload. No per-frame file scans, cache deletion, file copying,
-- frame synthesis, playback changes or automatic saves during recovery.
JLRSRecordRecovery={}
local R=JLRSRecordRecovery
local nativeNotify=JLReplayStudio.notify
local function copy(t)local out={};for k,v in pairs(t or {})do out[k]=v end;return out end
local function busy(c)
    return c.recording or c.replaying or #(c.liveTracks or {})>0 or c.finalRecording
        or c.finalPlaying or c.historyRepair or c.changePending or c.finalCacheJob
end
local function merge(restored,existing)
    local out,seen={},{}
    for _,list in ipairs({restored or {},existing or {}})do
        for _,item in ipairs(list)do if not seen[item.id]then seen[item.id]=true;out[#out+1]=item end end
    end
    return out
end
function R.request(c,reason,manual)
    if R.running or not c.mission or c.recoveryUnloading then return end
    if c.recoveryPrompt or c.recoveryJob or c.recoveryDialog then return end
    reason=tostring(reason or 'Rekaman tidak ditemukan.')
    if (c.recoverySeen or {})[reason] and not manual then return end
    c.recoveryPrompt=reason;c.recoveryLastProblem=reason
end
local function result(c,text)
    nativeNotify(c,text);c.recoveryInfo=text
end
function R.run(c)
    if busy(c)then result(c,'Recovery ditunda. Stop Record dan semua Replay dahulu, lalu buka daftar kembali.');return end
    local before=copy(c);local revision=JLRSPersist.revision
    R.running=true
    local ok,why=pcall(function()
        c.history={};c.jlrsRecovery=nil;c.jlrsPrimaryDamaged=nil
        c.jlrsHistoryReadFailed=false;c.jlrsLoadPending=true
        JLRSPersist.load(c)
        -- A restored folder can contain only the History recovery pair.
        if not c.jlrsLoadPending and #c.history==0 and not c.jlrsRecovery then
            c.jlrsRecovery=true;c.jlrsLoadPending=true;JLRSPersist.load(c)
        end
        c.finalTakes={};c.finalApplied={};c.finalDraft={};c.finalSelected=0
        c.finalLoadPending=true;c.finalReadFailed=false;c.finalLoadError=nil
        c.finalCatalogSaved=false;c.finalCatalogPrefix='final_';c.finalRevision=0
        JLRSFinal.load(c)
        if c.jlrsLoadPending or c.finalLoadPending then error('Folder cache belum dapat dibaca.')end
        local histories,finals=#c.history,#c.finalTakes
        if histories==0 and finals==0 then error(c.finalLoadError or 'Tidak ada katalog dan frame cadangan yang dapat dimuat.')end
        if histories>0 then
            c.history=merge(c.history,before.history)
            for _,clip in ipairs(c.history)do c.historyNextId=math.max(c.historyNextId or 0,clip.id)end
        else
            c.history=before.history;c.historyNextId=before.historyNextId
            c.jlrsRecovery=before.jlrsRecovery;c.jlrsPrimaryDamaged=before.jlrsPrimaryDamaged
            c.jlrsHistoryReadFailed=before.jlrsHistoryReadFailed;JLRSPersist.revision=revision
        end
        if finals>0 then
            c.finalTakes=merge(c.finalTakes,before.finalTakes)
            for _,take in ipairs(c.finalTakes)do
                if (before.finalApplied or {})[take.id]then c.finalApplied[take.id]=true end
                c.finalNextId=math.max(c.finalNextId or 1,take.id+1)
            end
            c.finalDraft=copy(c.finalApplied);c.finalSelected=math.min(math.max(1,before.finalSelected or 1),#c.finalTakes)
            c.finalListReady=#JLRSFinalList.ids(c)>0
        else
            for _,key in ipairs({'finalTakes','finalApplied','finalDraft','finalSelected','finalNextId',
                'finalListReady','finalCatalogSaved','finalCatalogPrefix','finalRevision','finalReadFailed','finalLoadError'})do c[key]=before[key]end
        end
        c.hitboxes={};c.historyDrag=nil;c.historyScrollDrag=nil
        c.recoveryResult='Recovery selesai: '..histories..' History dan '..finals..' Final dimuat. '
            ..'File asli tidak diubah. Frame yang terhapus tetap memerlukan backup.'
    end)
    R.running=nil
    if not ok then
        for key in pairs(c)do c[key]=nil end
        for key,value in pairs(before)do c[key]=value end
        JLRSPersist.revision=revision
        result(c,'Recovery belum berhasil. '..tostring(why):sub(1,220)
            ..' Kembalikan backup ke folder savegame cache yang sama saat FS22 ditutup. Data saat ini tetap dipertahankan.')
    else result(c,c.recoveryResult);c.recoveryResult=nil;c.recoveryLastProblem=nil end
end
local notify=JLReplayStudio.notify
JLReplayStudio.notify=function(c,message,...)
    local text=tostring(message or '')
    if R.running then return end
    if text:find('cache / data tidak dapat dibaca',1,true)
        or text:find('Chunk record',1,true) or text:find('File akhir History hilang',1,true)
        or text:find('History lama tidak lengkap',1,true)
        or text:find('History pemulihan juga tidak dapat dibaca',1,true)
        or text:find('Final memakai penyimpanan pemulihan',1,true)
        or text:find('Replay Final gagal: History #',1,true)
        or text=='Belum ada Record Final.' or text=='Belum ada rekaman yang dapat di-replay.'
        or text:find('Record tidak tersedia:',1,true)then R.request(c,text)end
    return notify(c,message,...)
end
local historyLoad=JLRSPersist.load
JLRSPersist.load=function(c,...)
    local pending=c.jlrsLoadPending;local value=historyLoad(c,...)
    if pending and not c.jlrsLoadPending and (c.jlrsHistoryReadFailed or c.jlrsPrimaryDamaged)then
        R.request(c,'Sebagian data History tidak dapat dimuat. Coba recovery dari katalog cadangan?')
    end
    return value
end
local finalLoad=JLRSFinal.load
JLRSFinal.load=function(c,...)
    local pending=c.finalLoadPending;local value=finalLoad(c,...)
    if pending and not c.finalLoadPending and (c.finalReadFailed or c.finalLoadError)then
        R.request(c,'Sebagian Record Final tidak dapat dimuat. Coba recovery dari katalog cadangan?')
    end
    return value
end
local historyOpen=JLRSHistory.open
JLRSHistory.open=function(c,...)
    local value=historyOpen(c,...)
    if #(c.history or {})==0 then R.request(c,'Daftar History kosong atau rekaman tidak ditemukan. Coba recovery?',true)
    elseif c.recoveryLastProblem then R.request(c,c.recoveryLastProblem,true)end
    return value
end
local finalOpen=JLRSFinalList.open
JLRSFinalList.open=function(c,...)
    local value=finalOpen(c,...)
    if #(c.finalTakes or {})==0 then R.request(c,'Daftar Record Final kosong atau rekaman tidak ditemukan. Coba recovery?',true)
    elseif c.recoveryLastProblem then R.request(c,c.recoveryLastProblem,true)end
    return value
end
local update=JLReplayStudio.update
JLReplayStudio.update=function(c,...)
    local value=update(c,...)
    if not c.mission or c.recoveryUnloading or (g_gui and g_gui:getIsGuiVisible())then return value end
    if c.recoveryJob then c.recoveryJob=nil;R.run(c);return value end
    if c.recoveryInfo and g_gui and type(g_gui.showInfoDialog)=='function'then
        local text=c.recoveryInfo;c.recoveryInfo=nil;g_gui:showInfoDialog({text=text,okText='OK'});return value
    end
    if not c.recoveryPrompt or busy(c)then return value end
    local reason=c.recoveryPrompt;c.recoveryPrompt=nil
    c.recoverySeen=c.recoverySeen or {};c.recoverySeen[reason]=true
    if not g_gui or type(g_gui.showYesNoDialog)~='function'then
        nativeNotify(c,'Recovery tersedia. Buka daftar kembali saat dialog game tersedia.');return value
    end
    local mission=c.mission;c.recoveryDialog=true
    local ok=pcall(g_gui.showYesNoDialog,g_gui,{title='J_L Cinema Studio | Recovery',yesText='OK',noText='Batal',
        text=reason..'\n\nKlik OK untuk memuat ulang katalog History dan Final yang tersedia. '
            ..'Tidak menghapus file. Jika belum pernah merekam, pilih Batal.',
        callback=function(yes)
            if c.mission~=mission or c.recoveryUnloading then return end
            c.recoveryDialog=nil
            if yes then c.recoveryJob=true end
        end})
    if not ok then c.recoveryDialog=nil;nativeNotify(c,'Dialog Recovery belum tersedia; buka daftar untuk mencoba kembali.')end
    return value
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    c.recoveryPrompt=nil;c.recoverySeen=nil;c.recoveryDialog=nil;c.recoveryJob=nil;c.recoveryInfo=nil;c.recoveryUnloading=nil;c.recoveryLastProblem=nil
    return load(c,...)
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    c.recoveryUnloading=true;c.recoveryPrompt=nil;c.recoveryJob=nil;c.recoveryInfo=nil
    return unload(c,...)
end
