-- Visual swatch audition on the selected map vehicle. Native configuration IDs
-- stay unchanged until Apply; Back/Close restore every uncommitted group.
JLRSColorMapPanel={}
local L=JLRSColorMapPanel
local C=JLRSColorCars
local P=JLRSColorPreview
function L.restore(c)
    local session=c.colorCarsLive
    if session and JLRSRecorder.valid(session.vehicle)then
        for name,group in pairs(session.dirty)do
            local ok=pcall(C.paint,session.vehicle,group,session.original[name])
            if not ok then c:notify('Gagal mengembalikan preview warna kendaraan.')end
        end
    end
    c.colorCarsLive=nil
end
function L.choose(c,color)
    local session=c.colorCarsLive;local group=(c.colorCarsGroups or {})[c.colorCarsGroup or 1]
    if not session or not group or not JLRSRecorder.valid(session.vehicle)then return end
    if c.changePending or c.changeWorker or c.carsWorker then return end
    local ok=pcall(C.paint,session.vehicle,group,color)
    session.dirty[group.name]=group
    if ok then c.colorCarsChoice=color;c.colorCarsMessage=nil
    else pcall(C.paint,session.vehicle,group,session.original[group.name]);c.colorCarsChoice=nil;c.colorCarsMessage='Preview warna tidak dapat diterapkan.'end
end
function L.back(c)
    L.restore(c);c.colorCarsPanel=false;c.colorCarsTarget=nil;c.colorCarsGroups={};c.colorCarsChoice=nil
    C.items(c);JLRSMouse.syncCursor(c)
end
local select=C.select
C.select=function(c,v,...)
    L.restore(c);local result=select(c,v,...)
    if c.colorCarsTarget==v then
        local session={vehicle=v,original={},dirty={}}
        for _,group in ipairs(c.colorCarsGroups or {})do session.original[group.name]=C.snapshot and C.snapshot(v,group)or (v.configurations or {})[group.name]or 1 end
        c.colorCarsLive=session;c.colorCarsPanel=true
    end
    return result
end
local apply=C.apply
C.apply=function(c,...)
    local result=apply(c,...)
    local session=c.colorCarsLive;local group=(c.colorCarsGroups or {})[c.colorCarsGroup or 1]
    if result and session and group then session.original[group.name]=C.snapshot and C.snapshot(session.vehicle,group)or session.vehicle.configurations[group.name];session.dirty[group.name]=nil end
    return result
end
local close=C.close
C.close=function(c,...)L.restore(c);c.colorCarsPanel=false;return close(c,...)end
local open=C.open
C.open=function(c,...)L.restore(c);c.colorCarsPanel=false;return open(c,...)end
local choose=P.choose
P.choose=function(c,color)if c.colorCarsPanel then return L.choose(c,color)end;return choose(c,color)end
function L.draw(c)
    if not JLRSRecorder.valid(c.colorCarsTarget)then L.back(c);return C.draw(c)end
    c.hitboxes={}
    JLRSMenu.rect(c,.755,.17,.23,.64,.015,.023,.037,.96)
    JLRSMenu.rect(c,.755,.73,.23,.08,.025,.16,.23)
    JLRSMenu.text(.768,.771,.017,'Change Color Cars')
    JLRSMenu.text(.768,.741,.011,C.name(c.colorCarsTarget):sub(1,28))
    JLRSMenu.text(.768,.696,.009,'Klik warna: preview langsung di map')
    local list=c.colorCarsGroups or {};local group=list[c.colorCarsGroup or 1]
    if group then
        local function change(d)
            local session=c.colorCarsLive
            if session.dirty[group.name]then pcall(C.paint,session.vehicle,group,session.original[group.name]);session.dirty[group.name]=nil end
            c.colorCarsGroup=((c.colorCarsGroup or 1)-1+d)%#list+1;c.colorCarsColorOffset=0;c.colorCarsChoice=nil
        end
        JLRSMenu.button(c,.768,.646,.028,.032,'<',function()change(-1)end)
        JLRSMenu.text(.808,.657,.011,group.label..' ('..c.colorCarsGroup..'/'..#list..')')
        JLRSMenu.button(c,.945,.646,.028,.032,'>',function()change(1)end)
        for index=1,C.COLORS do
            local color=group.colors[(c.colorCarsColorOffset or 0)+index]
            if color then
                local x=.769+((index-1)%6)*.034;local y=.579-math.floor((index-1)/6)*.059
                JLRSMenu.rect(c,x-.002,y-.003,.032,.049,c.colorCarsChoice==color and 1 or .12,.16,.20)
                JLRSMenu.button(c,x,y,.028,.043,'',function()L.choose(c,color)end,c.colorCarsChoice==color,color.rgb)
            end
        end
        JLRSMenu.button(c,.768,.393,.096,.032,'COLORS <',function()C.scroll(c,-1,true)end)
        JLRSMenu.button(c,.877,.393,.096,.032,'COLORS >',function()C.scroll(c,1,true)end)
        JLRSMenu.button(c,.768,.345,.205,.032,'CUSTOM COLOR',function()C.custom(c)end)
        JLRSMenu.text(.768,.328,.009,c.colorCarsChoice and c.colorCarsChoice.name:sub(1,29)or 'Pilih warna')
    else
        JLRSMenu.text(.768,.58,.010,'Kendaraan ini tidak memiliki')
        JLRSMenu.text(.768,.55,.010,'konfigurasi warna yang didukung.')
    end
    JLRSMenu.text(.768,.319,.009,(c.colorCarsMessage or ''):sub(1,31))
    JLRSMenu.button(c,.768,.260,.205,.04,'APPLY',function()C.apply(c)end,c.colorCarsChoice~=nil)
    JLRSMenu.button(c,.768,.204,.205,.04,'KEMBALI',function()L.back(c)end)
end
local draw=C.draw
C.draw=function(c,...)
    if c.colorCarsPanel then return L.draw(c)end
    return draw(c,...)
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)L.restore(c);c.colorCarsPanel=false;return deleteMap(c,...)end
