-- Lifecycle/error handling around the unchanged V1.13.1 feature chain.
JLRSUnlimited={}
function JLRSUnlimited.prune(c)
    local keep={}
    local function frames(f)
        if f then keep[f]=true;if f.jlrsActivities and f.jlrsActivities.frames then keep[f.jlrsActivities.frames]=true end end
    end
    local function scene(s) if s then for _,e in ipairs(s.entries or {}) do frames(e.samples) end end end
    frames(c.frames);scene(c.worldRecord)
    for _,clip in ipairs(c.history or {}) do
        frames(clip.frames);scene(clip.worldScene)
        for _,g in ipairs(clip.saved and clip.saved.groups or {}) do for _,e in ipairs(g.entries) do frames(e.samples) end end
    end
    for _,track in ipairs(c.liveTracks or {}) do frames(track.frames);if track.cargoReplay then scene(track.cargoReplay.scene) end end
    if c.worldReplay then scene(c.worldReplay.scene) end
    local remove={};for _,f in pairs(JLRSFrames.stores) do if not keep[f] then remove[#remove+1]=f end end
    for _,f in ipairs(remove) do JLRSFrames.release(f) end
    if JLRSFrames.ready then local ok,err=pcall(JLRSFrames.manifest);if not ok then print('[J_L Cinema Studio] CACHE INDEX: '..tostring(err)) end end
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c~=JLReplayStudio then return start(c,...) end
    local ok,err=JLRSFrames.prepare()
    if not ok then c:notify('Record belum dimulai: '..tostring(err));return end
    local result=start(c,...);JLRSUnlimited.prune(c);return result
end
local stopRecord=JLRSRecorder.stopRecord
function JLRSUnlimited.recover(c,err)
    c.cacheFault=tostring(err)
    local count=JLRSFrames.count(c.frames)
    local scene=c.worldRecord
    -- Only keep the timeline for which both vehicle and world samples completed.
    if scene and #scene.entries>0 and scene.sampleCount<count then
        count=scene.sampleCount
        if c.frames._jlrs then c.frames._jlrs.count=count end
    end
    if count>0 then
        local frame=JLRSFrames.get(c.frames,count)
        c.recordTime=frame.t;c.previousPose=frame.pose;c.recording=true
        stopRecord(c)
    else c.recording=false end
    c:notify('Record dihentikan karena cache tidak dapat ditulis; hasil tersedia di History. '..tostring(err))
end
JLRSRecorder.stopRecord=function(c,...)
    if c~=JLReplayStudio then return stopRecord(c,...) end
    local ok,result=pcall(stopRecord,c,...)
    if ok then return result end
    JLRSUnlimited.recover(c,result)
end
local tick=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,...)
    if c~=JLReplayStudio then return tick(c,...) end
    local ok,result=pcall(tick,c,...)
    if ok then return result end
    JLRSUnlimited.recover(c,result)
end
local remove=JLRSHistory.delete
JLRSHistory.delete=function(c,clip,...)
    local result=remove(c,clip,...)
    if c.worldRecord==clip.worldScene and JLRSFrames.count(c.frames)==0 then c.worldRecord=nil end
    JLRSUnlimited.prune(c);return result
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local ok,err=pcall(draw,c,...)
    if ok then return err end
    if c.replaying or #(c.liveTracks or {})>0 then c:stop() end
    c:notify('Replay berhenti: cache / data tidak dapat dibaca. '..tostring(err))
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    JLRSFrames.cleanup();return load(c,...)
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=deleteMap(c,...);JLRSFrames.cleanup();return result
end
