JLRSWorld={}
-- Native cargo tables cover fastened/dynamically mounted vehicles. A downward
-- support ray covers loose vehicles on a transporter. Called only at boundaries.
function JLRSWorld.isCargo(object,carriers)
    if not JLRSRecorder.valid(object) or not object.components then return false end
    for _,carrier in ipairs(carriers or {}) do
        if carrier~=object and JLRSRecorder.valid(carrier) then
            local mount=carrier.spec_dynamicMountAttacher
            if mount and mount.dynamicMountedObjects then
                for key,value in pairs(mount.dynamicMountedObjects) do
                    if key==object or value==object then return true end
                end
            end
            local belts=carrier.spec_tensionBelts
            for _,data in pairs(belts and belts.objectsToJoint or {}) do
                if type(data)=='table' and data.object==object then return true end
            end
        end
    end
    if type(raycastAll)~='function' or type(worldToLocal)~='function' then return false end
    local x,y,z=getWorldTranslation(object.rootNode)
    for _,carrier in ipairs(carriers or {}) do
        if carrier~=object and JLRSRecorder.valid(carrier) then
            local lx,ly,lz=worldToLocal(carrier.rootNode,x,y,z)
            local size=carrier.size or {}
            if ly>0.2 and ly<8 and math.abs(lx-(size.widthOffset or 0))<=(size.width or 3)/2+0.5
                and math.abs(lz-(size.lengthOffset or 0))<=(size.length or 8)/2+0.5 then
                local probe={distance=math.huge,hit=false}
                function probe:cargoSupportHit(node,hx,hy,hz,distance)
                    local owner=g_currentMission.getNodeObject and g_currentMission:getNodeObject(node)
                        or (g_currentMission.nodeToObject or {})[node]
                    local belongs=false;local current=node
                    -- Resolve collision shapes without requiring a nodeToObject entry per shape.
                    for depth=1,16 do
                        if not current or current==0 or not entityExists(current) then break end
                        if current==object.rootNode then owner=object;break end
                        for _,comp in ipairs(object.components) do if current==comp.node then owner=object;break end end
                        if owner==object then break end
                        if current==carrier.rootNode then belongs=true;break end
                        for _,comp in ipairs(carrier.components or {}) do if current==comp.node then belongs=true;break end end
                        if belongs then break end
                        current=getParent(current)
                    end
                    if owner~=object and distance<self.distance then
                        self.distance=distance;self.hit=belongs or owner==carrier
                    end
                    return true
                end
                local ok=pcall(raycastAll,x,y+2,z,0,-1,0,'cargoSupportHit',12,probe,nil,false,false)
                if ok and probe.hit then return true end
            end
        end
    end
    return false
end
function JLRSWorld.isTrain(v)
    return type(v)=='table' and (v.trainSystem~=nil or v.spec_train~=nil or v.spec_locomotive~=nil or v.isTrain==true)
end
function JLRSWorld.vehicleSet()
    local vehicles={}
    local function add(v)
        if type(v)=='table' and not JLRSWorld.isTrain(v) and JLRSRecorder.valid(v) then vehicles[v]=true end
    end
    local mission=g_currentMission or {}
    for _,v in pairs(mission.vehicles or {}) do add(v) end
    -- Support Lua traffic providers without scanning unrelated map objects.
    local traffic=mission.trafficSystem
    for _,list in ipairs({traffic and traffic.vehicles or {},traffic and traffic.trafficVehicles or {},mission.npcVehicles or {}}) do
        if type(list)=='table' then for key,value in pairs(list) do add(value);if type(key)=='table' then add(key) end end end
    end
    return vehicles
end
function JLRSWorld.collect(c)
    local groups,seen,primary={},{},{}
    local vehicles=JLRSWorld.vehicleSet()
    for _,e in ipairs(c.entries) do primary[e.node]=true end
    local function add(object)
        if type(object)~='table' or seen[object] then return end
        -- Map trains have shared joints managed by TrainSystem, not independent vehicle bodies.
        if JLRSWorld.isTrain(object) or not vehicles[object] then return end
        seen[object]=true
        local cargo=JLRSWorld.isCargo(object,c.recordVehicles)
        local vehicle=vehicles[object] or cargo
        local entries={}
        if object.components then
            for index,comp in ipairs(object.components) do
                local node=comp.node
                if node and entityExists(node) and not primary[node]
                    and (getRigidBodyType(node)==RigidBodyType.DYNAMIC or getRigidBodyType(node)==RigidBodyType.KINEMATIC
                        or (vehicle and getRigidBodyType(node)==RigidBodyType.NONE)) then
                    entries[#entries+1]={node=node,world=true,parent=getParent(node),vehicle=vehicle and object or nil,componentIndex=index}
                end
            end
        else
            local node=object.nodeId or object.rootNode
            if node and node~=0 and entityExists(node) and not primary[node]
                and (getRigidBodyType(node)==RigidBodyType.DYNAMIC or getRigidBodyType(node)==RigidBodyType.KINEMATIC) then
                entries[1]={node=node,world=true,parent=getParent(node)}
            end
        end
        if vehicle and object.components then
            local bodyNodes={};for _,entry in ipairs(entries) do bodyNodes[entry.node]=true end
            local topology=JLRSRecorder.topology(object)
            for _,entry in ipairs(topology) do
                if not entry.world and not primary[entry.node] and not bodyNodes[entry.node] then
                    bodyNodes[entry.node]=true;entries[#entries+1]=entry
                end
            end
        end
        if #entries>0 then groups[#groups+1]={object=object,entries=entries,vehicle=object.components~=nil,cargo=cargo} end
    end
    for object in pairs(vehicles) do add(object) end
    local entries={}
    for _,group in ipairs(groups) do
        group.first=#entries+1
        for _,entry in ipairs(group.entries) do entries[#entries+1]=entry end
    end
    return {groups=groups,entries=entries,sampleCount=0,duration=0,previousSampleTime=0}
end
function JLRSWorld.capture(scene)
    local pose=scene.captureBuffer or {};local offset=0
    local optimized=JLReplayStudio.antiLag~=false
    local changing=optimized and (scene.changeBuffer or {}) or nil
    if changing then for i=#changing,1,-1 do changing[i]=nil end;scene.changeBuffer=changing end
    local previous=scene.previousPose
    for _,e in ipairs(scene.entries) do
        local p=e.lastPose
        local probe=not e.prop or not scene.independentProps and (not p or e.propProbe==scene.propEpoch or (e.propMovingUntil or 0)>(scene.captureTime or 0))
        if probe and entityExists(e.node) and getParent(e.node)==e.parent then
            local previous
            if e.prop and p then previous=e.propPreviousPose or {};e.propPreviousPose=previous;for j=1,6 do previous[j]=p[j]end end
            p=p or {};if e.world then
                p[1],p[2],p[3]=getWorldTranslation(e.node);p[4],p[5],p[6]=getWorldRotation(e.node)
            else p[1],p[2],p[3]=getTranslation(e.node);p[4],p[5],p[6]=getRotation(e.node) end
            if e.prop and previous then
                local moved=false;for j=1,6 do if math.abs(p[j]-previous[j])>=0.00001 then moved=true;break end end
                if moved then e.propMovingUntil=(scene.captureTime or 0)+0.5
                else for j=1,6 do p[j]=previous[j]end end
            end
            e.lastPose=p
        end
        p=p or {0,0,0,0,0,0}
        local changed=false
        for j=1,6 do
            local value=p[j];pose[offset+j]=value
            if changing and e.recordedPose and ((previous and previous[offset+j]~=value) or value~=e.recordedPose[j])then changed=true end
        end
        if changed then changing[#changing+1]=offset/6+1 end
        offset=offset+6
    end
    for i=#pose,offset+1,-1 do pose[i]=nil end
    return pose
end
function JLRSWorld.initialize(scene)
    local pose=JLRSWorld.capture(scene)
    for i,e in ipairs(scene.entries) do
        local n=(i-1)*6;local p={};for j=1,6 do p[j]=pose[n+j] end
        e.objectPivot=e.prop and e.world and JLRSWorld.propPivot(e)or nil
        e.samples=JLRSFrames.new(6);JLRSFrames.push(e.samples,{t=0,pose=p})
        e.recordedPose=p;e.sampleIndex=1
    end
    scene.previousPose=pose;scene.captureBuffer={};scene.previousTime=0;scene.sampleCount=1;scene.duration=0
end
function JLRSWorld.fill(c)
    local scene=c.worldRecord
    if not scene or c.cacheFault then return end
    local now=c.recordTime
    if now<=(scene.previousTime or 0) and scene.sampleCount>=JLRSFrames.count(c.frames) then return end
    scene.captureTime=now
    local current=JLRSWorld.capture(scene)
    local previous=scene.previousPose or current;local previousTime=scene.previousTime or 0
    local changing=JLReplayStudio.antiLag~=false and scene.changeBuffer or nil
    if not changing then
        changing={}
        for ei,e in ipairs(scene.entries) do
            local n=(ei-1)*6
            for j=1,6 do
                if previous[n+j]~=current[n+j] or current[n+j]~=e.recordedPose[j] then changing[#changing+1]=ei;break end
            end
        end
    end
    for i=scene.sampleCount+1,JLRSFrames.count(c.frames) do
        local time=JLRSFrames.get(c.frames,i).t
        local alpha=now>previousTime and math.max(0,math.min(1,(time-previousTime)/(now-previousTime))) or 1
        for _,ei in ipairs(changing) do
            local e=scene.entries[ei]
            if not (e.prop and scene.independentProps) then
            local n=(ei-1)*6;local p={};local changed=false
            for j=1,6 do
                if j<=3 then p[j]=previous[n+j]+(current[n+j]-previous[n+j])*alpha
                else p[j]=JLRSRecorder.angle(previous[n+j],current[n+j],alpha) end
                if p[j]~=e.recordedPose[j] then changed=true end
            end
            if e.prop and alpha>0 and alpha<1 and JLRSWorld.blendCapturedObject then
                JLRSWorld.blendCapturedObject(previous,current,n,alpha,p,e.objectPivot)
                changed=false;for j=1,6 do if p[j]~=e.recordedPose[j]then changed=true;break end end
            end
            if changed then
                local last=JLRSFrames.get(e.samples,JLRSFrames.count(e.samples))
                -- A long idle interval must stay idle, not interpolate early.
                if last.t<scene.previousSampleTime-0.000001 then
                    JLRSFrames.push(e.samples,{t=scene.previousSampleTime,pose=e.recordedPose})
                end
                JLRSFrames.push(e.samples,{t=time,pose=p});e.recordedPose=p
            end
        end
        end
        scene.previousSampleTime=time;scene.sampleCount=i;scene.duration=time
    end
    scene.previousPose=current;scene.captureBuffer=previous;scene.previousTime=now
end
function JLRSWorld.release(state)
    local object=state.group.object
    for name,hook in pairs(state.hooks or {}) do if object[name]==hook.wrapper then object[name]=hook.raw end end
    if state.vehicleTrack then
        if JLRSWheelVisual then JLRSWheelVisual.clear(state.vehicleTrack) end
        state.vehicleTrack.replaying=false;JLRSLive.restorePhysics(state.vehicleTrack)
    elseif state.removed then
        for _,e in ipairs(state.group.entries) do if entityExists(e.node) then addToPhysics(e.node) end end
    end
end
function JLRSWorld.releaseReplay(replay)
    if not replay then return end
    for _,state in ipairs(replay.states) do
        if state.returnPose then
            local entries,pose={},{}
            for i,e in ipairs(state.group.entries) do
                if entityExists(e.node) then
                    local body=getRigidBodyType(e.node)
                    if body~=RigidBodyType.STATIC and (body~=RigidBodyType.NONE or state.vehicleTrack or state.visualOnly or (state.group.prop and JLRSProps and JLRSProps.isPallet(state.group.object))) then
                        entries[#entries+1]=e
                        for j=1,6 do pose[#pose+1]=state.returnPose[(i-1)*6+j] end
                    end
                end
            end
            if #entries>0 then
                    -- Scene vehicles have their own isolated owner, outside the
                    -- main-track guard. Avoid native vehicle reposition work.
                    local track=state.vehicleTrack
                    JLRSRecorder.apply(entries,pose,true,track and track.livePhysics and not track.collisionReplay)
                end
        end
        JLRSWorld.release(state)
    end
end
function JLRSWorld.stop(c)
    JLRSWorld.releaseReplay(c.worldReplay);c.worldReplay=nil
end
-- Only hand unrecorded, parked scene vehicles to Live Drive. Selecting a
-- vehicle with a recorded path must not release precision replay ownership.
function JLRSWorld.hasRecordedTravel(group)
    for _,entry in ipairs(group.entries) do
        if entry.world and JLRSFrames.count(entry.samples)>1 then return true end
    end
    return false
end
function JLRSWorld.allowLiveHandoff(c,group,cargo,hasTravel)
    if cargo or group.object~=g_currentMission.controlledVehicle then return false end
    if c.recording then return true end
    if not c.liveDrive then return false end
    if not c.preciseReplay then return true end
    return not hasTravel
end
function JLRSWorld.start(c,scene,owner,cargoOnly)
    if cargoOnly then JLRSWorld.releaseReplay(owner.cargoReplay);owner.cargoReplay=nil
    else JLRSWorld.stop(c) end
    if not scene or scene.sampleCount<2 then return end
    local exclude={}
    for _,e in ipairs(c.entries or {}) do exclude[e.node]=true end
    for _,track in ipairs(c.liveTracks or {}) do
        for _,e in ipairs(track.entries) do exclude[e.node]=true end
        for _,state in ipairs(track.cargoReplay and track.cargoReplay.states or {}) do
            for _,e in ipairs(state.group.entries) do exclude[e.node]=true end
        end
    end
    local replay={scene=scene,owner=owner,states={}}
    if cargoOnly then owner.cargoReplay=replay else c.worldReplay=replay end
    local vehicles=JLRSWorld.vehicleSet()
    -- Resolve source-model provenance once, including legacy catalogs which
    -- kept the converted sparse rows but omitted the group replacement flag.
    local donors={}
    for _,ch in ipairs(owner and owner.frames and owner.frames.jlrsActivities and owner.frames.jlrsActivities.schema or {})do
        if ch.owner and ch.config and ch.config~=''then donors[ch.owner]=ch.config end
    end
    local skipped=0
    for _,group in ipairs(scene.groups) do
        local cargo=group.cargo or JLRSWorld.isCargo(group.object,owner and owner.recordVehicles or c.recordVehicles)
        local overlap=(not vehicles[group.object] and not (JLRSProps and JLRSProps.safeGroup(group))) or JLRSWorld.isTrain(group.object)
            or JLRSWorld.allowLiveHandoff(c,group,cargo,JLRSWorld.hasRecordedTravel(group))
        -- Legacy History can contain transform roots of buildings (body NONE).
        -- A components table is not proof that the object is an FS22 vehicle.
        local vehicle=vehicles[group.object] or cargo
        for _,e in ipairs(group.entries) do
            if exclude[e.node] or not entityExists(e.node) then overlap=true
            else
                local body=getRigidBodyType(e.node)
                if body==RigidBodyType.STATIC or (body==RigidBodyType.NONE and e.world and not vehicle and not (JLRSPhysicsPlaceable and JLRSPhysicsPlaceable.isEntry(e))) then overlap=true end
            end
        end
        if overlap then skipped=skipped+1 end
        if not overlap and (not cargoOnly or cargo or group.prop) then
            local state={group=group,cargo=cargo,hasRecordedTravel=JLRSWorld.hasRecordedTravel(group),hooks={},returnPose=JLRSRecorder.capture(group.entries)}
            if state.returnPose then
                state.stationary=true
                for _,e in ipairs(group.entries) do if JLRSFrames.count(e.samples)>1 then state.stationary=false;break end end
                state.contexts={}
                for ei,e in ipairs(group.entries) do state.contexts[ei]={frames=e.samples,frameIndex=e.sampleIndex,objectPivot=group.prop and e.world and JLRSWorld.propPivot(e)or nil} end
                replay.states[#replay.states+1]=state
                if group.prop and JLRSProps then
                    if not JLRSProps.attach(state) then state.returnPose=nil end
                elseif vehicle and group.object.components then
                    local track={worldPoseReplay=true,entries=group.entries,recordVehicles={group.object},target=group.object,notify=function(_,s)c:notify(s)end}
                    local id=group.object.jlrsPersistentId
                    local remapped=group.remapReload or (id and donors[id] and donors[id]~=(group.object.configFileName or group.object.xmlFilename or ''))
                    for _,entry in ipairs(group.entries)do
                        if id and (entry.samples.jlrsRemappedOwners or {})[id]then remapped=true end
                    end
                    if remapped and id and not cargo then
                        -- Keep the evidence with the stream so Save/reload no
                        -- longer depends on retaining an older A/B catalog.
                        for _,entry in ipairs(group.entries)do
                            entry.samples.jlrsRemapped=true
                            entry.samples.jlrsRemappedOwners=entry.samples.jlrsRemappedOwners or {}
                            entry.samples.jlrsRemappedOwners[id]=true
                        end
                        local pose={}
                        for _,e in ipairs(group.entries)do
                            local first=JLRSFrames.get(e.samples,1)
                            for j=1,6 do pose[#pose+1]=first.pose[j]end
                        end
                        track.frames={{t=0,pose=pose}}
                        track.frames.jlrsRemapReloadOwners={[id]=true}
                        track.frames.jlrsActivities={schema={{owner=id,config=group.object.configFileName or group.object.xmlFilename or ''}}}
                    end
                    -- Force native isolation for scene playback, independent of collision mode.
                    local enabled=c.physicsReplay;c.physicsReplay=false
                    local ok=JLRSLive.detachPhysics(track);c.physicsReplay=enabled
                    if ok then state.vehicleTrack=track else state.returnPose=nil end
                elseif type(removeFromPhysics)=='function' and type(addToPhysics)=='function' then
                    for _,e in ipairs(group.entries) do removeFromPhysics(e.node) end
                    state.removed=true
                    for _,name in ipairs({'update','updateTick','updateInterpolation'}) do
                        if type(group.object[name])=='function' then
                            local hook={raw=rawget(group.object,name),wrapper=function()end};state.hooks[name]=hook;group.object[name]=hook.wrapper
                        end
                    end
                else state.returnPose=nil end
            end
        end
    end
    JLRSWorld.tick(c,0,replay)
    if not cargoOnly then c:notify('WORLD REPLAY | '..#replay.states..' objek | posisi awal dipulihkan') end
end
-- Six-channel sparse object sampler: reuse output without touching stored poses.
-- Keep a cached interval for high-FPS playback between the same recorded keys.
-- Tumbling props need full orientation interpolation, not three independent
-- Euler angles. Cache quaternion conversion once per source interval.
function JLRSWorld.rotatePivotValues(x,y,z,w,p)
    local tx=2*(y*p[3]-z*p[2]);local ty=2*(z*p[1]-x*p[3]);local tz=2*(x*p[2]-y*p[1])
    return p[1]+w*tx+y*tz-z*ty,p[2]+w*ty+z*tx-x*tz,p[3]+w*tz+x*ty-y*tx
end
function JLRSWorld.rotatePivot(q,p)return JLRSWorld.rotatePivotValues(q[1],q[2],q[3],q[4],p)end
function JLRSWorld.propPivot(entry)
    if entry.objectPivot~=nil then return entry.objectPivot or nil end
    entry.objectPivot=false
    if type(getCenterOfMass)~='function'or not mathEulerToQuaternion or not localToWorld then return end
    if not entityExists(entry.node)or getRigidBodyType(entry.node)~=RigidBodyType.DYNAMIC then return end
    local ok,x,y,z=pcall(getCenterOfMass,entry.node)
    if not ok or type(x)~='number'or type(y)~='number'or type(z)~='number' then return end
    if x~=x or y~=y or z~=z then return end
    -- Convert the local COM lever through the actual node scale once. Quaternion
    -- interpolation then operates on its world-oriented, scale-correct lever.
    local wx,wy,wz=localToWorld(entry.node,x,y,z)
    local px,py,pz=getWorldTranslation(entry.node)
    local q={mathEulerToQuaternion(getWorldRotation(entry.node))}
    local pivot={JLRSWorld.rotatePivot({-q[1],-q[2],-q[3],q[4]},{wx-px,wy-py,wz-pz})}
    if pivot[1]^2+pivot[2]^2+pivot[3]^2<1e-12 then return end
    entry.objectPivot=pivot;return pivot
end
local function objectRotation(context,a,b,time,out)
    local key=time<=a.t and a or (time>=b.t and b or nil)
    if key then for j=1,6 do out[j]=key.pose[j]end;return out end
    if not mathEulerToQuaternion or not mathQuaternionToEuler or b.t<=a.t then return out end
    local pair=context.objectRotationPair
    if not pair or pair.a~=a or pair.b~=b then
        pair=pair or {};pair.a=a;pair.b=b;pair.q=nil;pair.r=nil;pair.angle=nil;pair.sine=nil;pair.centerA=nil;pair.centerB=nil;context.objectRotationPair=pair
        local ap,bp=a.pose,b.pose
        local q={mathEulerToQuaternion(ap[4],ap[5],ap[6])}
        local r={mathEulerToQuaternion(bp[4],bp[5],bp[6])}
        local qn=math.sqrt(q[1]^2+q[2]^2+q[3]^2+q[4]^2)
        local rn=math.sqrt(r[1]^2+r[2]^2+r[3]^2+r[4]^2)
        if qn>1e-12 and rn>1e-12 then
            for j=1,4 do q[j]=q[j]/qn;r[j]=r[j]/rn end
            pair.q=q;pair.r=r
            pair.dot=math.max(-1,math.min(1,q[1]*r[1]+q[2]*r[2]+q[3]*r[3]+q[4]*r[4]))
            if math.abs(pair.dot)<.9995 then
                pair.angle=math.acos(math.abs(pair.dot));pair.sine=math.sin(pair.angle)
            end
        end
    end
    if not pair.q or time<=a.t or time>=b.t then return out end
    local alpha=(time-a.t)/(b.t-a.t);local dot=math.min(1,math.abs(pair.dot))
    local u,v=1-alpha,alpha
    if pair.angle then u=math.sin((1-alpha)*pair.angle)/pair.sine;v=math.sin(alpha*pair.angle)/pair.sine end
    local q,r=pair.q,pair.r;local sign=pair.dot<0 and -1 or 1
    local x,y,z,w=q[1]*u+r[1]*v*sign,q[2]*u+r[2]*v*sign,q[3]*u+r[3]*v*sign,q[4]*u+r[4]*v*sign
    local inv=1/math.sqrt(x*x+y*y+z*z+w*w)
    local pivot=context.objectPivot
    if pivot then
        if not pair.centerA then
            pair.centerA={JLRSWorld.rotatePivot(pair.q,pivot)}
            pair.centerB={JLRSWorld.rotatePivot(pair.r,pivot)}
        end
        local ox,oy,oz=JLRSWorld.rotatePivotValues(x*inv,y*inv,z*inv,w*inv,pivot)
        local ap,bp=a.pose,b.pose
        out[1]=ap[1]+pair.centerA[1]+(bp[1]+pair.centerB[1]-ap[1]-pair.centerA[1])*alpha-ox
        out[2]=ap[2]+pair.centerA[2]+(bp[2]+pair.centerB[2]-ap[2]-pair.centerA[2])*alpha-oy
        out[3]=ap[3]+pair.centerA[3]+(bp[3]+pair.centerB[3]-ap[3]-pair.centerA[3])*alpha-oz
    end
    out[4],out[5],out[6]=mathQuaternionToEuler(x*inv,y*inv,z*inv,w*inv)
    return out
end
-- Only resampled physics props use quaternion interpolation during capture.
-- Replay interpolation cannot repair an Euler-branch error already written to disk.
function JLRSWorld.blendCapturedObject(previous,current,n,alpha,out,pivot)
    if not mathEulerToQuaternion or not mathQuaternionToEuler then return out end
    local a={t=0,pose={}};local b={t=1,pose={}}
    for j=1,6 do a.pose[j]=previous[n+j];b.pose[j]=current[n+j]end
    return objectRotation({objectPivot=pivot},a,b,alpha,out)
end
function JLRSWorld.sampleObject(context,time)
    local a,b=context.objectA,context.objectB
    if not a or time<a.t or time>b.t then
        local sampled=JLRSRecorder.sample(context,time)
        local i=context.frameIndex or 1
        a=JLRSFrames.get(context.frames,i)
        b=JLRSFrames.get(context.frames,math.min(i+1,JLRSFrames.count(context.frames)))
        context.objectA=a;context.objectB=b
        local out=context.objectBuffer or {};context.objectBuffer=out
        for j=1,6 do out[j]=sampled[j] end
        return objectRotation(context,a,b,time,out)
    end
    local alpha=b.t>a.t and math.max(0,math.min(1,(time-a.t)/(b.t-a.t))) or 0
    local out=context.objectBuffer
    for j=1,6 do
        if j<=3 then out[j]=a.pose[j]+(b.pose[j]-a.pose[j])*alpha
        else out[j]=JLRSRecorder.angle(a.pose[j],b.pose[j],alpha)end
    end
    return objectRotation(context,a,b,time,out)
end
function JLRSWorld.tick(c,time,stateReplay)
    local replay=stateReplay or c.worldReplay
    if not replay then return end
    local scene=replay.scene
    for i=#replay.states,1,-1 do
        local state=replay.states[i];local group=state.group
        if JLRSWorld.allowLiveHandoff(c,group,state.cargo,state.hasRecordedTravel) then
            -- Permit Live Drive to hand a background vehicle back to the user.
            JLRSWorld.release(state);table.remove(replay.states,i)
        elseif state.returnPose and state.lastSampleTime~=time and not (state.stationary and state.lastAppliedPose) then
            local localPose=state.poseBuffer or {}
            for ei,entry in ipairs(group.entries) do
                local context=state.contexts and state.contexts[ei] or {frames=entry.samples,frameIndex=entry.sampleIndex}
                -- Every scene entry is a six-value transform stream, including
                -- legacy bales/balls. Final can reuse the same exact sampler.
                local pose=(group.prop or c.finalPlaying) and JLRSWorld.sampleObject(context,math.min(time,scene.duration)) or JLRSRecorder.sample(context,math.min(time,scene.duration));entry.sampleIndex=context.frameIndex
                for j=1,6 do localPose[(ei-1)*6+j]=pose[j] end
            end
            -- Stationary objects need their reset pose once, not a native
            if state.vehicleTrack and JLRSPrecisionSupport and JLRSPrecisionSupport.scenePose then
                JLRSPrecisionSupport.scenePose(state.vehicleTrack,localPose)
            end
            -- transform write every draw. The isolated replay owns these nodes.
            local changed=not state.lastAppliedPose
            if not changed then
                for j,value in ipairs(localPose) do
                    if value~=state.lastAppliedPose[j] then changed=true;break end
                end
            end
            if changed then
                local entries,pose=state.applyEntries or {},state.applyPose or {}
                for j=#entries,1,-1 do entries[j]=nil end
                for j=#pose,1,-1 do pose[j]=nil end
                for ei,entry in ipairs(group.entries) do
                    -- Legacy History may contain static map components.
                    -- Those cannot move through physics and must not be rewritten.
                    if entityExists(entry.node) and getRigidBodyType(entry.node)~=RigidBodyType.STATIC then
                        entries[#entries+1]=entry
                        for j=1,6 do pose[#pose+1]=localPose[(ei-1)*6+j] end
                    end
                end
                if #entries>0 then
                    -- Scene vehicles have their own isolated owner, outside the
                    -- main-track guard. Avoid native vehicle reposition work.
                    local track=state.vehicleTrack
                    JLRSRecorder.apply(entries,pose,true,track and track.livePhysics and not track.collisionReplay)
                end
                state.applyEntries=entries;state.applyPose=pose
                state.poseBuffer=state.lastAppliedPose or {}
                state.lastAppliedPose=localPose
            end
            if state.vehicleTrack and JLRSWheelVisual then
                local track=state.vehicleTrack
                track.replaying=true;track.replayTime=time
                track.replayAudioTime=time;track.replayAudioPose=state.lastAppliedPose
                JLRSWheelVisual.refresh(track)
            end
            state.lastSampleTime=time
        end
    end
end
local startRecord=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c==JLReplayStudio then JLRSWorld.stop(c) end
    local result=startRecord(c,...)
    if c==JLReplayStudio and c.recording then
        c.worldRecord=JLRSWorld.collect(c)
        JLRSWorld.initialize(c.worldRecord)
        c:notify('SCENE RECORD | '..#c.worldRecord.groups..' kendaraan / objek dinamis | dunia normal | kereta dikecualikan')
    end
    return result
end
local recordTick=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,...)
    local result=recordTick(c,...)
    if c==JLReplayStudio then
        JLRSWorld.fill(c)

    end
    return result
end
local archive=JLRSHistory.archive
JLRSHistory.archive=function(c,...)
    if c==JLReplayStudio then JLRSWorld.fill(c) end
    local result=archive(c,...)
    for _,clip in ipairs(c.history or {}) do if clip.frames==c.frames then clip.worldScene=c.worldRecord end end
    return result
end
local play=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c~=JLReplayStudio or c.worldBatch then return play(c,...) end
    JLRSWorld.stop(c)
    local result=play(c,...)
    local scene
    for _,clip in ipairs(c.history or {}) do if clip.frames==c.frames then scene=clip.worldScene;break end end
    local owner=c.replaying and c or (c.liveTracks and c.liveTracks[#c.liveTracks])
    if owner then JLRSWorld.start(c,scene,owner) end
    return result
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...)
    local replay=c.worldReplay
    if replay then
        if replay.owner.replaying then JLRSWorld.tick(c,replay.owner.replayTime) else JLRSWorld.stop(c) end
    end
    for _,track in ipairs(c.liveTracks or {}) do
        if track.cargoReplay then JLRSWorld.tick(c,track.replayTime,track.cargoReplay) end
    end
    return result
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    JLRSWorld.stop(c);return stop(c,...)
end
local toggle=JLRSLive.toggle
JLRSLive.toggle=function(c,...)
    if c.liveDrive then JLRSWorld.stop(c) end
    return toggle(c,...)
end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    JLRSWorld.stop(c);local result=delete(c,...);c.worldRecord=nil;return result
end
local all=JLRSGroup.all
JLRSGroup.all=function(c,...)
    local result=all(c,...)
    -- Earliest selected take defines the shared world's initial state.
    -- Vehicle tracks keep their own recordings; no duplicate body writers.
    local selected={}
    for _,track in ipairs(c.liveTracks or {}) do selected[track.frames]=track end
    for _,clip in ipairs(c.history or {}) do
        if selected[clip.frames] and clip.worldScene then
            JLRSWorld.start(c,clip.worldScene,selected[clip.frames]);break
        end
    end
    return result
end

local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.worldRecord=nil;c.worldReplay=nil;return result
end

-- Cargo belongs to its live vehicle track, not the replaceable background scene.
-- A new Record stops the old background but must keep the truck's cargo running.
local addLive=JLRSLive.add
JLRSLive.add=function(c,...)
    local previous={};for _,track in ipairs(c.liveTracks or {}) do previous[track]=true end
    local result=addLive(c,...)
    local track=c.liveTracks and c.liveTracks[#c.liveTracks]
    if track and not previous[track] then
        for _,clip in ipairs(c.history or {}) do
            if clip.frames==track.frames and clip.worldScene then
                local cargo=false
                for _,group in ipairs(clip.worldScene.groups or {}) do
                    if group.prop or group.cargo or JLRSWorld.isCargo(group.object,track.recordVehicles) then cargo=true;break end
                end
                if cargo then JLRSWorld.start(c,clip.worldScene,track,true) end
                break
            end
        end
    end
    return result
end
local resetLive=JLRSLive.resetClock
JLRSLive.resetClock=function(c,...)
    local result=resetLive(c,...)
    for _,track in ipairs(c.liveTracks or {}) do
        if track.cargoReplay then JLRSWorld.tick(c,track.replayTime,track.cargoReplay) end
    end
    return result
end
local stopReplay=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    JLRSWorld.releaseReplay(track.cargoReplay);track.cargoReplay=nil
    return stopReplay(track,...)
end
local hasVehicle=JLRSLive.hasVehicle
JLRSLive.hasVehicle=function(track,v)
    if hasVehicle(track,v) then return true end
    for _,state in ipairs(track.cargoReplay and track.cargoReplay.states or {}) do
        if state.group.object==v then return true end
    end
    return false
end
