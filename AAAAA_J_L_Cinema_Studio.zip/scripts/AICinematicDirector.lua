-- J_L Cinema Studio AI Cinematic Director
-- V1.18.86.136: deterministic shot grammar, scene hysteresis, subject lock,
-- cinematic rig presets and eased camera transitions.
-- This module is additive: recording, replay data, cache and history formats are untouched.

JLRSAIDirector = {}
local D = JLRSAIDirector

D.PROFILES = {
    balanced = {
        label = "BALANCED",
        stationarySpeed = 0.55,
        maneuverSpeed = 1.25,
        cruiseSpeed = 3.20,
        fastSpeed = 8.50,
        turnRate = 0.36,
        stateHold = 3.5,
        minimumShotHold = 12.0,
        interval = 18,
        transition = 2.2,
        aimSmooth = 0.42
    },
    action = {
        label = "ACTION",
        stationarySpeed = 0.40,
        maneuverSpeed = 1.05,
        cruiseSpeed = 2.70,
        fastSpeed = 7.00,
        turnRate = 0.27,
        stateHold = 2.5,
        minimumShotHold = 10.0,
        interval = 14,
        transition = 1.6,
        aimSmooth = 0.28
    },
    documentary = {
        label = "DOCUMENTARY",
        stationarySpeed = 0.70,
        maneuverSpeed = 1.55,
        cruiseSpeed = 3.80,
        fastSpeed = 10.00,
        turnRate = 0.46,
        stateHold = 5.0,
        minimumShotHold = 16.0,
        interval = 24,
        transition = 2.8,
        aimSmooth = 0.60
    }
}

D.PROFILE_ORDER = {"balanced", "action", "documentary"}

-- Curated, repeatable shot grammar. The order is intentional; no random selection.
-- Camera modes: 2 Orbit, 6 Dolly, 8 Tracking, 10 Crane, 11 Pedestal.
D.SHOTS = {
    parked = {11, 10, 2},
    reversing = {8, 6},
    turning = {8, 2, 6},
    fast = {8, 6, 10},
    cruising = {8, 2, 6, 10},
    maneuvering = {8, 6, 11}
}

-- Conservative virtual camera rigs. Subject lock is enabled while Director owns
-- the camera, preventing the vehicle from drifting out of frame during a shot.
D.SHOT_RIGS = {
    [2] = {distance = 18, height = 5.0, focusHeight = 1.8, side = 0, amplitude = 0.9, cameraSpeed = 0.14, fov = 48},
    [6] = {distance = 15, height = 4.0, focusHeight = 1.8, side = 4.5, amplitude = 0.8, cameraSpeed = 0.12, fov = 50},
    [8] = {distance = 16, height = 4.6, focusHeight = 1.8, side = 6.0, amplitude = 0.55, cameraSpeed = 0.12, fov = 48},
    [10] = {distance = 18, height = 7.0, focusHeight = 1.8, side = 7.0, amplitude = 1.6, cameraSpeed = 0.12, fov = 50},
    [11] = {distance = 12, height = 3.0, focusHeight = 1.8, side = 4.0, amplitude = 0.7, cameraSpeed = 0.12, fov = 50}
}

D.MIN_INTERVAL = 12
D.MAX_INTERVAL = 30
D.DEFAULT_INTERVAL = 18
D.SPEED_SMOOTH_TIME = 0.90
D.TURN_SMOOTH_TIME = 1.10
D.TRANSITION_MIN = 1.4

D.CAMERA_FIELDS = {
    "distance", "height", "focusHeight", "amplitude",
    "side", "cameraSpeed", "fov", "motionFov", "lock"
}

local function validVehicle(vehicle)
    return vehicle ~= nil and JLRSRecorder ~= nil
        and type(JLRSRecorder.valid) == "function"
        and JLRSRecorder.valid(vehicle)
end

local function angleDelta(a, b)
    return (b - a + math.pi) % (2 * math.pi) - math.pi
end

local function clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

local function smoothStep(value)
    local t = clamp(value, 0, 1)
    return t * t * (3 - 2 * t)
end

function D.profile(c)
    return D.PROFILES[c.directorProfile] or D.PROFILES.balanced
end

function D.target(c)
    if c.groupCamera and validVehicle(c.cameraTarget) then
        return c.cameraTarget
    end
    if validVehicle(c.target) then
        return c.target
    end
    return nil
end

function D.captureCameraPose(c)
    local pose = {
        x = tonumber(c.x) or 0,
        y = tonumber(c.y) or 0,
        z = tonumber(c.z) or 0,
        pitch = tonumber(c.pitch) or 0,
        yaw = tonumber(c.yaw) or 0,
        fov = tonumber(c.directorCurrentFov) or tonumber(c.motionFov) or tonumber(c.fov) or 55
    }
    -- Capture the rendered pose (not just the next rig destination), especially
    -- when a user presses NEXT SHOT during an in-progress transition.
    if c.camera then
        local ok, x, y, z = pcall(getWorldTranslation, c.camera)
        if ok and x ~= nil then
            pose.x, pose.y, pose.z = x, y, z
        end
        local okRotation, pitch, yaw = pcall(getWorldRotation, c.camera)
        if okRotation and pitch ~= nil and yaw ~= nil then
            pose.pitch, pose.yaw = pitch, yaw
        end
    end
    return pose
end

function D.captureSettings(c)
    if c.directorSavedSettings then
        return
    end
    local saved = {}
    for _, field in ipairs(D.CAMERA_FIELDS) do
        saved[field] = c[field]
    end
    c.directorSavedSettings = saved
end

function D.beginTransition(c, fromPose, duration)
    if not fromPose or not c.camera or not c.active then
        c.directorTransition = nil
        return
    end
    c.directorTransition = {
        from = fromPose,
        elapsed = 0,
        duration = math.max(D.TRANSITION_MIN, tonumber(duration) or 2.0)
    }
    c.directorAimPitch = fromPose.pitch
    c.directorAimYaw = fromPose.yaw
end

function D.restoreSettings(c)
    local saved = c.directorSavedSettings
    if not saved then
        return
    end

    local fromPose = D.captureCameraPose(c)
    for _, field in ipairs(D.CAMERA_FIELDS) do
        if saved[field] ~= nil then
            c[field] = saved[field]
        end
    end
    c.directorSavedSettings = nil

    -- Rebuild the current mode using the user's original rig, then ease to it.
    if c.active and c.camera and (c.replaying or c.groupCamera) and c.mode then
        local ok = pcall(JLRSCamera.choose, c, c.mode)
        if ok then
            D.beginTransition(c, fromPose, 1.8)
        end
    end
end

function D.resetSampling(c)
    c.directorSample = nil
    c.directorSpeed = 0
    c.directorYawRate = 0
    c.directorReverse = false
    c.directorClass = nil
    c.directorStableClass = nil
    c.directorCandidateClass = nil
    c.directorCandidateTime = 0
    c.directorSelectedClass = nil
    c.directorShotElapsed = 0
    c.directorCooldown = 0
    c.directorShotCount = 0
    c.directorClassCounts = {}
    c.directorLastMode = nil
    c.directorLastTick = nil
    c.directorTarget = nil
    c.directorStatus = "MENUNGGU REPLAY"
end

function D.resetClassification(c)
    c.directorSample = nil
    c.directorSpeed = 0
    c.directorYawRate = 0
    c.directorReverse = false
    c.directorClass = nil
    c.directorStableClass = nil
    c.directorCandidateClass = nil
    c.directorCandidateTime = 0
end

function D.classify(c, speed, yawRate, reverse)
    local profile = D.profile(c)
    if speed < profile.stationarySpeed then
        return "parked"
    end
    if reverse then
        return "reversing"
    end
    if yawRate > profile.turnRate and speed > profile.maneuverSpeed then
        return "turning"
    end
    if speed > profile.fastSpeed then
        return "fast"
    end
    if speed > profile.cruiseSpeed then
        return "cruising"
    end
    return "maneuvering"
end

function D.sample(c, target, dt)
    local x, y, z = getWorldTranslation(target.rootNode)
    local _, yaw, _ = getWorldRotation(target.rootNode)
    local previous = c.directorSample

    if previous == nil or previous.target ~= target or dt <= 0 or dt > 0.5 then
        c.directorSample = {target = target, x = x, y = y, z = z, yaw = yaw}
        if c.directorSpeed == nil then c.directorSpeed = 0 end
        if c.directorYawRate == nil then c.directorYawRate = 0 end
        if c.directorReverse == nil then c.directorReverse = false end
        if c.directorClass == nil then c.directorClass = "parked" end
        return
    end

    local vx = (x - previous.x) / dt
    local vz = (z - previous.z) / dt
    local measuredSpeed = math.sqrt(vx * vx + vz * vz)
    local measuredYawRate = math.abs(angleDelta(previous.yaw, yaw)) / dt
    local forwardX, _, forwardZ = localDirectionToWorld(target.rootNode, 0, 0, 1)
    local forwardDot = vx * forwardX + vz * forwardZ

    -- Reverse detection has a dead-band so wheel/pose jitter does not flip state.
    if measuredSpeed > 1.3 and forwardDot < -(measuredSpeed * 0.35) then
        c.directorReverse = true
    elseif measuredSpeed < 0.65 or forwardDot > measuredSpeed * 0.20 then
        c.directorReverse = false
    end

    local speedAlpha = 1 - math.exp(-dt / D.SPEED_SMOOTH_TIME)
    local turnAlpha = 1 - math.exp(-dt / D.TURN_SMOOTH_TIME)
    c.directorSpeed = (c.directorSpeed or 0)
        + (measuredSpeed - (c.directorSpeed or 0)) * speedAlpha
    c.directorYawRate = (c.directorYawRate or 0)
        + (measuredYawRate - (c.directorYawRate or 0)) * turnAlpha
    c.directorClass = D.classify(c, c.directorSpeed, c.directorYawRate, c.directorReverse)
    c.directorSample = {target = target, x = x, y = y, z = z, yaw = yaw}
end

function D.updateStableClass(c, dt)
    local rawClass = c.directorClass or "parked"
    if c.directorStableClass == nil then
        c.directorStableClass = rawClass
        c.directorCandidateClass = nil
        c.directorCandidateTime = 0
        return
    end

    if rawClass == c.directorStableClass then
        c.directorCandidateClass = nil
        c.directorCandidateTime = 0
        return
    end

    if c.directorCandidateClass ~= rawClass then
        c.directorCandidateClass = rawClass
        c.directorCandidateTime = 0
        return
    end

    c.directorCandidateTime = (c.directorCandidateTime or 0) + dt
    if c.directorCandidateTime >= D.profile(c).stateHold then
        c.directorStableClass = rawClass
        c.directorCandidateClass = nil
        c.directorCandidateTime = 0
    end
end

function D.applyShotRig(c, mode)
    local rig = D.SHOT_RIGS[mode]
    if not rig then
        return false
    end
    for field, value in pairs(rig) do
        c[field] = value
    end
    c.lock = true
    return true
end

function D.chooseShot(c, class, reason)
    if c.fixedAngleActive then
        c.directorStatus = "FIXED T ANGLE AKTIF"
        return false
    end
    if not c.active or c.camera == nil or not validVehicle(D.target(c)) then
        c.directorStatus = "KAMERA / TARGET BELUM SIAP"
        return false
    end

    local choices = D.SHOTS[class] or D.SHOTS.cruising
    local classCount = c.directorClassCounts and (c.directorClassCounts[class] or 0) or 0
    local selected = nil
    local selectedOffset = 0

    -- Deterministic round-robin inside a curated scene-specific shot list.
    -- Skip the current mode and avoid an immediate duplicate cut.
    for offset = 1, #choices do
        local index = ((classCount + offset - 1) % #choices) + 1
        local candidate = choices[index]
        if candidate ~= c.mode and candidate ~= c.directorLastMode then
            selected = candidate
            selectedOffset = offset
            break
        end
    end
    if selected == nil then
        for offset = 1, #choices do
            local index = ((classCount + offset - 1) % #choices) + 1
            local candidate = choices[index]
            if candidate ~= c.mode then
                selected = candidate
                selectedOffset = offset
                break
            end
        end
    end
    if selected == nil then
        c.directorStatus = "SHOT SUDAH AKTIF"
        return false
    end

    local fromPose = D.captureCameraPose(c)
    D.applyShotRig(c, selected)

    local ok, err = pcall(JLRSCamera.choose, c, selected)
    if not ok then
        c.directorStatus = "SHOT GAGAL"
        c:notify("AI Director gagal memilih shot: " .. tostring(err))
        return false
    end

    D.beginTransition(c, fromPose, D.profile(c).transition)
    c.directorClassCounts = c.directorClassCounts or {}
    c.directorClassCounts[class] = classCount + selectedOffset
    c.directorShotCount = (c.directorShotCount or 0) + 1
    c.directorLastMode = selected
    c.directorShotElapsed = 0
    c.directorCooldown = 0
    c.directorSelectedClass = class
    c.directorCandidateClass = nil
    c.directorCandidateTime = 0
    c.directorStatus = string.upper(class) .. " / " .. (JLRSCamera.names[selected] or "CAMERA")
    c:notify("AI DIRECTOR | " .. c.directorStatus .. " | TRANSISI HALUS")
    return true
end

function D.nextShot(c)
    if not c.directorEnabled then
        c:notify("Aktifkan AI Director terlebih dahulu.")
        return false
    end
    local class = c.directorStableClass or c.directorSelectedClass or "cruising"
    return D.chooseShot(c, class, "manual")
end

function D.setEnabled(c, enabled)
    local requested = enabled == true
    if requested == c.directorEnabled then
        return
    end

    if requested then
        D.captureSettings(c)
        c.directorEnabled = true
        c.directorPaused = false
        D.resetSampling(c)
        local profile = D.profile(c)
        if not c.directorIntervalManual then
            c.directorInterval = profile.interval
        end
        if c.replaying or c.groupCamera then
            c:notify("AI DIRECTOR ON | shot stabil dan transisi sinematik aktif.")
        else
            c:notify("AI DIRECTOR ARMED | mulai Replay untuk mengaktifkan kamera otomatis.")
        end
    else
        c.directorEnabled = false
        c.directorPaused = false
        c.directorTransition = nil
        D.restoreSettings(c)
        D.resetSampling(c)
        c:notify("AI DIRECTOR OFF | pengaturan kamera pengguna dipulihkan.")
    end
end

function D.toggle(c)
    D.setEnabled(c, not c.directorEnabled)
end

function D.togglePause(c)
    if not c.directorEnabled then
        c:notify("AI Director belum aktif.")
        return
    end
    c.directorPaused = not c.directorPaused
    c.directorLastTick = g_time or 0
    c:notify(c.directorPaused and "AI DIRECTOR PAUSED." or "AI DIRECTOR RESUMED.")
end

function D.cycleProfile(c)
    local current = c.directorProfile or "balanced"
    local index = 1
    for i, name in ipairs(D.PROFILE_ORDER) do
        if name == current then
            index = i
            break
        end
    end
    index = index % #D.PROFILE_ORDER + 1
    c.directorProfile = D.PROFILE_ORDER[index]
    if not c.directorIntervalManual then
        c.directorInterval = D.profile(c).interval
    end
    D.resetClassification(c)
    c:notify("AI DIRECTOR PROFILE | " .. D.profile(c).label)
end

function D.adjustInterval(c, delta)
    c.directorInterval = clamp(
        (tonumber(c.directorInterval) or D.profile(c).interval) + delta,
        D.MIN_INTERVAL,
        D.MAX_INTERVAL
    )
    c.directorIntervalManual = true
end

function D.statusLine(c)
    local class = c.directorStableClass or c.directorClass or "MENUNGGU"
    local speed = tonumber(c.directorSpeed) or 0
    local turn = math.deg(tonumber(c.directorYawRate) or 0)
    local interval = tonumber(c.directorInterval) or D.profile(c).interval
    local remaining = math.max(0, interval - (tonumber(c.directorShotElapsed) or 0))
    return string.format("Scene: %s | Speed: %.1f m/s | Turn: %.0f deg/s", class, speed, turn)
        .. string.format(" | Next shot: %.0fs", remaining)
end

function D.tick(c)
    if not c.directorEnabled then
        return
    end

    local now = tonumber(g_time) or 0
    local previousTime = c.directorLastTick
    c.directorLastTick = now
    local dt = previousTime and (now - previousTime) / 1000 or 0
    if dt < 0 or dt > 0.5 then
        dt = 0
    end

    local mission = c.mission
    local guiVisible = g_gui and g_gui.getIsGuiVisible and g_gui:getIsGuiVisible()
    if not mission or not c.active or not c.camera
        or not (c.replaying or c.groupCamera)
        or c.recording or c.finalPlaying or c.editingSession
        or c.fixedAngleActive or c.directorPaused
        or c.menu or guiVisible or mission.isPaused
        or (c.paused and not c.groupCamera)
        or (c.livePaused and c.groupCamera) then
        -- Rebase after menus/pauses to prevent false speed spikes.
        c.directorSample = nil
        return
    end

    local target = D.target(c)
    if not target then
        c.directorSample = nil
        c.directorStatus = "TARGET TIDAK TERSEDIA"
        return
    end

    if c.directorTarget ~= target then
        D.resetSampling(c)
        c.directorTarget = target
        c.directorLastTick = now
        D.sample(c, target, 0)
        c.directorStableClass = c.directorClass or "parked"
        D.chooseShot(c, c.directorStableClass, "initial")
        return
    end

    if dt <= 0 then
        D.sample(c, target, 0)
        return
    end

    D.sample(c, target, dt)
    D.updateStableClass(c, dt)
    c.directorShotElapsed = (c.directorShotElapsed or 0) + dt
    c.directorCooldown = (c.directorCooldown or 0) + dt

    local stableClass = c.directorStableClass or c.directorClass or "parked"
    local profile = D.profile(c)
    local minimumHold = profile.minimumShotHold
    local interval = clamp(
        tonumber(c.directorInterval) or profile.interval,
        D.MIN_INTERVAL,
        D.MAX_INTERVAL
    )

    -- A scene change is never an immediate cut. It must survive the profile's
    -- stability window and the current shot's minimum on-screen duration.
    local sceneChanged = stableClass ~= c.directorSelectedClass
    local shotReady = c.directorCooldown >= minimumHold
    local intervalReady = c.directorShotElapsed >= interval

    if shotReady and (sceneChanged or intervalReady) then
        D.chooseShot(c, stableClass, sceneChanged and "scene" or "interval")
    end
end

function D.drawPanel(c)
    local profile = D.profile(c)
    JLRSMenu.text(0.365, 0.735, 0.012, "AI CINEMATIC DIRECTOR / STABLE SHOT PLANNING", 0.12, 0.85, 0.9)
    JLRSMenu.button(
        c, 0.365, 0.675, 0.465, 0.046,
        c.directorEnabled and "AI DIRECTOR: ON" or "AI DIRECTOR: OFF",
        function() D.toggle(c) end,
        c.directorEnabled
    )
    JLRSMenu.button(
        c, 0.365, 0.612, 0.226, 0.040,
        "PROFILE: " .. profile.label,
        function() D.cycleProfile(c) end
    )
    JLRSMenu.button(
        c, 0.604, 0.612, 0.226, 0.040,
        c.directorPaused and "RESUME AI" or "PAUSE AI",
        function() D.togglePause(c) end,
        c.directorPaused
    )
    JLRSMenu.text(0.365, 0.557, 0.012, "Scheduled shot interval", 0.65, 0.74, 0.83)
    JLRSMenu.button(c, 0.653, 0.545, 0.032, 0.030, "-", function() D.adjustInterval(c, -1) end)
    JLRSMenu.text(
        0.703, 0.554, 0.013,
        string.format("%d s", clamp(tonumber(c.directorInterval) or profile.interval, D.MIN_INTERVAL, D.MAX_INTERVAL))
    )
    JLRSMenu.button(c, 0.798, 0.545, 0.032, 0.030, "+", function() D.adjustInterval(c, 1) end)
    JLRSMenu.button(
        c, 0.365, 0.478, 0.465, 0.042,
        "NEXT SHOT NOW",
        function() D.nextShot(c) end,
        false,
        {0.10, 0.34, 0.42}
    )
    JLRSMenu.text(0.365, 0.431, 0.011, D.statusLine(c), 0.82, 0.88, 0.92)
    JLRSMenu.text(
        0.365, 0.402, 0.011,
        "Current shot: " .. tostring(JLRSCamera.names[c.mode] or "N/A"),
        0.65, 0.74, 0.83
    )
    JLRSMenu.text(
        0.365, 0.375, 0.010,
        string.format("Scene hold %.1fs | Min shot %.0fs | Transition %.1fs",
            profile.stateHold, profile.minimumShotHold, profile.transition),
        0.65, 0.74, 0.83
    )
    JLRSMenu.text(0.365, 0.348, 0.010, "No random cuts | Subject lock ON | Camera rig restored when OFF", 0.65, 0.74, 0.83)
end

-- Smooth camera transitions are applied after the established camera tick has
-- computed its destination pose. Only Director-created transitions use this.
local previousCameraTick = JLRSCamera.tick
JLRSCamera.tick = function(c, dt, ...)
    local result = previousCameraTick(c, dt, ...)
    if not c.camera or not c.active then
        return result
    end

    local step = math.max(0, tonumber(dt) or 0)
    local targetPitch = tonumber(c.pitch) or 0
    local targetYaw = tonumber(c.yaw) or 0

    -- Smooth subject aim after the transition as well; this prevents a locked
    -- camera from snapping its heading when the recorded vehicle turns.
    if c.directorEnabled and c.lock then
        if c.directorAimPitch == nil or c.directorAimYaw == nil then
            c.directorAimPitch = targetPitch
            c.directorAimYaw = targetYaw
        end
        local aimTime = D.profile(c).aimSmooth
        local aimAlpha = 1 - math.exp(-step / math.max(0.05, aimTime))
        c.directorAimPitch = c.directorAimPitch + (targetPitch - c.directorAimPitch) * aimAlpha
        c.directorAimYaw = c.directorAimYaw + angleDelta(c.directorAimYaw, targetYaw) * aimAlpha
        targetPitch = c.directorAimPitch
        targetYaw = c.directorAimYaw
    else
        c.directorAimPitch = nil
        c.directorAimYaw = nil
    end

    local transition = c.directorTransition
    if transition then
        transition.elapsed = (transition.elapsed or 0) + step
        local linear = clamp(transition.elapsed / math.max(0.01, transition.duration or 2), 0, 1)
        local alpha = smoothStep(linear)
        local from = transition.from
        local toFov = tonumber(c.motionFov) or tonumber(c.fov) or from.fov

        local x = from.x + ((tonumber(c.x) or from.x) - from.x) * alpha
        local y = from.y + ((tonumber(c.y) or from.y) - from.y) * alpha
        local z = from.z + ((tonumber(c.z) or from.z) - from.z) * alpha
        local pitch = from.pitch + (targetPitch - from.pitch) * alpha
        local yaw = from.yaw + angleDelta(from.yaw, targetYaw) * alpha
        local fov = from.fov + (toFov - from.fov) * alpha

        setTranslation(c.camera, x, y, z)
        setRotation(c.camera, pitch, yaw, 0)
        setFovY(c.camera, math.rad(clamp(fov, 10, 110)))
        c.directorCurrentFov = fov

        if linear >= 1 then
            c.directorTransition = nil
            c.directorCurrentFov = nil
        end
    elseif c.directorEnabled and c.lock then
        setRotation(c.camera, targetPitch, targetYaw, 0)
    end
    return result
end

-- Attach to the existing lifecycle after all original camera wrappers are loaded.
local oldLoadMap = JLReplayStudio.loadMap
JLReplayStudio.loadMap = function(c, ...)
    local result = oldLoadMap(c, ...)
    c.directorProfile = "balanced"
    c.directorInterval = D.DEFAULT_INTERVAL
    c.directorIntervalManual = false
    c.directorEnabled = false
    c.directorPaused = false
    c.directorSavedSettings = nil
    c.directorTransition = nil
    c.directorCurrentFov = nil
    D.resetSampling(c)
    return result
end

local oldDeleteMap = JLReplayStudio.deleteMap
JLReplayStudio.deleteMap = function(c, ...)
    c.directorEnabled = false
    c.directorPaused = false
    c.directorTransition = nil
    c.directorSavedSettings = nil
    D.resetSampling(c)
    return oldDeleteMap(c, ...)
end

local oldDraw = JLReplayStudio.draw
JLReplayStudio.draw = function(c, ...)
    local result = oldDraw(c, ...)
    if c.mission then
        local ok, err = pcall(D.tick, c)
        if not ok then
            c.directorEnabled = false
            c.directorPaused = false
            c.directorTransition = nil
            D.restoreSettings(c)
            c.directorStatus = "ERROR / OFF"
            c:notify("AI Director dinonaktifkan karena error: " .. tostring(err))
        end
    end
    return result
end

local oldStartReplay = JLRSRecorder.startReplay
JLRSRecorder.startReplay = function(c, ...)
    local result = oldStartReplay(c, ...)
    if c == JLReplayStudio and c.directorEnabled then
        D.resetSampling(c)
    end
    return result
end
