-- All recording modes: retain distant chain collisions without reading six
-- transforms from sleeping props. Nearby/moving bodies already use full capture.
JLRSRecordAllIdleProps={}
local prepare=JLRSProps.prepare
JLRSProps.prepare=function(scene,...)
    local result=prepare(scene,...)
    local c=JLReplayStudio
    if not c.recording or c.antiLag==false
        or type(getIsSleeping)~='function' or type(getRigidBodyType)~='function' then return result end
    for _,entry in ipairs(scene.propEntries or {}) do
        if entry.propProbe~=scene.propEpoch and (entry.propMovingUntil or 0)<=(scene.captureTime or 0)
            and entry.world and entry.lastPose and entityExists(entry.node)
            and getParent(entry.node)==entry.parent and getRigidBodyType(entry.node)==RigidBodyType.DYNAMIC then
            local ok,sleeping=pcall(getIsSleeping,entry.node)
            if ok and sleeping==true then
                -- Existing full-rate sampler uses the last exact pose while a
                -- body is sleeping. No interpolation time or frame is dropped.
                -- Sample the final transition to sleep once. The final physics
                -- pose can differ from the last awake sample.
                if entry.jlrsWasSleeping~=true then entry.propProbe=scene.propEpoch end
                entry.jlrsWasSleeping=true
            elseif ok and sleeping==false then
                -- Also catch wakeups outside a parked vehicle's spatial cell:
                -- impacts by another obstacle/NPC must be recorded immediately.
                entry.propProbe=scene.propEpoch;entry.jlrsWasSleeping=false
            end
        end
    end
    return result
end
