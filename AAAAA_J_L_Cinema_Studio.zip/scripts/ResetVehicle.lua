-- Reset uses the selected recording's native component poses; never deletes History.
JLRSResetVehicle={}
local R=JLRSResetVehicle
-- Reset must hand sound back to native Motorized after replay releases its hooks.
-- A stopped loop is not restarted by native onUpdate while isMotorStarted is true.
local function captureMotor(v)
    local spec=v.spec_motorized
    if not spec then return nil end
    return {running=spec.isMotorStarted==true}
end
local function restoreMotor(v,state)
    local spec=v.spec_motorized
    if not state or not spec or not JLRSRecorder.valid(v) or v.isAddedToPhysics~=true then return end
    if state.running and spec.isMotorStarted~=true and type(v.startMotor)=='function' then
        v:startMotor(true)
    end
    if spec.isMotorStarted~=true or not g_soundManager then return end
    local manager=g_soundManager
    if type(manager.getIsSamplePlaying)~='function' or type(manager.playSample)~='function' then return end
    -- Restart only missing continuous loops. Never replay ignition/stop/horn sounds.
    local predecessor=spec.samples and spec.samples.motorStart
    if predecessor and not manager:getIsSamplePlaying(predecessor) then predecessor=nil end
    local function repair(samples)
        for _,sample in pairs(samples or {}) do
            if sample and not manager:getIsSamplePlaying(sample) then
                manager:playSample(sample,0,predecessor)
            end
        end
    end
    repair(spec.motorSamples)
    repair(spec.gearboxSamples)
end
function R.snapshot(c)
    local snapshot={};local seen={}
    for _,v in pairs((c.mission or {}).vehicles or {}) do
        if JLRSRecorder.valid(v) and v.components and not v.trainSystem and not v.spec_train then
            local entries,vehicles=JLRSRecorder.topology(v)
            for _,vehicle in ipairs(vehicles) do
                if not seen[vehicle] then
                    seen[vehicle]=true;local own={}
                    for _,entry in ipairs(entries) do
                        if entry.vehicle==vehicle and entry.world then own[#own+1]=entry end
                    end
                    local pose=JLRSRecorder.capture(own)
                    if #own>0 and pose then snapshot[#snapshot+1]={vehicle=vehicle,entries=own,pose=pose} end
                end
            end
        end
    end
    c.vehicleResetSnapshot=snapshot
end
function R.reset(c,selection,targets)
    if c.recording then c:notify('Stop / ESC dahulu sebelum Reset Vehicle. Rekaman tetap berjalan.');return end
    if not c.mission then return end
    local byNode={};local entries={};local vehicles={};local seen={};local alive={}
    local function visit(v)
        if not JLRSRecorder.valid(v) or alive[v] then return end
        alive[v]=true
        if type(v.getAttachedImplements)=='function' then
            for _,implement in ipairs(v:getAttachedImplements()) do if implement.object then visit(implement.object) end end
        end
    end
    for _,v in pairs(c.mission.vehicles or {}) do visit(v) end
    local function add(entry,pose,offset)
        local v=entry.vehicle
        if selection and not selection[v] then return end
        if not entry.world or not v or not alive[v] or v.trainSystem or v.spec_train or not JLRSRecorder.valid(v)
            or not entityExists(entry.node) or getParent(entry.node)~=entry.parent then return end
        if not byNode[entry.node] then entries[#entries+1]=entry end
        local p={};for j=1,6 do p[j]=pose[offset+j] end;byNode[entry.node]=p
        if not seen[v] then seen[v]=true;vehicles[#vehicles+1]=v end
    end
    -- Fallback for cars outside the selected take: position when map loaded.
    for _,item in ipairs(c.vehicleResetSnapshot or {}) do
        for i,entry in ipairs(item.entries) do add(entry,item.pose,(i-1)*6) end
    end
    local frames=c.frames;local recordedEntries=c.entries
    if not frames or JLRSFrames.count(frames)==0 then
        local clip=(c.history or {})[#(c.history or {})]
        if clip then frames=clip.frames;recordedEntries=clip.entries end
    end
    local scene=c.worldRecord
    for _,clip in ipairs(c.history or {}) do if clip.frames==frames then scene=clip.worldScene;break end end
    if scene then
        for _,entry in ipairs(scene.entries or {}) do
            local first=entry.samples and JLRSFrames.count(entry.samples)>0 and JLRSFrames.get(entry.samples,1)
            if first then add(entry,first.pose,0) end
        end
    end
    if frames and JLRSFrames.count(frames)>0 then
        local first=JLRSFrames.get(frames,1)
        for i,entry in ipairs(recordedEntries or {}) do add(entry,first.pose,(i-1)*6) end
    end
    for _,item in ipairs(targets or {}) do
        for i,entry in ipairs(item.entries) do add(entry,item.pose,(i-1)*6) end
    end
    if #entries==0 then c:notify('Reset Vehicle: belum ada posisi kendaraan yang tersedia.');return end
    for _,v in ipairs(vehicles) do
        if type(v.removeFromPhysics)~='function' or type(v.addToPhysics)~='function' then
            c:notify('Reset Vehicle batal: API physics kendaraan tidak tersedia.');return
        end
    end
    local motors={}
    for _,v in ipairs(vehicles) do motors[v]=captureMotor(v) end
    -- Selective History reset must not move the other vehicles when Stop releases replay.
    local keepEntries={};local keepNodes={};local keepMotors={}
    if selection then
        for v in pairs(alive) do if not selection[v] then
            keepMotors[v]=captureMotor(v)
            local topology=JLRSRecorder.topology(v)
            for _,entry in ipairs(topology or {}) do
                if entry.world and not selection[entry.vehicle] and not keepNodes[entry.node] then
                    keepNodes[entry.node]=true;keepEntries[#keepEntries+1]=entry
                end
            end
        end end
    end
    local keepPose=selection and JLRSRecorder.capture(keepEntries)
    c:stop()
    if keepPose then JLRSRecorder.apply(keepEntries,keepPose) end
    for v,state in pairs(keepMotors) do pcall(restoreMotor,v,state) end
    c.historyResetActive=selection
    local trailerReset=JLRSTrailers and JLRSTrailers.resetBegin(c,vehicles,frames)
    c.historyResetActive=nil
    -- Detach complete chains once, synchronize native interpolators, then restore physics.
    local states={};local original=JLRSRecorder.capture(entries);local pose={}
    for _,entry in ipairs(entries) do for j=1,6 do pose[#pose+1]=byNode[entry.node][j] end end
    local ok,err=pcall(function()
        for _,v in ipairs(vehicles) do
            local state={vehicle=v,added=v.isAddedToPhysics==true};states[#states+1]=state
            if state.added then v:removeFromPhysics() end
        end
        if not JLRSRecorder.apply(entries,pose) then error('Node kendaraan berubah.') end
    end)
    if not ok and original then pcall(JLRSRecorder.apply,entries,original,true) end
    local restored=true
    for _,state in ipairs(states) do
        if state.added and JLRSRecorder.valid(state.vehicle) then
            local success,failure=pcall(state.vehicle.addToPhysics,state.vehicle)
            if not success then restored=false;err=failure end
        end
    end
    if JLRSTrailers then JLRSTrailers.resetEnd(trailerReset) end
    -- One-time sound handoff, also after a rolled-back pose failure. No per-frame polling.
    for _,v in ipairs(vehicles) do
        local success,failure=pcall(restoreMotor,v,motors[v])
        if not success then print('[J_L Cinema Studio] Reset Vehicle audio: '..tostring(failure)) end
    end
    if ok and restored then
        for _,entry in ipairs(entries) do if entityExists(entry.node) then
            if type(setLinearVelocity)=='function' then setLinearVelocity(entry.node,0,0,0) end
            if type(setAngularVelocity)=='function' then setAngularVelocity(entry.node,0,0,0) end
        end end
        c:notify('RESET VEHICLE | '..#vehicles..' kendaraan kembali ke posisi awal | History tetap tersimpan')
    else c:notify('Reset Vehicle gagal: '..tostring(err)) end
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...)
    if c.mission then R.snapshot(c) end
    return result
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=deleteMap(c,...);c.vehicleResetSnapshot=nil;return result
end
