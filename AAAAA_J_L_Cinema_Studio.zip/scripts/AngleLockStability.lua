-- Cosmetic locked-aim stabilization only. Never write vehicle poses or camera controls.
JLRSAngleLockStable={TIME=0.04}
local S=JLRSAngleLockStable
local function enabled(c)
 return c.active and c.camera and c.angleEnabled and c.lock and c.mode~=8
  and not c.finalPlaying and not c.editingOpen and not c.curvaOpen
  and (c.replaying or c.groupCamera)
end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,dt,...)
 local cut=c.angleCutPending
 local result=tick(c,dt,...)
 if not enabled(c)then c.angleLockAim=nil;return result end
 -- Position and lock direction must share the current rendered vehicle pose.
 -- Filtering aim independently introduces a visible target-space lag while the
 -- camera arm moves. Input easing stays in Camera.applyInput, not in this lock.
 c.angleLockAim=nil
 setRotation(c.camera,c.pitch,c.yaw,0)
 return result
end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)c.angleLockAim=nil;return choose(c,...)end
local toggle=JLRSAngle.toggle
JLRSAngle.toggle=function(c,...)c.angleLockAim=nil;return toggle(c,...)end
local lock=JLRSCamera.toggleLock
JLRSCamera.toggleLock=function(c,...)c.angleLockAim=nil;return lock(c,...)end
local deactivate=JLRSCamera.deactivate
JLRSCamera.deactivate=function(c,...)c.angleLockAim=nil;return deactivate(c,...)end
