-- Keep every original sample and activity channel. Reduce temporary tables and
-- repeated native attachment queries only while Record All is recording.
JLRSRecordAllPerformance={}
local P=JLRSRecordAllPerformance
local function scalar(value)
    if type(value)=='boolean' then return value and 1 or 0 end
    return type(value)=='number' and value==value and math.abs(value)<math.huge and value or 0
end
local trailerRead=JLRSTrailers.read
JLRSTrailers.read=function(v,child)
    local context=P.attachments
    if not context then return trailerRead(v,child) end
    local map=context[v]
    if not map then
        map={};context[v]=map
        local list=type(v.getAttachedImplements)=='function' and v:getAttachedImplements()
            or (v.spec_attacherJoints or {}).attachedImplements or {}
        for _,imp in ipairs(list or {}) do if imp.object then
            map[imp.object]={1,imp.jointDescIndex or 0,imp.inputJointDescIndex or
                (imp.object.spec_attachable or {}).inputAttacherJointDescIndex or 0,0,0,0}
        end end
    end
    return map[child] or P.zero
end
P.zero={0,0,0,0,0,0}
function P.capture(schema,vehicles,buffer,reference)
    if not schema._recordOwners or schema._recordVehicles~=vehicles then
        local owners={};for _,v in ipairs(vehicles or {}) do owners[JLRSPersist.identity(v)]=v end
        schema._recordOwners=owners;schema._recordVehicles=vehicles
    end
    local offset=0;local changed=not reference
    for _,ch in ipairs(schema) do
        local v=schema._recordOwners[ch.owner] or ch.object
        local values=P.zero;local first,second,third
        if v and ch.kind=='light' then first=scalar((v.spec_lights or {})[ch.name])
        elseif v and ch.kind=='allMotor' then
            local spec=v.spec_motorized;local motor=spec and spec.motor
            if motor and motor.getLastModulatedMotorRpm then
                first=math.max(0,math.min(1,(motor:getLastModulatedMotorRpm()-(motor.minRpm or 0))/math.max(1,(motor.maxRpm or 1)-(motor.minRpm or 0))))
                second=spec.smoothedLoadPercentage or spec.rawLoadPercentage or 0
                third=spec.isMotorStarted and 1 or 0
            end
        elseif v and ch.kind=='custom' then
            local adapter=JLRSActivities.adapters[ch.getter]
            if adapter then
                local ok,result
                if adapter.readInto then
                    local scratch=ch._recordScratch or {};ch._recordScratch=scratch
                    for j=1,6 do scratch[j]=0 end
                    ok,result=pcall(adapter.readInto,v,ch,scratch)
                else ok,result=pcall(adapter.read,v,ch) end
                if ok and result then values=result end
            end
        else
            local scratch=ch._recordScratch or {};ch._recordScratch=scratch
            values=JLRSActivities.values(ch,v,scratch)
        end
        for j=1,6 do
            local value=values[j]
            if first~=nil then
                if j==1 then value=first elseif j==2 then value=second or 0 elseif j==3 then value=third or 0 end
            end
            value=value==0 and 0 or scalar(value);buffer[offset+j]=value
            if reference and reference[offset+j]~=value and (reference[offset+j]==nil or math.abs(value-reference[offset+j])>0.0000001) then changed=true end
        end
        offset=offset+6
    end
    for i=#buffer,offset+1,-1 do buffer[i]=nil end
    if reference and #reference~=offset then changed=true end
    return buffer,changed
end
local record=JLRSActivities.record
JLRSActivities.record=function(c,force)
    local state=c.activityRecording
    if not c.recordAllActive or not c.recording or not state then return record(c,force) end
    local buffer=state.allCaptureBuffer or {};state.allCaptureBuffer=buffer
    -- Context lifetime is one capture, including on adapter errors. Never cache
    -- a native coupling status across frames or reuse it during Replay.
    local previous=P.attachments;P.attachments={}
    local ok,pose,changed=pcall(P.capture,state.data.schema,c.recordVehicles,buffer,state.last)
    P.attachments=previous
    if not ok then error(pose) end
    local time=c.recordTime or 0;local count=JLRSFrames.count(state.data.frames)
    local durable=state.last
    if changed then
        durable={};for i=1,#pose do durable[i]=pose[i] end
    end
    if count==0 or force or changed then
        if count>0 and state.lastTime and time>state.lastTime and state.lastSampleTime<state.lastTime then
            JLRSFrames.push(state.data.frames,{t=state.lastTime,pose=state.last});state.lastSampleTime=state.lastTime
        end
        if count==0 or time>state.lastSampleTime then
            JLRSFrames.push(state.data.frames,{t=time,pose=durable});state.lastSampleTime=time
        end
    end
    state.last=durable;state.lastTime=time
end
