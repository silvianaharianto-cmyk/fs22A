JLRSCollision={}
-- Soft feedback rejects contact/suspension micro-jitter without moving bodies by pose.
function JLRSCollision.softError(value,deadband,gain,limit)
    local magnitude=math.max(0,math.abs(value)-deadband)
    return (value<0 and -1 or 1)*math.min(limit,magnitude*gain)
end
-- Native rigid-body angular velocity is a WORLD vector, not Euler rates.
function JLRSCollision.basis(node)
    local xx,xy,xz=localDirectionToWorld(node,1,0,0)
    local yx,yy,yz=localDirectionToWorld(node,0,1,0)
    local zx,zy,zz=localDirectionToWorld(node,0,0,1)
    return {xx,yx,zx,xy,yy,zy,xz,yz,zz}
end
function JLRSCollision.rotationVelocity(a,b,span)
    if span<=0 then return {0,0,0} end
    local m={}
    for row=0,2 do for col=0,2 do
        local sum=0
        for k=1,3 do sum=sum+b[row*3+k]*a[col*3+k] end
        m[row*3+col+1]=sum
    end end
    local w,x,y,z;local trace=m[1]+m[5]+m[9]
    if trace>0 then
        local t=math.sqrt(math.max(0,trace+1))*2
        w=t/4;x=(m[8]-m[6])/t;y=(m[3]-m[7])/t;z=(m[4]-m[2])/t
    elseif m[1]>m[5] and m[1]>m[9] then
        local t=math.sqrt(math.max(0,1+m[1]-m[5]-m[9]))*2
        w=(m[8]-m[6])/t;x=t/4;y=(m[2]+m[4])/t;z=(m[3]+m[7])/t
    elseif m[5]>m[9] then
        local t=math.sqrt(math.max(0,1+m[5]-m[1]-m[9]))*2
        w=(m[3]-m[7])/t;x=(m[2]+m[4])/t;y=t/4;z=(m[6]+m[8])/t
    else
        local t=math.sqrt(math.max(0,1+m[9]-m[1]-m[5]))*2
        w=(m[4]-m[2])/t;x=(m[3]+m[7])/t;y=(m[6]+m[8])/t;z=t/4
    end
    if w<0 then w=-w;x=-x;y=-y;z=-z end
    local length=math.sqrt(x*x+y*y+z*z)
    if length<0.00000001 then return {0,0,0} end
    local rate=2*math.atan2(length,w)/length/span
    return {x*rate,y*rate,z*rate}
end
function JLRSCollision.poseBasis(track,pose,n)
    -- Exact Euler-keyed reuse: straight-driving cars share the same native basis.
    -- Keep the engine conversion for every new orientation, including pitch/roll.
    local rx,ry,rz=pose[n+4],pose[n+5],pose[n+6]
    local cache=track.collisionBasisCache or {};track.collisionBasisCache=cache
    for _,item in ipairs(cache) do
        if item.rx==rx and item.ry==ry and item.rz==rz then return item.basis end
    end
    if not track.collisionHelper or not entityExists(track.collisionHelper) then
        track.collisionHelper=createTransformGroup('JLRS_Physics_Rotation');link(getRootNode(),track.collisionHelper)
    end
    setRotation(track.collisionHelper,pose[n+4],pose[n+5],pose[n+6])
    local basis=JLRSCollision.basis(track.collisionHelper)
    if #cache>=16 then table.remove(cache,1) end
    cache[#cache+1]={rx=rx,ry=ry,rz=rz,basis=basis}
    return basis
end
function JLRSCollision.toggle(c)
    if c.replaying or #(c.liveTracks or {})>0 then c:stop() end
    c.preciseReplay=not c.preciseReplay
    c.physicsReplay=not c.preciseReplay
    if c.preciseReplay then c:notify('REPLAY PRESISI | kendaraan dan obstacle mengikuti pose rekaman');return end
    c:notify('REPLAY PHYSICS '..(c.physicsReplay and 'ON | benturan dapat mengubah lintasan' or 'OFF | pose replay presisi'))
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...) load(c,...);c.physicsReplay=false;c.preciseReplay=true end
local detach=JLRSLive.detachPhysics
JLRSLive.detachPhysics=function(track)
    if track~=JLReplayStudio and JLReplayStudio.physicsReplay and not JLReplayStudio.preciseReplay then
        if type(setLinearVelocity)~='function' or type(setAngularVelocity)~='function' then
            track:notify('Replay physics batal: API velocity tidak tersedia.');return false
        end
        for _,entry in ipairs(track.entries) do
            if entry.world and getRigidBodyType(entry.node)~=RigidBodyType.DYNAMIC then
                track:notify('Replay physics batal: komponen bukan dynamic.');return false
            end
        end
        track.collisionReplay=true;return true
    end
    return detach(track)
end
function JLRSCollision.place(track,pose)
    -- Native wheel locations must not be displaced by a differently sized donor.
    track.collisionWheelNodes={}
    for _,vehicle in ipairs(track.recordVehicles or {track.target}) do
        for node in pairs(JLRSChange.wheelRoles(vehicle)) do track.collisionWheelNodes[node]=true end
    end
    local placement={};for i,value in ipairs(pose) do placement[i]=value end
    for i,entry in ipairs(track.entries) do
        if not entry.world and track.collisionWheelNodes[entry.node] and entityExists(entry.node) then
            local offset=(i-1)*6
            placement[offset+1],placement[offset+2],placement[offset+3]=getTranslation(entry.node)
        end
    end
    pose=placement
    -- One native detach/restore at a timeline reset, never per frame.
    local states={}
    for _,v in ipairs(track.recordVehicles or {track.target}) do
        states[#states+1]={v=v,added=v.isAddedToPhysics==true}
        if v.isAddedToPhysics then v:removeFromPhysics() end
    end
    JLRSRecorder.apply(track.entries,pose,true)
    for _,s in ipairs(states) do if s.added then s.v:addToPhysics() end end
    for _,e in ipairs(track.entries) do if e.world and entityExists(e.node) then
        setLinearVelocity(e.node,0,0,0);setAngularVelocity(e.node,0,0,0)
    end end
    track.collisionReleased=false;track.collisionVelocity={};track.collisionCorrection={}
end
local reset=JLRSLive.resetClock
JLRSLive.resetClock=function(c)
    reset(c)
    for _,track in ipairs(c.liveTracks) do if track.collisionReplay then JLRSCollision.place(track,JLRSFrames.get(track.frames,1).pose) end end
end
local play=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c==JLReplayStudio and c.physicsReplay and not c.liveDrive then JLRSLive.toggle(c) end
    return play(c,...)
end
-- Sleeping, stationary recorded components need no zero-velocity command.
-- Still inspect each frame: an incoming contact or recorded motion wakes the path.
function JLRSCollision.idle(node,pose,first,nextPose,n,x,y,z)
    if not getIsSleeping or getIsSleeping(node)~=true then return false end
    for j=1,6 do if first[n+j]~=nextPose[n+j] then return false end end
    if math.abs(pose[n+1]-x)>.01 or math.abs(pose[n+2]-y)>.01 or math.abs(pose[n+3]-z)>.01 then return false end
    local rx,ry,rz=getWorldRotation(node)
    local current={rx,ry,rz}
    for j=1,3 do
        local error=(pose[n+j+3]-current[j]+math.pi)%(2*math.pi)-math.pi
        if math.abs(error)>.003 then return false end
    end
    return true
end
local tick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,dt)
    if not track.collisionReplay then return tick(track,dt) end
    if not track.replaying then return end
    if not JLRSRecorder.valid(track.target) then JLRSRecorder.stopReplay(track);return end
    for _,entry in ipairs(track.entries) do
        if not entityExists(entry.node) or getParent(entry.node)~=entry.parent then
            JLRSRecorder.stopReplay(track);return
        end
    end
    if track.paused then
        for _,e in ipairs(track.entries) do if e.world and entityExists(e.node) then
            setLinearVelocity(e.node,0,0,0);setAngularVelocity(e.node,0,0,0)
        end end
        track.collisionVelocity={};track.collisionCorrection={};return
    end
    track.replayTime=track.replayTime+dt*track.replaySpeed
    if track.replayTime>=track.duration then
        if track.loop then
            track.replayTime=track.replayTime%track.duration;track.frameIndex=1
            JLRSCollision.place(track,JLRSFrames.get(track.frames,1).pose)
        else track.replayTime=track.duration;track.paused=true end
    end
    local pose=JLRSRecorder.sample(track,track.replayTime)
    track.replayAudioPose=pose;track.replayAudioTime=track.replayTime
    local localIndex=track.frameIndex or 1
    local localFirst=JLRSFrames.get(track.frames,localIndex).pose
    local localNext=JLRSFrames.get(track.frames,math.min(localIndex+1,JLRSFrames.count(track.frames))).pose
    -- A 150ms symmetric derivative window rejects noisy 60Hz body samples.
    -- Only body velocity uses this window: wheel poses/audio/activity keep exact time.
    -- Scale the window in timeline units so playback speed keeps the same real-time smoothing.
    local window=0.075*math.max(0.1,math.abs(track.replaySpeed))
    local previousTime=math.max(0,track.replayTime-window)
    local nextTime=math.min(track.duration,track.replayTime+window)
    local previousPose,nextPose -- Resolve only if a body needs active velocity control.
    local span=nextTime-previousTime
    -- A collision may displace the body; never abandon replay drive permanently.
    -- Retain native contacts and bounded/smoothed velocity correction, not teleports.
    track.collisionReleased=false
    track.collisionVelocity=track.collisionVelocity or {}
    track.collisionCorrection=track.collisionCorrection or {}
    local alpha=1-math.exp(-math.max(0,dt)*12)
    local feedbackAlpha=1-math.exp(-math.max(0,dt)*8)
    for i,e in ipairs(track.entries) do
        local n=(i-1)*6
        if e.world then
            local x,y,z=getWorldTranslation(e.node)
            local ex,ey,ez=pose[n+1]-x,pose[n+2]-y,pose[n+3]-z
            if track.paused then
                setLinearVelocity(e.node,0,0,0);setAngularVelocity(e.node,0,0,0)
                track.collisionVelocity[e.node]=nil;track.collisionCorrection[e.node]=nil
            elseif JLRSCollision.idle(e.node,pose,localFirst,localNext,n,x,y,z) then
                track.collisionVelocity[e.node]=nil;track.collisionCorrection[e.node]=nil
            elseif span>0 then
                if not previousPose then
                    local index=track.frameIndex
                    local final=JLRSFinalReplayPerf
                    if final and final.active()then
                        previousPose=final.bodySample(track,previousTime)
                        nextPose=final.bodySample(track,nextTime)
                    else
                        previousPose=JLRSRecorder.sample(track,previousTime)
                        nextPose=JLRSRecorder.sample(track,nextTime)
                    end
                    -- Derivative look-ahead must not move the main wheel/activity cursor.
                    track.frameIndex=index
                end
                local errors={ex,ey,ez};local desired={}
                local feedback=track.collisionCorrection[e.node]
                if not feedback then feedback={0,0,0,0,0,0};track.collisionCorrection[e.node]=feedback end
                local before=JLRSCollision.poseBasis(track,previousPose,n)
                local after=JLRSCollision.poseBasis(track,nextPose,n)
                local velocity=JLRSCollision.rotationVelocity(before,after,span)
                local target=JLRSCollision.poseBasis(track,pose,n)
                local rotationError=JLRSCollision.rotationVelocity(JLRSCollision.basis(e.node),target,1)
                local rotating=false
                for axis=4,6 do
                    if math.abs(JLRSRecorder.angle(localFirst[n+axis],localNext[n+axis],1)-localFirst[n+axis])>0.000000001 then rotating=true;break end
                end
                for axis=1,3 do
                    local linear=JLRSCollision.softError(errors[axis],0.01,1.5,1.5)
                    local angular=JLRSCollision.softError(rotationError[axis],0.003,2,2)
                    feedback[axis]=feedback[axis]+(linear-feedback[axis])*feedbackAlpha
                    feedback[axis+3]=feedback[axis+3]+(angular-feedback[axis+3])*feedbackAlpha
                    -- A future window must never start a parked car before its recorded start.
                    local moving=math.abs(localNext[n+axis]-localFirst[n+axis])>0.000000001
                    desired[axis]=(moving and (nextPose[n+axis]-previousPose[n+axis])/span*track.replaySpeed or 0)+feedback[axis]
                    desired[axis+3]=(rotating and velocity[axis]*track.replaySpeed or 0)+feedback[axis+3]
                end
                local smooth=track.collisionVelocity[e.node]
                if not smooth then smooth=desired;track.collisionVelocity[e.node]=smooth
                else for axis=1,6 do smooth[axis]=smooth[axis]+(desired[axis]-smooth[axis])*alpha end end
                setLinearVelocity(e.node,smooth[1],smooth[2],smooth[3])
                setAngularVelocity(e.node,smooth[4],smooth[5],smooth[6])
            else
                track.collisionVelocity[e.node]=nil;track.collisionCorrection[e.node]=nil
            end
        else
            if not (track.collisionWheelNodes and track.collisionWheelNodes[e.node]) then
                if JLRSFinalReplayPerf and JLRSFinalReplayPerf.localTranslation then JLRSFinalReplayPerf.localTranslation(e.node,pose[n+1],pose[n+2],pose[n+3]) else setTranslation(e.node,pose[n+1],pose[n+2],pose[n+3]) end
            end
            if JLRSFinalReplayPerf and JLRSFinalReplayPerf.localRotation then JLRSFinalReplayPerf.localRotation(e.node,pose[n+4],pose[n+5],pose[n+6]) else setRotation(e.node,pose[n+4],pose[n+5],pose[n+6]) end
        end
    end
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    if track.collisionReplay and track.replaying then
        if track.returnPose then JLRSCollision.place(track,track.returnPose) end
        track.collisionReplay=false;track.collisionVelocity=nil;track.collisionCorrection=nil
    end
    if track.collisionHelper then
        if entityExists(track.collisionHelper) then delete(track.collisionHelper) end
        track.collisionHelper=nil
    end
    track.collisionBasisCache=nil
    return stop(track,...)
end
local pause=JLReplayStudio.togglePause
JLReplayStudio.togglePause=function(c,...)
    local result=pause(c,...)
    if c.livePaused then
        for _,track in ipairs(c.liveTracks or {}) do if track.collisionReplay then
            for _,e in ipairs(track.entries) do if e.world and entityExists(e.node) then
                setLinearVelocity(e.node,0,0,0);setAngularVelocity(e.node,0,0,0)
            end end
        end end
    end
    return result
end
