-- Independent native-timestamp sampling for loose physics bodies. Vehicle and
-- activity cadence stays unchanged. Never synthesize catch-up collision poses.
JLRSPropSampling={STEP=1/60}
local S=JLRSPropSampling
local prepare=JLRSProps.prepare
JLRSProps.prepare=function(scene,...)
    if not scene.independentProps then return prepare(scene,...)end
end
local initialize=JLRSWorld.initialize
JLRSWorld.initialize=function(scene,...)
    local result=initialize(scene,...)
    local entries={}
    for _,e in ipairs(scene.entries or {})do
        if e.prop and e.world then entries[#entries+1]=e end
    end
    if #entries>0 then
        scene.independentProps=true;scene.independentPropEntries=entries
        scene.propSampleTime=0;scene.propNextSample=S.STEP
    end
    return result
end
function S.capture(c,force)
    local scene=c.worldRecord
    if not scene or not scene.independentProps or c.cacheFault then return end
    local now=c.recordTime or 0
    if now<=(scene.propSampleTime or 0)or (not force and now+1e-9<(scene.propNextSample or 0))then return end
    local previousTime=scene.propSampleTime or 0
    for _,e in ipairs(scene.independentPropEntries)do
        if entityExists(e.node)and getParent(e.node)==e.parent then
            local read=true
            if type(getIsSleeping)=='function'and getRigidBodyType(e.node)==RigidBodyType.DYNAMIC then
                local ok,sleeping=pcall(getIsSleeping,e.node)
                if ok then
                    read=not sleeping or e.propSampleSleeping~=true or force
                    e.propSampleSleeping=sleeping
                end
            end
            if read then
                local x,y,z=getWorldTranslation(e.node)
                local rx,ry,rz=getWorldRotation(e.node)
                local last=e.recordedPose
                if not last or x~=last[1]or y~=last[2]or z~=last[3]or rx~=last[4]or ry~=last[5]or rz~=last[6]then
                    local frame=JLRSFrames.get(e.samples,JLRSFrames.count(e.samples))
                    if frame and frame.t<previousTime-1e-6 then
                        JLRSFrames.push(e.samples,{t=previousTime,pose=last})
                    end
                    local p={x,y,z,rx,ry,rz}
                    JLRSFrames.push(e.samples,{t=now,pose=p});e.recordedPose=p;e.lastPose=p
                end
            end
        end
    end
    scene.propSampleTime=now
    local nextTime=(scene.propNextSample or 0)+S.STEP
    scene.propNextSample=nextTime>now and nextTime or now+S.STEP
end
local fill=JLRSWorld.fill
JLRSWorld.fill=function(c,...)
    if c.recording then S.capture(c,false)end
    return fill(c,...)
end
local stop=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    if c.recording then S.capture(c,true)end
    return stop(c,...)
end
