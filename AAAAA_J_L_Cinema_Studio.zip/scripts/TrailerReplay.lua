-- Sparse belt transitions and carrier-relative missing wheel-roll fallback.
JLRSTrailerReplay={visual=setmetatable({},{__mode='k'})}
local T=JLRSTrailerReplay
local NAME='jlrsTensionBelt'
local function belt(v,index)return v.spec_tensionBelts and (v.spec_tensionBelts.sortedBelts or {})[index]end
local function active(b)return b and b.mesh~=nil end
-- A recorded carrier can be replaced by any vehicle. Logical identity survives
-- Change Cars, but optional specializations and their native APIs do not.
local function supportsBelts(v)
    return v and type(v.spec_tensionBelts)=='table'
        and type(v.setTensionBeltsActive)=='function'
end
JLRSActivities.registerAdapter(NAME,{
    reuseReplayValues=true,
    discover=function(v)
        local out={};if not v.spec_tensionBelts or type(v.setTensionBeltsActive)~='function'then return out end
        for i in ipairs(v.spec_tensionBelts.sortedBelts or {})do out[#out+1]={index=i,name='belt',mode='step'}end
        return out
    end,
    read=function(v,ch)return {active(belt(v,ch.index))and 1 or 0,0,0,0,0,0}end,
    write=function(v,ch,p,paused,restoring)
        if not supportsBelts(v)then return end
        local b=belt(v,ch.index);if not b then return end
        if restoring then return end -- Stop restores the saved native state after body restoration.
        local on=p[1]>=.5
        if on==active(b)then
            if not on and T.visual[v]then T.visual[v][ch.index]=nil end
            return
        end
        if on and type(v.createTensionBelt)=='function'and type(v.getObjectToMount)=='function'then
            local objects=v:getObjectToMount(b)
            -- Geometry only: no second joint driving bodies owned by replay.
            v:createTensionBelt(b,false,objects or {},false)
            T.visual[v]=T.visual[v]or {};local cargo={};for _,data in pairs(objects or {})do if data.object then cargo[data.object]=true end end;T.visual[v][ch.index]=cargo
        elseif not on and type(v.removeTensionBelt)=='function'then v:removeTensionBelt(b,false)
        else v:setTensionBeltsActive(on,b.id or ch.index,true,false)end
        if not on and T.visual[v]then T.visual[v][ch.index]=nil end
        if type(v.updateFastenState)=='function'then v:updateFastenState()end
    end
})
function T.prepare(track)
    if track.beltOriginal then return end
    local data=track.frames and track.frames.jlrsActivities;if not data then return end
    local saved,seen={},{}
    for _,ch in ipairs(data.schema or {})do if ch.getter==NAME then
        local v=JLRSActivities.resolve(ch,track.recordVehicles or {track.target})
        if supportsBelts(v)and not seen[v]then
            seen[v]=true;local state={vehicle=v,belts={}}
            for i,b in ipairs(v.spec_tensionBelts.sortedBelts or {})do state.belts[i]=active(b)end
            saved[#saved+1]=state
            if type(v.setAllTensionBeltsActive)=='function'then v:setAllTensionBeltsActive(false,true)
            else for i,b in ipairs(v.spec_tensionBelts.sortedBelts or {})do v:setTensionBeltsActive(false,b.id or i,true,false)end end
            -- Cancel deferred native fastening of the end-of-record belt state.
            v.spec_tensionBelts.fastedAllBeltsIndex=0;v.spec_tensionBelts.beltsToLoad=nil
        end
    end end
    track.beltOriginal=saved
end
function T.restore(track)
    local saved=track.beltOriginal;track.beltOriginal=nil
    for _,state in ipairs(saved or {})do
        local v=state.vehicle;T.visual[v]=nil
        if JLRSRecorder.valid(v)and supportsBelts(v)then for i,on in ipairs(state.belts)do
            local b=belt(v,i)
            if b then
                -- An ON mesh made for replay has no native mount joint. Rebuild the
                -- native state even when its visible ON/OFF value already matches.
                if active(b)and type(v.removeTensionBelt)=='function'then v:removeTensionBelt(b,false)end
                v:setTensionBeltsActive(on,b.id or i,true,false)
            end
        end end
    end
end
local isolate=JLRSLive.detachPhysics
JLRSLive.detachPhysics=function(track,...)
    T.prepare(track);local ok,result=pcall(isolate,track,...)
    if not ok or result==false then T.restore(track)end
    if not ok then error(result)end;return result
end
local lock=JLRSRecorder.lockBodies
JLRSRecorder.lockBodies=function(track,...)
    T.prepare(track);local ok,result=pcall(lock,track,...)
    if not ok or result==false then T.restore(track)end
    if not ok then error(result)end;return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    local result=stop(track,...);T.restore(track);track.transportRoots=nil;return result
end
-- A carried car translates with the trailer, but that is not tyre travel.
-- Preserve measured wheel rotation. Only repair absent spin using relative travel.
function T.travel(track,vehicle,current,previous,travel)
    local state=track.transportRoots
    if not state or state.entries~=track.entries then
        state={entries=track.entries,roots={},carriers={}};track.transportRoots=state
        for i,e in ipairs(track.entries or {})do if e.world and e.vehicle and e.node==e.vehicle.rootNode then
            state.roots[e.vehicle]=(i-1)*6
            if e.vehicle.spec_tensionBelts or e.vehicle.spec_dynamicMountAttacher then state.carriers[#state.carriers+1]=e.vehicle end
        end end
    end
    local root=state.roots[vehicle];if not root or not previous then return travel end
    for _,carrier in ipairs(state.carriers)do if carrier~=vehicle then
        local o=state.roots[carrier];local dx=current[root+1]-current[o+1];local dy=current[root+2]-current[o+2];local dz=current[root+3]-current[o+3]
        local yaw=current[o+5];local cx=math.cos(yaw)*dx-math.sin(yaw)*dz;local cz=math.sin(yaw)*dx+math.cos(yaw)*dz
        local width=math.max(1,tonumber(carrier.sizeWidth)or 3)*.6
        local length=math.max(2,tonumber(carrier.sizeLength)or 10)*.6
        if math.abs(cx)<width and math.abs(cz)<length and dy>.2 and dy<6 then
            -- Relative travel still drives rolling while a vehicle climbs a
            -- deck; stale/end-state belt metadata must not force zero travel.
            local px=previous[root+1]-previous[o+1];local pz=previous[root+3]-previous[o+3];local a=previous[o+5]
            local mx=cx-(math.cos(a)*px-math.sin(a)*pz)
            local mz=cz-(math.sin(a)*px+math.cos(a)*pz)
            if math.sqrt(mx*mx+mz*mz)<.00001 then return 0 end
            local heading=current[root+5]-yaw
            return math.sqrt(mx*mx+mz*mz)*((mx*math.sin(heading)+mz*math.cos(heading))<0 and -1 or 1)
        end
    end end
    return travel
end
