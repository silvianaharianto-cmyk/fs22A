JLRSGround={CLEARANCE=0.75,RADIUS=0.4}
function JLRSGround.clamp(c)
    local mission=g_currentMission
    local terrain=mission and mission.terrainRootNode
    if not c.active or not c.camera or not terrain or terrain==0 or not entityExists(terrain)
        or type(getTerrainHeightAtWorldPos)~='function' then return end
    local x,y,z=c.x,c.y,c.z
    if not x or not y or not z then return end
    local minimum=-math.huge
    for _,offset in ipairs({{0,0},{JLRSGround.RADIUS,0},{-JLRSGround.RADIUS,0},{0,JLRSGround.RADIUS},{0,-JLRSGround.RADIUS}}) do
        local height=getTerrainHeightAtWorldPos(terrain,x+offset[1],0,z+offset[2])
        if type(height)=='number' and height==height then minimum=math.max(minimum,height+JLRSGround.CLEARANCE) end
    end
    if y>=minimum then return end
    c.y=minimum
    if c.angleStable then c.angleStable.y=minimum end
    -- Keep target framing when raising a locked camera out of a hillside.
    if c.lock then
        local tx,ty,tz=JLRSCamera.focus(c)
        if tx then c.pitch=math.max(-1.5,math.min(1.5,math.atan2(ty-c.y,math.sqrt((tx-x)^2+(tz-z)^2))+(c.offsetPitch or 0))) end
        if c.angleStable then c.angleStable.pitch=c.pitch end
    end
    setTranslation(c.camera,c.x,c.y,c.z);setRotation(c.camera,c.pitch,c.yaw,0)
end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,...)
    local result=tick(c,...);JLRSGround.clamp(c);return result
end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)
    local result=choose(c,...);JLRSGround.clamp(c);return result
end
local activate=JLRSCamera.activate
JLRSCamera.activate=function(c,...)
    local result=activate(c,...);JLRSGround.clamp(c);return result
end
