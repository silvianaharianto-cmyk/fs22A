-- Aggregate timings only. One log summary at Stop, no per-frame log/UI spam.
JLRSRecordStats={}
local D=JLRSRecordStats
local function clock() return type(getTimeSec)=='function' and getTimeSec() or nil end
local function elapsed(start)return start and math.max(0,(getTimeSec()-start)*1000) or 0 end
local function account(name,ms)
    local stats=D.active;if not stats then return end
    local s=stats[name] or {count=0,total=0,max=0,slow=0};stats[name]=s
    s.count=s.count+1;s.total=s.total+ms;s.max=math.max(s.max,ms)
    if ms>=16.7 then s.slow=s.slow+1 end
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    local result=start(c,...)
    if c==JLReplayStudio and c.recording then JLRSWriteBudget.peakBytes=JLRSWriteBudget.bytes;D.active={timer=type(getTimeSec)=='function',gapMax=0} end
    return result
end
local process=JLRSWriteBudget.process
JLRSWriteBudget.process=function(...)
    local t=clock();local result=process(...);account('cache',elapsed(t));return result
end
local capture=JLRSWorld.capture
JLRSWorld.capture=function(...)
    local t=clock();local result=capture(...);account('worldCapture',elapsed(t));return result
end
local fill=JLRSWorld.fill
JLRSWorld.fill=function(...)
    local t=clock();local result=fill(...);account('worldFill',elapsed(t));return result
end
local tick=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,dt,...)
    local t=clock();local result=tick(c,dt,...)
    if c==JLReplayStudio and D.active then
        D.active.gapMax=math.max(D.active.gapMax,(dt or 0)*1000)
        account('recordTick',elapsed(t))
    end
    return result
end
local stop=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    -- Snapshot excludes deliberate completion of pending chunks at Stop.
    local stats=c==JLReplayStudio and D.active or nil
    if stats then stats.queueChunks=#JLRSWriteBudget.queue;stats.queueBytes=JLRSWriteBudget.bytes;stats.peakBytes=JLRSWriteBudget.peakBytes;stats.spooling=JLRSWriteBudget.spooling;D.active=nil end
    local result=stop(c,...)
    if stats then
        print(string.format('[JLRS PERF V1.18.20] timer=%s inputGapMaxMs=%.3f queueChunks=%d queueEstimateBytes=%d peakEstimateBytes=%d spooling=%s',tostring(stats.timer),stats.gapMax,stats.queueChunks,stats.queueBytes,stats.peakBytes,tostring(stats.spooling)))
        for _,name in ipairs({'recordTick','cache','worldCapture','worldFill'}) do
            local s=stats[name]
            if s then print(string.format('[JLRS PERF] %s count=%d meanMs=%.3f maxMs=%.3f over16ms=%d',name,s.count,s.total/math.max(1,s.count),s.max,s.slow)) end
        end
    end
    return result
end
local cleanup=JLRSFrames.cleanup
JLRSFrames.cleanup=function(...)D.active=nil;return cleanup(...)end
