JLRSStopLoading={}
function JLRSStopLoading.request(c,all)
    if not c.recording then if all then c:stop() end;return end
    if not c.stopLoading then c.stopLoading={frames=0,all=all} end
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local state=c.stopLoading
    if not state then return draw(c,...)end
    JLRSMenu.rect(c,.30,.43,.40,.14,.015,.023,.037,.98)
    JLRSMenu.text(.33,.52,.023,'MENYIMPAN RECORD...')
    JLRSMenu.text(.33,.477,.014,'Mohon tunggu, jangan keluar dari game.')
    state.frames=state.frames+1
    if state.frames>=3 then
        local ok,err=pcall(function()if state.all then c:stop()else JLRSRecorder.stopRecord(c)end end)
        c.stopLoading=nil
        if not ok then c:notify('Stop / Save gagal: '..tostring(err))end
    end
end
local toggle=JLReplayStudio.toggleRecord
JLReplayStudio.toggleRecord=function(c,...)
    if c.stopLoading then return end
    if c.recording then return JLRSStopLoading.request(c,false)end
    return toggle(c,...)
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c.stopLoading then c:notify('Tunggu penyimpanan Record selesai.');return end
    return start(c,...)
end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if c.stopLoading then c.stopLoading=nil;c:stop()end
    return delete(c,...)
end
