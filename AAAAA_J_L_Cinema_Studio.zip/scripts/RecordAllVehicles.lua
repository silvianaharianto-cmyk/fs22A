-- One fixed topology and one shared clock. Normal Record remains V1.15.0.
JLRSRecordAll={}
local R=JLRSRecordAll
local topology=JLRSRecorder.topology
function R.collect(primary,mission)
    local entries,vehicles,seenNodes,seenVehicles={},{},{},{}
    local function add(v)
        if not JLRSRecorder.valid(v) or JLRSWorld.isTrain(v) or not v.components or seenVehicles[v] then return end
        local nodes,chain=topology(v)
        for _,object in ipairs(chain) do
            if not seenVehicles[object] then seenVehicles[object]=true;vehicles[#vehicles+1]=object end
        end
        for _,entry in ipairs(nodes) do
            if not seenNodes[entry.node] then seenNodes[entry.node]=true;entries[#entries+1]=entry end
        end
    end
    add(primary)
    local list={};local listed={}
    for v in pairs(JLRSWorld.vehicleSet()) do
        if JLRSRecorder.valid(v) and v.components and not listed[v] then listed[v]=true;list[#list+1]=v end
    end
    table.sort(list,function(a,b)return JLRSPersist.identity(a)<JLRSPersist.identity(b) end)
    -- Put complete tractor/implement chains into the snapshot before orphan implements.
    for _,v in ipairs(list) do
        local attached=false
        if type(v.getAttacherVehicle)=='function' then local ok,parent=pcall(v.getAttacherVehicle,v);attached=ok and parent~=nil end
        if not attached then add(v) end
    end
    for _,v in ipairs(list) do add(v) end
    return entries,vehicles
end
JLRSRecorder.topology=function(v)
    local c=JLReplayStudio
    if c.recordAllBuilding and v==g_currentMission.controlledVehicle then return R.collect(v,g_currentMission) end
    return topology(v)
end
function R.begin(c)
    if c.recording then
        c:notify(c.recordAllActive and 'Record All masih berjalan | Stop atau ESC untuk selesai.' or 'Hentikan Record biasa dengan Stop sebelum memulai Record All Vehicle.')
        return
    end
    if not c.mission or not JLRSRecorder.valid(g_currentMission.controlledVehicle) then c:notify('Masuk kendaraan dahulu untuk Record All Vehicle.');return end
    c.recordAllActive=true;c.recordAllBuilding=true;c.recordAllStarting=true
    local ok,err=pcall(JLRSRecorder.start,c)
    c.recordAllBuilding=nil;c.recordAllStarting=nil
    if not ok or not c.recording then
        c.recordAllActive=false
        if not ok then c:notify('Record All gagal dimulai: '..tostring(err)) end
        return
    end
    c.frames.jlrsRecordAll=true;c.recordAllCount=#c.recordVehicles
    c:notify('RECORD ALL VEHICLE | '..c.recordAllCount..' kendaraan | Tab bebas | Stop / ESC untuk selesai')
end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c.recordAllActive and c.recording and not c.recordAllStarting then c:notify('Record All masih berjalan | gunakan Stop / ESC.');return end
    return start(c,...)
end
local toggleRecord=JLReplayStudio.toggleRecord
JLReplayStudio.toggleRecord=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Record All masih berjalan | gunakan Stop / ESC.');return end
    return toggleRecord(c,...)
end
local startReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Selesaikan Record All dengan Stop / ESC sebelum Replay.');return end
    return startReplay(c,...)
end
local historyReplay=JLRSHistory.replay
JLRSHistory.replay=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Selesaikan Record All dengan Stop / ESC sebelum Replay.');return end
    return historyReplay(c,...)
end
local replayAll=JLRSGroup.all
JLRSGroup.all=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Selesaikan Record All dengan Stop / ESC sebelum Replay All.');return end
    return replayAll(c,...)
end
local archive=JLRSHistory.archive
JLRSHistory.archive=function(c,...)
    local result=archive(c,...)
    if c.frames and c.frames.jlrsRecordAll then
        for _,clip in ipairs(c.history or {}) do
            if clip.frames==c.frames and not clip.jlrsRecordAll then
                clip.jlrsRecordAll=true;clip.name='Record All Vehicle | '..#clip.vehicles..' kendaraan'
                if c==JLReplayStudio then JLRSPersist.safeSave(c) end
                break
            end
        end
    end
    return result
end
local stopRecord=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    local result=stopRecord(c,...)
    if not c.recording then c.recordAllActive=false;c.recordAllCount=nil end
    return result
end
local loadMap=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=loadMap(c,...)
    c.recordAllActive=false;c.recordAllBuilding=nil;c.recordAllStarting=nil;c.recordAllCount=nil
    return result
end
-- Primary engine audio stays unchanged. Other engines use optional activity channels.
local discover=JLRSActivities.discover
JLRSActivities.discover=function(vehicles)
    local schema=discover(vehicles)
    if not JLReplayStudio.recordAllActive then return schema end
    for _,v in ipairs(vehicles or {}) do
        local spec=v.spec_motorized;local motor=spec and spec.motor
        if v~=JLReplayStudio.target and motor and type(motor.getLastModulatedMotorRpm)=='function' then
            schema[#schema+1]={owner=JLRSPersist.identity(v),config=v.configFileName or v.xmlFilename or '',kind='allMotor',
                name='',index=0,mode='linear',getter='',setter='',object=v}
        end
    end
    return schema
end
local values=JLRSActivities.values
JLRSActivities.values=function(channel,v,buffer)
    if channel.kind~='allMotor' then return values(channel,v,buffer) end
    local spec=v and v.spec_motorized;local motor=spec and spec.motor
    if not motor or not motor.getLastModulatedMotorRpm then return {0,0,0,0,0,0} end
    local low,high=motor.minRpm or 0,motor.maxRpm or 1
    local rpm=(motor:getLastModulatedMotorRpm()-low)/math.max(1,high-low)
    return {math.max(0,math.min(1,rpm)),spec.smoothedLoadPercentage or spec.rawLoadPercentage or 0,spec.isMotorStarted and 1 or 0,0,0,0}
end
local apply=JLRSActivities.apply
JLRSActivities.apply=function(channel,v,pose,state,paused,restoring)
    if channel.kind~='allMotor' then return apply(channel,v,pose,state,paused,restoring) end
    if restoring or not JLRSRecorder.valid(v) or not v.spec_motorized then return end
    if not state.audioProxy then
        state.audioPose={0,0,0,0,0,0,0,0,0}
        state.audioProxy={target=v,entries={{node=v.rootNode,vehicle=v}},replayTime=0,replayAudioTime=0,replayAudioPose=state.audioPose}
    end
    state.audioPose[7]=pose[1];state.audioPose[8]=pose[2];state.audioPose[9]=pose[3]
    state.audioProxy.paused=paused;JLRSAudio.tick(state.audioProxy)
end
local restore=JLRSActivities.restore
JLRSActivities.restore=function(track)
    local state=track.activityReplay
    if state then for _,s in ipairs(state.channels) do if s.audioProxy then JLRSAudio.restore(s.audioProxy) end end end
    return restore(track)
end
local adapt=JLRSChange.adapt
JLRSChange.adapt=function(entries,frames,...)
    local result=adapt(entries,frames,...)
    if result and frames.jlrsRecordAll then result.frames.jlrsRecordAll=true end
    return result
end
-- Each independent car needs its own root displacement for the legacy wheel fallback.
-- The V1.15.0 fallback is left unchanged for normal recordings.
function R.wheels(track)
    if not track.frames.jlrsRecordAll or track.paused then return end
    local state=track.allWheelReplay
    if not state or state.entries~=track.entries then
        local initial=JLRSFrames.get(track.frames,1)
        state={entries=track.entries,wheels={},pose=initial.pose,time=initial.t};track.allWheelReplay=state
        local roots,roles={},{}
        for i,e in ipairs(track.entries) do if e.world and e.vehicle and e.node==e.vehicle.rootNode then roots[e.vehicle]=(i-1)*6 end end
        for _,v in ipairs(track.recordVehicles or {}) do
            for node,role in pairs(JLRSChange.wheelRoles(v)) do roles[node]={role=role,vehicle=v} end
        end
        for i,e in ipairs(track.entries) do
            local found=roles[e.node]
            if found and found.role.kind=='drive' and roots[found.vehicle] then
                state.wheels[#state.wheels+1]={node=e.node,offset=(i-1)*6,root=roots[found.vehicle],vehicle=found.vehicle,radius=math.max(0.001,found.role.radius)}
            end
        end
    end
    local pose=track.replayAudioTime==track.replayTime and track.replayAudioPose or JLRSRecorder.sample(track,track.replayTime)
    local previous=state.pose
    for _,wheel in ipairs(state.wheels) do
        if entityExists(wheel.node) then
            local o=wheel.offset;local rx=pose[o+4]
            if previous and state.time and track.replayTime>state.time then
                local r=wheel.root;local dx=pose[r+1]-previous[r+1];local dz=pose[r+3]-previous[r+3];local yaw=pose[r+5]
                local travel=math.sqrt(dx*dx+dz*dz)*((dx*math.sin(yaw)+dz*math.cos(yaw))<0 and -1 or 1)
                if JLRSTrailerReplay then travel=JLRSTrailerReplay.travel(track,wheel.vehicle,pose,previous,travel)end
                local delta=math.abs(JLRSRecorder.angle(previous[o+4],pose[o+4],1)-previous[o+4])
                if delta<0.000001 then
                    if math.abs(travel)>0.000001 then wheel.spin=(wheel.spin or previous[o+4])+travel/wheel.radius end
                    rx=wheel.spin or rx
                else wheel.spin=nil end
            elseif state.time==track.replayTime then rx=wheel.spin or rx
            else wheel.spin=nil end
            setRotation(wheel.node,rx,pose[o+5],pose[o+6])
        end
    end
    state.pose=pose;state.time=track.replayTime
end
local replayTick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
    local result=replayTick(track,...)
    if track.replaying and track.frames and track.frames.jlrsRecordAll then R.wheels(track) end
    return result
end
local stopReplay=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
    track.allWheelReplay=nil;return stopReplay(track,...)
end

local resetClock=JLRSLive.resetClock
JLRSLive.resetClock=function(c,...)
    local result=resetClock(c,...)
    for _,track in ipairs(c.liveTracks or {}) do if track.frames.jlrsRecordAll then R.wheels(track) end end
    return result
end
-- These actions normally end an active recording before altering its topology/mode.
-- In Record All they wait for the user's explicit Stop/ESC instead.
local changeOpen=JLRSChange.open
JLRSChange.open=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Selesaikan Record All dengan Stop / ESC sebelum Change Cars.');return end
    return changeOpen(c,...)
end
local changeBegin=JLRSChange.begin
JLRSChange.begin=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Selesaikan Record All dengan Stop / ESC sebelum Change Cars.');return end
    return changeBegin(c,...)
end
local liveToggle=JLRSLive.toggle
JLRSLive.toggle=function(c,...)
    if c.recordAllActive and c.recording then c:notify('Selesaikan Record All dengan Stop / ESC sebelum mengganti mode Live Drive.');return end
    return liveToggle(c,...)
end
local applyPlan=JLRSChange.applyPlan
JLRSChange.applyPlan=function(c,plan)
    local undo=applyPlan(c,plan)
    for _,p in ipairs(plan.clips or {}) do
        if p.clip.frames.jlrsRecordAll then p.clip.name='Record All Vehicle | '..#p.clip.vehicles..' kendaraan' end
    end
    return undo
end
