-- Camera edit decision list. Vehicle History and camera-angle memory remain separate.
JLRSFinal={}
local F=JLRSFinal
local function tracks(c)
    local out={};if c.replaying then out[#out+1]=c end
    for _,t in ipairs(c.liveTracks or {}) do if t.replaying then out[#out+1]=t end end
    return out
end
local function master(c)
    local best
    for _,t in ipairs(tracks(c)) do if not best or t.duration>best.duration then best=t end end
    return best
end
local function paused(c)
    local t=master(c)
    return not t or t.paused or c.livePaused or c.mission.isPaused or (g_gui and g_gui:getIsGuiVisible())
end
function F.pose(c,take)
    local node=getCamera()
    if not node or node==0 or not entityExists(node) then error('Kamera aktif tidak tersedia.') end
    local x,y,z=getWorldTranslation(node);local rx,ry,rz=getWorldRotation(node)
    local fov=type(getFovY)=='function' and getFovY(node) or math.rad(c.fov or 60)
    if not fov or fov<=0 or fov>=math.pi then fov=math.rad(c.fov or 60) end
    return {x,y,z,rx,ry,rz,fov,take.master.replayTime,take.shot,c.replaySpeed or 1,0,0}
end
function F.append(c,take)
    JLRSFrames.push(take.frames,{t=take.duration,pose=F.pose(c,take)})
end
function F.save(c)
    -- Never replace an unread existing catalog with the empty startup list.
    if c.finalLoadPending then F.load(c);if c.finalLoadPending then return false end end
    if c.finalReadFailed or not c.finalTakes  then return end
    local ok,err=pcall(function()
        local ready,why=JLRSFrames.prepare();if not ready then error(why) end
        local rev=(c.finalRevision or 0)+1
        local path=JLRSFrames.directory..(c.finalCatalogPrefix or 'final_')..(rev%2==0 and 'A.xml' or 'B.xml')
        local x=XMLFile.create('jlrsFinal',path,'final');if not x then error('Tidak dapat menulis Final.') end
        local written,why=pcall(function()
            x:setInt('final#nextId',c.finalNextId or 1);x:setInt('final#revision',rev);x:setInt('final#count',#c.finalTakes)
            for i,t in ipairs(c.finalTakes) do
                local k='final.take('..(i-1)..')'
                x:setString(k..'#name',t.name or string.format('Final #%03d',t.id));x:setInt(k..'#selected',(c.finalApplied or {})[t.id] and 1 or 0);x:setInt(k..'#id',t.id);x:setString(k..'#duration',tostring(t.duration));x:setString(k..'#start',tostring(t.sourceStart))
                x:setString(k..'#speed',tostring(t.speed));x:setInt(k..'#loop',t.loop and 1 or 0)
                x:setInt(k..'#clips',#t.clips);x:setInt(k..'#shots',t.shot);x:setInt(k..'#master',t.masterId)
                for j,id in ipairs(t.clips) do local ck=k..'.clip('..(j-1)..')';x:setInt(ck..'#id',id);x:setString(ck..'#start',tostring(t.starts[id] or t.sourceStart)) end
                JLRSPersist.writeStream(x,k..'.frames',t.frames)
                if JLRSFinalEditing then JLRSFinalEditing.writeTake(x,k,t) end
                if JLRSFinalCuts then JLRSFinalCuts.write(x,k,t)end
            end
            if x:save()==false then error('Penyimpanan Final gagal / disk penuh.') end
        end)
        x:delete();if not written then error(why) end
        local verify=XMLFile.load('jlrsFinalCheck',path)
        if not verify then error('Final tidak dapat dibaca setelah disimpan.') end
        local valid=verify:getInt('final#revision')==rev and verify:getInt('final#count')==#c.finalTakes
        verify:delete();if not valid then error('Verifikasi Final gagal.') end
        c.finalRevision=rev
        c.finalCatalogSaved=true
        for _,t in ipairs(c.finalTakes) do t.frames._jlrs.persistent=true end
    end)
    if not ok then c:notify('Final belum tersimpan: '..tostring(err)) end
    return ok
end
function F.load(c)
    if not c.finalLoadPending then return end
    if c.jlrsLoadPending then JLRSPersist.load(c) end
    if c.jlrsLoadPending then return end
    c.finalLoadPending=false
    local ready=JLRSFrames.prepare();if not ready then c.finalLoadPending=true;return end
    local catalogs={};local nextRecovery=1;local nextId=1
    local function add(prefix,generation)
        local exists=false
        for _,suffix in ipairs({'A.xml','B.xml'}) do
            local path=JLRSFrames.directory..prefix..suffix
            if fileExists(path) then
                exists=true
                local x=XMLFile.load('jlrsFinalLoad',path)
                if x then
                    nextId=math.max(nextId,x:getInt('final#nextId',1))
                    catalogs[#catalogs+1]={x=x,revision=x:getInt('final#revision',0),prefix=prefix,generation=generation}
                else c.finalReadFailed=true end
            end
        end
        return exists
    end
    local originalExists=add('final_',0)
    -- Recovery catalogs are not necessarily consecutive after a backup restore
    -- or manual cleanup. A missing generation must not hide later valid takes.
    -- Scan once at load, never on a replay tick; do not open absent files.
    for generation=1,1000 do
        if add('final_recovery_'..generation..'_',generation) then nextRecovery=generation+1 end
    end
    table.sort(catalogs,function(a,b)
        local preferred=c.finalCatalogSaved and c.finalCatalogPrefix
        if preferred and (a.prefix==preferred)~=(b.prefix==preferred) then return a.prefix==preferred end
        if a.generation~=b.generation then return a.generation>b.generation end
        return a.revision>b.revision
    end)
    local restored;local partial
    for _,catalog in ipairs(catalogs) do
        if not restored then
            local out={};local x=catalog.x;local count=x:getInt('final#count',-1)
            local complete=count>=0 and count<=100000 and count==math.floor(count)
            for i=1,complete and count or 0 do
                local ok,take=pcall(function()
                local k='final.take('..(i-1)..')'
                local t={name=x:getString(k..'#name'),selected=x:getInt(k..'#selected',0)==1,id=x:getInt(k..'#id'),duration=tonumber(x:getString(k..'#duration')),sourceStart=tonumber(x:getString(k..'#start')),speed=tonumber(x:getString(k..'#speed')),loop=x:getInt(k..'#loop')==1,shot=x:getInt(k..'#shots',1),masterId=x:getInt(k..'#master'),clips={},starts={}}
                if not t.id or not t.duration or t.duration<0 or not t.sourceStart or not t.speed or t.speed<=0 then error('Metadata Final rusak.') end
                for j=1,x:getInt(k..'#clips',0) do local ck=k..'.clip('..(j-1)..')';local id=x:getInt(ck..'#id');if not id then error('ID History Final hilang.') end;t.clips[j]=id;t.starts[id]=tonumber(x:getString(ck..'#start')) or t.sourceStart end
                if #t.clips==0 then error('Final tanpa History kendaraan.') end
                t.frames=JLRSPersist.readStream(x,k..'.frames');t.frames._jlrs.persistent=true
                if JLRSFinalEditing then JLRSFinalEditing.readTake(x,k,t) end
                if JLRSFinalCuts then JLRSFinalCuts.read(x,k,t)end
                local a=JLRSFrames.get(t.frames,1);local b=JLRSFrames.get(t.frames,JLRSFrames.count(t.frames))
                if #a.pose~=12 or #b.pose~=12 then error('Frame kamera Final rusak.') end

                    return t
                end)
                if ok then out[#out+1]=take;nextId=math.max(nextId,take.id+1)
                else complete=false;c.finalLoadError=tostring(take) end
            end
            if complete then
                c.finalTakes=out;c.finalRevision=catalog.revision;c.finalCatalogPrefix=catalog.prefix
                restored=true;c.finalReadFailed=false
            elseif not partial then partial=out end
        end
        catalog.x:delete()
    end
    if not restored and (originalExists or nextRecovery>1 or c.finalReadFailed) then
        if nextRecovery>1000 then
            c.finalReadFailed=true;c:notify('Pemulihan Final gagal: terlalu banyak katalog pemulihan. Berkas lama dilindungi.')
        else
            -- Never overwrite either damaged catalog. Recover readable takes
            -- and store all subsequent edits/recordings in a new generation.
            c.finalTakes=partial or {};c.finalRevision=0;c.finalReadFailed=false
            c.finalCatalogPrefix='final_recovery_'..nextRecovery..'_'
            c:notify('Final memakai penyimpanan pemulihan | berkas lama dilindungi | Record Final dapat dilanjutkan')
        end
    end
    c.finalNextId=math.max(c.finalNextId or 1,nextId)
    c.finalApplied={}
    c.finalNextId=c.finalNextId or 1
    for _,t in ipairs(c.finalTakes) do c.finalNextId=math.max(c.finalNextId,t.id+1);if t.selected then c.finalApplied[t.id]=true end end
    c.finalSelected=#c.finalTakes
end
function F.finish(c)
    local t=c.finalRecording;if not t then return end
    c.finalRecording=nil;t.master=nil;t.lastSource=nil
    if JLRSFrames.count(t.frames)>=2 and t.duration>0 then
        c.finalTakes[#c.finalTakes+1]=t;c.finalSelected=#c.finalTakes;c.finalNextId=t.id+1
        F.save(c);c:notify('FINAL tersimpan | '..JLRSMiniHud.formatTime(t.duration)..' | '..t.shot..' shot')
    else JLRSFrames.release(t.frames);c:notify('Final terlalu pendek; Replay dahulu lalu Record Final.') end
end
function F.record(c)
    if c.editingSession and JLRSFinalEditing then return JLRSFinalEditing.record(c) end
    F.load(c)
    if c.finalRecording then F.finish(c);return end
    if c.finalPlaying then c:notify('Stop Final dahulu sebelum Record Final.');return end
    if c.recording or c.miniScrub then c:notify('Selesaikan Record kendaraan / timeline dahulu.');return end
    local owner=master(c);if not owner then c:notify('Mulai Replay kendaraan dahulu.');return end
    if (c.replaySpeed or 1)<=0 then c:notify('Kecepatan Replay harus lebih dari nol.');return end
    if c.finalReadFailed then c:notify('Katalog Final rusak; rekaman lama dilindungi.');return end
    local ids={};local seen={};local starts={};local masterId
    for _,track in ipairs(tracks(c)) do
        local found
        for _,clip in ipairs(c.history or {}) do if clip.frames==track.frames and JLRSHistory.valid(clip) then found=clip.id;break end end
        if not found then c:notify('Simpan semua track kendaraan di History dahulu.');return end
        if not seen[found] then ids[#ids+1]=found;seen[found]=true;starts[found]=track.replayTime end
        if track==owner then masterId=found end
    end
    local ready,why=JLRSFrames.prepare();if not ready then c:notify(tostring(why));return end
    local t={id=c.finalNextId or 1,clips=ids,starts=starts,masterId=masterId,frames=JLRSFrames.new(12),duration=0,sourceStart=owner.replayTime,speed=c.replaySpeed or 1,loop=c.loop==true,shot=1,master=owner,lastSource=owner.replayTime,wasPaused=paused(c)}
    c.finalRecording=t
    local ok,err=pcall(F.append,c,t)
    if not ok then c.finalRecording=nil;JLRSFrames.release(t.frames);c:notify('Record Final gagal: '..tostring(err));return end
    c:notify('RECORD FINAL | Pause = siapkan cut | Play = lanjut shot | Stop Final = simpan')
end
function F.sample(t,time)
    local count=JLRSFrames.count(t.frames);local index=math.max(1,math.min(t.cameraIndex or 1,count))
    local steps=0
    while index<count and steps<8 and JLRSFrames.get(t.frames,index+1).t<=time do index=index+1;steps=steps+1 end
    if JLRSFrames.get(t.frames,index).t>time or (index<count and JLRSFrames.get(t.frames,index+1).t<=time) then
        local low,high=1,count;index=1
        -- Upper bound selects the new shot at a duplicate cut timestamp.
        while low<=high do local mid=math.floor((low+high)/2)
            if JLRSFrames.get(t.frames,mid).t<=time then index=mid;low=mid+1 else high=mid-1 end
        end
    end
    t.cameraIndex=index
    local a=JLRSFrames.get(t.frames,index);local b=JLRSFrames.get(t.frames,math.min(index+1,count))
    local p={};local blend=b.t>a.t and a.pose[9]==b.pose[9]
    local alpha=blend and math.max(0,math.min(1,(time-a.t)/(b.t-a.t))) or 0
    for i=1,12 do
        local delta=b.pose[i]-a.pose[i]
        if i>=4 and i<=6 then delta=(delta+math.pi)%(2*math.pi)-math.pi end
        p[i]=a.pose[i]+delta*alpha
    end
    return p
end
local function applyCamera(c,play)
    local p=F.sample(play.take,play.time)
    setTranslation(play.camera,p[1],p[2],p[3]);setRotation(play.camera,p[4],p[5],p[6]);setFovY(play.camera,p[7]);if getCamera()~=play.camera then setCamera(play.camera) end
end
function F.endPlay(c)
    local p=c.finalPlaying;if not p then return end
    c.finalPlaying=nil
    local normal=(c.active and c.camera) or JLRSCamera.gameplay() or p.previousCamera
    if normal and entityExists(normal) then setCamera(normal) end
    if p.camera and entityExists(p.camera) then delete(p.camera) end
    local s=p.settings;c.physicsReplay=s.physics;c.replaySpeed=s.speed;c.loop=s.loop
    c.mode=s.mode;c.lock=s.lock;c.angleEnabled=s.angle;c.nativeShortcuts=s.keys
    c.x=s.x;c.y=s.y;c.z=s.z;c.yaw=s.yaw;c.pitch=s.pitch;c.fov=s.fov
    return s
end
function F.stop(c)
    if c.finalRecording then F.finish(c)
    elseif c.finalPlaying then c:stop() end
end
function F.play(c)
    F.load(c)
    if c.finalRecording then F.finish(c) end
    if c.recording then c:notify('Stop Record kendaraan dahulu.');return end
    local t=(c.finalTakes or {})[c.finalSelected or 0]
    if not t then c:notify('Belum ada Record Final.');return end
    if t.editingPlan and JLRSFinalEditing then return JLRSFinalEditing.playTake(c,t) end
    if t.editingFilm and JLRSFinalClips then return JLRSFinalClips.playTake(c,t) end
    local selection={};local sources={};local used={}
    for _,id in ipairs(t.clips) do
        local valid=false
        for _,clip in ipairs(c.history or {}) do if clip.id==id and JLRSHistory.valid(clip) then valid=true;sources[id]=clip;break end end
        if not valid then c:notify('Final membutuhkan History #'..tostring(id)..' dan kendaraan penggantinya.');return end
        for _,vehicle in ipairs(sources[id].vehicles or {sources[id].target}) do
            if used[vehicle] then c:notify('Kendaraan History Final saling tumpang tindih; gunakan take berbeda.');return end
            used[vehicle]=true
        end
        selection[id]=true
    end
    if c.finalPlaying then c:stop() end
    local settings={physics=c.physicsReplay,speed=c.replaySpeed,loop=c.loop,mode=c.mode,lock=c.lock,angle=c.angleEnabled,live=c.liveDrive,keys=c.nativeShortcuts,x=c.x,y=c.y,z=c.z,yaw=c.yaw,pitch=c.pitch,fov=c.fov}
    c:stop();c.physicsReplay=not c.preciseReplay;c.replaySpeed=t.speed;c.loop=t.loop;c.angleEnabled=false
    -- Final playback follows the selected precise/dynamic mode. Seek only at startup.
    local ok,err=pcall(function()
        JLRSGroup.all(c,selection)
        local owner;local assigned={}
        for _,track in ipairs(tracks(c)) do for id,clip in pairs(sources) do if track.frames==clip.frames then assigned[id]=track;if id==t.masterId then owner=track end end end end
        for _,id in ipairs(t.clips) do if not assigned[id] then error('Track History Final saling tumpang tindih.') end end
        owner=owner or master(c);if not owner then error('Track kendaraan tidak tersedia.') end
        for id,track in pairs(assigned) do
            local startTime=t.starts[id] or t.sourceStart
            local time=math.min(track.duration,startTime)
            if t.loop and track.duration>0 then time=startTime%track.duration end
            JLRSRecorder.seek(track,time)
            if track.cargoReplay then JLRSWorld.tick(c,track.replayTime,track.cargoReplay) end
        end
        if c.worldReplay then JLRSWorld.tick(c,c.worldReplay.owner.replayTime) end
        local camera=createCamera('JLRSFinalCamera',math.rad(c.fov or 60),0.1,6000);link(getRootNode(),camera)
        c.finalPlaying={take=t,time=0,master=owner,lastSource=owner.replayTime,camera=camera,previousCamera=getCamera(),settings=settings,livePausedBefore=c.livePaused}
        applyCamera(c,c.finalPlaying)
    end)
    if not ok then
        c:stop();c.physicsReplay=settings.physics;c.replaySpeed=settings.speed;c.loop=settings.loop;c.mode=settings.mode;c.lock=settings.lock;c.angleEnabled=settings.angle;c.liveDrive=settings.live;c.nativeShortcuts=settings.keys
        c:notify('Replay Final gagal: '..tostring(err));return
    end
    c:notify('REPLAY FINAL | cut tanpa jeda | Space Pause/Play | Stop Final untuk selesai')
end
local function elapsed(t)
    local now=t.master.replayTime;local delta=now-t.lastSource
    if delta<0 and t.loop and t.master.duration>0 then delta=delta+t.master.duration end
    t.lastSource=now;return math.max(0,delta)/(t.speed or t.take.speed)
end
function F.tick(c)
    if c.finalRecording and JLRSWriteBudget and c.finalBudgetTime~=(g_time or 0) then
        c.finalBudgetTime=g_time or 0
        JLRSWriteBudget.service()
    end
    if JLRSFinalEditing and ((c.finalRecording and c.finalRecording.editingPlan) or (c.finalPlaying and c.finalPlaying.take.editingPlan)) then return JLRSFinalEditing.finalTick(c) end
    local t=c.finalRecording
    if t then
        if not t.master.replaying then F.finish(c);return end
        if c.replaySpeed~=t.speed or (c.loop==true)~=t.loop then F.finish(c);c:notify('Final disimpan sebelum perubahan speed / loop.');return end
        local isPaused=paused(c);local delta=elapsed(t)
        if not t.wasPaused and delta>0 then
            t.duration=t.duration+delta
            if t.pendingCut then t.shot=t.shot+1;t.pendingCut=nil end
            local ok,err=pcall(F.append,c,t)
            if not ok then F.finish(c);c:notify('Final dihentikan: '..tostring(err));return end
        end
        if t.wasPaused and not isPaused then t.shot=t.shot+1;F.append(c,t) end
        t.wasPaused=isPaused
        if not t.loop and t.master.replayTime>=t.master.duration then F.finish(c) end
    end
    local p=c.finalPlaying
    if p then
        if not p.master.replaying then c:stop();return end
        -- A camera take fixes the original playback speed and excludes UI pauses.
        c.replaySpeed=p.take.speed;c.loop=p.take.loop
        p.speed=p.take.speed;p.loop=p.take.loop
        p.time=math.min(p.take.duration,p.time+elapsed(p))
        applyCamera(c,p)
        if p.time>=p.take.duration then
            c.livePaused=true;c.paused=true
            for _,track in ipairs(tracks(c)) do track.paused=true end
            if not p.ended then p.ended=true;c:notify('Replay Final selesai | Replay Final untuk ulang | Stop Final untuk normal') end
        end
    end
end
function F.draw(c)
    c.finalHudHits={}
    if not c.miniHudEnabled or c.shortcutHudHidden or c.menu or not c.overlay or (g_gui and g_gui:getIsGuiVisible()) then return end
    local x,y,w,h=0.704,0.012,0.28,0.117
    JLRSMenu.rect(c,x,y,w,h,0.012,0.02,0.038,0.95)
    local t=c.finalRecording or (c.finalPlaying and c.finalPlaying.take) or c.finalTakes[c.finalSelected or 0]
    local status=c.finalRecording and 'REC FINAL' or c.finalPlaying and 'REPLAY FINAL' or 'FINAL CAMERA'
    if c.finalRecording and paused(c) then status='PAUSE / SIAPKAN CUT' end
    local time=c.finalRecording and c.finalRecording.duration or c.finalPlaying and c.finalPlaying.time or t and t.duration or 0
    JLRSMenu.text(x+0.008,y+h-0.026,0.012,status,c.finalRecording and 1 or 0.25,c.finalRecording and 0.2 or 0.85,0.95)
    local function button(bx,by,bw,label,callback,on)
        JLRSMenu.rect(c,bx,by,bw,0.028,on and 0.42 or 0.06,on and 0.09 or 0.13,on and 0.10 or 0.26,0.95)
        JLRSMenu.text(bx+0.005,by+0.009,0.009,label)
        c.finalHudHits[#c.finalHudHits+1]={x=bx,y=by,w=bw,h=0.028,callback=callback}
    end
    button(x+0.007,y+0.047,0.128,'RECORD FINAL',function()F.record(c)end,c.finalRecording~=nil)
    button(x+0.143,y+0.047,0.128,'REPLAY FINAL',function()if c.finalListReady then F.play(c) elseif JLRSFinalList then JLRSFinalList.open(c) else F.play(c) end end,c.finalPlaying~=nil)
    button(x+0.007,y+0.012,0.082,(c.paused or c.livePaused) and 'PLAY' or 'PAUSE / CUT',function()c:togglePause()end)
    button(x+0.097,y+0.012,0.082,'STOP FINAL',function()F.stop(c)end)
    button(x+0.187,y+0.012,0.036,'<',function()if not c.finalRecording and not c.finalPlaying then c.finalSelected=math.max(1,(c.finalSelected or 1)-1)end end)
    button(x+0.231,y+0.012,0.040,'>',function()if not c.finalRecording and not c.finalPlaying then c.finalSelected=math.min(#c.finalTakes,(c.finalSelected or 0)+1)end end)
    button(x+0.218,y+h-0.031,0.053,'LIST',function()if JLRSFinalList then JLRSFinalList.open(c)end end,c.finalListOpen)
    JLRSMenu.text(x+0.177,y+h-0.026,0.009,t and string.format('#%03d',t.id) or '---')
end
function F.install(c)
    if not c.mission or c.finalMouseWrapper then return end
    local previous=c.mission.mouseEvent
    c.finalMouseWrapper=function(m,x,y,isDown,isUp,button,...)
        if JLRSMiniHud.interacting(c) then
            for _,hit in ipairs(c.finalHudHits or {}) do
                if x>=hit.x and x<=hit.x+hit.w and y>=hit.y and y<=hit.y+hit.h then
                    if isDown and button==Input.MOUSE_BUTTON_LEFT then hit.callback() end
                    return
                end
            end
        end
        return previous(m,x,y,isDown,isUp,button,...)
    end
    c.mission.mouseEvent=c.finalMouseWrapper
    local deleteMap=c.deleteMap
    c.deleteMap=function(self,...)
        if self.mission and self.mission.mouseEvent==self.finalMouseWrapper then self.mission.mouseEvent=previous end
        self.finalMouseWrapper=nil;self.deleteMap=deleteMap;return deleteMap(self,...)
    end
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    load(c,...);c.finalTakes={};c.finalNextId=1;c.finalSelected=0;c.finalLoadPending=true;c.finalRevision=0;c.finalCatalogPrefix='final_';c.finalCatalogSaved=false;c.finalLoadError=nil;c.finalReadFailed=false;c.finalRecording=nil;c.finalPlaying=nil;c.finalHudHits={}
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    if c.finalPlaying then c.replaySpeed=c.finalPlaying.take.speed;c.loop=c.finalPlaying.take.loop end
    draw(c,...)
    if not c.mission then return end
    F.load(c);F.install(c)
    local ok,err=pcall(F.tick,c)
    if not ok then F.stop(c);c:notify('Final dihentikan: '..tostring(err)) end
    F.draw(c)
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    if c.finalRecording then F.finish(c) end
    -- Remove the Final camera before previous camera owners delete their nodes.
    local settings=F.endPlay(c);local result=stop(c,...)
    if settings then c.liveDrive=settings.live end
    return result
end
local pause=JLReplayStudio.togglePause
JLReplayStudio.togglePause=function(c,...)
    local t=c.finalRecording
    if t then
        -- Flush the outgoing shot while its view is still active.
        F.tick(c)
        t=c.finalRecording
    end
    local result=pause(c,...)
    if t then
        local isPaused=paused(c)
        if t.wasPaused and not isPaused then t.shot=t.shot+1;F.append(c,t) end
        t.wasPaused=isPaused;t.lastSource=t.master.replayTime
    end
    return result
end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,...)if c.finalPlaying then return end;return tick(c,...)end
local axis=JLRSCamera.mouseAxis
JLRSCamera.mouseAxis=function(c,...)if c.finalPlaying then return end;return axis(c,...)end
local begin=JLRSMiniHud.begin
JLRSMiniHud.begin=function(c,...)if c.finalRecording or c.finalPlaying then c:notify('Stop Final dahulu untuk menggeser timeline.');return end;return begin(c,...)end
local start=JLRSRecorder.start
JLRSRecorder.start=function(c,...)if c==JLReplayStudio and (c.finalRecording or c.finalPlaying) then c:notify('Stop Final dahulu sebelum Record kendaraan.');return end;if c==JLReplayStudio then F.load(c) end;return start(c,...)end
local prune=JLRSUnlimited.prune
JLRSUnlimited.prune=function(c,...)
    -- Existing prune walks History. Include camera streams only during the call,
    -- then remove the temporary keep references without archiving vehicle data.
    local history=c.history;local refs={};for i,v in ipairs(history or {})do refs[i]=v end
    for _,t in ipairs(c.finalTakes or {}) do refs[#refs+1]={frames=t.frames} end
    if c.finalRecording then refs[#refs+1]={frames=c.finalRecording.frames} end
    c.history=refs;local ok,err=pcall(prune,c,...);c.history=history;if not ok then error(err)end
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    F.finish(c);F.endPlay(c);F.save(c)
    c.finalHudHits={};return deleteMap(c,...)
end

local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,...)
    if c==JLReplayStudio and c.finalPlaying then return end
    local result=choose(c,...)
    if c==JLReplayStudio and c.finalRecording and not paused(c) then c.finalRecording.pendingCut=true end
    return result
end
for _,entry in ipairs({{JLRSGroup,'next'},{JLRSGroup,'camera'},{JLRSAngle,'random'},{JLRSAngle,'toggle'},{JLRSCamera,'toggleLock'}}) do
    local object,name=entry[1],entry[2];local previous=object[name]
    object[name]=function(c,...)if c.finalPlaying then return end;return previous(c,...)end
end
local startReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c==JLReplayStudio and (c.finalRecording or c.finalPlaying) then c:notify('Stop Final dahulu sebelum mengganti Replay.');return end
    return startReplay(c,...)
end
local liveToggle=JLRSLive.toggle
JLRSLive.toggle=function(c,...)
    if c.finalRecording or c.finalPlaying then c:notify('Stop Final dahulu sebelum mengganti Live Drive.');return end
    return liveToggle(c,...)
end
local physicsToggle=JLRSCollision.toggle
JLRSCollision.toggle=function(c,...)
    if c.finalRecording or c.finalPlaying then c:notify('Stop Final dahulu sebelum mengganti Physics.');return end
    return physicsToggle(c,...)
end
