-- Final's deferred render pass must complete before the cargo roll correction.
-- Once per draw, without advancing clocks or touching physics/recorded frames.
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local result=draw(c,...)
    if not c.jlrsRenderBoundary then
        JLRSCargoWheels.flush(c)
        if JLRSVehicleDirt and JLRSVehicleDirt.flush then JLRSVehicleDirt.flush(c)end
    end
    return result
end
