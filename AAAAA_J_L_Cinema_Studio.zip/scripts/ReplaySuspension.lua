-- Optional activity channels: native wheel graphics data and hydraulic scales.
-- Existing motion streams, wheel-shape physics and old History stay compatible.
JLRSReplaySuspension={}
local S=JLRSReplaySuspension
local function wheel(v,ch)
    return v.spec_wheels and (v.spec_wheels.wheels or {})[ch.index]
end
local function suspensionNode(v,ch)
    if ch.name=='node' then
        local part=v.spec_suspensions and (v.spec_suspensions.suspensionNodes or {})[ch.index]
        return part and part.node
    end
    local depth=tonumber(ch.name:match('^wheelParent(%d+)$'))
    local w=depth and wheel(v,ch);local node=w and w.repr
    for i=1,depth or 0 do if not node or not entityExists(node) then return end;node=getParent(node) end
    return node
end
function S.discover(v)
    local out={};local seen={}
    if v.rootNode then seen[v.rootNode]=true end
    for _,component in ipairs(v.components or {}) do if component.node then seen[component.node]=true end end
    for i,w in ipairs(v.spec_wheels and v.spec_wheels.wheels or {}) do
        if w.netInfo and type(w.netInfo.suspensionLength)=='number' then
            out[#out+1]={name='wheel',index=i,mode='transform'}
        end
        local node=w.repr
        for depth=1,8 do
            if not node or not entityExists(node) then break end
            node=getParent(node)
            if not node or node==0 or not entityExists(node) or node==v.rootNode then break end
            local component=false;for _,part in ipairs(v.components or {}) do if node==part.node then component=true;break end end
            if component then break end
            if not seen[node] then seen[node]=true;out[#out+1]={name='wheelParent'..depth,index=i,mode='transform'} end
        end
    end
    for i,part in ipairs(v.spec_suspensions and v.spec_suspensions.suspensionNodes or {}) do
        if part.node and entityExists(part.node) then out[#out+1]={name='node',index=i,mode='transform'} end
    end
    if type(getScale)=='function' and type(setScale)=='function' then
        for _,kind in ipairs({'movingParts','movingTools'}) do
            for i,part in ipairs(v.spec_cylindered and v.spec_cylindered[kind] or {}) do
                if part.node and entityExists(part.node) then out[#out+1]={name=kind,index=i,mode='linear'} end
            end
        end
    end
    return out
end
function S.readInto(v,ch,out)
    if ch.name=='node' or ch.name:match('^wheelParent%d+$') then
        local node=suspensionNode(v,ch)
        if node and entityExists(node) then
            out[1],out[2],out[3]=getTranslation(node);out[4],out[5],out[6]=getRotation(node)
        else for i=1,6 do out[i]=0 end end
    elseif ch.name=='wheel' then
        local w=wheel(v,ch);local n=w and w.netInfo or {}
        out[1]=n.x or 0;out[2]=n.y or 0;out[3]=n.z or 0
        out[4]=n.xDrive or 0;out[5]=n.suspensionLength or 0;out[6]=w and w.steeringAngle or 0
    else
        local part=v.spec_cylindered and (v.spec_cylindered[ch.name] or {})[ch.index]
        if part and part.node and entityExists(part.node) and getScale then
            out[1],out[2],out[3]=getScale(part.node)
        else out[1],out[2],out[3]=1,1,1 end
        out[4],out[5],out[6]=0,0,0
    end
    return out
end
function S.read(v,ch)return S.readInto(v,ch,{})end
function S.write(v,ch,p,paused,restoring)
    -- Native geometry/deformation parameters belong to this exact model.
    -- Cross-model Change Cars retains its established safe motion conversion.
    if (v.configFileName or v.xmlFilename or '')~=ch.config then return end
    if ch.name=='node' or ch.name:match('^wheelParent%d+$') then
        local node=suspensionNode(v,ch)
        if node and entityExists(node) then
            JLRSActivities.localPose(node,p,false)
        end
    elseif ch.name=='wheel' then
        local w=wheel(v,ch);if not w or not w.netInfo then return end
        local changed=restoring or w.jlrsReplaySuspension==nil
        if restoring then w.jlrsReplaySuspension=nil else
            local state=w.jlrsReplaySuspension or {};w.jlrsReplaySuspension=state
            for i=1,6 do if state[i]~=p[i] then changed=true end;state[i]=p[i] end
        end
        w.netInfo.x,w.netInfo.y,w.netInfo.z=p[1],p[2],p[3]
        w.netInfo.xDrive,w.netInfo.suspensionLength=p[4],p[5];w.steeringAngle=p[6]
        if changed and WheelsUtil and WheelsUtil.updateVisualWheel then
            WheelsUtil.updateVisualWheel(v,w,p[1],p[2],p[3],p[4],p[5])
        end
    else
        local part=v.spec_cylindered and (v.spec_cylindered[ch.name] or {})[ch.index]
        if part and part.node and entityExists(part.node) and setScale then
            local x,y,z
            if getScale then x,y,z=getScale(part.node) end
            if x~=p[1] or y~=p[2] or z~=p[3] then setScale(part.node,p[1],p[2],p[3]) end
        end
    end
end
JLRSActivities.registerAdapter('jlrsSuspension',{discover=S.discover,read=S.read,readInto=S.readInto,write=S.write})
