-- Preserve moving recorded rotator poses; recover missing/constant legacy
-- rotation and multiBlink on the source clock without vehicle simulation.
JLRSReplacementBeacons={}
local B=JLRSReplacementBeacons
local function valid(n)return n and entityExists(n)end
local function blink(b,time)
    local s=b.shader
    if not s then return end
    local phase=time*s.rate
    local alpha=math.max(0,math.min(1,math.sin(phase)-math.max(phase%((s.on+s.off)*2*math.pi)-(s.on*2-1)*math.pi,0)+.2))
    setShaderParameter(s.node,'lightControl',s.intensity*alpha,s.y,s.z,s.w,false)
    if setLightColor and b.beacon.defaultColor then
        local c=b.beacon.defaultColor
        for _,n in ipairs(s.lights)do if valid(n)then setLightColor(n,c[1]*alpha,c[2]*alpha,c[3]*alpha)end end
    end
end
local tick=JLRSActivities.tick
JLRSActivities.tick=function(track,...)
    local result=tick(track,...)
    local state=track.activityReplay
    if not state then return result end
    if not state.replacementBeacons then
        local recorded={};local list={}
        for i,ch in ipairs(state.data.schema)do
            local v=state.channels[i]and state.channels[i].vehicle
            if v and ch.kind=='rotator' and ch.config==(v.configFileName or v.xmlFilename or '')then
                recorded[v]=recorded[v]or {};recorded[v][ch.index]=state.channels[i]
            end
        end
        for v in pairs(state.renderVehicles)do
            for i,b in pairs(v.spec_lights and v.spec_lights.beaconLights or {})do
                if valid(b.rotatorNode)or b.multiBlink then
                    local x,y,z=0,0,0
                    if valid(b.rotatorNode)then x,y,z=getRotation(b.rotatorNode)end
                    local source=recorded[v]and recorded[v][i]
                    local p=source and source.values
                    local entry={vehicle=v,beacon=b,node=b.rotatorNode,x=x,y=y,z=z,source=source,
                        initial=p and {p[1],p[2],p[3]}or nil}
                    local shader=b.lightShaderNode
                    if b.multiBlink and valid(shader)and getShaderParameter and setShaderParameter
                        and getHasShaderParameter and getHasShaderParameter(shader,'blinkOffset')and getHasShaderParameter(shader,'lightControl')then
                        local on,off,rate=getShaderParameter(shader,'blinkOffset')
                        local intensity,sy,sz,sw=getShaderParameter(shader,'lightControl')
                        if rate and rate>0 and on+off>0 then
                            local lights={};if valid(b.realLightNode)then
                                lights[1]=b.realLightNode
                                if getNumOfChildren and getChildAt then for ci=0,getNumOfChildren(b.realLightNode)-1 do lights[#lights+1]=getChildAt(b.realLightNode,ci)end end
                            end
                            entry.shader={node=shader,on=on,off=off,rate=rate,intensity=b.intensity or intensity,
                                original=intensity,y=sy,z=sz,w=sw,lights=lights}
                        end
                    end
                    list[#list+1]=entry
                end
            end
        end
        state.replacementBeacons=list
    end
    for _,b in ipairs(state.replacementBeacons)do
        local p=b.source and b.source.values
        if p and b.initial and not b.recordedMotion then
            for i=1,3 do
                if math.abs((p[i]-b.initial[i]+math.pi)%(2*math.pi)-math.pi)>1e-6 then b.recordedMotion=true end
            end
        end
        local owner=JLRSSecondaryEffects and JLRSSecondaryEffects.owners[b.vehicle]
        if not owner or owner.track==track or not owner.track.replaying then
            if b.vehicle.spec_lights.beaconLightsActive then
                if not b.recordedMotion and valid(b.node)then setRotation(b.node,b.x,(b.y+(b.beacon.speed or .015)*(track.replayTime or 0)*1000)%(2*math.pi),b.z)end
                blink(b,track.replayTime or 0)
            end
        end
    end
    return result
end
local restore=JLRSActivities.restore
JLRSActivities.restore=function(track,...)
    local state=track.activityReplay
    for _,b in ipairs(state and state.replacementBeacons or {})do
        local owner=JLRSSecondaryEffects and JLRSSecondaryEffects.owners[b.vehicle]
        if not owner or owner.track==track or not owner.track.replaying then
            if not b.recordedMotion and valid(b.node)then setRotation(b.node,b.x,b.y,b.z)end
            local s=b.shader
            if s and valid(s.node)then setShaderParameter(s.node,'lightControl',s.original,s.y,s.z,s.w,false)end
        end
    end
    return restore(track,...)
end
