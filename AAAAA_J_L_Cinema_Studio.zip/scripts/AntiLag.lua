-- Allocation/scan optimization only; no physics simplification or frame dropping.
JLRSAntiLag={}
function JLRSAntiLag.toggle(c)
    c.antiLag=not c.antiLag
    c:notify('ANTI LAG '..(c.antiLag and 'ON | buffer pose dioptimalkan' or 'OFF | sampler standar'))
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.antiLag=true;return result
end
