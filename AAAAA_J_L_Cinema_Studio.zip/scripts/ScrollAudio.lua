-- Optical wheel zoom stays independent of native camera translation/audio distance.
-- No sample recreation, radius/volume override, or motor restart.
JLRSScrollAudio={}
local S=JLRSScrollAudio
function S.active(c)
    return c and c.mission and (c.active or c.finalPlaying) and not c.menu
        and not (g_gui and g_gui:getIsGuiVisible())
end
function S.wheel(c,button)
    return S.active(c) and Input and (button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN)
end
function S.install()
    local owner=VehicleCamera
    if not owner or type(owner.zoomSmoothly)~='function' or owner.zoomSmoothly==S.wrapper then return end
    -- Native zoom may arrive via an action event outside mission.mouseEvent.
    local original=owner.zoomSmoothly
    local wrapper=function(camera,...)
        local c=JLReplayStudio;local m=g_currentMission
        if S.active(c) and m and camera.vehicle==m.controlledVehicle then return end
        return original(camera,...)
    end
    S.owner=owner;S.original=original;S.wrapper=wrapper;owner.zoomSmoothly=wrapper
end
local refresh=JLRSMouse.refresh
JLRSMouse.refresh=function(c,...) S.install();return refresh(c,...) end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...) local result=load(c,...);S.install();return result end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    if S.owner and S.owner.zoomSmoothly==S.wrapper then S.owner.zoomSmoothly=S.original end
    S.owner=nil;S.original=nil;S.wrapper=nil
    return unload(c,...)
end
S.install()
