-- Render-boundary Final processing. Preserve clocks, shot cuts and all existing
-- replay writers; capture/apply the Final camera only after their final pass.
JLRSReplayRenderOrder={LIMIT=16,decoded={},order={}}
local R=JLRSReplayRenderOrder
local get=JLRSFrames.get
JLRSFrames.get=function(frames,index,...)
    local frame=get(frames,index,...)
    -- Pending lossless compact frames otherwise allocate a complete pose each
    -- time .pose is read. Keep only sixteen decoded keys, never a full recording.
    if not frame or rawget(frame,'pose')~=nil or not getmetatable(frame) then return frame end
    local cached=R.decoded[frame]
    if cached then return cached end
    local pose=frame.pose
    if type(pose)~='table' then return frame end
    cached={t=frame.t,pose=pose};R.decoded[frame]=cached
    R.order[#R.order+1]=frame
    if #R.order>R.LIMIT then R.decoded[table.remove(R.order,1)]=nil end
    return cached
end
local finalTick=JLRSFinal.tick
JLRSFinal.tick=function(c,...)
    if c.jlrsRenderBoundary then c.jlrsFinalTickPending=true;return end
    return finalTick(c,...)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local previous=c.jlrsRenderBoundary
    if not previous then c.jlrsRenderAimDt=nil;c.jlrsRenderAimCut=nil end
    c.jlrsRenderBoundary=true
    local ok,result=pcall(draw,c,...)
    c.jlrsRenderBoundary=previous
    if not previous then c.jlrsRenderAimDt=nil;c.jlrsRenderAimCut=nil end
    if not ok then c.jlrsFinalTickPending=nil;error(result,0)end
    if not previous and c.jlrsFinalTickPending then
        c.jlrsFinalTickPending=nil
        local success,why=pcall(JLRSFinal.tick,c)
        if not success then JLRSFinal.stop(c);c:notify('Final dihentikan: '..tostring(why))end
    end
    return result
end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(c,...)
    R.decoded={};R.order={};return stop(c,...)
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    c.jlrsRenderBoundary=nil;c.jlrsFinalTickPending=nil;R.decoded={};R.order={}
    return unload(c,...)
end
