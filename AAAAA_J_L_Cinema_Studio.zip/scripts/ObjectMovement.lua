-- Object shooting is camera-only: replay targets, tracks and physics are untouched.
JLRSObject={order={1,3,5,7,9,11,2,4,6,8,10}}
function JLRSObject.cursor(c)
    if not c.objectEnabled or c.menu or (g_gui and g_gui:getIsGuiVisible()) then return false end
    return c.objectPicking or (Input.KEY_lalt and Input.isKeyPressed(Input.KEY_lalt))
        or (Input.KEY_ralt and Input.isKeyPressed(Input.KEY_ralt)) or false
end
function JLRSObject.open(c)
    c.objectEnabled=true;c.objectHud=true;c.objectPicking=true;c.objectMode=c.objectMode or 2
    c.menu=false;c.historyOpen=false;c:notify('OBJECT MOVEMENT | pilih preset lalu klik objek | F9 mulai | 9 HUD')
    JLRSMouse.refresh(c)
end
function JLRSObject.stop(c,restore)
    if not c.objectRunning then return end
    JLRSAngle.save(c)
    c.objectRunning=false;c.objectTick=false
    local saved=c.objectReturn;c.objectReturn=nil
    JLRSCamera.deactivate(c)
    if saved then
        c.mode=saved.mode;c.lock=saved.lock;c.angleEnabled=saved.angleEnabled
        c.distance=saved.distance;c.height=saved.height;c.fov=saved.fov;c.motionFov=saved.fov
        c.groupCamera=saved.groupCamera;c.cameraTarget=saved.cameraTarget
        if restore and (c.replaying or (c.groupCamera and #(c.liveTracks or {})>0)) then
            JLRSCamera.activate(c);JLRSCamera.choose(c,c.mode)
        else c.groupCamera=false end
    end
end
function JLRSObject.start(c)
    if not JLRSRecorder.valid(c.objectTarget) then c:notify('Pilih objek dahulu melalui klik di map.');return end
    if not c.objectRunning then
        c.objectReturn={mode=c.mode,lock=c.lock,angleEnabled=c.angleEnabled,distance=c.distance,height=c.height,fov=c.fov,
            groupCamera=c.groupCamera,cameraTarget=c.cameraTarget}
        if c.angleEnabled and c.active then JLRSAngle.save(c) end
        c.groupCamera=false;c.objectRunning=true;c.angleEnabled=false
        JLRSCamera.activate(c)
    end
    c.objectPicking=false;c.lock=true
    JLRSCamera.choose(c,c.objectMode or 2)
    c:notify('OBJECT MOVEMENT | '..c.objectTarget.name..' | '..JLRSCamera.names[c.mode])
    JLRSMouse.refresh(c)
end
function JLRSObject.pick(c,x,y)
    local camera=c.active and c.camera or JLRSCamera.gameplay()
    if not camera or not entityExists(camera) or type(raycastClosest)~='function' then
        c:notify('Pemilihan objek tidak tersedia.');return
    end
    local ox,oy,oz,dx,dy,dz
    if RaycastUtil and RaycastUtil.getCameraPickingRay then
        ox,oy,oz,dx,dy,dz=RaycastUtil.getCameraPickingRay(x,y,camera)
    elseif type(unProject)=='function' then
        ox,oy,oz=getWorldTranslation(camera);dx,dy,dz=unProject(x,y,1)
    end
    if not dz then c:notify('Ray kamera tidak tersedia.');return end
    local length=math.sqrt(dx*dx+dy*dy+dz*dz)
    if length<0.000001 then return end
    local picker={}
    function picker:onHit(node,hx,hy,hz,distance)
        if not node or node==0 or not entityExists(node) or node==c.mission.terrainRootNode then return true end
        local root=node;local object
        local parent=node
        for _=1,32 do
            if parent==0 or not entityExists(parent) then break end
            object=c.mission.nodeToObject and c.mission.nodeToObject[parent]
            if object then break end
            parent=getParent(parent)
        end
        if object then
            local candidate=object.rootNode or object.nodeId or (object.components and object.components[1] and object.components[1].node)
            if candidate and entityExists(candidate) then root=candidate end
        end
        local rx,ry,rz=getWorldTranslation(root)
        local lx,ly,lz=worldDirectionToLocal(root,hx-rx,hy-ry,hz-rz)
        local name=object and object.getName and object:getName() or (type(getName)=='function' and getName(node)) or 'Objek map'
        picker.target={rootNode=root,localX=lx,localY=ly,localZ=lz,name=tostring(name)}
        return false
    end
    local mask=CollisionMask and CollisionMask.ALL or 4294967295
    if CollisionMask and CollisionMask.TRIGGERS then mask=mask-CollisionMask.TRIGGERS end
    raycastClosest(ox,oy,oz,dx/length,dy/length,dz/length,'onHit',1000,picker,mask)
    if not picker.target then c:notify('Objek tidak terdeteksi. Klik permukaan objek yang memiliki collision.');return end
    if c.objectRunning then JLRSObject.stop(c,true) end
    c.objectTarget=picker.target;c.objectPicking=false
    c:notify('Objek dipilih: '..picker.target.name..' | F9 mulai movement')
    JLRSMouse.refresh(c)
end
function JLRSObject.draw(c)
    c.objectHits={}
    if not c.objectEnabled or not c.objectHud or c.menu or not c.overlay then return end
    local hits=c.hitboxes;c.hitboxes={}
    JLRSMenu.rect(c,0.018,0.215,0.284,0.532,0.015,0.025,0.04,0.96)
    JLRSMenu.rect(c,0.018,0.744,0.284,0.003,0,0.76,0.82)
    JLRSMenu.text(0.030,0.713,0.016,'OBJECT MOVEMENT',0.12,0.85,0.9)
    local label=c.objectTarget and c.objectTarget.name or 'Belum ada objek dipilih'
    JLRSMenu.text(0.030,0.689,0.011,label:sub(1,35))
    for i,id in ipairs(JLRSObject.order) do
        JLRSMenu.button(c,0.030+((i-1)%2)*0.133,0.635-math.floor((i-1)/2)*0.042,0.127,0.034,JLRSCamera.names[id],function()
            c.objectMode=id
            if c.objectRunning then JLRSCamera.choose(c,id) end
        end,c.objectMode==id)
    end
    JLRSMenu.button(c,0.030,0.368,0.127,0.034,'Pilih Objek',function() c.objectPicking=true end,c.objectPicking)
    JLRSMenu.button(c,0.163,0.368,0.127,0.034,'Mulai / F9',function() JLRSObject.start(c) end,c.objectRunning)
    JLRSMenu.button(c,0.030,0.325,0.127,0.034,'Stop Camera',function() JLRSObject.stop(c,true) end)
    JLRSMenu.button(c,0.163,0.325,0.127,0.034,'Tutup Fitur',function()
        JLRSObject.stop(c,true);c.objectEnabled=false;c.objectHud=false;c.objectPicking=false
    end)
    JLRSMenu.text(0.030,0.298,0.010,c.objectPicking and 'Klik kiri objek di map untuk memilih.' or 'Tahan ALT untuk klik HUD / pilih objek.')
    JLRSMenu.text(0.030,0.275,0.010,'F9 mulai | 9 tampil / sembunyikan HUD')
    JLRSMenu.text(0.030,0.252,0.010,'WASDQE + mouse + scroll: kamera')
    JLRSMenu.text(0.030,0.228,0.009,'©Copyright 2023 | Jupryan Lowlight',0.65,0.74,0.83)
    c.objectHits=c.hitboxes;c.hitboxes=hits
end
local focus=JLRSCamera.focus
JLRSCamera.focus=function(c)
    if c.objectRunning and JLRSRecorder.valid(c.objectTarget) then
        local t=c.objectTarget;local x,y,z=getWorldTranslation(t.rootNode)
        local dx,dy,dz=localDirectionToWorld(t.rootNode,t.localX,t.localY,t.localZ)
        return x+dx,y+dy,z+dz
    end
    return focus(c)
end
local angleTarget=JLRSAngle.target
JLRSAngle.target=function(c) return c.objectRunning and c.objectTarget or angleTarget(c) end
local choose=JLRSCamera.choose
JLRSCamera.choose=function(c,index,...)
    if not c.objectRunning then return choose(c,index,...) end
    c.objectMode=index
    local target=c.target;c.target=c.objectTarget
    local result=choose(c,index,...);c.target=target;return result
end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,...)
    if not c.objectRunning then return tick(c,...) end
    if not c.objectTick then return end -- Replay and ensemble draw must not tick twice.
    local target=c.target;local paused,livePaused=c.paused,c.livePaused
    c.target=c.objectTarget;c.paused=false;c.livePaused=false
    local result=tick(c,...)
    c.target=target;c.paused=paused;c.livePaused=livePaused;return result
end
local axis=JLRSCamera.mouseAxis
JLRSCamera.mouseAxis=function(c,...)
    if JLRSObject.cursor(c) then return end
    return axis(c,...)
end
local refresh=JLRSMouse.refresh
JLRSMouse.refresh=function(c,...)
    local result=refresh(c,...)
    if c.objectEnabled and not c.menu and g_inputBinding and not (g_gui and g_gui:getIsGuiVisible()) then
        JLRSMouse.syncCursor(c)
    end
    return result
end
local groupCamera=JLRSGroup.camera
JLRSGroup.camera=function(c,...)
    JLRSObject.stop(c,false);return groupCamera(c,...)
end
local groupNext=JLRSGroup.next
JLRSGroup.next=function(c,...)
    JLRSObject.stop(c,false);return groupNext(c,...)
end
local locked=JLRSInputGuard.isLocked
JLRSInputGuard.isLocked=function()
    return JLReplayStudio.objectRunning or locked()
end
local own=JLRSInputGuard.isOwn
JLRSInputGuard.isOwn=function(target,action)
    if JLReplayStudio.objectRunning then
        for _,name in ipairs({'AXIS_ACCELERATE_VEHICLE','AXIS_BRAKE_VEHICLE','AXIS_MOVE_SIDE_VEHICLE','AXIS_MOVE_FORWARD_PLAYER','AXIS_MOVE_SIDE_PLAYER'}) do
            if action==name or (InputAction and action==InputAction[name]) then return false end
        end
    end
    return own(target,action)
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)
    local now=g_time or 0;local dt=c.objectClock and math.max(0,(now-c.objectClock)/1000) or 0;c.objectClock=now
    local gui=g_gui and g_gui:getIsGuiVisible()
    local f9=Input.KEY_f9 and Input.isKeyPressed(Input.KEY_f9) or false
    local nine=(Input.KEY_9 or Input.KEY_9_STANDARD);nine=nine and Input.isKeyPressed(nine) or false
    local start=f9 and not c.objectF9;local hide=nine and not c.objectNine
    c.objectF9=f9;c.objectNine=nine
    if c.objectEnabled then
        -- Reserve F9 only while Object Movement is enabled; restore old behavior on close.
        c.keyState.KEY_f9=f9;c.groupKeys=c.groupKeys or {};c.groupKeys.KEY_f9=f9
        if not c.menu and not gui then
            if hide then c.objectHud=not c.objectHud;c.objectPicking=false end
            if start then JLRSObject.start(c) end
        end
    end
    draw(c,...)
    if not c.mission or gui then return end
    if c.objectRunning then
        if not JLRSRecorder.valid(c.objectTarget) then JLRSObject.stop(c,true);c:notify('Object movement berhenti: objek dihapus.')
        elseif not c.mission.isPaused then c.objectTick=true;JLRSCamera.tick(c,math.min(dt,0.1));c.objectTick=false end
    end
    JLRSObject.draw(c);if c.objectEnabled then JLRSMouse.refresh(c) end
end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    load(c,...);if not c.mission then return end
    c.objectEnabled=false;c.objectHud=false;c.objectPicking=false;c.objectRunning=false;c.objectTarget=nil;c.objectHits={}
    c.objectF9=false;c.objectNine=false;c.objectClock=nil;c.objectConsumeRelease=false
    c.objectOldMouse=c.mission.mouseEvent
    c.objectMouse=function(m,x,y,isDown,isUp,button,...)
        if c.objectConsumeRelease and isUp and button==Input.MOUSE_BUTTON_LEFT then c.objectConsumeRelease=false;return end
        if not c.menu and not (g_gui and g_gui:getIsGuiVisible()) and JLRSObject.cursor(c) then
            c.mouseX=x;c.mouseY=y;c.miniMouseX=x;c.miniMouseY=y
            if button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN then
                return c.objectOldMouse(m,x,y,isDown,isUp,button,...)
            end
            if isDown and button==Input.MOUSE_BUTTON_LEFT then
                c.objectConsumeRelease=true
                -- Visible toolbar controls own their clicks before map picking.
                -- Object-selection cursor also permits clicking the Mini HUD.
                if c.miniHudEnabled then
                    for _,hit in ipairs(c.miniHudHits or {}) do
                        if x>=hit.x and x<=hit.x+hit.w and y>=hit.y and y<=hit.y+hit.h then
                            hit.callback();return
                        end
                    end
                end
                for _,hit in ipairs(c.objectHits or {}) do
                    if c.objectHud and x>=hit.x and x<=hit.x+hit.w and y>=hit.y and y<=hit.y+hit.h then hit.callback();return end
                end
                JLRSObject.pick(c,x,y)
            end
            return
        end
        return c.objectOldMouse(m,x,y,isDown,isUp,button,...)
    end
    c.mission.mouseEvent=c.objectMouse
    c.objectOldKey=c.mission.keyEvent
    c.objectKey=function(m,unicode,sym,modifier,isDown,...)
        if c.objectEnabled and not (g_gui and g_gui:getIsGuiVisible()) and (sym==Input.KEY_f9 or sym==Input.KEY_9) then return end
        if c.objectOldKey then return c.objectOldKey(m,unicode,sym,modifier,isDown,...) end
    end
    c.mission.keyEvent=c.objectKey
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)
    JLRSObject.stop(c,false);return stop(c,...)
end
local startRecord=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c==JLReplayStudio then JLRSObject.stop(c,false) end
    return startRecord(c,...)
end
local replay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(c,...)
    if c==JLReplayStudio then JLRSObject.stop(c,false) end
    return replay(c,...)
end
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    JLRSObject.stop(c,false)
    if c.mission and c.mission.mouseEvent==c.objectMouse then c.mission.mouseEvent=c.objectOldMouse end
    if c.mission and c.mission.keyEvent==c.objectKey then c.mission.keyEvent=c.objectOldKey end
    c.objectEnabled=false;c.objectHud=false;c.objectPicking=false;c.objectTarget=nil;c.objectHits={}
    c.objectKey=nil;c.objectOldKey=nil
    deleteMap(c,...);c.objectOldMouse=nil;c.objectMouse=nil
end
