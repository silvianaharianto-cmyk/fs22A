-- Cache only idempotent local geometry/animation setters in isolated precise
-- playback. Active/changed values still pass through on every rendered frame.
JLRSStaticActivityReplay={vehicles=setmetatable({},{__mode='k'}),frame=0}
local P=JLRSStaticActivityReplay
local apply=JLRSActivities.apply
JLRSActivities.apply=function(ch,v,values,state,paused,restoring)
    local c=JLReplayStudio
    local eligible=ch.kind=='animation' or ch.kind=='tool' or ch.kind=='part' or ch.kind=='rotator'
    if not eligible or not v then return apply(ch,v,values,state,paused,restoring)end
    if restoring then P.vehicles[v]=nil;return apply(ch,v,values,state,paused,restoring)end
    if not c.preciseReplay or c.recording or (c.liveDrive and g_currentMission and g_currentMission.controlledVehicle==v)then
        P.vehicles[v]=nil;return apply(ch,v,values,state,paused,restoring)
    end
    local key=ch.jlrsStaticKey
    if not key then key=ch.kind..':'..(ch.config or '')..':'..(ch.name or '')..':'..tostring(ch.index or 0);ch.jlrsStaticKey=key end
    local vehicle=P.vehicles[v];if not vehicle then vehicle={};P.vehicles[v]=vehicle end
    local previous=vehicle[key]
    local effects=JLRSSecondaryEffects
    local writer=effects and effects.track
    if previous and previous.writer==writer and previous.paused==paused and P.frame%16~=0 then
        local equal=true
        for i=1,6 do if previous[i]~=values[i]then equal=false;break end end
        if equal then return end
    end
    local result=apply(ch,v,values,state,paused,restoring)
    -- A suppressed background writer did not move the node. Its values must
    -- not replace the cache of the direct replay which actually owns the ramp.
    local owner=effects and effects.owners[v]
    if writer and owner and owner.track~=writer and owner.track.replaying then return result end
    previous=previous or {};vehicle[key]=previous
    for i=1,6 do previous[i]=values[i]end
    previous.paused=paused;previous.writer=writer
    return result
end
local draw=JLReplayStudio.draw
JLReplayStudio.draw=function(c,...)P.frame=P.frame+1;return draw(c,...)end
local stop=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(t,...)P.vehicles=setmetatable({},{__mode='k'});return stop(t,...)end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)P.vehicles=setmetatable({},{__mode='k'});P.frame=0;return delete(c,...)end
