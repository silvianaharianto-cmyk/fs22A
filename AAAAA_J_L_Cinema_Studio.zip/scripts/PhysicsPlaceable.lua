-- Optional placeable motion in the existing sparse world/history/Final stream.
JLRSPhysicsPlaceable={}
local P=JLRSPhysicsPlaceable
local PREFIX='placeableMotion:'
function P.isEntry(e) return e.propField and e.propField:sub(1,#PREFIX)==PREFIX end
local function marked(group)
    for _,e in ipairs(group.entries or {})do
        if e.propField and e.propField:sub(1,#PREFIX)==PREFIX then return true end
    end
    return false
end
local function pathNode(o,path)
    local node=o.rootNode or o.nodeId or o.node
    if path==''then return node end
    if type(getChildAt)~='function'then return end
    for index in path:gmatch('%d+')do
        if not node or not entityExists(node)then return end
        node=getChildAt(node,tonumber(index))
    end
    return node
end
local field=JLRSProps.fieldNode
JLRSProps.fieldNode=function(o,key)
    if key and key:sub(1,#PREFIX)==PREFIX then return pathNode(o,key:sub(#PREFIX+1))end
    return field(o,key)
end
local collect=JLRSWorld.collect
JLRSWorld.collect=function(c,...)
    local scene=collect(c,...)
    if not c.physicsPlaceable then return scene end
    if type(getNumOfChildren)~='function'or type(getChildAt)~='function'then
        c:notify('Physics Placeable: API hierarki objek tidak tersedia.');return scene
    end
    local owned,groups={},{}
    for _,e in ipairs(c.entries or {})do owned[e.node]=true end
    for _,g in ipairs(scene.groups)do groups[g.object]=g;for _,e in ipairs(g.entries)do owned[e.node]=true end end
    for _,track in ipairs(c.liveTracks or {})do
        for _,state in ipairs(track.cargoReplay and track.cargoReplay.states or {})do
            for _,e in ipairs(state.group.entries)do owned[e.node]=true end
        end
    end
    local placeables=c.mission and c.mission.placeableSystem and c.mission.placeableSystem.placeables or {}
    for _,o in pairs(placeables)do if type(o)=='table'and not o.isDeleted then
        local root=o.rootNode or o.nodeId or o.node
        local targets={}
        for _,animated in ipairs(o.spec_animatedObjects and o.spec_animatedObjects.animatedObjects or {})do
            for _,part in ipairs(animated.animation and animated.animation.parts or {})do if part.node then targets[part.node]=true end end
        end
        if root and entityExists(root)then
            local additions={};local visited={}
            local function walk(node,path)
                if visited[node]then return end;visited[node]=true
                local body=getRigidBodyType(node)
                if owned[node] and targets[node] and groups[o]then
                    for _,e in ipairs(groups[o].entries)do if e.node==node then
                        e.propField=PREFIX..path;e.prop=nil
                    end end
                end
                if not owned[node] and (targets[node] or body==RigidBodyType.KINEMATIC) and body~=RigidBodyType.STATIC then
                    additions[#additions+1]={node=node,world=true,parent=getParent(node),propField=PREFIX..path}
                    owned[node]=true
                end
                for i=0,getNumOfChildren(node)-1 do walk(getChildAt(node,i),path==''and tostring(i)or path..'/'..i)end
            end
            walk(root,'')
            if #additions>0 then
                local group=groups[o]
                if not group then group={object=o,entries={},prop=true,cargo=false};scene.groups[#scene.groups+1]=group;groups[o]=group end
                group.prop=true;o.jlrsDynamicProp=true
                for _,e in ipairs(additions)do group.entries[#group.entries+1]=e end
            end
        end
    end end
    scene.entries={}
    for _,g in ipairs(scene.groups)do g.first=#scene.entries+1;for _,e in ipairs(g.entries)do scene.entries[#scene.entries+1]=e end end
    return scene
end
local safe=JLRSProps.safeGroup
JLRSProps.safeGroup=function(group)
    if not marked(group)then return safe(group)end
    if not group.object or group.object.isDeleted then return false end
    for _,e in ipairs(group.entries)do
        if not entityExists(e.node)or getParent(e.node)~=e.parent or getRigidBodyType(e.node)==RigidBodyType.STATIC then return false end
    end
    return true
end
local attach=JLRSProps.attach
JLRSProps.attach=function(state)
    local ok=attach(state)
    if not ok or not marked(state.group)then return ok end
    state.placeableMotionHooks={}
    local function stopUpdates(object)
        for _,name in ipairs({'update','updateTick','updateInterpolation','updateEnd'})do
            if type(object[name])=='function'then
                local hook={object=object,name=name,raw=rawget(object,name),wrapper=function()end}
                state.placeableMotionHooks[#state.placeableMotionHooks+1]=hook;object[name]=hook.wrapper
            end
        end
    end
    stopUpdates(state.group.object)
    for _,animated in ipairs(state.group.object.spec_animatedObjects and state.group.object.spec_animatedObjects.animatedObjects or {})do stopUpdates(animated)end
    return true
end
local release=JLRSProps.release
JLRSProps.release=function(state)
    for _,hook in ipairs(state.placeableMotionHooks or {})do if hook.object[hook.name]==hook.wrapper then hook.object[hook.name]=hook.raw end end
    state.placeableMotionHooks=nil
    return release(state)
end
function P.toggle(c)
    if c.recording or c.replaying or c.finalPlaying or c.finalRecording or #(c.liveTracks or {})>0 then
        c:notify('Stop Record/Replay sebelum mengubah Physics Placeable.');return
    end
    c.physicsPlaceable=not c.physicsPlaceable
    c:notify('Physics Placeable: '..(c.physicsPlaceable and 'ON | aktif untuk Record berikutnya' or 'OFF'))
end
