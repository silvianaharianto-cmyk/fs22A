-- J_L Cinema Studio V1.18.86.137
-- Zero-Configuration Documentary Foundation.
-- Passive gameplay observer + per-take event metadata. Does NOT own the camera.
-- Existing vehicle frames, History format, replay writers and Final data are untouched.

JLRZeroConfigDocumentary = {}
local Z = JLRZeroConfigDocumentary

Z.VERSION = 1
Z.SAMPLE_STEP = 0.10
Z.MAX_EVENTS = 256
Z.PROFILE = "DOCUMENTARY"

local function clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

local function angleDelta(a, b)
    return (b - a + math.pi) % (2 * math.pi) - math.pi
end

local function validVehicle(vehicle)
    return vehicle ~= nil
        and JLRSRecorder ~= nil
        and type(JLRSRecorder.valid) == "function"
        and JLRSRecorder.valid(vehicle)
end

local function numeric(value, fallback)
    value = tonumber(value)
    if value == nil then
        return fallback or 0
    end
    return value
end

local function copyEvents(events)
    local out = {}
    for i, event in ipairs(events or {}) do
        out[i] = {
            time = numeric(event.time),
            kind = tostring(event.kind or "UNKNOWN"),
            x = numeric(event.x),
            y = numeric(event.y),
            z = numeric(event.z),
            yaw = numeric(event.yaw),
            speed = numeric(event.speed),
            confidence = numeric(event.confidence),
            severity = numeric(event.severity)
        }
    end
    return out
end

function Z.resetTake(c)
    c.zeroDocEvents = {}
    c.zeroDocSampleCount = 0
    c.zeroDocPrevious = nil
    c.zeroDocCooldowns = {}
    c.zeroDocAirborne = false
    c.zeroDocAirborneTime = 0
    c.zeroDocTakeoffY = nil
    c.zeroDocDescending = false
    c.zeroDocUpwardSamples = 0
    c.zeroDocStationaryTime = 0
    c.zeroDocStarted = false
    c.zeroDocStopped = false
    c.zeroDocLastEvent = nil
    c.zeroDocLastEventTime = nil
    c.zeroDocSampleAccumulator = 0
    c.zeroDocTakeTarget = c.target
    c.zeroDocStatus = "RECORDING / EVENT SCANNER READY"
end

function Z.capture(vehicle, time)
    if not validVehicle(vehicle) then
        return nil
    end

    local okPosition, x, y, z = pcall(getWorldTranslation, vehicle.rootNode)
    if not okPosition or x == nil then
        return nil
    end

    local okRotation, rx, ry, rz = pcall(getWorldRotation, vehicle.rootNode)
    if not okRotation or ry == nil then
        return nil
    end

    return {
        vehicle = vehicle,
        time = numeric(time),
        x = x, y = y, z = z,
        pitch = numeric(rx),
        yaw = numeric(ry),
        roll = numeric(rz)
    }
end

function Z.emit(c, sample, kind, confidence, severity)
    local events = c.zeroDocEvents
    if events == nil or #events >= Z.MAX_EVENTS then
        c.zeroDocStatus = "EVENT LIMIT REACHED"
        return false
    end

    local cooldowns = c.zeroDocCooldowns or {}
    c.zeroDocCooldowns = cooldowns
    local cooldown = ({
        START = 0,
        STOP = 0,
        TAKEOFF = 0,
        LANDING = 0,
        IMPACT_CANDIDATE = 1.5,
        HARD_BRAKING = 2.0,
        SHARP_TURN = 2.0,
        ROUGH_TERRAIN = 2.5
    })[kind] or 1.5

    local previous = cooldowns[kind]
    if previous ~= nil and sample.time - previous < cooldown then
        return false
    end

    local event = {
        time = sample.time,
        kind = kind,
        x = sample.x,
        y = sample.y,
        z = sample.z,
        yaw = sample.yaw,
        speed = numeric(sample.speed),
        confidence = clamp(numeric(confidence), 0, 1),
        severity = clamp(numeric(severity), 0, 1)
    }

    events[#events + 1] = event
    cooldowns[kind] = sample.time
    c.zeroDocLastEvent = kind
    c.zeroDocLastEventTime = sample.time
    c.zeroDocStatus = string.format("RECORDING / %d EVENTS", #events)
    return true
end

function Z.observe(c)
    if not c or not c.recording or not c.zeroDocArmed then
        return
    end

    local vehicle = c.zeroDocTakeTarget or c.target
    if not validVehicle(vehicle) then
        c.zeroDocStatus = "OBSERVER / TARGET UNAVAILABLE"
        c.zeroDocPrevious = nil
        return
    end

    local time = numeric(c.recordTime)
    local sample = Z.capture(vehicle, time)
    if sample == nil then
        return
    end

    local previous = c.zeroDocPrevious
    if previous == nil or previous.vehicle ~= vehicle then
        sample.vehicle = vehicle
        sample.speed = 0
        sample.vx = 0
        sample.vy = 0
        sample.vz = 0
        c.zeroDocPrevious = sample
        c.zeroDocStatus = "RECORDING / EVENT SCANNER READY"
        return
    end

    local dt = time - previous.time
    if dt < Z.SAMPLE_STEP then
        return
    end

    -- Rebase after long stalls/pauses. Never turn a frame hitch into a fake impact.
    if dt > 0.60 then
        sample.vehicle = vehicle
        sample.speed = previous.speed or 0
        sample.vx = previous.vx or 0
        sample.vy = previous.vy or 0
        sample.vz = previous.vz or 0
        c.zeroDocPrevious = sample
        c.zeroDocUpwardSamples = 0
        return
    end

    local vx = (sample.x - previous.x) / dt
    local vy = (sample.y - previous.y) / dt
    local vz = (sample.z - previous.z) / dt
    local speed = math.sqrt(vx * vx + vz * vz)
    local previousSpeed = numeric(previous.speed)
    local deceleration = (speed - previousSpeed) / dt
    local ax = (vx - numeric(previous.vx)) / dt
    local ay = (vy - numeric(previous.vy)) / dt
    local az = (vz - numeric(previous.vz)) / dt
    local acceleration = math.sqrt(ax * ax + ay * ay + az * az)
    local yawRate = math.abs(angleDelta(previous.yaw, sample.yaw)) / dt
    local pitchRate = math.abs(angleDelta(previous.pitch, sample.pitch)) / dt
    local rollRate = math.abs(angleDelta(previous.roll, sample.roll)) / dt
    local verticalDelta = sample.y - previous.y
    local verticalAcceleration = (vy - numeric(previous.vy)) / dt

    sample.speed = speed
    sample.vx = vx
    sample.vy = vy
    sample.vz = vz
    c.zeroDocSampleCount = (c.zeroDocSampleCount or 0) + 1

    local emitted = false

    -- Airborne is an inferred motion event, not a native contact/ground-truth signal.
    if not c.zeroDocAirborne then
        if speed > 3.0 and vy > 1.55 and verticalDelta > 0.12 then
            c.zeroDocUpwardSamples = (c.zeroDocUpwardSamples or 0) + 1
        else
            c.zeroDocUpwardSamples = 0
        end

        if c.zeroDocUpwardSamples >= 2 then
            c.zeroDocAirborne = true
            c.zeroDocAirborneTime = time
            c.zeroDocTakeoffY = previous.y
            c.zeroDocDescending = false
            emitted = Z.emit(c, sample, "TAKEOFF",
                clamp((vy - 1.0) / 2.5, 0.35, 0.90),
                clamp((vy - 1.0) / 3.5, 0.20, 1.0))
            c.zeroDocUpwardSamples = 0
        end
    else
        if vy < -0.65 then
            c.zeroDocDescending = true
        end

        local airborneDuration = time - numeric(c.zeroDocAirborneTime)
        local returnedNearTakeoff = c.zeroDocTakeoffY ~= nil
            and sample.y <= c.zeroDocTakeoffY + 0.30
        if c.zeroDocDescending and airborneDuration > 0.25
            and (vy > -0.15 or returnedNearTakeoff) then
            emitted = Z.emit(c, sample, "LANDING",
                clamp((math.abs(vy) + 0.35) / 2.0, 0.45, 0.95),
                clamp((acceleration - 2.0) / 9.0, 0.20, 1.0))
            c.zeroDocAirborne = false
            c.zeroDocAirborneTime = 0
            c.zeroDocTakeoffY = nil
            c.zeroDocDescending = false
        elseif airborneDuration > 6.0 then
            -- Safety reset for unusual terrain/vehicle poses; do not invent a landing.
            c.zeroDocAirborne = false
            c.zeroDocAirborneTime = 0
            c.zeroDocTakeoffY = nil
            c.zeroDocDescending = false
        end
    end

    -- One principal event per sample keeps the event timeline readable.
    if not emitted then
        if previousSpeed > 2.0 and (deceleration < -7.0
            or (speed > 2.0 and acceleration > 8.5)) then
            emitted = Z.emit(c, sample, "IMPACT_CANDIDATE",
                clamp((math.max(-deceleration, acceleration) - 5.5) / 10.0, 0.35, 0.95),
                clamp((math.max(-deceleration, acceleration) - 5.0) / 12.0, 0.20, 1.0))
        end

        if not emitted and previousSpeed > 3.0 and deceleration < -4.2 then
            emitted = Z.emit(c, sample, "HARD_BRAKING",
                clamp((-deceleration - 2.5) / 6.0, 0.35, 0.90),
                clamp((-deceleration - 2.0) / 8.0, 0.20, 1.0))
        end

        if not emitted and speed > 2.5 and yawRate > 0.55 then
            emitted = Z.emit(c, sample, "SHARP_TURN",
                clamp((yawRate - 0.35) / 1.2, 0.35, 0.90),
                clamp((yawRate - 0.30) / 1.5, 0.20, 1.0))
        end

        if not emitted and speed > 2.0
            and (math.abs(verticalAcceleration) > 5.5
                or pitchRate > 0.75 or rollRate > 0.75) then
            emitted = Z.emit(c, sample, "ROUGH_TERRAIN",
                clamp((math.max(math.abs(verticalAcceleration), pitchRate, rollRate) - 0.45) / 2.0, 0.30, 0.85),
                clamp((acceleration - 2.5) / 9.0, 0.20, 1.0))
        end
    end

    if not c.zeroDocStarted and speed > 1.0 then
        c.zeroDocStarted = true
        if not emitted then
            emitted = Z.emit(c, sample, "START", 0.95, 0.35)
        end
    end

    if speed < 0.25 then
        c.zeroDocStationaryTime = (c.zeroDocStationaryTime or 0) + dt
    else
        c.zeroDocStationaryTime = 0
    end

    if c.zeroDocStarted and not c.zeroDocStopped
        and c.zeroDocStationaryTime >= 1.5 then
        c.zeroDocStopped = true
        if not emitted then
            emitted = Z.emit(c, sample, "STOP", 0.85, 0.25)
        end
    elseif speed > 0.80 then
        c.zeroDocStopped = false
    end

    c.zeroDocPrevious = sample
    if not emitted then
        c.zeroDocStatus = string.format("RECORDING / %d EVENTS / %.1f m/s",
            #(c.zeroDocEvents or {}), speed)
    end
end

local function storagePath(clipId)
    if not JLRSFrames then
        return nil
    end
    if not JLRSFrames.directory then
        local ok = pcall(JLRSFrames.prepare)
        if not ok or not JLRSFrames.directory then
            return nil
        end
    end
    local id = math.floor(numeric(clipId, -1))
    if id < 1 then
        return nil
    end
    return JLRSFrames.directory .. "director_events_" .. tostring(id) .. ".xml"
end

function Z.saveEvents(clipId, events, duration)
    local path = storagePath(clipId)
    if not path or not XMLFile or type(XMLFile.create) ~= "function" then
        return false, "EVENT STORAGE UNAVAILABLE"
    end

    local list = copyEvents(events)
    local xml = XMLFile.create("jlrsDirectorEvents", path, "directorEvents")
    if not xml then
        return false, "EVENT XML CREATE FAILED"
    end

    local ok, err = pcall(function()
        xml:setInt("directorEvents#version", Z.VERSION)
        xml:setInt("directorEvents#clipId", math.floor(numeric(clipId)))
        xml:setInt("directorEvents#count", #list)
        xml:setString("directorEvents#duration", string.format("%.6f", numeric(duration)))
        for i, event in ipairs(list) do
            local key = "directorEvents.event(" .. tostring(i - 1) .. ")"
            xml:setString(key .. "#time", string.format("%.6f", event.time))
            xml:setString(key .. "#kind", event.kind)
            xml:setString(key .. "#x", string.format("%.6f", event.x))
            xml:setString(key .. "#y", string.format("%.6f", event.y))
            xml:setString(key .. "#z", string.format("%.6f", event.z))
            xml:setString(key .. "#yaw", string.format("%.6f", event.yaw))
            xml:setString(key .. "#speed", string.format("%.6f", event.speed))
            xml:setString(key .. "#confidence", string.format("%.4f", event.confidence))
            xml:setString(key .. "#severity", string.format("%.4f", event.severity))
        end
        if xml:save() == false then
            error("EVENT XML SAVE FAILED")
        end
    end)
    xml:delete()
    if not ok then
        return false, tostring(err)
    end

    local check = XMLFile.load("jlrsDirectorEventsVerify", path)
    if not check then
        return false, "EVENT XML VERIFY OPEN FAILED"
    end
    local valid = check:getInt("directorEvents#version", 0) == Z.VERSION
        and check:getInt("directorEvents#clipId", 0) == math.floor(numeric(clipId))
        and check:getInt("directorEvents#count", -1) == #list
    check:delete()
    if not valid then
        return false, "EVENT XML VERIFY FAILED"
    end
    return true
end

function Z.loadEvents(clipId)
    local path = storagePath(clipId)
    if not path or not XMLFile or type(XMLFile.load) ~= "function" then
        return {}
    end
    if type(fileExists) == "function" and not fileExists(path) then
        return {}
    end

    local xml = XMLFile.load("jlrsDirectorEventsRead", path)
    if not xml then
        return {}
    end

    local events = {}
    local ok = pcall(function()
        local count = clamp(xml:getInt("directorEvents#count", 0), 0, Z.MAX_EVENTS)
        if xml:getInt("directorEvents#version", 0) ~= Z.VERSION
            or xml:getInt("directorEvents#clipId", 0) ~= math.floor(numeric(clipId)) then
            error("EVENT METADATA VERSION / ID MISMATCH")
        end
        for i = 0, count - 1 do
            local key = "directorEvents.event(" .. tostring(i) .. ")"
            local kind = xml:getString(key .. "#kind", "")
            local time = tonumber(xml:getString(key .. "#time", ""))
            if kind ~= "" and time ~= nil then
                events[#events + 1] = {
                    time = time,
                    kind = kind,
                    x = numeric(xml:getString(key .. "#x", "0")),
                    y = numeric(xml:getString(key .. "#y", "0")),
                    z = numeric(xml:getString(key .. "#z", "0")),
                    yaw = numeric(xml:getString(key .. "#yaw", "0")),
                    speed = numeric(xml:getString(key .. "#speed", "0")),
                    confidence = numeric(xml:getString(key .. "#confidence", "0")),
                    severity = numeric(xml:getString(key .. "#severity", "0"))
                }
            end
        end
    end)
    xml:delete()
    if not ok then
        return {}
    end
    return events
end

function Z.findClip(c, frames)
    for _, clip in ipairs(c.history or {}) do
        if clip.frames == frames then
            return clip
        end
    end
    return nil
end

function Z.statusLine(c)
    local state = c.zeroDocStatus or "ARMED"
    local count = #(c.zeroDocEvents or {})
    local samples = numeric(c.zeroDocSampleCount)
    return string.format("AUTO OBSERVER: %s | %d events | %d samples",
        tostring(state), count, samples)
end

function Z.refreshControlledVehicle(c)
    if not c or not c.mission then
        return
    end
    local vehicle = c.mission.controlledVehicle
    if validVehicle(vehicle) then
        if c.zeroDocObservedVehicle ~= vehicle then
            c.zeroDocObservedVehicle = vehicle
            local name = "VEHICLE"
            if type(vehicle.getName) == "function" then
                local ok, value = pcall(vehicle.getName, vehicle)
                if ok and value ~= nil then
                    name = tostring(value)
                end
            end
            c.zeroDocVehicleName = name
        end
        if not c.recording then
            c.zeroDocStatus = "ARMED / " .. tostring(c.zeroDocVehicleName or "VEHICLE READY")
        end
    else
        c.zeroDocObservedVehicle = nil
        c.zeroDocVehicleName = nil
        if not c.recording then
            c.zeroDocStatus = "ARMED / WAITING FOR VEHICLE"
        end
    end
end

-- Lifecycle: initialize passively when the existing single-player studio loads.
local oldLoadMap = JLReplayStudio.loadMap
JLReplayStudio.loadMap = function(c, ...)
    local result = oldLoadMap(c, ...)
    if not c.mission then
        return result
    end

    c.zeroDocArmed = true
    c.zeroDocStatus = "ARMED / WAITING FOR VEHICLE"
    c.zeroDocEvents = {}
    c.zeroDocSampleCount = 0
    c.zeroDocPrevious = nil
    c.zeroDocLivePoll = 0
    c.zeroDocObservedVehicle = nil
    c.zeroDocVehicleName = nil
    c.zeroDocCurrentClipId = nil
    c.zeroDocStorageError = nil
    Z.refreshControlledVehicle(c)
    c:notify("ZERO-CONFIG DOCUMENTARY ARMED | observer siap saat Record.")
    return result
end

local oldStudioUpdate = JLReplayStudio.update
JLReplayStudio.update = function(c, dt, ...)
    local result = oldStudioUpdate(c, dt, ...)
    if c.mission and c.zeroDocArmed then
        c.zeroDocLivePoll = (c.zeroDocLivePoll or 0) + math.max(0, numeric(dt)) / 1000
        if c.zeroDocLivePoll >= 0.50 then
            c.zeroDocLivePoll = c.zeroDocLivePoll % 0.50
            Z.refreshControlledVehicle(c)
        end
    end
    return result
end

-- The observer samples separately from the fixed vehicle-frame writer.
-- It never inserts data into c.frames and never changes Recorder.STEP.
local oldRecorderStart = JLRSRecorder.start
JLRSRecorder.start = function(c, ...)
    local result = oldRecorderStart(c, ...)
    if c == JLReplayStudio and c.recording then
        Z.resetTake(c)
        local initial = Z.capture(c.target, c.recordTime or 0)
        if initial then
            initial.vehicle = c.target
            initial.speed = 0
            initial.vx = 0
            initial.vy = 0
            initial.vz = 0
            c.zeroDocPrevious = initial
        end
        c.zeroDocStatus = "RECORDING / EVENT SCANNER READY"
    end
    return result
end

local oldRecordTick = JLRSRecorder.recordTick
JLRSRecorder.recordTick = function(c, dt, ...)
    local result = oldRecordTick(c, dt, ...)
    if c == JLReplayStudio and c.recording then
        local ok, err = pcall(Z.observe, c)
        if not ok then
            c.zeroDocStatus = "OBSERVER DEGRADED"
            if not c.zeroDocObserverErrorLogged then
                print("[J_L Cinema Studio] Documentary observer error: " .. tostring(err))
                c.zeroDocObserverErrorLogged = true
            end
        end
    end
    return result
end

local oldStopRecord = JLRSRecorder.stopRecord
JLRSRecorder.stopRecord = function(c, ...)
    local wasRecording = c.recording
    local result = oldStopRecord(c, ...)
    if c == JLReplayStudio and wasRecording then
        local clip = Z.findClip(c, c.frames)
        local events = copyEvents(c.zeroDocEvents)
        if clip then
            clip.directorEvents = events
            clip.directorEventCount = #events
            c.zeroDocCurrentClipId = clip.id
            local saved, err = Z.saveEvents(clip.id, events, clip.duration)
            if not saved then
                c.zeroDocStorageError = tostring(err)
                print("[J_L Cinema Studio] Event metadata not saved: " .. tostring(err))
                c.zeroDocStatus = "TAKE SAVED / EVENT CACHE MEMORY ONLY"
            else
                c.zeroDocStatus = string.format("TAKE SAVED / %d EVENTS", #events)
            end
        else
            c.zeroDocStatus = string.format("TAKE STOPPED / %d EVENTS", #events)
        end
    end
    return result
end

-- Restore event metadata when a saved History clip is selected for Replay.
if JLRSHistory and type(JLRSHistory.replay) == "function" then
    local oldHistoryReplay = JLRSHistory.replay
    JLRSHistory.replay = function(c, clip, ...)
        local events = clip.directorEvents
        if events == nil then
            events = Z.loadEvents(clip.id)
            clip.directorEvents = events
            clip.directorEventCount = #events
        end
        c.zeroDocEvents = copyEvents(events)
        c.zeroDocCurrentClipId = clip.id
        c.zeroDocStatus = #events > 0
            and string.format("REPLAY / %d EVENT MARKERS", #events)
            or "REPLAY / NO EVENT METADATA"
        return oldHistoryReplay(c, clip, ...)
    end
end

local oldStartReplay = JLRSRecorder.startReplay
JLRSRecorder.startReplay = function(c, ...)
    if c == JLReplayStudio then
        local clip = Z.findClip(c, c.frames)
        if clip then
            local events = clip.directorEvents
            if events == nil then
                events = Z.loadEvents(clip.id)
                clip.directorEvents = events
                clip.directorEventCount = #events
            end
            c.zeroDocEvents = copyEvents(events)
            c.zeroDocCurrentClipId = clip.id
            c.zeroDocStatus = #events > 0
                and string.format("REPLAY / %d EVENT MARKERS", #events)
                or "REPLAY / NO EVENT METADATA"
        end
    end
    return oldStartReplay(c, ...)
end

-- Keep the existing Director panel, adding observer diagnostics only.
if JLRSAIDirector and type(JLRSAIDirector.drawPanel) == "function" then
    local oldDrawPanel = JLRSAIDirector.drawPanel
    JLRSAIDirector.drawPanel = function(c, ...)
        local result = oldDrawPanel(c, ...)
        JLRSMenu.text(0.365, 0.318, 0.010,
            "ZERO-CONFIG OBSERVER | " .. tostring(c.zeroDocStatus or "ARMED"),
            0.25, 0.88, 0.70)
        JLRSMenu.text(0.365, 0.292, 0.009,
            string.format("Events %d / %d | Samples %d | Camera automation: PHASE 3",
                #(c.zeroDocEvents or {}), Z.MAX_EVENTS, numeric(c.zeroDocSampleCount)),
            0.65, 0.74, 0.83)
        return result
    end
end

local oldDeleteMap = JLReplayStudio.deleteMap
JLReplayStudio.deleteMap = function(c, ...)
    -- Let the existing Stop/History wrappers finish and persist a live take first.
    c.zeroDocArmed = false
    local result = oldDeleteMap(c, ...)
    c.zeroDocPrevious = nil
    c.zeroDocEvents = nil
    c.zeroDocObservedVehicle = nil
    c.zeroDocVehicleName = nil
    c.zeroDocStatus = nil
    return result
end
