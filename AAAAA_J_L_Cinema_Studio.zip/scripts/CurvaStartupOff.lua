-- Start a session on the original recorded path. Keep every saved route and
-- editing control; the user can enable Curva explicitly from its HUD.
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    local result=load(c,...);c.curvaEnabled=false;return result
end
local restore=JLRSCurva.load
JLRSCurva.load=function(c,...)
    local first=not c.curvaLoaded
    local result=restore(c,...)
    if first and c.curvaLoaded then c.curvaEnabled=false end
    return result
end
