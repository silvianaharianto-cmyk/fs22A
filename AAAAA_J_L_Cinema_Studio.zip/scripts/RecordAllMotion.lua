-- Exact dense-format Record All motion. No sleeping-node assumptions, omitted
-- vehicles, reduced rates or physics hooks. All nodes are read every draw.
JLRSRecordAllMotion={}
local M=JLRSRecordAllMotion
local capture=JLRSRecorder.capture
JLRSRecorder.capture=function(entries)
    local context=M.context
    if not context or entries~=context.entries then return capture(entries) end
    -- Previous poses are immutable once passed to the frame/cache streams.
    -- Reuse only exact equality; every native node is still read this draw.
    local previous=context.previous
    local pose=previous or {};local offset=0
    local changed=previous and {} or nil
    local function own()
        if previous and pose==previous then
            pose={};for i=1,#previous do pose[i]=previous[i] end
        end
    end
    for _,entry in ipairs(entries) do
        if not entityExists(entry.node) or getParent(entry.node)~=entry.parent then return nil end
        local x,y,z,rx,ry,rz
        if entry.world then x,y,z=getWorldTranslation(entry.node);rx,ry,rz=getWorldRotation(entry.node)
        else x,y,z=getTranslation(entry.node);rx,ry,rz=getRotation(entry.node) end
        if pose[offset+1]~=x or pose[offset+2]~=y or pose[offset+3]~=z
            or pose[offset+4]~=rx or pose[offset+5]~=ry or pose[offset+6]~=rz then
            own()
            pose[offset+1]=x;pose[offset+2]=y;pose[offset+3]=z
            pose[offset+4]=rx;pose[offset+5]=ry;pose[offset+6]=rz
            if changed then for j=1,6 do local index=offset+j
                if pose[index]~=previous[index] then changed[#changed+1]=index end
            end end
        end
        offset=offset+6
    end
    -- Identical primary audio tail to ReplayAudio.capture, including engine OFF.
    local v=entries[1] and entries[1].vehicle
    local spec=v and v.spec_motorized;local motor=spec and spec.motor
    if motor and motor.getLastModulatedMotorRpm then
        local low=motor.minRpm or 0;local high=motor.maxRpm or low+1
        local rpm=math.max(0,math.min(1,(motor:getLastModulatedMotorRpm()-low)/math.max(1,high-low)))
        local load=math.max(-1,math.min(1,spec.smoothedLoadPercentage or spec.rawLoadPercentage or 0))
        local on=spec.isMotorStarted and 1 or 0
        if pose[offset+1]~=rpm or pose[offset+2]~=load or pose[offset+3]~=on then
            own();pose[offset+1]=rpm;pose[offset+2]=load;pose[offset+3]=on
            if changed then for j=1,3 do local index=offset+j
                if pose[index]~=previous[index] then changed[#changed+1]=index end
            end end
        end
        offset=offset+3
    end
    if #pose>offset then own();for i=#pose,offset+1,-1 do pose[i]=nil end end
    context.current=pose;context.changed=changed
    return pose
end
function M.plan(a,b)
    local context=M.context
    if context and context.previous==a and context.current==b and context.changed and #a==#b then
        local delta={}
        for j,i in ipairs(context.changed) do
            if (i-1)%6<3 then delta[j]=b[i]-a[i]
            else delta[j]=(b[i]-a[i]+math.pi)%(2*math.pi)-math.pi end
        end
        return {a=a,b=b,indices=context.changed,delta=delta}
    end
    local indices,delta={},{}
    for i=1,#a do
        if a[i]~=b[i] then
            indices[#indices+1]=i
            if (i-1)%6<3 then delta[#delta+1]=b[i]-a[i]
            else delta[#delta+1]=(b[i]-a[i]+math.pi)%(2*math.pi)-math.pi end
        end
    end
    return {a=a,b=b,indices=indices,delta=delta}
end
function M.interpolate(plan,t)
    local a=plan.a
    if #plan.indices==0 then return a end
    local pose={};for i=1,#a do pose[i]=a[i] end
    for j,index in ipairs(plan.indices) do pose[index]=a[index]+plan.delta[j]*t end
    return pose
end
local blend=JLRSRecorder.blend
JLRSRecorder.blend=function(a,b,t)
    local context=M.context
    if not context then return blend(a,b,t) end
    if a==b or t==0 then return a end
    local plan=context.plan
    if not plan or plan.a~=a or plan.b~=b then plan=M.plan(a,b);context.plan=plan end
    return M.interpolate(plan,t)
end
local tick=JLRSRecorder.recordTick
JLRSRecorder.recordTick=function(c,dt,...)
    if not c.recording or not c.recordAllActive then return tick(c,dt,...) end
    local previous=M.context;M.context={entries=c.entries,previous=c.previousPose}
    local ok,result=pcall(tick,c,dt,...)
    M.context=previous
    if not ok then error(result) end
    return result
end
