-- Follow One is separate from recorded streams: no History is copied, deleted or overwritten.
JLRSFollowOne={ROWS=5}
local F=JLRSFollowOne
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<1e9 end
local function init(c)c.followConfigs=c.followConfigs or {};c.followNames=c.followNames or {};c.followStates=c.followStates or {};c.followTraces=c.followTraces or {};c.followIcons=c.followIcons or {}end
local function editable(c)return not(c.recording or c.replaying or c.finalRecording or c.finalPlaying or #(c.liveTracks or {})>0 or c.changePending)end
local function valid(v)return JLRSRecorder.valid(v)and v.components and v.spec_motorized and not JLRSWorld.isTrain(v)end
local function id(v)return JLRSPersist.identity(v)end
function F.vehicle(c,key)
 if c.followVehicleLookup then return c.followVehicleLookup[key]end
 for _,v in pairs((c.mission or {}).vehicles or {})do if valid(v)and id(v)==key then return v end end
end
function F.name(c,v)return(c.followNames or {})[id(v)]or JLRSCurva.name(c,v)or 'Vehicle'end
local function recorded(c,v)
 for _,clip in ipairs(c.history or {})do for _,vehicle in ipairs(clip.vehicles or {clip.target})do if vehicle==v then return true end end end
 return false
end
local function angle(a,b,t)return JLRSRecorder.angle(a,b,t)end
function F.rename(c,v,text)
 if not valid(v)then return end
 if text~=nil then text=tostring(text):gsub('[%c]',''):match('^%s*(.-)%s*$');if text~=''then c.followNames[id(v)]=text:sub(1,64);for _,item in ipairs(c.curvaItems or {})do if item.vehicle==v then item.name=('#%03d %s'):format(item.clip.id,F.name(c,v))end end;F.save(c)end
 elseif g_gui and g_gui.showTextInputDialog then g_gui:showTextInputDialog({text='Rename Follow One',defaultText=F.name(c,v),maxCharacters=64,callback=function(value,ok)if ok then F.rename(c,v,value)end end})end
end
function F.save(c)
 init(c);if not JLRSFrames.directory or c.followLoadError then return false end
 local ok,err=pcall(function()
  local revision=(c.followRevision or 0)+1;local path=JLRSFrames.directory..'followOne_'..(revision%2==0 and 'A.xml'or 'B.xml')
  local xml=assert(XMLFile.create('jlrsFollowOne',path,'follow'))
  local written,why=pcall(function()
   xml:setInt('follow#revision',revision);xml:setInt('follow#enabled',c.followEnabled and 1 or 0);local count=0
   for key,cfg in pairs(c.followConfigs)do local k='follow.item('..count..')';xml:setString(k..'#vehicle',key);xml:setString(k..'#parent',cfg.parent);xml:setString(k..'#root',cfg.root);xml:setString(k..'#gap',tostring(cfg.gap));count=count+1 end
   xml:setInt('follow#count',count);count=0
   for key,name in pairs(c.followNames)do local k='follow.name('..count..')';xml:setString(k..'#vehicle',key);xml:setString(k..'#text',name);count=count+1 end
   xml:setInt('follow#names',count);xml:setString('follow#complete','JLRS_FOLLOW_1');assert(xml:save()~=false,'Save Follow One gagal.')
  end);xml:delete();if not written then error(why)end
  local check=assert(XMLFile.load('jlrsFollowCheck',path));local verified=check:getString('follow#complete')=='JLRS_FOLLOW_1'and check:getInt('follow#revision')==revision;check:delete();assert(verified)
  c.followRevision=revision
 end)
 if not ok then c:notify('Follow One belum tersimpan: '..tostring(err))end;return ok
end
function F.load(c)
 init(c);if c.followLoaded or c.jlrsLoadPending or not JLRSFrames.directory then return end
 local best,exists
 for _,suffix in ipairs({'A.xml','B.xml'})do local path=JLRSFrames.directory..'followOne_'..suffix
  if fileExists(path)then exists=true;local xml=XMLFile.load('jlrsFollowLoad',path)
   if xml then local ok,data=pcall(function()
    assert(xml:getString('follow#complete')=='JLRS_FOLLOW_1');local n=xml:getInt('follow#count',0);local names=xml:getInt('follow#names',0);assert(n>=0 and n<=10000 and names>=0 and names<=10000)
    local data={configs={},names={},enabled=xml:getInt('follow#enabled',0)==1,revision=xml:getInt('follow#revision',0)}
    for i=0,n-1 do local k='follow.item('..i..')';local key=xml:getString(k..'#vehicle','');local parent=xml:getString(k..'#parent','');local root=xml:getString(k..'#root','');local gap=tonumber(xml:getString(k..'#gap',''));assert(key~=''and parent~=''and root~=''and key~=parent and finite(gap)and gap>=1);data.configs[key]={parent=parent,root=root,gap=gap}end
    for i=0,names-1 do local k='follow.name('..i..')';data.names[xml:getString(k..'#vehicle','')]=xml:getString(k..'#text',''):sub(1,64)end
    for key in pairs(data.configs)do local seen={};local walk=key;while data.configs[walk]do assert(not seen[walk],'Rantai Follow One melingkar.');seen[walk]=true;walk=data.configs[walk].parent end end
    return data
   end);xml:delete();if ok and(not best or data.revision>best.revision)then best=data end end
  end
 end
 if best then c.followConfigs=best.configs;c.followNames=best.names;c.followEnabled=best.enabled;c.followRevision=best.revision elseif exists then c.followLoadError=true;c:notify('File Follow One tidak terbaca; konfigurasi asli dilindungi.')end
 c.followLoaded=true
end
function F.apply(c,v,parent,gap)
 init(c);if not editable(c)then c:notify('Stop Record / Replay sebelum mengatur Follow One.');return false end
 if not valid(v)or not valid(parent)or v==parent or not finite(gap)or gap<1 then c:notify('Pilih kendaraan dan jarak minimal 1 meter.');return false end
 if v.getAttacherVehicle and v:getAttacherVehicle()or v.getAttachedImplements and #v:getAttachedImplements()>0 then c:notify('Lepaskan implement kendaraan pengikut dahulu.');return false end
 local key,pkey=id(v),id(parent);local seen={[key]=true};local walk=pkey
 while c.followConfigs[walk]do if seen[walk]then c:notify('Follow One dibatalkan: rantai melingkar.');return false end;seen[walk]=true;walk=c.followConfigs[walk].parent end
 if seen[walk]then c:notify('Follow One dibatalkan: rantai melingkar.');return false end
 if not recorded(c,F.vehicle(c,walk))then c:notify('Mobil yang diikuti harus memiliki rekaman atau sudah mengikuti mobil utama.');return false end
 c.followConfigs[key]={parent=pkey,root=walk,gap=gap}
 for child,cfg in pairs(c.followConfigs)do local root=child;while c.followConfigs[root]do root=c.followConfigs[root].parent end;cfg.root=root end
 F.save(c);c:notify('FOLLOW ONE | '..F.name(c,v)..' mengikuti '..F.name(c,parent)..' | '..string.format('%.1fm',gap));return true
end
function F.parents(c,v)
 local list={};local root=F.vehicle(c,c.followRootId)
 for _,candidate in pairs((c.mission or {}).vehicles or {})do
  if valid(candidate)and candidate~=v then local key=id(candidate)
   local seen={};local walk=key;local allowed=true
   while c.followConfigs[walk]and not seen[walk]do if v and walk==id(v)then allowed=false;break end;seen[walk]=true;walk=c.followConfigs[walk].parent end
    if v and walk==id(v)then allowed=false end
    if allowed then list[#list+1]=candidate end
  end
 end
 table.sort(list,function(a,b)if a==b then return false elseif a==root then return true elseif b==root then return false end;local an,bn=F.name(c,a),F.name(c,b);if an==bn then return id(a)<id(b)end;return an<bn end);return list
end
function F.items(c)
 local root=F.vehicle(c,c.followRootId);local list={};local distances={}
 if not root then return list end
 local x,y,z=getWorldTranslation(root.rootNode)
 for _,v in pairs(c.mission.vehicles or {})do if valid(v)and v~=root then local vx,vy,vz=getWorldTranslation(v.rootNode);distances[v]=(vx-x)^2+(vy-y)^2+(vz-z)^2;list[#list+1]=v end end
 table.sort(list,function(a,b)if distances[a]==distances[b]then return id(a)<id(b)end;return distances[a]<distances[b]end);return list
end
function F.open(c)
 init(c);F.load(c);if not editable(c)then c:notify('Stop Record / Replay sebelum membuka Follow One.');return end
 local item=JLRSCurva.selected(c);if not item or not valid(item.vehicle)then c:notify('Pilih Curva mobil utama dahulu.');return end
 c.followRootId=id(item.vehicle);c.followOpen=true;c.followOffset=0;c.followChoice=nil;c.followParent=1;c.followGap=1;c.followParentPicker=false;c.followDraftParent=nil
end
function F.close(c)c.followSuccess=nil;c.followOpen=false;c.followParentPicker=false;c.curvaLabelVehicle=nil;for _,overlay in pairs(c.followIcons or {})do delete(overlay)end;c.followIcons={}end
function F.toggle(c)
 init(c);F.load(c);if not editable(c)then c:notify('Stop Replay sebelum mengubah Follow One.');return end
 c.followEnabled=not c.followEnabled;if c.followEnabled then F.open(c)else F.stop(c);F.close(c)end;F.save(c)
end
function F.success(c,v,parent)
 c.followSuccess={vehicle=F.name(c,v),parent=F.name(c,parent)}
 c.hitboxes={}
end
function F.status(c,v)
 local cfg=(c.followConfigs or {})[id(v)]
 if not cfg then return 'BELUM IKUT',false end
 if not F.vehicle(c,cfg.parent)then return 'TARGET HILANG',false end
 return c.followEnabled and 'MENGIKUTI' or 'MENGIKUTI (OFF)',true
end
function F.panel(c)
 if c.followSuccess then
  local M=JLRSMenu;local message=c.followSuccess;c.hitboxes={}
  M.rect(c,0,0,1,1,0,0,0,.70)
  M.rect(c,.19,.33,.62,.34,.015,.025,.04,.99)
  M.text(.23,.602,.024,'SUKSES !!!',.25,1,.45)
  M.text(.23,.548,.016,JLRSHistoryGroups.fitName('Mobil "'..message.vehicle..'"',.016,.54))
  M.text(.23,.501,.014,'mengikuti mobil',.70,.80,.90)
  M.text(.23,.454,.016,JLRSHistoryGroups.fitName('"'..message.parent..'"',.016,.54))
  M.button(c,.43,.363,.14,.045,'OK',function()c.followSuccess=nil;c.hitboxes={}end)
  return
 end
 local M=JLRSMenu;c.hitboxes={};local list=c.followParentPicker and F.parents(c,c.followChoice)or F.items(c);local visible={};c.followOffset=math.max(0,math.min(c.followOffset or 0,math.max(0,#list-F.ROWS)))
 M.rect(c,.735,.13,.25,.71,.015,.025,.04,.98);M.text(.75,.805,.015,c.followParentPicker and 'PILIH MOBIL DI DEPAN'or 'FOLLOW ONE');M.button(c,.945,.797,.025,.03,'X',function()F.close(c)end)
 M.button(c,.75,.750,.22,.033,c.followEnabled and 'FOLLOW ONE: ON'or 'FOLLOW ONE: OFF',function()c.followEnabled=not c.followEnabled;if not c.followEnabled then F.stop(c)end;F.save(c)end,c.followEnabled)
 for row=1,F.ROWS do local v=list[c.followOffset+row];if v then local y=.68-(row-1)*.066
  M.button(c,.746,y,.176,.058,'',function()
   c.curvaLabelVehicle=v
   if c.followParentPicker then c.followDraftParent=v;c.followParentPicker=false;c.followOffset=0
   else c.followChoice=v;c.followParent=1;local cfg=c.followConfigs[id(v)];c.followGap=cfg and cfg.gap or 1;local parents=F.parents(c,v);for i,p in ipairs(parents)do if cfg and id(p)==cfg.parent then c.followParent=i end end;c.followDraftParent=parents[c.followParent]end
  end,(c.followParentPicker and c.followDraftParent or c.followChoice)==v)
  local store=g_storeManager and g_storeManager:getItemByXMLFilename(v.configFileName or '');local image=store and store.imageFilename
  if image and image~=''then visible[image]=true;local overlay=c.followIcons[image];if not overlay then overlay=createImageOverlay(image);if overlay and overlay~=0 then c.followIcons[image]=overlay end end;if overlay and overlay~=0 then setOverlayColor(overlay,1,1,1,1);renderOverlay(overlay,.752,y+.006,.035,.043)end end
  M.text(.793,y+.029,.010,JLRSHistoryGroups.fitName(F.name(c,v),.010,.12))
  local status,assigned=F.status(c,v)
  M.rect(c,.790,y+.006,.005,.006,assigned and .2 or .65,assigned and .9 or .65,assigned and .4 or .65)
  M.text(.800,y+.010,.008,JLRSHistoryGroups.fitName(status,.008,.118),assigned and .3 or .70,assigned and 1 or .75,assigned and .5 or .80)
  M.button(c,.925,y+.018,.04,.025,'NAME',function()F.rename(c,v)end)
 end end
 for image,overlay in pairs(c.followIcons)do if not visible[image]then delete(overlay);c.followIcons[image]=nil end end
 local parents=F.parents(c,c.followChoice);local parent=c.followDraftParent;local allowed=false;for _,p in ipairs(parents)do if p==parent then allowed=true end end;if not allowed then parent=parents[1];c.followDraftParent=parent end
 M.text(.75,.388,.010,'Ikuti: '..(parent and JLRSHistoryGroups.fitName(F.name(c,parent),.010,.181)or 'Pilih mobil'))
 M.button(c,.75,.344,.22,.030,'PILIH MOBIL YANG DIIKUTI',function()if c.followChoice then c.followParentPicker=not c.followParentPicker;c.followOffset=0 else c:notify('Pilih mobil pengikut dahulu.')end end)
 M.button(c,.75,.295,.035,.032,'-',function()c.followGap=math.max(1,(c.followGap or 1)-1)end)
 M.text(.794,.307,.012,string.format('Jarak: %.1f m',c.followGap or 1))
 M.button(c,.935,.295,.035,.032,'+',function()c.followGap=(c.followGap or 1)+1 end)
 M.button(c,.75,.247,.22,.036,'APPLY',function()if F.apply(c,c.followChoice,parent,c.followGap or 1)then c.followEnabled=true;F.save(c);F.success(c,c.followChoice,parent)end end)
 M.button(c,.75,.197,.22,.031,c.followParentPicker and 'KEMBALI KE PENGIKUT'or 'KEMBALI KE CURVA',function()if c.followParentPicker then c.followParentPicker=false;c.followOffset=0 else F.close(c)end end)
 M.text(.75,.166,.009,'Scroll daftar | Jarak antar bumper')
 M.text(.75,.143,.008,'Rekaman kendaraan tetap disimpan')
end
function F.label(c,v)
 if not JLRSRecorder.valid(v)or type(project)~='function'then return end
 local x,y,z=getWorldTranslation(v.rootNode);local sx,sy,depth=project(x,y+math.max(1.5,tonumber(v.sizeHeight)or 2)+.6,z)
 if not sx or not sy or not depth or depth<0 or depth>1 or sx<0 or sx>1 or sy<0 or sy>1 then return end
 local name=F.name(c,v);local textWidth=#name*.012*1.2;if type(getTextWidth)=='function'then local ok,w=pcall(getTextWidth,.012,name);if ok and type(w)=='number'then textWidth=w end end
 local width=math.max(.18,math.min(.40,textWidth+.016));local left=math.max(.005,math.min(.995-width,sx-width/2));local M=JLRSMenu
 M.rect(c,left,sy-.008,width,.031,0,0,0,.78);M.text(left+.005,sy+.002,.012,JLRSHistoryGroups.fitName(name,.012,width-.010))
end
local function half(v)return math.max(.5,(tonumber(v.sizeLength)or 4)/2)end
local function owned(c,v)
 local function has(track)if not track or not track.replaying then return false end;for _,vehicle in ipairs(track.recordVehicles or {track.target})do if vehicle==v then return true end end end
 if has(c)then return true end;for _,track in ipairs(c.liveTracks or {})do if has(track)then return true end end
 for _,replay in ipairs({c.worldReplay or {},c.cargoReplay or {}})do for _,state in ipairs(replay.states or {})do if state.group.object==v and state.vehicleTrack then return true end end end
 for _,track in ipairs(c.liveTracks or {})do for _,state in ipairs((track.cargoReplay or {}).states or {})do if state.group.object==v and state.vehicleTrack then return true end end end
 return false
end
function F.release(c,key)
 local state=c.followStates[key];if not state then return end;c.followStates[key]=nil
 for _,wheel in ipairs(state.track.visualWheelStates or {})do if JLRSWheelVisual.nodes[wheel.node]==wheel then local previous=state.wheelPrevious[wheel.node];JLRSWheelVisual.nodes[wheel.node]=previous and previous.track.replaying and previous or nil end end
 state.track.visualWheelStates=nil
 JLRSAudio.restore(state.track)
 if not state.borrowed and JLRSRecorder.valid(state.vehicle)then JLRSRecorder.apply(state.entries,state.original,true)end
 F.restorePhysics(state)
 for i=#state.helpers,1,-1 do local node=state.helpers[i];if entityExists(node)then delete(node)end end
end
function F.restorePhysics(state)
 local v=state.vehicle
 local handedOff=false;local c=JLReplayStudio
 local seen={};local function clean(track)
  if not track or seen[track]then return end;seen[track]=true
  for _,owner in ipairs(track.livePhysics or {})do if owner.vehicle==v then
   for name,hook in pairs(owner.hooks or {})do local ours=(state.nativeHooks or {})[name];if ours and hook.raw==ours.wrapper then hook.raw=ours.raw end end
   if state.removed then owner.added=true;handedOff=true end
  end end
  for _,replay in ipairs({track.worldReplay or {},track.cargoReplay or {}})do for _,entry in ipairs(replay.states or {})do clean(entry.vehicleTrack)end end
 end
 clean(c);for _,track in ipairs(c and c.liveTracks or {})do clean(track)end
 for name,hook in pairs(state.nativeHooks or {})do if v[name]==hook.wrapper then v[name]=hook.raw end end
 if state.removed and not handedOff and JLRSRecorder.valid(v)then state.nativeAdd(v)end
 state.nativeHooks=nil;state.removed=false
end
function F.isolate(state)
 local v=state.vehicle
 if type(v.removeFromPhysics)~='function'or type(v.addToPhysics)~='function'then return false end
 if state.borrowed and v.isAddedToPhysics~=true then return true end
 state.nativeHooks={};state.nativeAdd=v.addToPhysics
 local ok,err=pcall(function()
  if v.isAddedToPhysics==true then state.removed=true;v:removeFromPhysics()end
  for _,name in ipairs({'update','updateTick','updateInterpolation','addToPhysics'})do if type(v[name])=='function'then local hook={raw=rawget(v,name),wrapper=function()end};state.nativeHooks[name]=hook;v[name]=hook.wrapper end end
 end)
 if not ok then F.restorePhysics(state);state.track:notify('Follow One tidak dimulai: '..tostring(err))end
 return ok
end
function F.stop(c)
 init(c);local keys={};for key in pairs(c.followStates)do keys[#keys+1]=key end;for _,key in ipairs(keys)do F.release(c,key)end;for _,trace in pairs(c.followTraces)do if trace.track then trace.track.followLeaderInterp=nil end end;c.followTraces={}
end
function F.state(c,v,rootTrack,leader)
 local key=id(v);local state=c.followStates[key];if state and state.borrowed and not owned(c,v)then F.release(c,key);state=nil end
 if state then if v.isAddedToPhysics==true and not F.isolate(state)then F.release(c,key);return end;return state end
 local entries,vehicles=JLRSRecorder.topology(v);if #vehicles~=1 then return end
 local original=JLRSRecorder.capture(entries);if not original then return end
 local sx,sy,sz=getWorldTranslation(v.rootNode);local srx,sry,srz=getWorldRotation(v.rootNode)
 local snapshot=(c.followPendingStarts or c.followStarts or {})[key]
 if snapshot and snapshot.vehicle==v and #snapshot.pose==#original then
  original=snapshot.pose;sx,sy,sz,srx,sry,srz=unpack(snapshot.root)
  -- World/Record All reset may have already moved this vehicle. Reestablish
  -- its pre-start pose before deriving component offsets or borrowing replay.
  JLRSRecorder.apply(entries,original,true)
 end
 local track={target=v,entries=entries,frames={},recordVehicles={v},notify=function(_,message)c:notify(message)end,replaying=true,paused=false,duration=rootTrack.duration,replayTime=0}
 state={vehicle=v,entries=entries,original=original,track=track,rootTrack=rootTrack,borrowed=owned(c,v),components={},wheels={},pose={},helpers={},wheelPrevious={}}
 state.startPoint={sx,sy,sz,srx,sry,srz}
 c.followStates[key]=state
 for i=1,2 do local n=createTransformGroup('JLRS_FollowOne');link(getRootNode(),n);state.helpers[i]=n end
 local helper,child=state.helpers[1],state.helpers[2];link(v.rootNode,child)
 local roles=JLRSChange.wheelRoles(v)
 for i,e in ipairs(entries)do local offset=(i-1)*6
  if e.world then
   local x,y,z=getWorldTranslation(e.node);local rx,ry,rz=getWorldRotation(e.node);setWorldTranslation(child,x,y,z);setWorldRotation(child,rx,ry,rz)
   local px,py,pz=getTranslation(child);local prx,pry,prz=getRotation(child);state.components[#state.components+1]={offset=offset,base={px,py,pz,prx,pry,prz}}
  elseif roles[e.node]then state.wheels[#state.wheels+1]={offset=offset,role=roles[e.node]};state.wheelPrevious[e.node]=JLRSWheelVisual.nodes[e.node]end
 end
 local function clearance(vehicle)
  if not valid(vehicle)then return end
  link(vehicle.rootNode,child);local minimum
  for _,wheel in ipairs(vehicle.spec_wheels and vehicle.spec_wheels.wheels or {})do
   local node=wheel.repr or wheel.driveNode
   if node and entityExists(node)then local x,y,z=getWorldTranslation(node);setWorldTranslation(child,x,y,z);local _,height=getTranslation(child);local contact=height-(wheel.radius or (wheel.physics and wheel.physics.radius)or 1);minimum=minimum and math.min(minimum,contact)or contact end
  end
  return minimum
 end
 local ownHeight,leaderHeight=clearance(v),clearance(leader or rootTrack.target)
 state.heightOffset=ownHeight and leaderHeight and leaderHeight-ownHeight or 0
 link(helper,child)
 if not F.isolate(state)then F.release(c,key);return end
 return state
end
local function push(trace,p)
 local previous=trace.rows[#trace.rows];p.s=previous and previous.s+math.sqrt((p[1]-previous[1])^2+(p[2]-previous[2])^2+(p[3]-previous[3])^2)or 0
 if not previous or p.s-previous.s>1e-6 then trace.rows[#trace.rows+1]=p else for i=4,6 do previous[i]=p[i]end end
end
function F.trace(c,v,track)
 local key=id(v);local offset
 for i,e in ipairs(track.entries or {})do if e.world and e.node==v.rootNode then offset=(i-1)*6;break end end;if not offset then return end
 -- Follow the rendered leader, not a future target that the physics driver
 -- has not reached yet. Camera and convoy now share one coordinate reference.
 local x,y,z=getWorldTranslation(v.rootNode);local rx,ry,rz=getWorldRotation(v.rootNode)
 local current={x,y,z,rx,ry,rz}
 local curve
 local frames=track.frames;while frames and frames.editingView do frames=frames.editingView.source end
 for _,item in ipairs(c.curvaItems or {})do if item.vehicle==v and item.clip.frames==frames then curve=c.curvas[item.key];break end end
 local time=track.replayTime or 0;local trace=c.followTraces[key]
 if not trace or trace.track~=track or trace.frames~=track.frames or time<(trace.time or 0)or time-(trace.time or 0)>.5 or trace.revision~=(curve and curve.revision)then
  trace={rows={},track=track,frames=track.frames,revision=curve and curve.revision};c.followTraces[key]=trace
  local sourceTime=JLRSCurva.vehicleTime(track,v,time)
  if curve and not curve.deleted and curve.enabled~=false then
   for i,p in ipairs(curve.preview or {})do if(p.t or 0)<sourceTime then local next=(curve.preview or {})[i+1]or p;local dx,dy,dz=next[1]-p[1],next[2]-p[2],next[3]-p[3];push(trace,{p[1],p[2],p[3],-math.atan2(dy,math.sqrt(dx*dx+dz*dz)),math.atan2(dx,dz),current[6]})end end
  end
 end
 push(trace,current);trace.time=time
 return trace
end
function F.at(trace,s)
 local rows=trace.rows;local first,last=rows[1],rows[#rows];if not first then return end
 if s<first.s then local d=s-first.s;return {first[1]+math.sin(first[5])*d,first[2],first[3]+math.cos(first[5])*d,first[4],first[5],first[6]}end
 local lo,hi=1,#rows-1;local index=#rows
 while lo<=hi do local mid=math.floor((lo+hi)/2);if rows[mid+1].s<s then lo=mid+1 elseif rows[mid].s>s then hi=mid-1 else index=mid;break end end
 local a,b=rows[index],rows[math.min(index+1,#rows)];local alpha=b.s>a.s and math.max(0,math.min(1,(s-a.s)/(b.s-a.s)))or 0;local p={}
 for j=1,6 do p[j]=j<=3 and a[j]+(b[j]-a[j])*alpha or angle(a[j],b[j],alpha)end;return p
end
-- Join from the parked position, rather than placing the follower on the
-- extrapolated trail at replay time zero. The entry is evaluated by leader
-- travel, so pause, rewind and repeated render passes remain deterministic.
function F.entry(state,trace,distance)
 local first,last=trace.rows[1],trace.rows[#trace.rows]
 local time=state.rootTrack and state.rootTrack.replayTime or last.s/3
 if state.entryTrace~=trace then
  local previous=state.entryTrace
  local continuing=previous and time>=(state.entryTime or time) and previous.track==trace.track and previous.frames==trace.frames and previous.revision==trace.revision
  state.entryTrace=trace
  if not continuing then
   state.entryPosition={unpack(state.startPoint)}
   state.entryPosition[2]=state.entryPosition[2]-(state.heightOffset or 0)
   state.entryTravel=0;state.entrySpeed=0;state.entryJoined=false;state.entryLeaderMoved=false
  end
  state.entryTime=time;state.entryArc=last.s
 end
 local dt=math.max(0,time-(state.entryTime or time));local ds=math.max(0,last.s-(state.entryArc or last.s))
 local current=state.entryPosition;local target=F.at(trace,last.s-distance)
 local p,curvature=current,0
 if dt>0 and not(state.rootTrack and state.rootTrack.paused)then
  if state.entryJoined then
   local decay=math.exp(-ds*2);local offset=state.entryOffset
   for i=1,6 do offset[i]=offset[i]*decay end
   p={target[1]+offset[1],target[2]+offset[2],target[3]+offset[3],target[4]+offset[4],target[5]+offset[5],target[6]+offset[6]}
   local before,after=F.at(trace,last.s-distance-1),F.at(trace,last.s-distance+1)
   curvature=(angle(before[5],after[5],1)-before[5])/2
  else
   local leaderSpeed=ds/dt
   local dx,dz=target[1]-current[1],target[3]-current[3]
   local along=dx*math.sin(current[5])+dz*math.cos(current[5])
   local lateral=dx*math.cos(current[5])-dz*math.sin(current[5])
   local speed=math.max(0,leaderSpeed+along*.8)
   if along<-.5 and math.abs(lateral)<1 and math.abs(angle(current[5],target[5],1)-current[5])<.3 then speed=0 end
   if ds>1e-8 then state.entryLeaderMoved=true end
   if not state.entryLeaderMoved then speed=0
   elseif math.abs(lateral)>1 and dx*dx+dz*dz>4 then speed=math.max(speed,1) end
   speed=math.min(speed,math.max(2,leaderSpeed*1.4))
   local previous=state.entrySpeed or 0
   state.entrySpeed=previous+math.max(-5*dt,math.min(3*dt,speed-previous))
   local travel=math.max(0,(previous+state.entrySpeed)*.5*dt)
   local lookAhead=math.max(2,(tonumber(state.vehicle and state.vehicle.sizeLength)or 4)*.7)
   local aim=F.at(trace,last.s-distance+lookAhead)
   local wheelbase=math.max(1,(tonumber(state.vehicle and state.vehicle.sizeLength)or 4)*.65)
   local steps=math.max(1,math.ceil(travel/.15));local step=travel/steps
   p={unpack(current)}
   for _=1,steps do
    local ax,az=aim[1]-p[1],aim[3]-p[3]
    local side=ax*math.cos(p[5])-az*math.sin(p[5])
    curvature=math.max(-math.tan(.6)/wheelbase,math.min(math.tan(.6)/wheelbase,2*side/math.max(1,ax*ax+az*az)))
    local turn=curvature*step
    p[1]=p[1]+math.sin(p[5]+turn*.5)*step;p[3]=p[3]+math.cos(p[5]+turn*.5)*step;p[5]=p[5]+turn
   end
   local blend=1-math.exp(-travel*.5)
   p[2]=p[2]+(target[2]-p[2])*blend;p[4]=angle(p[4],target[4],blend);p[6]=angle(p[6],target[6],blend)
   local error=math.sqrt((p[1]-target[1])^2+(p[3]-target[3])^2)
   if error<.2 and math.abs(angle(p[5],target[5],1)-p[5])<.08 then
    state.entryJoined=true;state.entryOffset={}
    for i=1,6 do state.entryOffset[i]=i<4 and p[i]-target[i] or angle(target[i],p[i],1)-target[i] end
   end
  end
  state.entryTravel=state.entryTravel+math.sqrt((p[1]-current[1])^2+(p[2]-current[2])^2+(p[3]-current[3])^2)
 end
 state.entryPosition=p;state.entryTime=time;state.entryArc=last.s
 return p,curvature
end
function F.drive(c,state,trace,distance)
 local arc=trace.rows[#trace.rows].s-distance;local owner=state.rootTrack
 if state.driveTrace==trace and state.driveArc==arc and state.driveTime==owner.replayTime and state.track.paused==owner.paused then
  -- Camera cuts / post-render pinning must not resample the convoy or restart
  -- audio/interpolation. Repair only a body overwritten by another replay.
  local pose=state.pose;local changed=false
  for _,component in ipairs(state.components)do local n=component.offset;local entry=state.entries[n/6+1]
   if entityExists(entry.node)then local x,y,z=getWorldTranslation(entry.node);local rx,ry,rz=getWorldRotation(entry.node)
    if math.abs(x-pose[n+1])+math.abs(y-pose[n+2])+math.abs(z-pose[n+3])>1e-8 or math.abs(angle(rx,pose[n+4],1)-rx)+math.abs(angle(ry,pose[n+5],1)-ry)+math.abs(angle(rz,pose[n+6],1)-rz)>1e-8 then changed=true;break end
   end
  end
  if changed then JLRSRecorder.apply(state.entries,pose,true)end
  for _,wheel in ipairs(state.track.visualWheelStates or {})do JLRSWheelVisual.nodes[wheel.node]=wheel end;JLRSWheelVisual.refresh(state.track);return true
 end
 local p,curvature=F.entry(state,trace,distance)
 local helper,child=state.helpers[1],state.helpers[2];setTranslation(helper,p[1],p[2]+state.heightOffset,p[3]);setRotation(helper,p[4],p[5],p[6])
 local pose=state.pose;for i,value in ipairs(state.original)do pose[i]=value end
 for _,component in ipairs(state.components)do local base=component.base;setTranslation(child,base[1],base[2],base[3]);setRotation(child,base[4],base[5],base[6]);local n=component.offset;pose[n+1],pose[n+2],pose[n+3]=getWorldTranslation(child);pose[n+4],pose[n+5],pose[n+6]=getWorldRotation(child)end
 for _,wheel in ipairs(state.wheels)do local n=wheel.offset;local role=wheel.role
  if role.kind=='drive'then pose[n+4]=state.original[n+4]+state.entryTravel/math.max(.01,role.radius)
  elseif role.kind=='repr'then local w=(state.vehicle.spec_wheels.wheels or {})[role.index];if w and math.abs(tonumber(w.rotSpeed)or 0)>1e-9 then pose[n+5]=state.original[n+5]+math.max(-.65,math.min(.65,math.atan(math.max(1,(tonumber(state.vehicle.sizeLength)or 4)*.65)*curvature)))end end
 end
 if not JLRSRecorder.apply(state.entries,pose,true)then return false end
 local audio=owner.replayAudioPose;local n=#state.entries*6;local source=#owner.entries*6
 pose[n+1]=audio and audio[source+1]or .4;pose[n+2]=audio and audio[source+2]or .3;pose[n+3]=audio and audio[source+3]or 1
 state.track.replayTime=owner.replayTime;state.track.paused=owner.paused;state.track.replayAudioPose=pose;state.track.replayAudioTime=owner.replayTime;JLRSAudio.tick(state.track)
 for _,wheel in ipairs(state.track.visualWheelStates or {})do JLRSWheelVisual.nodes[wheel.node]=wheel end
 JLRSWheelVisual.refresh(state.track)
 state.driveTrace=trace;state.driveArc=arc;state.driveTime=owner.replayTime
 return true
end
function F.syncLeader(track,leader)
 -- Reset stale graphics interpolation to the current native pose without
 -- moving the body, changing contact shapes, or changing the recording.
 local cache=track.followLeaderInterp or {};track.followLeaderInterp=cache
 for _,entry in ipairs(track.entries or {})do if entry.world and entry.vehicle==leader then
  local component=entry.componentIndex and leader.components[entry.componentIndex];local interp=component and component.networkInterpolators
  if interp and interp.position and interp.quaternion and type(mathEulerToQuaternion)=='function'and entityExists(entry.node)then
   local x,y,z=getWorldTranslation(entry.node);local rx,ry,rz=getWorldRotation(entry.node);local qx,qy,qz,qw=mathEulerToQuaternion(rx,ry,rz)
   local previous=cache[entry.node]
   if not previous or previous.interp~=interp or previous[1]~=x or previous[2]~=y or previous[3]~=z or previous[4]~=rx or previous[5]~=ry or previous[6]~=rz then
    interp.position:setPosition(x,y,z);interp.quaternion:setQuaternion(qx,qy,qz,qw);cache[entry.node]={x,y,z,rx,ry,rz,interp=interp}
   end
  end
 end end
end
function F.tick(c,onlyTrack)
 init(c);F.load(c);if not c.followEnabled or not c.curvaEnabled then if next(c.followStates)then F.stop(c)end;return end
 local tracks={};if c.replaying then tracks[#tracks+1]=c end;for _,track in ipairs(c.liveTracks or {})do if track.replaying then tracks[#tracks+1]=track end end
 if #tracks==0 then if next(c.followStates)then F.stop(c)end;return end
 local active,roots,distances,rootTracks={},{},{},{}
 if onlyTrack then for key,state in pairs(c.followStates)do if state.rootTrack~=onlyTrack then active[key]=true end end end
 c.followVehicleLookup={};for _,v in pairs((c.mission or {}).vehicles or {})do if valid(v)then c.followVehicleLookup[id(v)]=v end end
 for _,track in ipairs(tracks)do for _,v in ipairs(track.recordVehicles or {track.target})do rootTracks[v]=track end end
 local resolving={}
 local function distanceTo(key,root)
  if key==root then return 0 end
  if distances[key]then return distances[key]end
  if resolving[key]then return end;resolving[key]=true
  local link=c.followConfigs[key];local child=F.vehicle(c,key);local parent=link and F.vehicle(c,link.parent)
  local previous=link and child and parent and link.root==root and distanceTo(link.parent,root)
  resolving[key]=nil
  if previous then distances[key]=previous+link.gap+half(child)+half(parent);return distances[key]end
 end
 for key,cfg in pairs(c.followConfigs)do
  local v=F.vehicle(c,key);local root=F.vehicle(c,cfg.root);local track=root and rootTracks[root];local distance=distanceTo(key,cfg.root)
  if v and track and distance and(not onlyTrack or track==onlyTrack)then
   local trace=roots[cfg.root];if not trace then F.syncLeader(track,root);trace=F.trace(c,root,track);roots[cfg.root]=trace end
   if trace then trace.keep=math.max(trace.keep or 0,distance);local state=F.state(c,v,track,root);if state then state.rootTrack=track;if F.drive(c,state,trace,distance)then active[key]=true end end end
  end
 end
 local release={};for key in pairs(c.followStates)do if not active[key]then release[#release+1]=key end end;for _,key in ipairs(release)do F.release(c,key)end
 -- Keep only a bounded trail behind the longest active follower chain.
 for key,trace in pairs(c.followTraces)do if not roots[key]then if not onlyTrack or trace.track==onlyTrack then c.followTraces[key]=nil end
  elseif not trace.trimTime or trace.time-trace.trimTime>.5 then
   local rows=trace.rows;local cutoff=rows[#rows].s-(trace.keep or 0)-10;local lo,hi,index=1,#rows-1,1
   while lo<=hi do local mid=math.floor((lo+hi)/2);if rows[mid].s<cutoff then index=mid;lo=mid+1 else hi=mid-1 end end
   if index>1 then local remaining={};for i=index,#rows do remaining[#remaining+1]=rows[i]end;trace.rows=remaining end;trace.trimTime=trace.time
  end
 end
 c.followVehicleLookup=nil
end
local drawCurva=JLRSCurva.draw
JLRSCurva.draw=function(c,...)
 local result;if c.followOpen then result=F.panel(c)else
  result=drawCurva(c,...)
  if c.curvaOpen and c.curvaPage=='edit' and not c.curvaViews then
   JLRSMenu.button(c,.50,.390,.215,.032,'FOLLOW ONE: '..(c.followEnabled and 'ON' or 'OFF'),function()F.toggle(c)end,c.followEnabled)
   JLRSMenu.button(c,.50,.350,.215,.032,'LIST FOLLOW ONE',function()F.open(c)end)
  end
 end
 if c.curvaOpen and c.menu then local selected=c.followParentPicker and c.followDraftParent or c.curvaLabelVehicle;if not selected and c.curvaPage=='edit'then local item=JLRSCurva.selected(c);selected=item and item.vehicle end;F.label(c,selected)end
 return result
end
local mouseCurva=JLRSCurva.mouse
JLRSCurva.mouse=function(c,x,y,down,up,button,...)
 -- These added buttons occupy the map-side strip; consume their clicks
 -- before the original Curva gizmo hit test can swallow them.
 if not c.followOpen and c.curvaOpen and c.curvaPage=='edit' and not c.curvaViews
  and down and button==Input.MOUSE_BUTTON_LEFT and x>=.50 and x<=.715
  and ((y>=.390 and y<=.422)or(y>=.350 and y<=.382))then
  JLRSMenu.click(c,x,y,down,button);return
 end
 if c.followOpen then c.mouseX=x;c.mouseY=y
  if c.followSuccess then if down then JLRSMenu.click(c,x,y,down,button)end;return end
  if down and x>=.735 and(button==Input.MOUSE_BUTTON_WHEEL_UP or button==Input.MOUSE_BUTTON_WHEEL_DOWN)then local list=c.followParentPicker and F.parents(c,c.followChoice)or F.items(c);c.followOffset=math.max(0,math.min(math.max(0,#list-F.ROWS),(c.followOffset or 0)+(button==Input.MOUSE_BUTTON_WHEEL_UP and -1 or 1)));return end
  if down then JLRSMenu.click(c,x,y,down,button)end;return
 end;return mouseCurva(c,x,y,down,up,button,...)
end
local closeCurva=JLRSCurva.close
JLRSCurva.close=function(c,...)F.close(c);return closeCurva(c,...)end
local saveCurva=JLRSCurva.save
JLRSCurva.save=function(c,...)local result=saveCurva(c,...);if result then F.save(c)end;return result end
local draw=JLReplayStudio.draw
local function safeTick(c,track)
 local ok,err=pcall(F.tick,c,track);c.followVehicleLookup=nil;if not ok then F.stop(c);c.followEnabled=false;c:notify('Follow One berhenti: '..tostring(err))end
end
-- Advance Follow after its leader's replay pass; never run replay work inside
-- camera polling, cut resolution, or a second zero-dt camera callback.
local replayTick=JLRSRecorder.replayTick
JLRSRecorder.replayTick=function(track,...)
 local result=replayTick(track,...);local c=JLReplayStudio;if c and c.followEnabled then safeTick(c,track)end;return result
end
JLReplayStudio.draw=function(c,...)
 local result=draw(c,...);if c.followEnabled or next(c.followStates or {})then safeTick(c)end;return result
end
local stop=JLReplayStudio.stop
JLReplayStudio.stop=function(c,...)F.stop(c);return stop(c,...)end
local stopReplay=JLRSRecorder.stopReplay
JLRSRecorder.stopReplay=function(track,...)
 track.followLeaderInterp=nil
 local c=JLReplayStudio;if c and c.followStates then local keys={};for key,state in pairs(c.followStates)do if state.rootTrack==track then keys[#keys+1]=key end end;for _,key in ipairs(keys)do F.release(c,key)end end
 return stopReplay(track,...)
end
local reset=JLRSResetVehicle.reset
JLRSResetVehicle.reset=function(c,...)F.stop(c);return reset(c,...)end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
 local result=load(c,...);c.followConfigs={};c.followNames={};c.followStates={};c.followTraces={};c.followIcons={};c.followEnabled=false;c.followLoaded=false;c.followLoadError=nil;c.followRevision=0;c.followOpen=false;return result
end
local unload=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
 F.stop(c);F.close(c);if c.followLoaded then F.save(c)end;return unload(c,...)
end
-- Snapshot before any native/History/World replay reset, not after its first
-- tick. Nested Replay All / History / startReplay calls share one snapshot.
function F.captureStarts(c)
 local out={}
 for key in pairs(c.followConfigs or {})do
  local v=F.vehicle(c,key)
  if valid(v)then
   local entries=JLRSRecorder.topology(v);local pose=JLRSRecorder.capture(entries)
   if pose then local x,y,z=getWorldTranslation(v.rootNode);local rx,ry,rz=getWorldRotation(v.rootNode);out[key]={vehicle=v,pose=pose,root={x,y,z,rx,ry,rz}}end
  end
 end
 return out
end
local function startWithSnapshot(c,call,...)
 if not c or not c.followEnabled or not c.curvaEnabled then return call(...)end
 local outer=(c.followStartDepth or 0)==0
 if outer then c.followPendingStarts=F.captureStarts(c)end
 c.followStartDepth=(c.followStartDepth or 0)+1
 local results={pcall(call,...)}
 c.followStartDepth=c.followStartDepth-1
 if outer then c.followStarts=c.followPendingStarts;c.followPendingStarts=nil end
 if not results[1]then error(results[2])end
 table.remove(results,1);return unpack(results)
end
local startReplay=JLRSRecorder.startReplay
JLRSRecorder.startReplay=function(track,...)return startWithSnapshot(JLReplayStudio,startReplay,track,...)end
local historyReplay=JLRSHistory.replay
JLRSHistory.replay=function(c,...)return startWithSnapshot(c,historyReplay,c,...)end
local replayAll=JLRSGroup.all
JLRSGroup.all=function(c,...)return startWithSnapshot(c,replayAll,c,...)end
