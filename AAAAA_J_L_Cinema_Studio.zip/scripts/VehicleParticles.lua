-- Replay particle status without invoking Wheels physics/contact updates.
JLRSVehicleParticles={params=setmetatable({},{__mode='k'}),cache=setmetatable({},{__mode='k'}),playback=setmetatable({},{__mode='k'})}
local P=JLRSVehicleParticles
local EMPTY={}
local WHITE={1,1,1}
local settings={{'setEmitCountScale','count',2},{'setParticleSystemSpeed','speed',3},{'setParticleSystemSpeedRandom','random',4}}
local function number(v,fallback) return type(v)=='number' and v==v and math.abs(v)<math.huge and v or fallback end
local function encode(k)
    if type(k)=='number' then return 'n'..k end
    return 's'..k:gsub('.',function(c)return string.format('%02x',string.byte(c))end)
end
local function decode(k)
    if k:sub(1,1)=='n' then return tonumber(k:sub(2)) end
    return (k:sub(2):gsub('%x%x',function(h)return string.char(tonumber(h,16))end))
end
function P.install()
    if not ParticleUtil then return end
    if not P.emissionHook and type(ParticleUtil.setEmittingState)=='function' then
        local original=ParticleUtil.setEmittingState
        ParticleUtil.setEmittingState=function(ps,on,...)
            local state=P.playback[ps]
            if state then on=state.on end
            local result=original(ps,on,...)
            if type(ps)=='table' and ps.geometry then
                local params=P.params[ps];if not params then params={};P.params[ps]=params end
                params.emitting=on==true
            end
            return result
        end
        P.emissionHook=true
    end
    for method,key in pairs({setEmitCountScale='count',setParticleSystemSpeed='speed',setParticleSystemSpeedRandom='random'}) do
        P.hooks=P.hooks or {}
        if not P.hooks[method] and type(ParticleUtil[method])=='function' then
            local original=ParticleUtil[method]
            ParticleUtil[method]=function(ps,value,...)
                local owned=P.playback[ps]
                if owned and owned[key]~=nil then value=owned[key] end
                local result=original(ps,value,...)
                if type(ps)=='table' and ps.geometry then
                    local state=P.params[ps];if not state then state={};P.params[ps]=state end
                    state[key]=value
                end
                return result
            end
            P.hooks[method]=true
        end
    end
end
local function valid(ps)
    return type(ps)=='table' and type(ps.geometry)=='number' and ps.geometry~=0 and
        ps.shape and entityExists(ps.shape)
end
function P.discover(v)
    P.install()
    local channels={};local seen={};local count=0;local cache={};P.cache[v]=cache
    local function visit(t,path,depth,wheel)
        if type(t)~='table' or seen[t] or depth>7 or count>=3000 then return end
        seen[t]=true;count=count+1
        if valid(t) then
            local prefix=table.concat(path,'/');cache[prefix]={ps=t,wheel=wheel}
            channels[#channels+1]={name=prefix..'/state',mode='step'}
            if t.isTintable then channels[#channels+1]={name=prefix..'/color',mode='linear'} end
            return
        end
        local keys={}
        for key,value in pairs(t) do
            if type(value)=='table' and (type(key)=='string' or type(key)=='number') then keys[#keys+1]=key end
        end
        table.sort(keys,function(a,b)return encode(a)<encode(b)end)
        for _,key in ipairs(keys) do
            path[#path+1]=encode(key);visit(t[key],path,depth+1,wheel);path[#path]=nil
        end
    end
    -- Wheel particle emitters have world-space particle geometry but local emitters.
    for i,wheel in ipairs(v.spec_wheels and v.spec_wheels.wheels or {}) do
        visit(wheel.driveGroundParticleSystems,{encode('spec_wheels'),encode('wheels'),encode(i),encode('driveGroundParticleSystems')},0,wheel)
        visit(wheel.mudSystem,{encode('spec_wheels'),encode('wheels'),encode(i),encode('mudSystem')},0,wheel)
        for j,additional in ipairs(wheel.additionalWheels or {}) do
            visit(additional.mudSystem,{encode('spec_wheels'),encode('wheels'),encode(i),encode('additionalWheels'),encode(j),encode('mudSystem')},0,additional)
        end
    end
    local roots={}
    for name in pairs(v) do
        if type(name)=='string' and name:sub(1,5)=='spec_' and name~='spec_wheels' and not name:find('instant',1,true) then roots[#roots+1]=name end
    end
    table.sort(roots)
    for _,name in ipairs(roots) do
        -- Limit discovery to explicit particle containers, never walk all vehicle state.
        local spec=v[name]
        if type(spec)=='table' then
            local keys={};for key,value in pairs(spec) do if type(key)=='string' and type(value)=='table' and key:lower():find('particle',1,true) then keys[#keys+1]=key end end
            table.sort(keys);for _,key in ipairs(keys) do visit(spec[key],{encode(name),encode(key)},0,nil) end
        end
    end
    return channels
end
function P.resolve(v,ch)
    local prefix,kind=ch._particlePrefix,ch._particleKind
    if not prefix then
        prefix,kind=ch.name:match('^(.*)/([^/]+)$');if not prefix then return end
        ch._particlePrefix,ch._particleKind=prefix,kind
    end
    local cache=P.cache[v];if not cache then cache={};P.cache[v]=cache end
    local entry=cache[prefix]
    if entry and valid(entry.ps) then return entry,kind end
    local t=v;local wheel
    for part in prefix:gmatch('[^/]+') do
        if type(t)~='table' then return end
        t=t[decode(part)]
        if type(t)=='table' and t.driveGroundParticleSystems then wheel=t end
    end
    if valid(t) then entry={ps=t,wheel=wheel};cache[prefix]=entry;return entry,kind end
end
local function fill(out,a,b,c,d,e,f)
    out[1]=a or 0;out[2]=b or 0;out[3]=c or 0;out[4]=d or 0;out[5]=e or 0;out[6]=f or 0;return out
end
function P.readInto(v,ch,out)
    local entry,kind=P.resolve(v,ch);if not entry then return fill(out,0,0,0,0,0,0) end
    local ps=entry.ps
    if kind=='color' then local color=ps.currentColor or (entry.wheel and entry.wheel.lastColor) or WHITE;return fill(out,color[1],color[2],color[3],0,0,0) end
    local params=P.params[ps] or EMPTY;local yaw=0
    if ps.emitterShape and entityExists(ps.emitterShape) then local rx;rx,yaw=getRotation(ps.emitterShape) end
    local emitting=params.emitting
    if emitting==nil then emitting=ps.isEmitting==true or ps.emittingState==true or ps.isActive==true end
    return fill(out,emitting and 1 or 0,number(params.count,number(ps.emitCountScale,1)),
        number(params.speed,number(ps.particleSpeed,0)),number(params.random,number(ps.particleRandomSpeed,0)),yaw,0)
end
function P.read(v,ch)return P.readInto(v,ch,{})end

function P.write(v,ch,values,paused,restoring)
    local entry,kind=P.resolve(v,ch);if not entry or not ParticleUtil then return end
    local ps=entry.ps
    if kind=='color' then
        local color=ps.currentColor
        if not color or color[1]~=values[1] or color[2]~=values[2] or color[3]~=values[3] then
            ps.currentColor={values[1],values[2],values[3]}
            if I3DUtil and I3DUtil.setShaderParameterRec then I3DUtil.setShaderParameterRec(ps.shape,'colorAlpha',values[1],values[2],values[3],1,false) end
        end
        return
    end
    if restoring then P.playback[ps]=nil end
    local on=values[1]>=0.5 and (not paused or restoring)
    if not restoring then
        local state=P.playback[ps];if not state then state={};P.playback[ps]=state end
        state.on=on;state.count=values[2];state.speed=values[3];state.random=values[4]
    end
    local params=P.params[ps] or EMPTY
    for _,setting in ipairs(settings) do
        if params[setting[2]]~=values[setting[3]] and ParticleUtil[setting[1]] then ParticleUtil[setting[1]](ps,values[setting[3]]) end
    end
    local emitting=params.emitting
    if emitting==nil then emitting=ps.isEmitting==true or ps.emittingState==true end
    if emitting~=on and ParticleUtil.setEmittingState then ParticleUtil.setEmittingState(ps,on) end
    local emitter=ps.emitterShape
    -- Inactive systems still receive every recorded state/parameter update.
    -- Wheel geometry is needed only by emitters that actually emit this pass.
    if not restoring and on and emitter and entityExists(emitter) then
        local wheel=entry.wheel
        local isMud=wheel and wheel.mudSystem and wheel.mudSystem.mudPS==ps
        local source=wheel and ((isMud and wheel.wheelTire) or wheel.driveNode)
        if source and not entityExists(source) then source=wheel and wheel.driveNode end
        if source and entityExists(source) then
            local offsets=ps.offsets
            local ox=offsets and offsets[1] or (isMud and wheel.xOffset) or 0
            local oy=offsets and offsets[2] or 0;local oz=offsets and offsets[3] or 0
            local x,y,z=worldToLocal(getParent(emitter),getWorldTranslation(source))
            setTranslation(emitter,x+ox,y+oy,z+oz)
            setRotation(emitter,0,values[5],0)
        end
    elseif restoring and emitter and entityExists(emitter) then
        local rx,ry,rz=getRotation(emitter);setRotation(emitter,rx,values[5],rz)
    end
end
JLRSActivities.registerAdapter('jlrsVehicleParticles',{discover=P.discover,read=P.read,readInto=P.readInto,write=P.write})
P.install()
local deleteMap=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    local result=deleteMap(c,...)
    P.cache=setmetatable({},{__mode='k'});P.params=setmetatable({},{__mode='k'});P.playback=setmetatable({},{__mode='k'})
    return result
end
