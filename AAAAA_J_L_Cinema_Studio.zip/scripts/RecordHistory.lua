-- Independent snapshots keep their frame arrays and topology references.
-- No pose data is copied or overwritten when the next recording starts.
JLRSHistory={PAGE_SIZE=8}
function JLRSHistory.archive(c)
    if not c.history or not c.frames or JLRSFrames.count(c.frames)==0 then return end
    for _,clip in ipairs(c.history) do if clip.frames==c.frames then return end end
    c.historyNextId=c.historyNextId+1
    local clip={id=c.historyNextId,frames=c.frames,entries=c.entries,
        vehicles=c.recordVehicles,target=c.target,duration=c.duration,
        name=JLRSRecorder.valid(c.target) and c.target:getName() or 'Kendaraan',
        clock=(g_time or 0)/1000}
    c.history[#c.history+1]=clip;c.historySelected=clip.id
    c:notify(string.format('Record #%03d tersimpan di History | %.2fs',clip.id,clip.duration))
end
function JLRSHistory.valid(clip)
    return JLRSFrames.count(clip.frames)>=2 and JLRSRecorder.valid(clip.target)
        and JLRSRecorder.capture(clip.entries)~=nil
end
function JLRSHistory.replay(c,clip)
    if not JLRSHistory.valid(clip) then c:notify('Record tidak tersedia: kendaraan/node berubah atau record terlalu pendek.');return end
    if c.recording then JLRSRecorder.stopRecord(c) end
    if c.replaying then JLRSRecorder.stopReplay(c) end
    c.target=clip.target;c.entries=clip.entries;c.recordVehicles=clip.vehicles
    c.frames=clip.frames;c.duration=clip.duration;c.recordTime=clip.duration
    c.replayTime=0;c.frameIndex=1;c.historySelected=clip.id
    JLRSRecorder.startReplay(c)
    if c.replaying then JLRSHistory.close(c);c.menu=false;JLRSMouse.refresh(c) end
end
function JLRSHistory.mark(c,clip)
    c.historyMarked=c.historyMarked or {}
    c.historyMarked[clip.id]=not c.historyMarked[clip.id] or nil
end
function JLRSHistory.markedCount(c)
    local count=0
    for _,clip in ipairs(c.history or {}) do
        if c.historyMarked and c.historyMarked[clip.id] then count=count+1 end
    end
    return count
end
function JLRSHistory.replayMarked(c)
    if JLRSHistory.markedCount(c)==0 then c:notify('Tandai record dengan centang sebelum Replay.');return end
    -- Copy only selection flags. Original History and frame storage remain intact.
    local selection={}
    for id,marked in pairs(c.historyMarked or {}) do if marked then selection[id]=true end end
    return JLRSGroup.all(c,selection)
end
function JLRSHistory.delete(c,clip)
    if c.frames==clip.frames then
        if c.replaying then c:stop() end
        c.frames={};c.duration=0;c.replayTime=0;c.recordTime=0;c.historySelected=nil
    end
    if c.historyMarked then c.historyMarked[clip.id]=nil end
    for i,item in ipairs(c.history) do
        if item==clip then table.remove(c.history,i);break end
    end
    c.historyPage=math.min(c.historyPage,math.max(1,math.ceil(#c.history/JLRSHistory.PAGE_SIZE)))
    c:notify(string.format('Record #%03d dihapus',clip.id))
end
function JLRSHistory.open(c)
    c.historyReturnMenu=c.menu;c.historyOpen=true;c.menu=true
    c.historyPage=c.historyPage or 1;c.hitboxes={}
    if g_inputBinding then g_inputBinding:setShowMouseCursor(true) end
    JLRSMouse.refresh(c)
end
function JLRSHistory.close(c)
    c.historyOpen=false;c.menu=c.historyReturnMenu or false;c.hitboxes={}
    if g_inputBinding then g_inputBinding:setShowMouseCursor(c.menu) end
    JLRSMouse.refresh(c)
end
function JLRSHistory.draw(c)
    if not c.overlay then return end
    c.hitboxes={}
    JLRSMenu.rect(c,0.19,0.13,0.62,0.74,0.015,0.023,0.037,0.98)
    JLRSMenu.rect(c,0.19,0.79,0.62,0.08,0.025,0.16,0.23)
    JLRSMenu.text(0.21,0.825,0.025,'J_L Cinema Studio | History',0.95,1,1)
    JLRSMenu.text(0.21,0.802,0.011,'History tersimpan per savegame | Record baru tidak menimpa')
    JLRSMenu.button(c,0.755,0.808,0.035,0.038,'X',function() JLRSHistory.close(c) end)
    JLRSMenu.button(c,0.21,0.257,0.24,0.030,'REPLAY CHECKED ('..JLRSHistory.markedCount(c)..')',function() JLRSHistory.replayMarked(c) end)
    JLRSMenu.button(c,0.47,0.257,0.315,0.030,c.preciseReplay and 'REPLAY PRESISI' or ('PHYSICS '..(c.physicsReplay and 'ON' or 'OFF')),function() JLRSCollision.toggle(c) end,c.physicsReplay)
    JLRSMenu.button(c,0.64,0.808,0.10,0.038,'SAVE',function() JLRSManualSave.save(c,false) end)
    local pages=math.max(1,math.ceil(#c.history/JLRSHistory.PAGE_SIZE))
    c.historyPage=math.min(c.historyPage,pages)
    JLRSMenu.text(0.21,0.76,0.013,string.format('%d record | Halaman %d / %d',#c.history,c.historyPage,pages),0.1,0.88,0.90)
    JLRSMenu.button(c,0.545,0.749,0.24,0.033,'REPLAY ALL VEHICLE',function() JLRSGroup.all(c) end)
    if #c.history==0 then JLRSMenu.text(0.21,0.66,0.016,'Belum ada hasil Record. Mulai Record melalui HUD.') end
    for row=1,JLRSHistory.PAGE_SIZE do
        local index=(c.historyPage-1)*JLRSHistory.PAGE_SIZE+row
        local clip=c.history[index]
        if clip then
            local y=0.692-(row-1)*0.057
            JLRSMenu.rect(c,0.205,y-0.006,0.59,0.050,0.05,0.075,0.105)
            local checked=c.historyMarked and c.historyMarked[clip.id]
            JLRSMenu.button(c,0.215,y,0.032,0.033,'',function() JLRSHistory.mark(c,clip) end,checked)
            if checked then
                -- Draw the check in geometry; no dependency on Unicode font glyphs.
                for step=0,3 do JLRSMenu.rect(c,0.222+step*0.0018,y+0.016-step*0.0018,0.003,0.003,0.2,1,0.65,1) end
                for step=0,7 do JLRSMenu.rect(c,0.227+step*0.0014,y+0.010+step*0.0018,0.003,0.003,0.2,1,0.65,1) end
            end
            local label=string.format('#%03d  %s',clip.id,clip.name)
            if #label>32 then label=label:sub(1,29)..'...' end
            JLRSMenu.text(0.255,y+0.021,0.013,label)
            JLRSMenu.text(0.255,y+0.002,0.011,string.format('%.2fs | %d frames | %s',clip.duration,JLRSFrames.count(clip.frames),
                JLRSHistory.valid(clip) and 'READY' or 'TIDAK TERSEDIA'),0.65,0.74,0.83)
            JLRSMenu.button(c,0.600,y,0.085,0.033,'REPLAY',function() JLRSHistory.replay(c,clip) end,c.historySelected==clip.id)
            JLRSMenu.button(c,0.700,y,0.085,0.033,'DELETE',function() JLRSHistory.delete(c,clip) end,false,{0.48,0.07,0.13})
        end
    end
    JLRSMenu.button(c,0.21,0.21,0.12,0.036,'< PREV',function() c.historyPage=math.max(1,c.historyPage-1) end)
    JLRSMenu.button(c,0.34,0.21,0.12,0.036,'NEXT >',function() c.historyPage=math.min(pages,c.historyPage+1) end)
    JLRSMenu.button(c,0.47,0.21,0.08,0.036,'CAMERA',function() JLRSGroup.camera(c) end,c.groupCamera)
    JLRSMenu.button(c,0.56,0.21,0.08,0.036,'NEXT CAR',function() JLRSGroup.next(c) end)
    JLRSMenu.button(c,0.65,0.21,0.135,0.036,'CLOSE',function() JLRSHistory.close(c) end)
    JLRSMenu.text(0.21,0.179,0.011,'Centang record lalu REPLAY CHECKED. Satu take terbaru per kendaraan.')
    JLRSMenu.text(0.21,0.151,0.011,(c.notice or ''):sub(1,90),1,0.75,0.35)
    JLRSMenu.text(0.21,0.134,0.009,'©Copyright 2023 | Jupryan Lowlight',0.65,0.74,0.83)
    setTextColor(1,1,1,1);setTextAlignment(RenderText.ALIGN_LEFT)
end
local oldLoad=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)
    oldLoad(c,...)
    if not c.mission then return end
    c.historyMarked={};c.history={};c.historyNextId=0;c.historyPage=1;c.historyOpen=false
end
local oldStopRecord=JLRSRecorder.stopRecord
JLRSRecorder.stopRecord=function(c,...)
    local was=c.recording
    oldStopRecord(c,...)
    if was then JLRSHistory.archive(c) end
end
local oldStart=JLRSRecorder.start
JLRSRecorder.start=function(c,...)
    if c.recording then JLRSRecorder.stopRecord(c) end
    -- Preserve an unsaved clip, e.g. one produced before this module initialized.
    if c.frames and JLRSFrames.count(c.frames)>1 then JLRSHistory.archive(c) end
    return oldStart(c,...)
end
local oldDraw=JLRSMenu.draw
JLRSMenu.draw=function(c,...)
    if c.historyOpen and c.menu then return JLRSHistory.draw(c) end
    if c.historyOpen then c.historyOpen=false end
    return oldDraw(c,...)
end
local oldToggle=JLRSMenu.toggle
JLRSMenu.toggle=function(c,...)
    if c.historyOpen then return JLRSHistory.close(c) end
    return oldToggle(c,...)
end
local oldDelete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    oldDelete(c,...)
    c.historyMarked=nil;c.history={};c.historyOpen=false
end
