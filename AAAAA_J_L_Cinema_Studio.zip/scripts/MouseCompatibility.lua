-- Late camera bridge: AGS smoothing intentionally bypasses superFunc when active.
-- During cinematic control, consume raw input here instead of native camera updates.
JLRSMouseCompatibility={hooks={}}
local M=JLRSMouseCompatibility
function M.queue(c,axis,value,source)
    if not c.active or c.finalPlaying or c.menu or (g_gui and g_gui:getIsGuiVisible())then return end
    local pending=c.compatMouse or {};c.compatMouse=pending
    local channel=pending[axis]or {};pending[axis]=channel
    channel[source]=(channel[source]or 0)+value
end
JLRSMouse.onAxis=function(target,action,value,state,isAnalog,isMouse)
    if isMouse and value~=0 then M.queue(target.controller,state,value,'own')end
end
function M.flush(c)
    local pending=c.compatMouse;c.compatMouse=nil
    for _,axis in ipairs({'X','Y'})do
        local channel=pending and pending[axis]
        if channel then
            -- Own and native bindings can both deliver the same motion. Use one source.
            JLRSCamera.mouseAxis(c,axis,channel.own or channel.native or 0)
        end
    end
end
function M.install(c)
    local candidates={{VehicleCamera,'actionEventLookLeftRight','X',true},{VehicleCamera,'actionEventLookUpDown','Y',true},
        {Player,'onInputLookLeftRight','X',false},{Player,'onInputLookUpDown','Y',false}}
    for index,item in ipairs(candidates)do
        local owner,name,axis,vehicle=item[1],item[2],item[3],item[4]
        local existing=M.hooks[index]
        if owner and type(owner[name])=='function'and(not existing or owner[name]~=existing.wrapper)then
            local original=owner[name]
            local wrapper=function(object,action,value,state,analog,mouse,...)
                local studio=JLReplayStudio;local mission=g_currentMission
                local controlled=mission and mission.controlledVehicle
                local matches=vehicle and controlled and object.vehicle==controlled or not vehicle and mission and object==mission.player
                if studio and matches and JLRSMouse.hudOwns and JLRSMouse.hudOwns(studio)then return end
                if studio and studio.active and matches then
                    if mouse then M.queue(studio,axis,value,'native')end
                    return
                end
                return original(object,action,value,state,analog,mouse,...)
            end
            owner[name]=wrapper;M.hooks[index]={owner=owner,name=name,original=original,wrapper=wrapper}
            -- Vehicle callbacks may already have been registered before the late hook.
            for _,event in pairs(g_inputBinding and g_inputBinding.events or {})do
                if type(event)=='table'then for _,key in ipairs({'callback','eventCallback'})do
                    local callback=event[key];local raw=JLRSInputGuard.wrapped[callback]or callback
                    if raw==original then event[key]=JLRSInputGuard.wrap(wrapper)end
                end end
            end
        end
    end
end
local refresh=JLRSMouse.refresh
JLRSMouse.refresh=function(c,...)M.install(c);return refresh(c,...)end
local tick=JLRSCamera.tick
JLRSCamera.tick=function(c,...)if not c.objectRunning or c.objectTick then M.flush(c)end;return tick(c,...)end
local disable=JLRSMouse.disable
JLRSMouse.disable=function(c,...)c.compatMouse=nil;return disable(c,...)end
local load=JLReplayStudio.loadMap
JLReplayStudio.loadMap=function(c,...)local result=load(c,...);M.install(c);return result end
local delete=JLReplayStudio.deleteMap
JLReplayStudio.deleteMap=function(c,...)
    c.compatMouse=nil
    for _,hook in pairs(M.hooks)do
        if hook.owner[hook.name]==hook.wrapper then hook.owner[hook.name]=hook.original end
        for _,event in pairs(g_inputBinding and g_inputBinding.events or {})do
            if type(event)=='table'then for _,key in ipairs({'callback','eventCallback'})do
                local callback=event[key];local raw=JLRSInputGuard.wrapped[callback]or callback
                if raw==hook.wrapper then event[key]=JLRSInputGuard.wrap(hook.original)end
            end end
        end
    end
    M.hooks={};return delete(c,...)
end
